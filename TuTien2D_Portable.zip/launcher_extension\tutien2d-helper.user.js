// ==UserScript==
// @name         Tu Tiên 2D - Trợ thủ
// @namespace    tutien2d-helper
// @version      0.63.21
// @description  Tự chiến, thiền hồi máu, hồi sinh, Tranh Đoạt Linh Thụ, Trấn Mạch, Báo cáo Telegram, Xuất/Nhập cấu hình, Giám sát mạng & bản vá game, giữ bãi farm & tự đổi lại đúng khu cũ sau khi săn Boss, tối đa sát thương Boss thế giới (khô máu dồn DPS), bắt trọn 100% gói tin máy chủ (WebSocket/Gateway), tự động săn Yêu Thú Xổng Chuồng (Bãi Đá, Thung Lũng...), sửa kẹt tiến trình cướp tiêu, chủ động áp sát tâm chạm quái <= 2px ngay từ 100% HP tranh Last Hit và nhặt đồ rơi Yêu thú xổng chuồng / Boss, tối ưu Auto Trận Bàn tự kích hoạt khi Săn Boss World, Thương Đội và Thú Xổng Chuồng, chặn triệt để dùng Trận Bàn (Tụ Linh Trận & Sát thương) khi farm quái thường (Thạch Quy, Xuyên Sơn Giáp, gom quái...), cải tiến Vết Nứt Không Gian (chạy thẳng tới cửa khi mở, cấm thiền), Cảm biến Thiên Lao & Kill-switch Chống Ban (ngắt khẩn cấp toàn bộ auto khi bị phạt tù Thiên Lao / Bát Quái Thạch Bàn), Đón đầu Thạch Quỷ biến dị trước 20s theo thông báo toàn khu, Cập nhật trọn bộ hệ tu Nho Tu / Huyết Tu & 15 bí tịch, 10 vũ khí mới, Tam Yêu Linh Bội chốt hạ 3 Boss TG, Khô máu dồn DPS Thú Xổng & Thương Đội khắc chế hồi máu 100 người, Tối ưu sinh tồn từ phân tích Log (chống vòng lặp hồi sinh tự sát Boss & PK Cướp tiêu, khắc phục cạn MP 1% xe tiêu, chặn lao cận chiến tự sát máu < 35%, bảo toàn mạng Boss Capped, cấm thiền dưới chân Boss Bí Cảnh), Tối ưu chuyên sâu Sỹ Sách Điện / Hư Thiên Điện. Tab Dev (tốc độ) luôn được mở.
// @match        https://tutien2d.com/*
// @match        https://www.tutien2d.com/*
// @match        https://tutien2d.online/*
// @match        http://localhost/*
// @match        http://localhost:*/*
// @match        http://127.0.0.1/*
// @match        http://127.0.0.1:*/*
// @run-at       document-start
// @grant        GM_xmlhttpRequest
// @grant        unsafeWindow
// @connect      api.telegram.org
// ==/UserScript==

// Chỉ đi qua đúng các đường nút bấm / phím của game dùng (Input, Hotbar, Pathfinder, Gateway…). Phím ` hoặc F8 ẩn/hiện bảng.
(function (window) {
  'use strict';

  var VERSION = '0.63.21'; // giữ trùng @version ở đầu file
  var STORE_KEY = 'ttbot.settings.v1';
  var DEFAULTS = {
    keepAuto: true,      // tự bật lại Tự Động nếu bị tắt
    dodge: true,         // đi ra khỏi vùng chiêu của địch khi thấy cảnh báo
    dodgeMargin: 30,     // px đứng cách mép vùng chiêu
    dodgePlayers: true,  // né cả chiêu người chơi khác (bỏ qua chiêu họ đánh quái)
    kite: true,          // hit & run: quái sắp chém lại thì lùi ra ngoài tầm với của nó
    kiteGap: 12,         // px đứng ngoài tầm với của quái
    keepDist: 0,         // px giữ cách mục tiêu đang đánh (0 = tự tính theo tầm chiêu / tầm địch)
    kiteOut: 300,        // ms đứng ngoài sau mỗi đòn / chiêu của mình rồi mới áp vào lại
    healEarly: true,     // tính máu đang mất mỗi giây, rút đi thiền sớm cho kịp tới chỗ an toàn
    autoShield: true,    // đang mất máu mà máu < shieldHp% thì dùng Kim Long (nếu dùng được) / Kim Giáp
    shieldHp: 35,
    autoMpTal: true,     // đang đánh mà linh lực < 15% thì dùng Thanh Tâm Phù
    autoHaste: true,     // chạy ra chỗ thiền / né xa thì dùng Tốc Hành Phù
    autoDash: true,      // bị trói chân, hoặc né chiêu mà chạy không kịp thì dùng Thổ Độn Phù lướt theo đường thoát
    autoKhoiLoi: true,   // đang đánh thì tự triệu hồi Khôi Lỗi / Thi Khôi (cần Trúc Cơ, có trong túi)
    khoiLoiPref: 'auto', // auto | dps (ra đòn nặng) | tank (chịu đòn)
    bossFocus: true,     // có boss gần thì nhắm boss (để đủ ngưỡng nhận đồ)
    lastHitBoss: true,   // giữ chiêu mạnh nhất để kết liễu boss
    lastHitDouble: true, // tính ngưỡng theo hai chiêu mạnh nhất (tung chiêu nhì trước, chiêu nhất kết liễu)
    lastHitScan: true,   // tự động quét & chuyển mục tiêu sang Boss / Xổng chuồng sắp chết để cướp Last Hit
    autoHpMargin: true,  // hệ số an toàn ngưỡng last-hit tự tính theo máu boss tụt / người quanh boss
    hpMarginPct: 110,    // hệ số đặt tay (%) khi tắt tự tính
    bossRadar: true,     // hỏi lịch boss toàn máy chủ (như bảng Hoạt Động) mỗi 30 giây
    honRun: false,       // Hồn Phiên: tự làm (cần đã có Hồn Phiên)
    honFarm: true,       // săn người phàm lấy Phàm / Oán Hồn cho con Âm Hồn kế tiếp
    honLuyen: true,      // Pháp bảo phe phái (Hồn Phiên / Kiếm Hạp / Thiết Hoàn / Loan Kết): đủ nguyên liệu thì tự luyện con kế tiếp
    honSummon: false,    // [Legacy] Game đã tự động gọi Âm Hồn / Kiếm Linh khi bật Tự Động, bot không gửi lệnh thủ công để tránh lỗi máy chủ
    honAllowRed: false,  // cho săn quá mốc tên đỏ (như kẻ đồ sát — người khác được giết mình)
    honCung: false,      // chạm mốc nghiệp thì tới Ông Từ Giữ Miếu cúng gột (500 Linh Thạch/điểm)
    honFocus: true,      // tập trung săn: bỏ farm, khu hết người phàm thì đổi khu ngay, xong mới về farm
    honSell: false,      // săn thêm hồn để bán chợ (ngoài phần cần cho con Âm Hồn kế tiếp)
    honSellPham: 300,    // giữ dư chừng này Phàm Hồn để bán (0 = không săn thêm)
    honSellOan: 60,      // giữ dư chừng này Oán Hồn để bán (0 = không săn thêm; Oán Hồn chỉ có từ Thương Đội)
    bossNoSit: true,     // đang đánh boss thế giới thì không ngồi thiền (đồ chia theo sát thương)
    bossBurst: true,     // đánh boss (mọi loại): chiêu nào hồi xong là tung ngay, không chờ auto của game
    autoTran: true,      // tự dựng trận bàn khi đánh (Liệt Hỏa, Tụ Linh, Loạn Lôi Hỏa, Tứ Tượng, Đạo Gia, Ma Đạo)
    tranOnlyBossTd: true, // chỉ sử dụng trận bàn khi: Săn Boss World, Thương Đội hoặc Thú Xổng Chuồng (tránh hao phí Linh Thạch ở hoạt động khác)
    tran_liet_hoa: true, tran_tu_linh: true, tran_loan_loi_hoa: true, tran_tu_tuong: true, tran_dao_gia: true, tran_ma_dao: true,
    tranMp: 50,          // % linh lực dưới mức này (đang đánh) thì dựng Tụ Linh Trận
    tranMobs: 3,         // trận sát thương: boss thì luôn dựng, quái thường cần ít nhất chừng này con trong vòng trận
    scanMode: 'map',     // tìm mục tiêu (người phàm, biến dị, xổng chuồng, Thương Đội, boss): map = dò kín toàn bộ map | spawn = chỉ quanh chỗ sinh
    bossAllSkills: true, // chọn chiêu trong mọi chiêu sát thương đã học, kể cả chiêu chưa tick Tự Động
    prioOpt: true,       // tới giờ boss / vào hoạt động: tạm bật bộ cài đặt tối ưu cho việc đó, xong trả lại như cũ
    prioVt: false,       // giao tiêu xong mới đi việc khác (không bỏ rơi xe dở dang)
    vtAutoTrigger: true, // tự động vận tiêu khi chạm mốc giờ hẹn (mặc định 13h)
    vtScheduleHour: 13,  // mốc giờ hẹn tự chạy vận tiêu (11..21h)
    vtQuietKhu: true,    // tự đổi sang Khu vắng nhất trước khi nhận tiêu để tránh 100% bị cướp
    vtGuardCart: true,   // hộ tiêu: diệt quái cắn xe và dừng lại chờ xe hồi đầy máu an toàn
    vtSafePortal: true,  // chờ xe sát cổng (<= 80px) mới bước qua cổng sang map mới
    bossHunt: false,     // tự đi đánh boss thế giới theo giờ, xong về chỗ farm
    bdHunt: false,       // Thiên Đạo báo quái biến dị xuất hiện → tới map, dò khu, đánh, xong về chỗ farm
    tlRun: false,        // Tam Lộ Tranh Phong (tối Thứ Tư): tự ghi danh, chấp nhận trận, đi đường, núp sau lính, tránh trụ địch
    ltRun: false,        // Tranh Đoạt Linh Thụ (tối Thứ Ba · Thứ Bảy): tự ghi danh, vào sân, giữ cây, nối rễ, Thụ Tâm
    tlLane: 'a',         // đường: a Tự chọn (đường cần người nhất) · 0 Thượng · 1 Trung · 2 Hạ
    tlJungle: false,     // đi rừng: dọn bãi rừng phe mình, hỗ trợ đường, gom Rồng / Baron
    tlBackHp: 35,        // % máu: về suối hồi máu (đứng an toàn thì về thành)
    xcHunt: true,        // Thiên Đạo báo yêu thú xổng chuồng (Xích Nhãn Ngưu, Bạch Hổ Tuyết…) ở map + khu → tới đánh, giành đòn kết liễu
    tdHunt: false,       // Thiên Đạo báo Thương Đội → săn Tiêu Sư / Thương Nhân lấy Oán Hồn (khi Hồn Phiên cần)
    bossMaxDmg: true,    // đánh boss thế giới: dồn sát thương tối đa (không lùi, hạ hộ vệ khi cần, bùa sát thương)
    planRun: false,      // lịch treo máy: làm lần lượt các việc được chọn, xong hết thì về farm
    hlRun: true,         // vào Chiến Trường thì tự hái Vạn Hoang Huyết Lan (khóm trong bo, đứng yên 2 giây)
    planOrder: [],       // thứ tự việc trong lịch (kéo thả ở tab Lịch); trống = thứ tự mặc định
    plan_hauky36: true,  // Giai đoạn 36: hạ Thạch Quy biến dị + gom Mảnh Bia / Quy Đan (chỉ chạy khi đang ở giai đoạn đó)
    plan_diemdanh: true, plan_gacha: true, plan_sect: true, plan_dc: true, plan_vt: false, plan_hon: false, plan_farmcare: true, plan_gather: false, plan_fish: false,
    btAuto: false,       // bộ bí tịch: tự đổi bộ (8 chiêu trên thanh + 5 bị động) theo việc đang làm: boss / farm / PK / tổ đội
    autoHoaThan: true,   // tự động kích hoạt Bí tịch Hóa Thân (Kim Cương Hóa Thân / Xích Ma Hóa Thân / Bàn Thạch Hộ Thể) khi săn Boss, PK hoặc máu <= 50%
    speed125: true,      // luôn duy trì tốc độ di chuyển 1.25x
    runLoot: true,       // chạy nhặt đồ rơi ngay: quái vừa rớt là chạy lại nhặt (kể cả đồ của mình, kể cả lúc đang đánh)
    fpsUnlock: true,     // mở khoá FPS: gỡ ép 30 FPS khi treo máy / đông người, ép 10 FPS khi tiết kiệm pin
    fpsTarget: '120',    // '120' · '60' · '30' (nhẹ máy khi treo nhiều nhân vật) · '0' = tối đa theo màn hình
    antiAutoDowngrade: true, // chống game tự hạ đồ hoạ khi giật
    hideRemoteSkills: true,  // ẩn chiêu của người chơi khác (vẫn hiện chiêu + vòng đỏ của boss)
    hideImpactFx: true,  // tắt hiệu ứng chém trúng của người khác, chống dồn âm thanh
    hideDamage: 'remote', // số sát thương nhảy: remote = chỉ của mình · throttle = giảm tải · all = ẩn hết · off = hiện hết
    hideWeatherFx: true, // tắt thời tiết / hiệu ứng môi trường map
    playerVis: 'default', // hiện người chơi khác: default = theo game · none · party · all
    ctRun: false,        // tổ đội cướp tiêu: cắm cờ vàng, camp Thung Lũng, gặp xe nào cũng cướp; cướp được thì kéo về Thăng Long, đồng đội hộ tống
    ctCap: true,         // chỉ đi cướp khi đã đủ trần Linh Thạch ngày (thưởng giao xe không tính vào trần)
    ctKhu: 0,
    ctH_trang: true, ctH_luc: true, ctH_do: true, ctH_vang: true, // loại xe sẽ cướp (Tiêu Kỳ Trắng / Lục / Đỏ / Vàng)
    ctFlag: 'vang',      // màu cờ tổ đội (nhóm trưởng chọn; thành viên tự cắm theo màu nhóm trưởng): vang · lam · luc · den
    ctCampMap: '', ctCampPos: 'dau', // chỗ chờ xe: '' = tự tính theo số người; hoặc map trên tuyến + đầu / giữa / cuối đường xe trong map đó
    teamOn: false,       // tổ đội trợ thủ: các nhân vật trong teamNames tự lập tổ đội và phối hợp (Vết Nứt: chia 3 trụ ấn…)
    teamNames: '',       // tên các nhân vật cùng dùng trợ thủ, cách nhau dấu phẩy; người đầu danh sách làm đội trưởng
    vnRun: false,        // Vết Nứt Không Gian: tự tới vết nứt, vào mê cung, mở đường tới Hòm, nhặt đồ
    vnBuy: true,         // tự mua Hư Không Lệnh (vé) ở Hồng Tỷ khi hết vé
    vnTicketKeep: 1,     // giữ sẵn chừng này vé
    vnHomHold: true,
    hxRun: false,        // Huyết Xích Cấm Địa: tự đăng ký ở nữ tu Miếu Hoang, quét 3 tầng, hạ boss, hái hết tài nguyên
    hxLeave: true,       // xong 3 tầng thì rời bí cảnh luôn (để đi lượt kế), không chờ hết 15 phút
    hxKeep: 0,           // giữ lại ít nhất ngần này Linh Thạch (phí 100/lượt)
    ylRun: false,        // Yên Lãng Sơn: tự đăng ký / vào lại, nghe lệnh núi, đổ bia, hái linh thảo, đánh Tộc Trưởng
    plan_hx: false, plan_yl: false,     // đang cầm đồ Hòm thì đứng xa người lạ trong Phòng Hòm cho đủ 20 giây
    fishRun: false,      // tự câu cá săn Linh Ngư (Tự động câu của game ở Hồ Bích Thủy / Suối Dược Cốc)
    fishGoal: 20,        // câu tới khi túi có chừng này Linh Ngư (0 = câu mãi)
    fishSpot: '',        // chỗ câu: '' = tự chọn | ho_bich_thuy_cong | suoi_duoc_coc
    planGatherMin: 20,   // phút nhặt nguyên liệu mỗi lượt trong lịch
    snRun: false,        // nhiệm vụ tông môn ngoài lịch
    sn_chat_cay: true, sn_linh_chi: true, sn_phong_linh: true, sn_tinh_thach: false, sn_ca_linh_thu: false, sn_yeu_cot: false,
    sn_tru_yeu: false, sn_huyen_thiet: false, sn_yeu_dan: false, sn_pha_canh: false, sn_to_doi_huyet_sac: false,
    vtRun: false,        // Vận Tiêu ngoài lịch (tới khi hết lượt)
    tmTru: false,        // Đánh Trụ Trấn Mạch (Mỏ Linh Thạch): chỉ bật khi tông chiếm mạch cờ Đỏ, tắt để né lao vào trụ nổ
    llRun: false,        // Bí Cảnh Lãm Làng: tông mở lượt thì tự vào, làm hai tuyến, đánh Tà Soái
    llThe: 'kiem',       // Thệ Nguyện: kiem (+15% sát thương) | xuan (hồi máu) | menh (gục mất nửa Tông Mệnh)
    llTuyen: 'auto',     // tuyến làm trước: auto (nhiều trợ thủ tự chia nhau) | lao (Cổng Đông, cứu phàm dân) | tru (Đài Đá, phá trụ)
    htRun: false,        // Sỹ Sách Điện (tối Thứ Năm): tự tới Thủ Điện, vào điện, qua các ải, đánh Sỹ Sách Đỉnh
    htMatThat: true,     // Ải 2 có vòng xoáy tím thì vào Mật Thất đánh Lôi Thú
    bossLead: 60,        // giây: boss sắp ra trong chừng này thì lên đường
    bh_than_thu_xich_long: true, bh_linh_ho_tran_son: true, bh_song_duc_ma_bao: true,
    reFly: true,         // đang bay mà phải thiền (game tự hạ cánh) thì thiền xong bay lại
    alwaysFly: false,    // luôn bay, trừ lúc thiền (và lúc câu cá / chặt cây / vận thu)
    autoLoot: true,      // tự đi nhặt đồ rơi không chủ (bí cảnh, quái rơi chung)
    lootRadius: 260,     // px quanh mình tìm đồ để nhặt
    lootSweep: true,     // nhiều món thì chạy một đường qua tất cả, không dừng từng món
    smartPriority: true, // nhặt món phẩm cấp cao trước (Thiên > Địa > Linh > Phàm)
    lootOnly: '',        // chỉ nhặt các món này (mã hoặc một phần tên, cách nhau dấu phẩy); trống = nhặt hết
    farmAuto: false,     // vườn có việc (chín / trống có hạt / khô có nước) thì tự đi chăm rồi về
    dcRun: false,        // tự chạy việc Dược Công hằng ngày
    dhRun: false, dhAll: false, // Đại Hội Tu Tiên: tự ghi danh + đánh (mặc định chỉ khi hôm nay chưa vào đài / có việc Dược Công)
    dcReturn: null,      // {map, x, y}: chỗ đứng lúc bật Dược Công, làm xong thì về đây farm tiếp
    gatherRun: false,    // đi nhặt nguyên liệu chế tạo (mạch khoáng, linh thảo), hết thì đổi khu / đổi map
    gatherGoal: 0,       // dừng khi mỗi loại đủ chừng này (0 = nhặt mãi)
    gatherFightOn: false, // lúc đi nhặt có quái đuổi sát thì đánh (mặc định tắt: chỉ nhặt, né chiêu / thiền lo an toàn)
    farmKhu: false,      // đang tự đánh thì tìm khu ít người nhất, sang đó đánh
    splashPos: true,     // vũ khí đánh lan: chọn chỗ đứng trúng nhiều con nhất (tầm lan tự đo)
    splashManual: 0,     // tầm lan đặt tay (px); 0 = tự đo
    splashLearn2: null,  // số đo tầm lan theo vũ khí (tự ghi)
    farmKhuAuto: false,  // cứ farmKhuMin phút tự chạy ra Bảng Khu xem, có khu vắng hơn thì sang
    farmKhuMin: 3,       // phút giữa hai lần xem số người các khu
    ga_mach_han_tinh: true, ga_mach_tu_tinh: true, ga_mach_luc_tinh: true, ga_phong_tinh_mach: true,
    ga_phong_linh_thao: true, ga_ling_chi_prop: true,
    dc_duoc_moc: true, dc_cau_ca: true, dc_ho_tong_chau: true, dc_truc_gia: true, dc_linh_chi: true,
    harvest: true,       // bí cảnh: tự tới điểm tài nguyên (Huyết Xích, linh thảo Yên Lãng) vận thu 3s
    smartTarget: true,   // ưu tiên "Gần nhất": chọn con có lời nhất thay vì con gần nhất
    optimize: true,     // tự chọn chiêu theo sát thương / linh lực thay cho xoay vòng
    mpFull: 70,          // % linh lực từ mức này trở lên: dồn sát thương tối đa
    mpReserve: 20,       // % linh lực dưới mức này: chỉ đánh thường (trừ boss)
    noOverkill: true,    // quái sắp chết, một đòn thường là đủ thì không phí chiêu
    alwaysRun: true,     // giữ chế độ chạy (Shift)
    healSit: true,       // máu thấp thì tắt auto, ngồi thiền
    healLow: 35,         // % máu bắt đầu ngồi
    healHigh: 90,        // % máu đứng dậy đánh tiếp
    healSafe: 200,       // px: chỉ ngồi thiền khi không có quái hung hăng trong khoảng này
    autoRevive: true,
    reviveMode: 'spot',  // 'spot' = gượng dậy tại chỗ (còn lượt), 'home' = về làng
    reviveDelay: 3,      // giây chờ sau khi gục
    autoEat: true,
    priority: '',        // '' = giữ nguyên cài đặt game; auto|boss|quai|nguoi|mau
    logFilter: 'all',    // lọc tab Log: all|fight|loot|dc
    stayFarm: false,     // ra khỏi bãi (hoặc chết về làng) thì tự đi về
    farmRadius: 400,     // px quanh điểm farm
    farm: null,          // {map, name, x, y}
    tgOn: false,         // gửi báo cáo sự kiện về Telegram
    tgToken: '',         // token bot từ @BotFather
    tgChat: '',          // chat ID nhóm nhận báo cáo
    tgAlwaysFile: false, // luôn gửi kèm file log .txt kể cả khi bình thường
    tgEv_tl: true, tgEv_lt: true, tgEv_vn: true, tgEv_dh: true, tgEv_bc: true, tgEv_ll: true, tgEv_ct: true, tgEv_td: true, tgEv_vt: true, tgEv_bh: true, tgEv_xc: true,
    tgEv_bd: true, tgEv_lao: true, tgEv_upd: true, tgEv_khu: true,
    ui: { x: null, y: 8, collapsed: false, hidden: false, tab: 'fight' }
  };
  var TICK_MS = 150;

  var prioSaved = null, prioMode = '';
  var cfg = load();
  var enabled = false;
  var st = {
    jailed: false, jailedAt: 0, jailedPanic: false,
    healing: false, travel: null, graph: null, dodging: false, dodgeTo: null, kiting: false, kiteTo: null, kiteAt: 0, kiteSince: 0,
    engaging: false, engageTo: null, engageAt: 0, cornerUntil: 0,
    healMoving: false, healTo: null, healAt: 0, reFly: false, flyTries: 0, lastFlyPress: 0, looting: null,
    harvest: null, farmTarget: null, farmPickAt: 0, towerOut: null,
    lastAutoPress: 0, lastSitPress: 0, lastRevive: 0, lastEat: 0,
    lastRoute: 0, routeTo: null, lastPos: null, lastMoveAt: 0, lastAct: null, log: '',
    vtTriggeredDay: null,
    lastTdResult: '', lastVtResult: '', tdDoneTg: '', tdDoneTgAt: 0,
    lt: null, ltXem: 0, ltReg: 0, ltWhy: '', tgWait: 0, tgErr: ''
  };
  var dev = { mult: 1.25, baseSpeed: null };
  var stats = newStats();
  function newStats() {
    return { since: now(), kills: 0, exp: 0, dmg: 0, mp: 0, killSec: 0, skill: {} };
  }

  function load() {
    var c;
    try { c = Object.assign({}, DEFAULTS, JSON.parse(localStorage.getItem(STORE_KEY) || '{}')); }
    catch (e) { c = Object.assign({}, DEFAULTS); }
    c.ui = Object.assign({}, DEFAULTS.ui, c.ui || {});
    delete c.tdCamp; delete c.tdCampPick; delete c.tdCampV2; // bỏ treo chờ Thương Đội (Thiên Đạo đã báo map + khu)
    delete c.honSummon; c.honSummon = false; // Triệt tiêu cấu hình gọi âm hồn thủ công cũ
    if (!c.llTuyenV2) { c.llTuyen = 'auto'; c.llTuyenV2 = true; }
    if (!c.xcHuntV2) { c.xcHunt = true; c.xcHuntV2 = true; }
    if (!c.tranBossTdV3) { c.tranOnlyBossTd = true; c.tranBossTdV3 = true; }
    return c;
  }
  function save() {
    var o = prioSaved ? Object.assign({}, cfg, prioSaved) : cfg; // cài đặt tạm lúc ưu tiên boss / hoạt động không lưu
    try { localStorage.setItem(STORE_KEY, JSON.stringify(o)); } catch (e) { }
  }
  // Người dùng tự đổi một mục đang bị ghi đè tạm: giữ giá trị mới cho lúc trả lại.
  function userSet(k) { if (prioSaved && k in prioSaved) prioSaved[k] = cfg[k]; }
  function now() { return performance.now(); }
  function dist(ax, ay, bx, by) { var x = ax - bx, y = ay - by; return Math.sqrt(x * x + y * y); }
  function say(msg) {
    st.log = new Date().toLocaleTimeString() + '  ' + msg;
    console.log('[TTBot]', msg);
    if (ui.log) ui.log.textContent = st.log;
  }

  function game() {
    var P = window.PNTT;
    if (!P || !P.SceneWorld || !P.Game || P.Game.scene !== P.SceneWorld) return null;
    var sw = P.SceneWorld;
    if (!sw.player || !sw.map || !sw.map.data || sw.transitioning) return null;
    return { P: P, sw: sw, me: sw.player, mapId: sw.map.data.id };
  }

  function busyUI(P) {
    return !!(P.HUD && (P.HUD.dialogOpen || P.HUD.bagOpen)) ||
      !!(P.SceneWorld.menuOpen) ||
      !!(P.SkillBook && P.SkillBook.open);
  }

  function setAuto(g, on) {
    if (g.sw.autoOn === on) return;
    if (now() - st.lastAutoPress < 500) return;
    st.lastAutoPress = now();
    g.P.Input.pressAutoToggle();
  }

  /* ================= Bộ đón gói tin Máy chủ (WebSocket / Gateway) ================= */
  // Bắt trọn 100% mọi request / response / event từ server gửi xuống (và gửi lên).
  // Hỗ trợ cả khi chạy ở document-start hoặc document-idle, không sợ mất hook khi rớt mạng / đổi map.
  var netState = {
    hooked: false,
    wsCount: 0,
    activeSocket: null,
    receivedCount: 0,
    sentCount: 0,
    lastReceivedAt: 0,
    lastSentAt: 0,
    byOp: Object.create(null),
    history: [],
    historyMax: 120
  };

  var ServerBus = {
    _listeners: Object.create(null),
    _wildcards: [],
    on: function (op, fn) {
      if (!op || typeof fn !== 'function') return this;
      (this._listeners[op] = this._listeners[op] || []).push(fn);
      return this;
    },
    off: function (op, fn) {
      if (!op || !this._listeners[op]) return this;
      this._listeners[op] = this._listeners[op].filter(function (f) { return f !== fn; });
      return this;
    },
    onAny: function (fn) {
      if (typeof fn === 'function') this._wildcards.push(fn);
      return this;
    },
    emit: function (op, packet, raw, isSent) {
      var list = this._listeners[op];
      if (list && list.length) {
        for (var i = 0; i < list.length; i++) {
          try { list[i](packet, raw, isSent); } catch (e) {
            console.error('[ServerBus] Lỗi xử lý op ' + op + ':', e);
          }
        }
      }
      for (var j = 0; j < this._wildcards.length; j++) {
        try { this._wildcards[j](op, packet, raw, isSent); } catch (e) { }
      }
    }
  };

  function recordPacketHistory(dir, op, p) {
    var item = {
      t: Date.now(),
      dir: dir,
      op: op,
      summary: op
    };
    if (op === 'tin' || op === 'bao' || op === 'toast' || op === 'world_chat') {
      item.summary = p.text || (p.name ? (p.name + ': ' + (p.text || '')) : op);
    } else if (op === 'bosses') {
      item.summary = 'Lịch ' + (p.boards ? p.boards.length : 0) + ' bảng';
    } else if (op === 'spawn') {
      item.summary = 'Sinh: ' + (p.e ? (p.e.t || p.e.id) : '?');
    } else if (op === 'kill') {
      item.summary = 'Hạ ' + p.id + (p.exp ? (' +' + p.exp + ' exp') : '');
    } else if (op === 'loot') {
      item.summary = 'Rơi ' + (p.l ? p.l.length : (p.items ? p.items.length : 0)) + ' món';
    } else if (op === 'khu') {
      item.summary = (p.mapId || '') + ' (' + (p.ds ? p.ds.length : 0) + ' khu)';
    } else if (op === 'map') {
      item.summary = (p.mapId || '') + ' k' + (p.khu || 1);
    }
    netState.history.unshift(item);
    if (netState.history.length > netState.historyMax) netState.history.pop();
  }

  function handleServerData(data, wsInstance) {
    if (wsInstance) netState.activeSocket = wsInstance;
    netState.receivedCount++;
    netState.lastReceivedAt = Date.now();
    if (typeof data === 'string') {
      var packet;
      try { packet = JSON.parse(data); } catch (e) { return; }
      if (!packet || typeof packet !== 'object') return;
      var op = packet.op || (packet.cmd ? ('cmd_' + packet.cmd) : 'unknown');
      netState.byOp[op] = (netState.byOp[op] || 0) + 1;
      recordPacketHistory('down', op, packet);
      if (packet.op === 'hacthi' && packet.act === 'giam' && (packet.conMs > 0 || (packet.giamDen && packet.giamDen > Date.now()))) {
        var gCur = typeof game === 'function' ? game() : null;
        if (typeof panicThienLao === 'function') {
          panicThienLao(gCur, 'Nhận gói tin máy chủ giam giữ Thiên Lao (conMs: ' + (packet.conMs || 0) + ')');
        }
      }
      if ((packet.op === 'chat' || packet.op === 'thongbao' || packet.op === 'toast') && packet.text) {
        if (/(?:bi giam|phat tu|vao lao|thien lao)/i.test(packet.text)) {
          var gCur2 = typeof game === 'function' ? game() : null;
          if (typeof panicThienLao === 'function' && typeof isJailed === 'function' && isJailed(gCur2)) {
            panicThienLao(gCur2, 'Thông báo máy chủ: ' + packet.text);
          }
        }
      }
      ServerBus.emit(op, packet, data, false);
    }
  }

  function handleClientData(data, wsInstance) {
    if (wsInstance) netState.activeSocket = wsInstance;
    netState.sentCount++;
    netState.lastSentAt = Date.now();
    if (typeof data === 'string') {
      try {
        var packet = JSON.parse(data);
        if (packet && typeof packet === 'object') {
          var op = packet.op || (packet.cmd ? ('cmd_' + packet.cmd) : 'unknown');
          recordPacketHistory('up', op, packet);
          ServerBus.emit('client_' + op, packet, data, true);
        }
      } catch (e) { }
    }
  }

  function wrapSocketInstance(ws) {
    if (!ws) return;
    netState.activeSocket = ws;
    if (!ws._ttInstanceAEL) {
      try {
        var fallbackListener = function (ev) {
          if (ev && !ev._ttHandled) {
            ev._ttHandled = true;
            try { handleServerData(ev.data, ws); } catch (e) { }
          }
        };
        if (ws.addEventListener) {
          ws.addEventListener('message', fallbackListener);
          ws._ttInstanceAEL = true;
        }
      } catch (e) { }
    }

    if (typeof ws.onmessage === 'function' && !ws.onmessage._ttWrapped) {
      var oldHandler = ws.onmessage;
      var newHandler = function (ev) {
        if (ev && !ev._ttHandled) {
          ev._ttHandled = true;
          try { handleServerData(ev.data, ws); } catch (e) { }
        }
        return oldHandler.apply(this, arguments);
      };
      newHandler._ttWrapped = true;
      newHandler._ttOrig = oldHandler;
      ws.onmessage = newHandler;
    }
  }

  function hookPNTTGateway(P) {
    P = P || window.PNTT;
    if (!P || !P.Gateway) return;
    var G = P.Gateway;
    if (G.socket) wrapSocketInstance(G.socket);
    if (!G._ttSocketSetterHooked) {
      var curSock = G.socket;
      try {
        Object.defineProperty(G, 'socket', {
          get: function () { return curSock; },
          set: function (s) {
            curSock = s;
            if (s) wrapSocketInstance(s);
          },
          enumerable: true,
          configurable: true
        });
        G._ttSocketSetterHooked = true;
      } catch (e) { }
    }
    if (typeof G.connect === 'function' && !G.connect._ttHooked) {
      var origConn = G.connect;
      G.connect = function () {
        var r = origConn.apply(this, arguments);
        if (G.socket) wrapSocketInstance(G.socket);
        return r;
      };
      G.connect._ttHooked = true;
    }
  }

  function installNetHooks() {
    if (typeof window === 'undefined') return;
    if (window.WebSocket && window.WebSocket.prototype) {
      var proto = window.WebSocket.prototype;
      var onmessageDesc = Object.getOwnPropertyDescriptor(proto, 'onmessage');
      var origSet = onmessageDesc && onmessageDesc.set;
      var origGet = onmessageDesc && onmessageDesc.get;

      if (!proto._ttOnmessageHooked) {
        Object.defineProperty(proto, 'onmessage', {
          get: function () {
            return this._ttRawOnMessage || (origGet ? origGet.call(this) : null);
          },
          set: function (fn) {
            this._ttRawOnMessage = fn;
            if (typeof fn !== 'function') {
              if (origSet) return origSet.call(this, fn);
              return;
            }
            var self = this;
            var wrapped = function (ev) {
              if (ev && !ev._ttHandled) {
                ev._ttHandled = true;
                try { handleServerData(ev.data, self); } catch (e) { }
              }
              return fn.apply(this, arguments);
            };
            wrapped._ttWrapped = true;
            wrapped._ttOrig = fn;
            if (origSet) {
              return origSet.call(this, wrapped);
            }
          },
          enumerable: true,
          configurable: true
        });
        proto._ttOnmessageHooked = true;
      }

      if (proto.addEventListener && !proto._ttAELHooked) {
        var origAEL = proto.addEventListener;
        proto.addEventListener = function (type, listener, options) {
          if (type === 'message' && typeof listener === 'function' && !listener._ttWrapped) {
            var self = this;
            var wrapped = function (ev) {
              if (ev && !ev._ttHandled) {
                ev._ttHandled = true;
                try { handleServerData(ev.data, self); } catch (e) { }
              }
              return listener.apply(this, arguments);
            };
            wrapped._ttWrapped = true;
            wrapped._ttOrig = listener;
            return origAEL.call(this, type, wrapped, options);
          }
          return origAEL.apply(this, arguments);
        };
        proto._ttAELHooked = true;
      }

      if (proto.send && !proto._ttSendHooked) {
        var origSend = proto.send;
        proto.send = function (data) {
          try { handleClientData(data, this); } catch (e) { }
          return origSend.apply(this, arguments);
        };
        proto._ttSendHooked = true;
      }
    }

    if (window.WebSocket && !window.WebSocket._ttConstructorHooked) {
      var RealWS = window.WebSocket;
      var HookedWS = function (url, protocols) {
        var ws = protocols ? new RealWS(url, protocols) : new RealWS(url);
        netState.wsCount++;
        netState.activeSocket = ws;
        wrapSocketInstance(ws);
        return ws;
      };
      HookedWS.prototype = RealWS.prototype;
      Object.keys(RealWS).forEach(function (k) {
        try { HookedWS[k] = RealWS[k]; } catch (e) { }
      });
      HookedWS._ttConstructorHooked = true;
      try { window.WebSocket = HookedWS; } catch (e) { }
    }

    hookPNTTGateway();
    netState.hooked = true;
  }

  function initServerPacketListeners() {
    if (initServerPacketListeners._done) return;
    initServerPacketListeners._done = true;

    // 1. Kênh chat và thông báo máy chủ
    ServerBus.on('world_chat', function (p) {
      if (p.text) {
        readChatHint(p.text, p.name);
        var who = plainVi(p.name || '');
        var txtP = plainVi(p.text);
        if (who === 'thien dao' || p.id === 'thien_dao' || !p.id || /^(?:\[?(?:thien dao|he thong|thong bao)\]?|thien dao:|he thong:|thong bao:)/i.test(txtP) || /xong chuong|thuong doi|bien di|xuat hien o/i.test(txtP)) {
          readServerNews(p.text);
        }
      }
    });

    ServerBus.on('tin', function (p) {
      if (p.text) {
        readServerNews(p.text);
        readChatHint(p.text, 'Hệ thống');
      }
    });

    ServerBus.on('bantin', function (p) {
      if (p.tieuDe) {
        readServerNews(p.tieuDe);
        readChatHint(p.tieuDe, 'Bản tin');
      }
      if (Array.isArray(p.doan)) {
        p.doan.forEach(function (txt) {
          if (txt) {
            readServerNews(txt);
            readChatHint(txt, 'Bản tin');
          }
        });
      }
    });

    ServerBus.on('bao', function (p) {
      if (p.text) {
        readServerNews(p.text);
        readChatHint(p.text, 'Thông báo');
      }
    });

    ServerBus.on('toast', function (p) {
      if (p.text) {
        readServerNews(p.text);
      }
    });

    ServerBus.on('notice', function (p) {
      if (p.text) {
        readServerNews(p.text);
      }
    });

    ServerBus.on('chat', function (p) {
      if (p.text) {
        readChatHint(p.text, p.name);
        var who = plainVi(p.name || '');
        var txtP = plainVi(p.text);
        if (who === 'thien dao' || p.id === 'thien_dao' || /^(?:\[?(?:thien dao|he thong|thong bao)\]?|thien dao:|he thong:|thong bao:)/i.test(txtP) || /xong chuong|thuong doi|bien di|xuat hien o/i.test(txtP)) {
          readServerNews(p.text);
        }
      }
    });

    // 2. Lịch boss toàn máy chủ
    ServerBus.on('bosses', function (p) {
      if (p.boards) {
        st.bossList = { ok: true, boss: [], boards: p.boards };
        st.bossListAt = now();
        klog('[Mạng] Nhận lịch boss mới nhất từ máy chủ');
      }
    });

    // 3. Quái sinh (Boss / Biến dị / Xổng chuồng)
    ServerBus.on('spawn', function (p) {
      var e = p.e;
      if (!e) return;
      var tName = e.t || '';
      var g = game();
      var isB = BOSS_TABLE.some(function (b) { return b.type === tName; });
      if (isB) {
        radarSeen[tName] = { map: g ? g.mapId : '', khu: g ? gaKhu(g.P) : 1, at: now() };
        klog('[Mạng] Boss ' + (BH_NAMES[tName] || tName) + ' vừa sinh tại khu ' + (g ? gaKhu(g.P) : '') + ' (' + e.x + ', ' + e.y + ')');
      } else if (/bien_di|xong_chuong/.test(tName)) {
        klog('[Mạng] Yêu thú ' + tName + ' vừa sinh tại (' + e.x + ', ' + e.y + ')');
      }
    });

    // 4. Tiêu diệt quái (hạ boss / quái thường)
    ServerBus.on('kill', function (p) {
      var P = window.PNTT, G = P && P.Gateway, self = G && G.selfId;
      if (p.by && self && p.by === self) {
        stats.kills++;
        if (p.exp > 0) stats.exp += (+p.exp || 0);
      }
    });

    // 5. Sát thương vào quái (trực tiếp từ máy chủ)
    ServerBus.on('hit', function (p) {
      var g = game();
      if (!g || !p.id) return;
      var m = (g.sw.enemies || []).filter(function (e) { return e && e.id === p.id; })[0];
      if (m && p.dmg > 0) {
        noteHit(m, +p.dmg || 0);
      }
    });

    // 6. Vật phẩm rơi (loot tức thì khi rơi cạnh mình: Siêu cảm biến Frame-0 Zero Latency)
    ServerBus.on('loot', function (p) {
      var items = Array.isArray(p) ? p : (p && (p.l || p.items));
      if (!Array.isArray(items) || !items.length) return;
      var g = game();
      if (!g || !enabled || !cfg.autoLoot) return;
      var G = g.P.Gateway, L = g.P.Loot, pl = g.me;
      if (!G || !G.cmd || !pl) return;
      var R = ((L && L.PICK_R) || 40) + 12;

      // Sắp xếp theo giá trị giảm dần: nhặt vật phẩm xịn nhất trước!
      var sorted = items.slice().sort(function (a, b) {
        var idA = a && (a.item || a.itemId);
        var idB = b && (b.item || b.itemId);
        return gradeScore(g.P, idB) - gradeScore(g.P, idA);
      });

      sorted.forEach(function (it) {
        if (!it || it.id == null || it.ht) return;
        var itemId = it.item || it.itemId;
        var lid = it.id != null ? it.id : it.lootId;
        var d = dist(pl.x, pl.y, it.x, it.y);
        var isOwner = !it.owner || (G.selfId && it.owner === G.selfId);
        var isExpiredLock = (it.age || 0) >= (it.khoa || (L && L.OWNER_SECS) || 45);

        if (d <= R) {
          if (!isOwner && !isExpiredLock) return;
          if (!lootFilterOk(g.P, itemId)) return;
          it._ttAsked = true;
          G.cmd('loot.pick', { id: lid }, function () { });
          if (gradeScore(g.P, itemId) >= 5000) {
            var iName = (g.P.ITEMS && g.P.ITEMS[itemId] && g.P.ITEMS[itemId].name) || itemId;
            klog('[Siêu Nhặt Frame-0] ' + iName + ' vừa phát từ Server → Gửi lệnh nhặt ngay (0ms, không chờ rơi)!');
          }
        } else if (d <= 260 && (isOwner || !it.owner) && gradeScore(g.P, itemId) >= 6000) {
          // Vật phẩm cực phẩm / Bí tịch giữa trận / Đồ xổng chuồng rơi ngoài tầm 40px nhưng trong tầm lướt (<= 260px): lập tức lướt tới nhặt Frame-0!
          if ((cfg.autoHaste || cfg.autoDash) && !st.looting) {
            if (cfg.autoHaste) talUse(g, 'toc_hanh', 'lướt nhặt ' + (itemId || 'bảo vật'));
            moveFighting(g, [{ x: it.x, y: it.y }]);
          }
        }
      });
    });

    // 7. Nhặt vật phẩm thành công
    ServerBus.on('loot_gone', function (p) {
      var g = game();
      if (!g || !p.id) return;
      var G = g.P.Gateway;
      if (p.by && G && p.by === G.selfId) {
        var dr = (g.sw.drops || []).filter(function (x) { return x && x.lootId === p.id; })[0];
        if (dr && !dr.granted) {
          dr.granted = true;
          recordLoot(g, dr.itemId, dr.n || 1);
        }
      }
    });

    // 8. Cập nhật số người các khu
    ServerBus.on('khu', function (p) {
      if (p && p.mapId) {
        khuList = p;
        khuListAt = now();
        klog('[Mạng] Danh sách ' + (p.ds ? p.ds.length : 0) + ' khu map ' + (mapName(p.mapId) || p.mapId) + ' đã cập nhật');
      }
    });

    // 9. Đổi map
    ServerBus.on('map', function (p) {
      if (p && p.mapId) {
        klog('[Mạng] Chuyển map: ' + (mapName(p.mapId) || p.mapId) + ' (khu ' + (p.khu || 1) + '/' + (p.soKhu || 1) + ')');
      }
    });

    // 10. Trạng thái nhân vật (khiên, tốc hành)
    ServerBus.on('status', function (p) {
      var g = game();
      if (!g || !g.me) return;
      if (p.sh != null) g.me.shieldHp = +p.sh || 0;
      if (p.ht != null) g.me.hasteT = +p.ht || 0;
    });

    // 11. Hồi toàn bộ chiêu
    ServerBus.on('hoichieu', function () {
      klog('[Mạng] Máy chủ hồi toàn bộ thời gian hồi chiêu');
    });

    // 12. Phản hồi lệnh (ack)
    ServerBus.on('ack', function (p) {
      if (p && p.ok === false && p.why) {
        if (/khong du|het luot|qua xa|that bai/i.test(p.why)) {
          klog('[Mạng] Máy chủ từ chối: ' + p.why);
        }
      }
    });
  }

  // Khởi động hook mạng ngay lập tức
  installNetHooks();
  initServerPacketListeners();

  /* ================= Bản đồ cổng ================= */
  function mapGraph(P) {
    P = P || (typeof window !== 'undefined' && (window.PNTT || (typeof unsafeWindow !== 'undefined' && unsafeWindow.PNTT)));
    var MD = (P && P.MapData) || {};
    var mdKeys = Object.keys(MD);
    if (st.graph && Object.keys(st.graph).length >= mdKeys.length && mdKeys.length > 0) return st.graph;
    var out = {};
    mdKeys.forEach(function (k) {
      var m = MD[k];
      if (m && typeof m === 'object' && typeof m.id === 'string' && Array.isArray(m.portals) && !out[m.id]) {
        out[m.id] = { id: m.id, name: m.name || m.id, portals: m.portals.slice() };
      }
    });
    // Không tính Truyền Tống Trận vào đường đi: trận đang không chuyển được, chỉ đi qua cổng thường.
    // (Vẫn né trận trong portalZones để khỏi đứng lên.)
    if (Object.keys(out).length) st.graph = out;
    return st.graph || out;
  }

  function mapName(id) {
    var P = window.PNTT, node = P && mapGraph(P)[id];
    return node ? node.name : id;
  }

  // BFS theo số lần qua cổng; trả về map kế tiếp phải bước sang.
  function nextHop(graph, from, to) {
    if (from === to) return to;
    var prev = {}, q = [from];
    prev[from] = null;
    while (q.length) {
      var cur = q.shift(), node = graph[cur];
      if (!node) continue;
      for (var i = 0; i < node.portals.length; i++) {
        var nx = node.portals[i].toMap;
        if (!nx || nx in prev) continue;
        prev[nx] = cur;
        if (nx === to) {
          var step = to;
          while (prev[step] !== from) step = prev[step];
          return step;
        }
        q.push(nx);
      }
    }
    return null;
  }

  /* ================= Đi bộ ================= */
  function walkTo(g, x, y) {
    var me = g.me;
    var same = st.routeTo && dist(st.routeTo.x, st.routeTo.y, x, y) < 8;
    if (same && me.path && me.path.length && now() - st.lastRoute < 2500) return true;
    var C = g.P.CONFIG.PLAYER;
    var path = g.P.Pathfinder.route(g.sw.map, me.x, me.y, x, y, C.HITBOX_W / 2, C.HITBOX_H);
    st.lastRoute = now();
    st.routeTo = { x: x, y: y };
    if (!path || !path.length) return false;
    if (me.state === 'sit') g.P.Player.stand(me);
    me.setPath(path);
    return true;
  }

  function portalTarget(g, toMap) {
    var T = g.P.CONFIG.TILE, me = g.me, list = [];
    var node = mapGraph(g.P)[g.mapId];
    (node ? node.portals : g.sw.map.data.portals || []).forEach(function (p) {
      if (p.toMap !== toMap) return;
      var x = (p.tx + 0.5) * T, y = (p.ty + 0.5) * T;
      list.push({ x: x, y: y, d: dist(me.x, me.y, x, y), pad: !!p.pad });
    });
    list.sort(function (a, b) { return a.d - b.d; });
    return list;
  }

  function startTravel(map, x, y, why, khu) {
    var sw0 = window.PNTT && window.PNTT.SceneWorld;
    if (sw0 && (sw0.fishing || sw0.fishingAuto) && sw0.stopFishing) sw0.stopFishing(); // đang câu thì không đi được: thôi câu
    st.travel = { map: map, x: x, y: y, khu: khu || 0, fails: 0 };
    st.lastMoveAt = now();
    st.routeTo = null;
    say(why || 'Đi tới ' + mapName(map));
  }

  function stopTravel(msg) {
    var t = st.travel;
    st.travel = null;
    st.routeTo = null;
    if (msg) say(msg);
    if (msg && t && /Không|Kẹt/.test(msg)) klog('[Đi đường] ' + msg + ' (đang đi tới ' + mapName(t.map) + ')');
  }

  function tickTravel(g) {
    var t = st.travel;
    if (!t) return false;
    var me = g.me;
    if (g.P.Input.hasManualMove()) { stopTravel('Bạn tự điều khiển → huỷ đi đường'); return false; }
    if (now() < (st.wbLootUntil || 0) && g.mapId === (st.wbLootPos && st.wbLootPos.map)) {
      // Đang trong 25s chờ bốc thăm quà boss thế giới: giữ chân ở map boss
      return false;
    }
    if (g.mapId !== t.map && !t.rush && lootBeforeLeave(g)) { st.lastMoveAt = now(); st.routeTo = null; return true; }

    // Đứng yên quá lâu thì tính lại đường; ba lần liền vẫn kẹt thì bỏ.
    if (!st.lastPos || dist(st.lastPos.x, st.lastPos.y, me.x, me.y) > 4) {
      st.lastPos = { x: me.x, y: me.y };
      st.lastMoveAt = now();
    } else if (now() - st.lastMoveAt > 4000) {
      st.lastMoveAt = now();
      st.routeTo = null;
      if (++t.fails >= 3) { stopTravel('Kẹt đường, dừng (có thể map bị khoá cảnh giới)'); return false; }
    }

    setAuto(g, false);
    if (g.mapId === t.map) {
      if (t.x == null || dist(me.x, me.y, t.x, t.y) <= 40) { stopTravel('Đã tới nơi'); return false; }
      if (!walkTo(g, t.x, t.y)) { stopTravel('Không tìm được đường tới điểm đích'); return false; }
      return true;
    }
    var hop = nextHop(mapGraph(g.P), g.mapId, t.map);
    if (!hop) { stopTravel('Không có đường cổng từ map này tới ' + mapName(t.map)); return false; }
    var targets = portalTarget(g, hop);
    if (targets && targets.pad && targets.d < 24) {
      // Đang đứng trên trận, chờ game đếm xong — không tính là kẹt.
      st.lastMoveAt = now();
      return true;
    }
    for (var i = 0; i < targets.length; i++) {
      if (walkTo(g, targets[i].x, targets[i].y)) return true;
    }
    stopTravel('Không tới được cổng sang ' + mapName(hop));
    return false;
  }

  // Về chỗ cũ sau một việc (đánh boss, săn hồn, chăm vườn, Dược Công). Đi về một lần là chưa đủ: gục
  // rồi gượng dậy (hồi sinh xoá đường đi), kẹt đường, bị quái chen ngang… thì vẫn đi lại tới khi tới nơi.
  // Đồng thời tự động ghi nhớ và đổi về đúng số Khu cũ (nếu map có chia nhiều khu).
  var BACK_RETRY_MS = 3000, BACK_TRIES = 8, BACK_NEAR = 80;
  function goBack(map, x, y, why, kind, khu) {
    if (!map || (cfg.planRun && enabled)) return; // lịch tự về chỗ farm khi xong hết việc
    if (map && typeof map === 'object') {
      khu = map.khu;
      why = x;
      kind = y;
      y = map.y;
      x = map.x;
      map = map.map;
    }
    var targetKhu = khu || (st.back && st.back.khu) || 0;
    st.back = {
      map: map, x: x, y: y, khu: targetKhu, why: why, kind: kind || '',
      tries: 1, retryAt: now() + BACK_RETRY_MS,
      khuWant: 0, khuAt: 0, touches: 0, touchAt: 0, routeAt: 0, khuDone: false, khuFail: false
    };
    startTravel(map, x, y, why, targetKhu);
  }
  // Việc mới bắt đầu giữa đường về: nhận luôn chỗ cũ làm chỗ về của việc mới (kèm số Khu).
  function takeBack(g) {
    var b = st.back;
    st.back = null;
    g = g || game();
    var curMap = (g && g.mapId) || '';
    var curX = (g && g.me && g.me.x != null) ? g.me.x : 0;
    var curY = (g && g.me && g.me.y != null) ? g.me.y : 0;
    var k = (cfg.farm && cfg.farm.map === curMap && cfg.farm.khu) ? cfg.farm.khu : (g && g.P ? gaKhu(g.P) : 1);
    return b ? { map: b.map, x: b.x, y: b.y, khu: b.khu || k } : { map: curMap, x: curX, y: curY, khu: k };
  }
  function tickGoBack(g) {
    var b = st.back;
    if (!b || st.bh || st.bd || st.xc || st.td || st.hon || st.fa || st.dc || st.ga || now() < (st.wbLootUntil || 0)) return false;
    if (g.P.Input.hasManualMove()) { st.back = null; say('Bạn tự điều khiển → thôi về chỗ cũ'); return false; }

    var P = g.P;
    var soKhu = gaSoKhu(P);
    var curKhu = gaKhu(P);

    // 1) Khi đã về tới đúng map đích: kiểm tra số khu nếu cần đổi lại khu cũ
    if (g.mapId === b.map) {
      if (b.khuWant && curKhu === b.khu) {
        b.khuDone = true;
        b.khuWant = 0;
        klog('[Về chỗ] Đã đổi sang khu ' + b.khu + ' thành công');
      }
      var needKhu = b.khu && b.khu > 0 && soKhu > 1 && curKhu !== b.khu && !b.khuDone && !b.khuFail;
      if (needKhu) {
        if (st.travel) stopTravel();
        b.khuWant = b.khu;
        var busyKhu = khuGo(g, b, '[Về chỗ]');
        if (busyKhu) return true;
        // khuGo đã xong hoặc không tìm được Bảng Khu / lỗi
        if (gaKhu(P) === b.khu) {
          b.khuDone = true;
          b.khuWant = 0;
          klog('[Về chỗ] Đã đổi sang khu ' + b.khu + ' thành công');
        } else {
          b.khuFail = true;
          b.khuWant = 0;
          klog('[Về chỗ] Không sang được khu ' + b.khu + ' (bảng lỗi / khu đầy) → ở lại khu ' + curKhu + ' farm tiếp');
        }
      }

      // 2) Đã đúng khu (hoặc map chỉ 1 khu / đã thử đổi xong): kiểm tra cự ly bãi farm
      var d = (b.x != null && b.y != null) ? dist(g.me.x, g.me.y, b.x, b.y) : 0;
      if (d <= BACK_NEAR) {
        var finK = gaKhu(P);
        st.back = null;
        if (st.travel) stopTravel();
        say('Đã về chỗ farm' + (soKhu > 1 ? ' khu ' + finK : '') + ' → farm tiếp');
        klog('[Về chỗ] Đã về đúng bãi farm ' + mapName(b.map) + (soKhu > 1 ? ' khu ' + finK : '') + ' (' + Math.round(g.me.x) + ', ' + Math.round(g.me.y) + ')');
        setAuto(g, true);
        return false;
      }
    }

    // 3) Chưa tới map hoặc đang ở map nhưng còn cách bãi farm > BACK_NEAR (sau khi đổi khu)
    if (!st.travel || st.travel.map !== b.map) {
      if (now() < b.retryAt) return true;
      if (++b.tries > BACK_TRIES) { st.back = null; say('Về chỗ farm ' + BACK_TRIES + ' lần không được → ở lại đây'); return false; }
      b.retryAt = now() + BACK_RETRY_MS;
      startTravel(b.map, b.x, b.y, b.why + ' (thử lại lần ' + b.tries + ')', b.khu);
    }
    tickTravel(g);
    return true;
  }

  // Việc đang dở (kể cả lúc phần riêng của việc đó đang chờ / tạm nghỉ trong nhịp này): Giữ bãi và "về chỗ farm" của
  // Lịch không được kéo nhân vật về bãi, nếu không hai bên giành nhau (chạy ra Bảng Khu đổi khu, đi câu, đi Vết Nứt…).
  function jobBusy(g) {
    return st.fk ? 'đổi khu' : st.fish ? 'câu cá' : st.fa ? 'chăm vườn' : st.dc ? 'Dược Công' : st.ga ? 'nhặt nguyên liệu' : st.hon ? 'săn hồn' :
      st.td ? 'Thương Đội' : st.bd ? 'biến dị' : st.xc ? 'xổng chuồng' : st.bh ? 'boss' : st.vn ? 'Vết Nứt' : st.ll || st.llOpen ? 'Lãm Làng' :
        st.ht ? 'Sỹ Sách Điện' : st.tl ? 'Tam Lộ' : st.vt || vtActive(g) ? 'Vận Tiêu' : st.sn ? 'NV tông môn' : st.honBuy ? 'mua đồ Hồn Phiên' :
          st.ct ? 'cướp tiêu' : st.tq ? 'Giai đoạn 36' : st.hl || (g.P.ChienTruong && g.mapId === g.P.ChienTruong.MAP) ? 'Chiến Trường' : st.contest ? 'tranh đồ' : st.looting ? 'nhặt đồ' : st.back ? 'đang về chỗ cũ' : st.dd ? 'điểm danh' : st.gc ? 'Tàng Kinh' : st.harvest ? 'thu hái' : '';
  }
  function tickStayFarm(g) {
    var f = cfg.farm;
    if (!cfg.stayFarm || !f || st.travel || cfg.dcRun || cfg.gatherRun || jobBusy(g) || (cfg.planRun && st.plan && st.plan.job)) return;

    // Người chơi vừa tự điều khiển (trong 15s): không giật ngược lại bãi
    var manualRecent = (now() - (st.lastManualAt || 0)) < 15000;
    if (manualRecent) return;

    // Người chơi chủ động sang map khác (hoặc bấm Đi bộ tới): tạm ngưng giữ bãi cũ để người chơi tự do
    if (g.mapId !== f.map) {
      if ((now() - (st.lastManualAt || 0)) < 45000 || st.travelManual) {
        if (!st.stayFarmPaused) {
          st.stayFarmPaused = true;
          say('Bạn vừa di chuyển sang ' + mapName(g.mapId) + ' → tạm dừng giữ bãi cũ. Bấm "Lưu chỗ này" nếu muốn đổi bãi farm.');
          klog('Tạm ngưng giữ bãi ' + f.name + ' do người chơi tự sang ' + mapName(g.mapId));
        }
        return;
      }
      if (st.stayFarmPaused) return;
      startTravel(f.map, f.x, f.y, 'Quay về bãi ' + f.name, f.khu);
      return;
    }

    // Đang ở đúng map: nếu đã quay về trong phạm vi bãi thì tự động mở lại giữ bãi
    var d = dist(g.me.x, g.me.y, f.x, f.y);
    if (d <= cfg.farmRadius) {
      st.stayFarmPaused = false;
      st.travelManual = false;
    }
    if (st.stayFarmPaused) return;

    if (f.khu && gaSoKhu(g.P) > 1 && gaKhu(g.P) !== f.khu && !st.fk) {
      fkStart('sai khu bãi farm');
      if (st.fk) st.fk.want = f.khu;
    }
    else if (d > cfg.farmRadius) startTravel(f.map, f.x, f.y, 'Ra khỏi bãi → quay lại', f.khu);
  }

  /* ================= Né chiêu ================= */
  // Vùng nổ có hình báo trước trong VFX.list (game vẽ elip R × R/2 → đo trục dọc nhân 2).
  var DODGE_FX = { luutinhbao: 'Lưu tinh', tahoabao: 'Tà hoả', nhentobao: 'Phún Tơ (trói 10s)' };
  // Chiêu boss báo trước bằng điểm rơi (Tà Hoả, Lưu Tinh / Ngọc Châm Vũ / Tử Diễm, Phún Tơ của Nhện Bạch Ngọc…):
  var fxHaz = [];
  // circle: vùng tròn đủ bán kính (chưa rõ máy chủ xét elip hay tròn thì lấy tròn cho chắc — Yên Lãng).
  function fxNote(pts, sec, r, what, circle) {
    if (!Array.isArray(pts) || !(r > 0)) return;
    var until = now() + Math.max(0.3, +sec || 1.5) * 1000;
    pts.forEach(function (p) { if (p && isFinite(p.x) && isFinite(p.y)) fxHaz.push({ x: +p.x, y: +p.y, R: +r, until: until, what: what, circ: !!circle }); });
    if (fxHaz.length > 80) fxHaz.splice(0, fxHaz.length - 80);
  }
  function hookBossFx(P) {
    var V = P.VFX, B = P.BossBiTich;
    function wrap(o, k, what, unitMs) {
      if (!o || typeof o[k] !== 'function' || o[k]._tt) return;
      var f = o[k];
      o[k] = function (pts, w, r) { try { fxNote(pts, unitMs ? w / 1000 : w, r, what); } catch (e) { } return f.apply(this, arguments); };
      o[k]._tt = true;
    }
    wrap(V, 'spawnTaHoaBao', 'Tà hoả');
    wrap(V, 'spawnLongLuuTinh', 'Lưu tinh');
    wrap(V, 'spawnNhenTo', 'Phún Tơ (trói 10s)');
    wrap(B, 'vong', 'Chiêu boss', true);
    // Kim Quang Cự Kiếm (Tà Soái Lãm Làng) khoá đúng mình: chạy không thoát, phải đỡ bằng giáp.
    var K = P.KimKiemFX;
    if (K && typeof K.spawn === 'function' && !K.spawn._tt) {
      var ks = K.spawn;
      K.spawn = function (from, to, o) {
        try { if (o && o.ghost === false) st.kimKiemAt = now(); } catch (e) { }
        return ks.apply(this, arguments);
      };
      K.spawn._tt = true;
    }
  }

  var BODY_R = 12;   // nửa thân người, cộng vào bán kính trúng đạn
  var BOLT_DY = 14;  // đạn bay ngang ngực, bóng dưới đất thấp hơn chừng này

  // Mọi vùng chiêu sắp trúng. Mỗi vùng là đoạn thẳng (x,y)→(x2,y2) dày r; vùng tròn có hai đầu
  // trùng nhau. t = giây còn lại tới lúc nổ (nếu biết), what = tên đòn để ghi log.
  function hazards(g) {
    var out = [];
    function add(x, y, r, x2, y2, t, what, ex) {
      if (!isFinite(x) || !isFinite(y) || !(r > 0)) return;
      if (!isFinite(x2) || !isFinite(y2)) { x2 = x; y2 = y; }
      var h = { x: +x, y: +y, x2: +x2, y2: +y2, r: r + cfg.dodgeMargin, core: r, t: t, what: what };
      if (ex) { if (ex.sy) h.sy = ex.sy; if (ex.hole > 0) h.hole = ex.hole; }
      out.push(h);
    }
    (g.sw.enemies || []).forEach(function (e) {
      var d = e && !e.dead && e.def;
      if (!d) return;
      var who = d.name ? ' của ' + d.name.split('·')[0].trim() : '';
      if (e.novaWind > 0 && d.fireNova) {
        var isWb = isWorldBoss(g, e);
        // Boss World (như Xích Long) phun Hỏa trận liên tục mỗi 2.4s (chỉ 90 dmg): không né để dồn 100% DPS
        if (!isWb || (d.fireNova.dmg || 0) > 300) {
          add(e.novaX, e.novaY, d.fireNova.radius, null, null, e.novaWind, 'Hoả trận' + who);
        }
      }
      if (e.tcWind > 0 && d.tuyetChieu) add(e.tcX, e.tcY, d.tuyetChieu.radius, null, null, e.tcWind, (d.tuyetChieu.ten || 'Tuyệt chiêu') + who);
      if (e.pounceWind > 0 && d.pounce) add(e.pounceX, e.pounceY, d.pounce.radius, null, null, e.pounceWind, 'Vồ' + who);
    });
    bossTacticHazards(g, add);
    var fx = g.P.VFX && g.P.VFX.list;
    if (fx) fx.forEach(function (f) { if (f && DODGE_FX[f.type] && f.life > 0) add(f.x, f.y, f.R, null, null, f.life, DODGE_FX[f.type], { sy: 2 }); });
    var tn = now();
    fxHaz = fxHaz.filter(function (h) { return h.until > tn; });
    fxHaz.forEach(function (h) { add(h.x, h.y, h.R, null, null, (h.until - tn) / 1000, h.what, h.circ ? null : { sy: 2 }); });
    if (cfg.dodgePlayers) playerHazards(g, add);
    return out;
  }

  // Chiêu người khác: chỉ lấy chiêu chưa nổ, không nhắm vào quái.
  // Chiêu khoá mục tiêu vào chính mình thì đi đâu cũng bám theo nên bỏ qua.
  function playerHazards(g, add) {
    var S = g.P.Skills, me = g.me;
    if (!S) return;
    var mobs = g.sw.enemies || [];
    function aimedAtMob(t) { return !!t && mobs.indexOf(t) >= 0; }
    (S.grounds || []).forEach(function (r) {
      if (!r || !r.ghost || r.fired || r.waiting || !r.def) return;
      if (r.target === me || aimedAtMob(r.target)) return;
      add(r.x, r.y, r.def.blastR, null, null, (r.delay || 0) - (r.t || 0), r.def.short || r.def.name);
    });
    (S.auras || []).forEach(function (r) {
      if (!r || !r.ghost || r.fired || !r.def || aimedAtMob(r.target)) return;
      var o = r.owner || r;
      add(o.x, o.y, r.def.blastR, null, null, (r.delay || 0) - (r.t || 0), r.def.short || r.def.name);
    });
    (S.bolts || []).forEach(function (b) {
      if (!b || !b.ghost || !b.def || aimedAtMob(b.target)) return;
      if (b.guided && b.target === me) return;
      var v = Math.sqrt(b.vx * b.vx + b.vy * b.vy);
      if (!(v > 0)) return;
      var left = Math.max(0, (b.maxTravel || b.def.range || 0) - (b.travel || 0));
      var x = b.x, y = b.y + BOLT_DY;
      add(x, y, (b.def.hitR || 8) + (b.def.blastR || 0) + BODY_R, x + b.vx / v * left, y + b.vy / v * left,
        dist(x, y, me.x, me.y) / v, b.def.short || b.def.name);
    });
  }

  // sy: vùng vẽ nghiêng (game đo trục dọc nhân sy, vòng tròn thành elip dẹt) → đo trong hệ đã giãn trục dọc.
  function segDist(h, x, y) {
    var sy = h.sy || 1, y2 = h.y + (h.y2 - h.y) * sy, py = h.y + (y - h.y) * sy;
    var dx = h.x2 - h.x, dy = y2 - h.y, len = dx * dx + dy * dy;
    var t = len ? Math.max(0, Math.min(1, ((x - h.x) * dx + (py - h.y) * dy) / len)) : 0;
    return dist(h.x + dx * t, h.y + dy * t, x, py);
  }

  // hole: vành khuyên — đứng trong lõi (bán kính hole) là an toàn.
  function inHazard(list, x, y) {
    for (var i = 0; i < list.length; i++) {
      var d = segDist(list[i], x, y);
      if (d < list[i].r && !(list[i].hole && d < list[i].hole)) return true;
    }
    return false;
  }

  // Chiêu boss có cảnh báo (BossTactics: Xích Mãng Vương, Thạch Mạch Vương, U Minh Cự Mãng…): đường thẳng / vòng …
  function bossTacticHazards(g, add) {
    var BT = g.P.BossTactics;
    (g.sw.enemies || []).forEach(function (e) {
      if (!e || e.dead || !e.def) return;
      var who = e.def.name ? ' của ' + e.def.name.split('·')[0].trim() : '';
      var mv = BT && BT.move && e.ctWind > 0 ? BT.move(e) : null;
      if (mv && isFinite(e.ctX) && isFinite(e.ctY)) {
        if (mv.shape === 'line') {
          var a = (e.ctAngle || 0) / 1000, c = Math.cos(a), sn = Math.sin(a);
          add(e.ctX, e.ctY, mv.width, e.ctX + c * mv.length, e.ctY + sn * mv.length / 2, e.ctWind, mv.name + who, { sy: 2 });
        } else {
          add(e.ctX, e.ctY, mv.radius, null, null, e.ctWind, mv.name + who,
            { sy: 2, hole: mv.shape === 'ring' ? Math.max(0, (mv.inner || 0) - cfg.dodgeMargin) : 0 });
        }
      }
      var bk = e.def.baoKich;
      if (bk && !(e.def.tranMach && !cfg.tmTru) && e._ttBkAt) {
        var isWb = isWorldBoss(g, e);
        // Với Boss thế giới: chỉ né bạo kích nếu máu nhân vật đang thấp (<= 45%)
        if (!isWb || (g.me && g.me.hpMax > 0 && g.me.hp / g.me.hpMax <= 0.45)) {
          var left = ((bk.hitsMax || 4) * (bk.gap || 0.55) + 0.4) - (now() - e._ttBkAt) / 1000;
          if (left > 0) add(e.x, e.y, bk.radius || 160, null, null, 0, (bk.ten || 'Bạo Kích') + who);
        }
      }
    });
  }

  /* ================= Trụ bắn (Trấn Sơn Bia, trụ Lâm Lang / Hư Thiên) ================= */
  // Trụ không cắn (contactDmg 0) nên các phần khác coi nó vô hại, nhưng cứ mỗi NHIP_MS nó bắn một …
  var TOWER_PAD = 24;        // px chừa ngoài tầm bắn của trụ
  var TOWER_TAM = 220;       // tầm mặc định khi game không cho số
  function towerSpec(P, m) {
    var t = m && m.type, src = null;
    if (t === 'yl_tran_son_bia' && P.YenLang) src = P.YenLang.BIA_BAN;
    else if ((t === 'htd_tru_bang' || t === 'htd_tru_hoa') && P.HuThien) src = P.HuThien.TRU_BAN;
    else if (P.LamLang) src = P.LamLang.TRU_BAN;
    return { tam: src && src.TAM || TOWER_TAM, nhip: src && src.NHIP_MS || 1500 };
  }
  function isTower(m) {
    if (!m || m.dead) return false;
    if (m.def && m.def.truBan) return true;
    if (m.type === 'htd_tru_bang' || m.type === 'htd_tru_hoa') return true;
    var P = window.PNTT;
    if (P && P.HuThien && typeof P.HuThien.laTru === 'function' && P.HuThien.laTru(m.type)) return true;
    return false;
  }
  // Các trụ còn sống thành vùng {x,y,x2,y2,r}; except: trụ đang là mục tiêu thì không tính.
  function towerZones(g, except) {
    var out = [];
    (g.sw.enemies || []).forEach(function (m) {
      if (!isTower(m) || m === except) return;
      var sp = towerSpec(g.P, m);
      out.push({
        x: m.x, y: m.y, x2: m.x, y2: m.y, r: sp.tam + TOWER_PAD, tower: m, tam: sp.tam,
        name: (m.def.name || 'Trụ').split('·')[0].trim()
      });
    });
    return out;
  }
  // Trụ cần tránh lúc này: mọi trụ trừ cái đang bị mình đánh.
  function towerAvoid(g) {
    var t = kiteTarget(g);
    return towerZones(g, isTower(t) ? t : null);
  }

  // Đứng trong tầm trụ mà không đánh trụ đó: ra ngoài tầm. Quái đang đuổi sẽ theo ra, thành ra
  // kéo được quái ra khỏi tầm trụ. Mục tiêu đứng yên trong tầm trụ thì thôi (đằng nào cũng phải vào).
  var TOWER_EXIT_REPLAN_MS = 1500;
  function tickTowerExit(g) {
    var me = g.me, zones = towerAvoid(g);
    var inside = zones.filter(function (z) { return dist(me.x, me.y, z.x, z.y) < z.r; });
    if (!inside.length) { st.towerOut = null; return false; }
    var t = kiteTarget(g);
    var follows = !t || t.state === 'chase' || t.state === 'attack' || !inHazard(zones, t.x, t.y);
    if (!follows) return false;
    var cur = st.towerOut;
    if (cur && me.path && me.path.length && now() - cur.at < TOWER_EXIT_REPLAN_MS && !inHazard(zones, cur.to.x, cur.to.y)) return true;
    var hz = hazards(g), out = function (x, y) { return !inHazard(zones, x, y) && !inHazard(hz, x, y); };
    var r = planEscape(g, threatsOf(g), out, { radius: 20, avoid: hz, wT: 1, wO: 1.2, wM: 0.4 }) ||
      escapePath(g, zones.concat(hz), 520, 24);
    if (!r) return false;
    moveFighting(g, r.path);
    st.towerOut = { to: r.to, at: now() };
    klog('Đang trong tầm ' + inside[0].name + ' (' + inside[0].tam + 'px) mà không đánh nó → ra ngoài ' +
      Math.round(dist(me.x, me.y, r.to.x, r.to.y)) + 'px' + (t && !isTower(t) ? ', kéo ' + (t.def ? mobLabel(t) : 'địch') + ' theo' : ''));
    return true;
  }

  // Tìm chỗ thoát ra ngoài mọi vùng trong list. Chỉ lấy điểm đứng được (không phải tường, …
  var OPEN_R = 48;      // bán kính đo độ thoáng quanh chỗ đứng
  var OPEN_COST = 20;   // mỗi hướng bị chặn quanh chỗ đứng tính như đi xa thêm chừng này px

  // Cổng / cổng chuyển cảnh kích hoạt khi chân đứng đúng ô đó; Truyền Tống Trận là vòng tròn
  // lớn tự đếm rồi chuyển map. Né hay lùi mà giẫm vào là bị đưa sang map khác.
  var PORTAL_R = 1.3;   // ô, quanh cổng / cổng chuyển cảnh
  var PAD_R = 2.6;      // ô, quanh Truyền Tống Trận

  function portalZones(g) {
    var map = g.sw.map, T = g.P.CONFIG.TILE || 32, out = [];
    function add(tx, ty, r) {
      var x = (tx + 0.5) * T, y = (ty + 0.5) * T;
      out.push({ x: x, y: y, x2: x, y2: y, r: r * T });
    }
    (map.portals || []).forEach(function (p) { add(p.tx, p.ty, PORTAL_R); });
    (map.warps || []).forEach(function (p) { add(p.tx, p.ty, PORTAL_R); });
    var TT = g.P.TruyenTong;
    if (TT && TT.PADS) TT.PADS.forEach(function (p) { if (p.map === g.mapId) add(p.tx, p.ty, PAD_R); });
    return out;
  }

  // Đường đi (từ chỗ đứng qua các điểm) có cắt vào vùng nào trong list không.
  function pathCrosses(g, path, list) {
    var px = g.me.x, py = g.me.y;
    for (var i = 0; i < path.length; i++) {
      var seg = { x: px, y: py, x2: path[i].x, y2: path[i].y };
      for (var j = 0; j < list.length; j++) {
        // khoảng cách từ tâm vùng tới đoạn đi = khoảng cách từ đoạn tới tâm
        if (segDist(seg, list[j].x, list[j].y) < list[j].r) return true;
      }
      px = path[i].x; py = path[i].y;
    }
    return false;
  }

  // Kiểm tra chỗ đứng: trong bản đồ, không phải tường, không dính cổng; route() thì kiểm tra
  // đúng điểm cuối của đường đi thật và đường đi không cắt ngang cổng.
  function spotCheck(g) {
    var me = g.me, map = g.sw.map, C = g.P.CONFIG.PLAYER, T = g.P.CONFIG.TILE || 32;
    var hw = C.HITBOX_W / 2, hh = C.HITBOX_H;
    // Đang đứng sẵn trong vùng cổng (vd. vừa qua cổng) thì không chặn đường ra khỏi đó.
    var portals = portalZones(g).filter(function (p) { return dist(p.x, p.y, me.x, me.y) >= p.r; });
    return {
      portals: portals,
      standable: function (x, y) {
        if (x < 0 || y < 0 || (map.pxWidth && x >= map.pxWidth) || (map.pxHeight && y >= map.pxHeight)) return false;
        if (inHazard(portals, x, y)) return false;
        return !map.rectBlocked || !map.rectBlocked(x - hw, y - hh, x + hw, y + hh);
      },
      crossesPortal: function (path) { return portals.length > 0 && pathCrosses(g, path, portals); },
      route: function (x, y) {
        var path = g.P.Pathfinder.route(map, me.x, me.y, x, y, hw, hh);
        if (!path || !path.length) return null;
        var end = path[path.length - 1];
        if (dist(end.x, end.y, x, y) > T || this.crossesPortal(path)) return null;
        return { to: { x: end.x, y: end.y }, path: path };
      }
    };
  }

  function escapePath(g, list, maxD, step) {
    var me = g.me, sc = spotCheck(g), portals = sc.portals, standable = sc.standable;
    function free(x, y) { return standable(x, y) && !inHazard(list, x, y); }
    var spots = [];
    for (var d = step; d <= maxD; d += step) {
      for (var i = 0; i < 24; i++) {
        var a = i / 24 * Math.PI * 2, x = me.x + Math.cos(a) * d, y = me.y + Math.sin(a) * d;
        if (!free(x, y)) continue;
        if (portals.length && pathCrosses(g, [{ x: x, y: y }], portals)) continue;
        var open = 0;
        for (var j = 0; j < 8; j++) {
          var b = j / 8 * Math.PI * 2;
          if (free(x + Math.cos(b) * OPEN_R, y + Math.sin(b) * OPEN_R)) open++;
        }
        spots.push({ x: x, y: y, score: d + (8 - open) * OPEN_COST });
      }
    }
    spots.sort(function (p, q) { return p.score - q.score; });
    for (var k = 0; k < spots.length && k < 12; k++) {
      var r = sc.route(spots[k].x, spots[k].y);
      if (r && !inHazard(list, r.to.x, r.to.y)) return r;
    }
    return null;
  }

  /* ================= Tìm đường thoát nhiều bước ================= */
  // Lưới ô quanh mình (Dijkstra): chỉ qua ô mình tới trước địch, chọn đích gần, thoáng, tới trước địch lâu nhất.
  var PLAN_R = 12;          // ô quanh mình được tính (lùi / thoát vây)
  var PASS_MARGIN = 0.15;   // giây: chỉ đi qua ô mình tới trước địch ít nhất chừng này
  var OPEN_CELLS = 2;       // ô: bán kính đo độ thoáng quanh chỗ đứng
  var MARGIN_CAP = 3;       // giây: tới trước địch lâu hơn thế không cộng thêm điểm
  var THREAT_SCAN = 480;    // px: địch xa hơn không tính vào thời gian tới

  function tileFree(g, sc, tx, ty) {
    var map = g.sw.map, T = g.P.CONFIG.TILE || 32;
    var W = map.width || Math.ceil((map.pxWidth || 0) / T), H = map.height || Math.ceil((map.pxHeight || 0) / T);
    if (tx < 0 || ty < 0 || (W && tx >= W) || (H && ty >= H)) return false;
    if (map.isBlockedTile && map.isBlockedTile(tx, ty)) return false;
    return !inHazard(sc.portals, (tx + 0.5) * T, (ty + 0.5) * T);
  }

  // Độ thoáng của một chỗ đứng, 0..1: nửa là khoảng cách tới tường gần nhất (tới CLEAR_CAP ô), …
  var CLEAR_CAP = 4;        // ô: cách tường từ chừng này trở lên coi là giữa bãi
  function roomScore(clear, freeFrac) { return 0.5 * Math.min(clear, CLEAR_CAP) / CLEAR_CAP + 0.5 * freeFrac; }

  function openAt(g, sc, x, y) {
    var T = g.P.CONFIG.TILE || 32, tx = Math.floor(x / T), ty = Math.floor(y / T), open = 0, n = 0, clear = CLEAR_CAP;
    for (var dy = -CLEAR_CAP; dy <= CLEAR_CAP; dy++) {
      for (var dx = -CLEAR_CAP; dx <= CLEAR_CAP; dx++) {
        if (!dx && !dy) continue;
        var ring = Math.max(Math.abs(dx), Math.abs(dy)), ok = tileFree(g, sc, tx + dx, ty + dy);
        if (!ok && ring <= clear) clear = ring - 1;
        if (ring <= OPEN_CELLS) { n++; if (ok) open++; }
      }
    }
    return roomScore(clear, open / n);
  }

  function threatsOf(g) {
    var me = g.me, C = g.P.CONFIG.PLAYER, out = [];
    mobsAlive(g).forEach(function (m) {
      if (!(m.def.contactDmg > 0) || dist(me.x, me.y, m.x, m.y) > THREAT_SCAN) return;
      var v = (m.def.speed || 40) * (m.slowT > 0 && m.slowMult ? m.slowMult : 1);
      if (m.stunT > 0 || m.freezeT > 0) v *= 0.3;
      out.push({ x: m.x, y: m.y, reach: mobBaseReach(g, m), v: Math.max(1, v) });
    });
    hostilePlayers(g).forEach(function (r) {
      if (dist(me.x, me.y, r.x, r.y) > THREAT_SCAN) return;
      out.push({ x: r.x, y: r.y, reach: enemyReach(g, r), v: C.SPEED * (C.RUN_MULT || 1) });
    });
    return out;
  }

  // goal(x, y): ô đích hợp lệ. opt: radius (ô), maxTime (giây, giới hạn quãng đi), avoid (vùng
  // cấm thêm), wT / wO / wM: trọng số thời gian đi, độ thoáng, khoảng tới trước địch.
  function planEscape(g, threats, goal, opt) {
    var me = g.me, map = g.sw.map, P = g.P, T = P.CONFIG.TILE || 32, C = P.CONFIG.PLAYER;
    var v = Math.max(1, (me.speed || C.SPEED) * (P.Input.run ? C.RUN_MULT || 1 : 1));
    var R = opt.radius || PLAN_R, S = 2 * R + 1, N = S * S;
    var ptx = Math.floor(me.x / T), pty = Math.floor(me.y / T), ox = ptx - R, oy = pty - R;
    var sc = spotCheck(g), avoid = opt.avoid || [];
    var freeC = new Int8Array(N), cost = new Float64Array(N), par = new Int32Array(N), done = new Uint8Array(N);
    for (var q = 0; q < N; q++) { cost[q] = Infinity; par[q] = -1; }
    function at(tx, ty) { var lx = tx - ox, ly = ty - oy; return lx < 0 || ly < 0 || lx >= S || ly >= S ? -1 : ly * S + lx; }
    function free(tx, ty) {
      var i = at(tx, ty);
      if (i < 0) return false;
      if (!freeC[i]) freeC[i] = tileFree(g, sc, tx, ty) ? 1 : 2;
      return freeC[i] === 1;
    }
    function center(i) { return { x: (ox + i % S + 0.5) * T, y: (oy + (i / S | 0) + 0.5) * T }; }
    // Khoảng cách tới tường của mọi ô trong lưới: loang từ các ô bị chặn ra (BFS 8 hướng).
    var clr = new Int8Array(N), wave = [];
    for (var q2 = 0; q2 < N; q2++) {
      if (free(ox + q2 % S, oy + (q2 / S | 0))) clr[q2] = CLEAR_CAP; else { clr[q2] = 0; wave.push(q2); }
    }
    for (var h = 0; h < wave.length; h++) {
      var wi = wave[h], wc = clr[wi] + 1;
      if (wc >= CLEAR_CAP) continue;
      var wx = wi % S, wy = wi / S | 0;
      for (var ey = -1; ey <= 1; ey++) {
        for (var ex = -1; ex <= 1; ex++) {
          var nx2 = wx + ex, ny2 = wy + ey;
          if (nx2 < 0 || ny2 < 0 || nx2 >= S || ny2 >= S) continue;
          var wj = ny2 * S + nx2;
          if (clr[wj] > wc) { clr[wj] = wc; wave.push(wj); }
        }
      }
    }
    function room(i) {
      var tx = ox + i % S, ty = oy + (i / S | 0), open = 0, n = 0;
      for (var dy = -OPEN_CELLS; dy <= OPEN_CELLS; dy++) {
        for (var dx = -OPEN_CELLS; dx <= OPEN_CELLS; dx++) {
          if (!dx && !dy) continue;
          n++;
          if (free(tx + dx, ty + dy)) open++;
        }
      }
      return roomScore(clr[i], open / n);
    }
    function foeTime(x, y) {
      var t = Infinity;
      for (var k = 0; k < threats.length; k++) {
        var m = threats[k];
        t = Math.min(t, Math.max(0, dist(x, y, m.x, m.y) - m.reach) / m.v);
      }
      return t;
    }
    // Hàng đợi ưu tiên nhỏ theo cost.
    var heap = [];
    function push(i) {
      heap.push(i);
      for (var c = heap.length - 1; c > 0;) {
        var p = (c - 1) >> 1;
        if (cost[heap[p]] <= cost[heap[c]]) break;
        var tmp = heap[p]; heap[p] = heap[c]; heap[c] = tmp; c = p;
      }
    }
    function pop() {
      var top = heap[0], last = heap.pop();
      if (heap.length) {
        heap[0] = last;
        for (var c = 0; ;) {
          var l = 2 * c + 1, r = l + 1, m = c;
          if (l < heap.length && cost[heap[l]] < cost[heap[m]]) m = l;
          if (r < heap.length && cost[heap[r]] < cost[heap[m]]) m = r;
          if (m === c) break;
          var tmp = heap[m]; heap[m] = heap[c]; heap[c] = tmp; c = m;
        }
      }
      return top;
    }
    var start = at(ptx, pty), best = -1, bestScore = Infinity, bestInfo = null;
    cost[start] = 0;
    push(start);
    while (heap.length) {
      var i = pop();
      if (done[i]) continue;
      done[i] = 1;
      var tx = ox + i % S, ty = oy + (i / S | 0), c0 = center(i), myT = cost[i] * T / v;
      if (opt.maxTime && myT > opt.maxTime) continue;
      if (i !== start) {
        var ft = foeTime(c0.x, c0.y);
        if (ft - myT < PASS_MARGIN || inHazard(avoid, c0.x, c0.y)) continue; // không đi qua được ô này
        if (goal(c0.x, c0.y)) {
          var open = room(i), lead = Math.min(ft - myT, MARGIN_CAP);
          var score = opt.wT * myT - opt.wO * open - opt.wM * lead;
          if (!(opt.minRoom && open < opt.minRoom) && score < bestScore) {
            bestScore = score; best = i; bestInfo = { open: open, lead: lead, time: myT };
          }
        }
      }
      for (var dy = -1; dy <= 1; dy++) {
        for (var dx = -1; dx <= 1; dx++) {
          if (!dx && !dy) continue;
          var nx = tx + dx, ny = ty + dy;
          if (!free(nx, ny)) continue;
          if (dx && dy && (!free(tx + dx, ty) || !free(tx, ty + dy))) continue; // không cắt góc tường
          var j = at(nx, ny), nc = cost[i] + (dx && dy ? Math.SQRT2 : 1);
          if (nc < cost[j]) { cost[j] = nc; par[j] = i; push(j); }
        }
      }
    }
    if (best < 0) return null;
    var cells = [];
    for (var cc = best; cc !== start && cc >= 0; cc = par[cc]) cells.push(center(cc));
    cells.reverse();
    // Rút gọn đường: nhảy thẳng tới điểm xa nhất còn đi thẳng được mà không lướt qua tầm với địch.
    var hw = C.HITBOX_W / 2, hh = C.HITBOX_H, path = [], fx = me.x, fy = me.y, k = 0;
    function straightOk(ax, ay, b) {
      if (map.lineClear && !map.lineClear(ax, ay, b.x, b.y, hw, hh)) return false;
      var seg = { x: ax, y: ay, x2: b.x, y2: b.y };
      return !threats.some(function (m) { return segDist(seg, m.x, m.y) < m.reach; });
    }
    while (k < cells.length) {
      var far = k;
      for (var jj = cells.length - 1; jj > k; jj--) if (straightOk(fx, fy, cells[jj])) { far = jj; break; }
      path.push(cells[far]);
      fx = cells[far].x; fy = cells[far].y;
      k = far + 1;
    }
    var to = cells[cells.length - 1];
    return { to: to, path: path, open: bestInfo.open, lead: bestInfo.lead, time: bestInfo.time };
  }

  // Chỗ đứng cách mục tiêu trong khoảng [lo, hi], ưu tiên gần chỗ mình đang đứng và thoáng (để
  // còn đường lùi tiếp), tránh các vùng trong avoid (chiêu đang chờ nổ, tầm với của địch khác).
  var RING_OPEN_COST = 120; // px: chỗ kín hẳn (0% thoáng) tính như đi xa thêm chừng này
  function ringPath(g, t, lo, hi, avoid, keep) {
    var me = g.me, sc = spotCheck(g), mid = (lo + hi) / 2, spots = [];
    var a0 = Math.atan2(me.y - t.y, me.x - t.x);
    for (var k = 0; k <= 12; k++) {
      var off = (k % 2 ? 1 : -1) * Math.ceil(k / 2) * Math.PI / 12; // 0, ±15°, ±30°… ±90°
      var x = t.x + Math.cos(a0 + off) * mid, y = t.y + Math.sin(a0 + off) * mid;
      if (!sc.standable(x, y) || inHazard(avoid, x, y) || (keep && !keep(x, y))) continue;
      spots.push({ x: x, y: y, d: dist(me.x, me.y, x, y) + (1 - openAt(g, sc, x, y)) * RING_OPEN_COST });
    }
    spots.sort(function (p, q) { return p.d - q.d; });
    for (var i = 0; i < spots.length && i < 6; i++) {
      var r = sc.route(spots[i].x, spots[i].y), e = r && dist(r.to.x, r.to.y, t.x, t.y);
      if (r && e >= lo - 6 && e <= hi + 6 && !inHazard(avoid, r.to.x, r.to.y)) return r;
    }
    return null;
  }

  // Đi như khi chạm đất trong lúc Tự Động: game bật tuChiDuong thì auto vẫn đánh / ra chiêu
  // nhưng không giật đường đi lại, nên không phải tắt auto.
  function moveFighting(g, path) {
    if (g.me.state === 'sit') g.P.Player.stand(g.me);
    if ((g.sw.fishing || g.sw.fishingAuto) && g.sw.stopFishing) g.sw.stopFishing(); // đang câu thì nhân vật đứng yên, phải thôi câu mới đi được
    g.sw.tuChiDuong = true;
    g.me.setPath(path);
  }

  // Né: chạy dày (vòng 50ms), chọn lối ra gần nhất (dò từng 12px trước, xa dần), và huỷ đòn …
  var DODGE_NEAR = 240;   // px dò lối ra mịn trước
  var DODGE_FAR = 680;    // px dò thêm (bước thô) khi gần không có lối ra
  function tickDodge(g) {
    var me = g.me;
    if (!cfg.dodge || g.P.Input.hasManualMove()) { st.dodging = false; st.dodgeFar = false; return false; }
    var list = hazards(g);
    if (!inHazard(list, me.x, me.y)) {
      if (st.dodging) { st.dodging = false; st.dodgeTo = null; st.routeTo = null; st.dodgeFar = false; }
      return false;
    }
    var inBossFight = !!(worldBossNear(g) || (st.bh && st.bh.boss) || nearBoss(g) || (me.attackTarget && (isBoss(me.attackTarget) || isWorldBoss(g, me.attackTarget))));
    if (me.state === 'attack' && !me.attackFired) {
      me.state = 'idle';
      me.attackTime = 0;
      klog('Huỷ đòn chém đang vung để né' + (inBossFight ? ' chiêu Boss' : ''));
    }
    var t = st.dodgeTo;
    if (st.dodging && t && me.path && me.path.length && !inHazard(list, t.x, t.y)) return true;
    var r = escapePath(g, list, DODGE_NEAR, 12) || escapePath(g, list, DODGE_FAR, 40);
    if (!r) { klog('Không có lối ra khỏi vùng chiêu'); return st.dodging; }
    moveFighting(g, r.path);
    st.dodgeTo = r.to;
    // Ghi đòn sắp nổ sớm nhất mà mình đang đứng trong.
    var hit = list.filter(function (h) { return segDist(h, me.x, me.y) < h.r; })
      .sort(function (a, b) { return (a.t == null ? 99 : a.t) - (b.t == null ? 99 : b.t); })[0];
    var C = g.P.CONFIG.PLAYER, v = (me.speed || C.SPEED) * (g.P.Input.run ? C.RUN_MULT || 1 : 1);
    var need = dist(me.x, me.y, r.to.x, r.to.y);
    klog('Né ' + (hit && hit.what || 'chiêu') + (hit && hit.t != null ? ': còn ' + Math.max(0, hit.t).toFixed(2) + 's' : '') +
      ', chạy ' + Math.round(need) + 'px (~' + (need / Math.max(1, v)).toFixed(2) + 's)');
    if (!st.dodging) say('Né ' + (hit && hit.what || 'chiêu địch'));
    st.dodging = true;
    st.dodgeFar = need > 120;
    // Chạy bộ không kịp ra trước lúc nổ: lướt Thổ Độn theo đường thoát vừa đặt.
    if (cfg.autoDash && hit && hit.t != null && need / Math.max(1, v) > hit.t - 0.1) talUse(g, 'tho_don', 'không kịp né ' + (hit.what || 'chiêu'));
    return true;
  }

  /* ================= Đánh rồi lùi (hit & run) ================= */
  // Lùi theo đòn của chính mình (trạng thái gồng của quái về máy muộn): đòn chém trúng giữa động tác / chiêu vừa ra thì lùi
  // ra ngoài tầm địch trong kiteOut ms rồi áp lại. Quái vừa chém mình thì đang hồi đòn: đứng đánh. Người chơi vung đòn thì lùi.
  var KITE_SAFE_MS = 250;    // bỏ bớt cuối thời gian hồi đòn của quái cho kịp lùi
  var KITE_FAST_MS = 50;     // kiểm tra dày hơn vòng chính
  var KITE_REPLAN_MS = 1500; // đi tới chỗ lùi lâu hơn chừng này mà chưa thoát thì tìm chỗ khác
  var KITE_SCAN = 60;        // px ngoài tầm với của địch vẫn tính là đang áp sát
  // Địch tầm xa thì không chạy mãi: chỉ lùi khi ra khỏi tầm nó kịp trong kiteOut, không thì đứng
  // đánh. Lùi liên tục lâu mà mình không ra được đòn nào thì tạm thôi lùi cho auto áp vào đánh.
  var KITE_STARVE_MS = 2500; // lùi suốt chừng này mà chưa ra đòn → tạm thôi lùi
  var KITE_ENGAGE_MS = 1200; // thời gian để auto áp vào ra đòn trước khi lại được lùi
  var KITE_GAP_SHARE = 0.75; // khoảng cách đứng ngoài tối đa = phần này của quãng lùi tối đa
  var KITE_SEARCH_PAD = 36;  // dò chỗ lùi xa hơn quãng lùi một chút (lùi chéo, né vật cản)
  // Một nhịp lùi: bắt đầu khi đòn / chiêu của mình ra, lùi tới khi ra khỏi tầm địch, rồi đứng
  // ngoài thêm kiteOut ms mới áp vào lại. Quãng lùi không phụ thuộc kiteOut.
  var KITE_MAX_RETREAT = 160;   // px: lùi xa nhất một nhịp
  var KITE_RUN_TIMEOUT_MS = 2000; // lùi mãi chưa ra khỏi tầm thì thôi nhịp đó
  var lastStrikeAt = 0, sawFired = false, kitePauseUntil = 0, outAt = 0;

  // Nhật ký hit & run: lý do lùi / không lùi, gộp dòng lặp lại liền nhau.
  var KLOG_MAX = 150;
  var kiteLog = [], kiteNow = '';
  // Loại dòng log để lọc trong tab Log.
  function logCat(msg) {
    if (/^\[(Mạng|Server|Gói|WebSocket|Packet)\]/i.test(msg)) return 'net';
    if (/^\[(Dược Công|Lịch|Tông môn|Vận Tiêu|Điểm danh|Tàng Kinh|Lãm Làng|Sỹ Sách Điện)\]/.test(msg)) return 'dc';
    if (/^\[Nhặt NL\]|^\[Vườn\]|^Quét|nhặt|Đi thu|Thu |Đã thu|Vận |vận |tài nguyên/.test(msg)) return 'loot';
    return 'fight';
  }
  function klog(msg) {
    var last = kiteLog[kiteLog.length - 1];
    if (last && last.msg === msg) { last.n++; last.at = new Date(); return; }
    kiteLog.push({ at: new Date(), msg: msg, n: 1, cat: logCat(msg) });
    if (kiteLog.length > KLOG_MAX) kiteLog.shift();
  }

  function markSwing(m) { m._ttSwing = now(); }

  // Thời điểm đòn của mình thật sự ra: đòn chém lúc attackFired bật, chiêu lúc castSpell thành công.
  function tickStrike(g) {
    var me = g.me, fired = me.state === 'attack' && !!me.attackFired;
    if (fired && !sawFired) {
      lastStrikeAt = now();
      var at = me.attackTarget;
      pendingSwing = { at: lastStrikeAt, hit: false, name: at && at.def ? at.def.name : at && at.name };
      splashSwing(g);
    }
    sawFired = fired;
  }

  // Người chơi thù địch đang ở gần (đấu, PK tự do, đồ sát…) theo đúng luật game.
  function hostilePlayers(g) {
    var G = g.P.Gateway, T = g.P.Targeting, out = [];
    if (!G || !G.remotes || !T || !T.thuDich) return out;
    Object.keys(G.remotes).forEach(function (id) {
      var r = G.remotes[id];
      try { if (r && !r.downed && T.thuDich(r)) out.push(r); } catch (e) { }
    });
    return out;
  }

  // Theo dõi nhịp gồng và vận tốc của từng con quái (để đón đầu khi nó đang chạy).
  var VEL_SMOOTH = 0.5;      // trộn vận tốc mới với cũ cho đỡ giật
  function tickSwings(g) {
    var t = now();
    (g.sw.enemies || []).forEach(function (m) {
      if (!m) return;
      if (m.def && m.def.baoKich) {
        if (m._ttBk != null && m.bkSeq !== m._ttBk) { m._ttBkAt = now(); klog('Boss ' + mobLabel(m) + ' gầm · ' + (m.def.baoKich.ten || 'Bạo Kích') + ' → ra khỏi vòng ' + (m.def.baoKich.radius || 160) + 'px'); }
        m._ttBk = m.bkSeq;
      }
      var tg = m.attackState === 'telegraph';
      if (m._ttTg && !tg) markSwing(m);
      m._ttTg = tg;
      if (m._tpt == null || m.dead) { m._tpx = m.x; m._tpy = m.y; m._tpt = t; m._vx = 0; m._vy = 0; return; }
      var dt = (t - m._tpt) / 1000;
      if (dt < 0.03) return;
      var vx = (m.x - m._tpx) / dt, vy = (m.y - m._tpy) / dt;
      m._vx = m._vx * (1 - VEL_SMOOTH) + vx * VEL_SMOOTH;
      m._vy = m._vy * (1 - VEL_SMOOTH) + vy * VEL_SMOOTH;
      m._tpx = m.x; m._tpy = m.y; m._tpt = t;
    });
  }

  /* --- chém trúng / chém hụt --- */
  // Đòn chém chỉ tính trúng lúc attackFired (giữa động tác). Quái đang chạy ra khỏi tầm thì tới …
  var SWING_SLACK = 6;        // px dư cho tầm chém
  var SWING_CONFIRM_MS = 500; // chờ số sát thương báo về (online có độ trễ mạng)
  var CHASE_REPATH_MS = 250;
  var pendingSwing = null, chaseAt = 0, chaseLogAt = 0;

  function swingWouldMiss(g, pl, t) {
    if (!t || !t.def || t.dead || t._vx == null) return null;
    var PL = g.P.Player;
    var tf = (PL.attackTime ? PL.attackTime() : 0.8) * (PL.hitAt ? PL.hitAt() : 0.35);
    var px = t.x + t._vx * tf, py = t.y + t._vy * tf;
    var reach = (PL.reach ? PL.reach() : 26) + (t.def.bodyRadius || 0) + SWING_SLACK;
    return dist(pl.x, pl.y, px, py) > reach ? { x: px, y: py } : null;
  }

  function chaseTo(g, t, p) {
    if (now() - chaseAt < CHASE_REPATH_MS) return;
    chaseAt = now();
    var r = spotCheck(g).route(p.x, p.y);
    if (r) moveFighting(g, r.path);
    if (now() - chaseLogAt > 1500) {
      chaseLogAt = now();
      klog((t.def.name || 'Quái') + (t.state === 'return' ? ' đang chạy về chỗ cũ' : ' đang chạy ra khỏi tầm') + ' → đón đầu, không chém hụt');
    }
  }

  function noteSwingHit() {
    if (pendingSwing && !pendingSwing.hit && now() - pendingSwing.at < SWING_CONFIRM_MS + 300) {
      pendingSwing.hit = true;
      if (cfg.kite) klog('Đòn chém trúng');
    }
  }

  // Hụt thì huỷ nhịp lùi của đòn đó: áp vào lại ngay chứ không chạy ra vô ích.
  function tickSwingConfirm() {
    var p = pendingSwing;
    if (!p || p.hit || now() - p.at < SWING_CONFIRM_MS) return;
    pendingSwing = null;
    if (!cfg.kite) return;
    klog('Chém hụt' + (p.name ? ' (' + p.name + ' ra khỏi tầm)' : '') + ' → huỷ lùi, áp vào lại');
    if (lastStrikeAt === p.at) lastStrikeAt = 0;
    st.kiting = false;
    // Hụt liên tục (quái đuổi theo nhịp lùi nên lúc áp vào nó đã dịch đi): thôi đánh-lùi một lúc, đứng đánh cho trúng.
    missTimes.push(now());
    while (missTimes.length && now() - missTimes[0] > MISS_WIN_MS) missTimes.shift();
    if (missTimes.length >= MISS_MAX && now() >= kitePauseUntil) {
      kitePauseUntil = now() + MISS_PAUSE_MS;
      missTimes.length = 0;
      klog('Chém hụt ' + MISS_MAX + ' lần trong ' + MISS_WIN_MS / 1000 + 's → thôi đánh-lùi ' + MISS_PAUSE_MS / 1000 + 's, đứng đánh cho trúng');
    }
  }
  var MISS_WIN_MS = 20000, MISS_MAX = 3, MISS_PAUSE_MS = 25000, missTimes = [];

  function mobBaseReach(g, m) {
    return (m.def.hitRadius || (g.P.CONFIG.ENEMY && g.P.CONFIG.ENEMY.HIT_RADIUS) || 26) + BODY_R;
  }

  function anyBossNear(g, customR) {
    if (!g || !g.me) return null;
    var me = g.me, R = customR || WORLD_BOSS_R;
    return mobsAlive(g).filter(function (m) {
      return (isBoss(m) || isWorldBoss(g, m)) && dist(me.x, me.y, m.x, m.y) <= R;
    })[0] || null;
  }

  function tickKite(g) {
    var me = g.me;
    if (!cfg.kite) { st.kiting = false; kiteNow = 'Đang tắt'; return false; }
    var kt0 = kiteTarget(g);
    if (kt0 && kt0.ctRecover > 0) { st.kiting = false; kiteNow = mobLabel(kt0) + ' đang SƠ HỞ (+25% sát thương) → đứng dồn đánh'; return false; }
    var wbk = worldBossNear(g) || (st.bh && st.bh.boss) || (kt0 && (isBoss(kt0) || isWorldBoss(g, kt0))) || anyBossNear(g) || nearBoss(g);
    if (wbk && !(now() < (st.reviveGraceUntil || 0) && me.hp / (me.hpMax || 1) < 0.40)) { st.kiting = false; kiteNow = 'Đang đánh Boss: dồn sát thương liên tục (không lùi, chỉ né skill)'; return false; }
    if (dmgOnly(g) && kt0 && isBoss(kt0) && me.hp > (me.hpMax || 1) * 0.4) { st.kiting = false; kiteNow = 'Hoạt động chia thưởng theo sát thương, không rơi đồ → đứng dồn sát thương (né chiêu vẫn chạy)'; return false; }
    if (st.vn && st.vn.inside) { st.kiting = false; kiteNow = 'Vết Nứt: tự đi / tự đánh theo mê cung → không lùi'; return false; }
    if (st.ll && (st.ll.hold > now() || st.ll.boss)) { st.kiting = false; kiteNow = 'Lãm Làng: đánh Tà Soái / giữ chỗ hợp lực → không lùi'; return false; }
    if (!g.sw.autoOn) { st.kiting = false; kiteNow = 'Không lùi: Tự Động đang tắt'; return false; }
    if (g.P.Input.hasManualMove()) { st.kiting = false; kiteNow = 'Không lùi: bạn đang tự điều khiển'; return false; }
    if (now() < kitePauseUntil) { st.kiting = false; kiteNow = 'Tạm thôi lùi, để auto áp vào đánh'; return false; }
    if (st.kiting && now() - st.kiteSince > KITE_STARVE_MS && now() - lastStrikeAt > KITE_STARVE_MS) {
      kitePauseUntil = now() + KITE_ENGAGE_MS;
      st.kiting = false;
      klog('Lùi ' + (KITE_STARVE_MS / 1000) + 's chưa ra được đòn → thôi lùi ' + (KITE_ENGAGE_MS / 1000) + 's để áp vào');
      return false;
    }
    var danger = [], PL = g.P.Player, myReach = PL.reach ? PL.reach() : 0;
    var C = g.P.CONFIG.PLAYER, v = (me.speed || C.SPEED) * (g.P.Input.run ? C.RUN_MULT || 1 : 1);
    var maxStep = KITE_MAX_RETREAT;
    // Đang vung đòn chém mà đòn chưa trúng thì đứng yên cho trúng đã.
    var winding = me.state === 'attack' && !me.attackFired;
    // Đang trong nhịp lùi: từ lúc ra đòn tới khi đã đứng ngoài tầm địch đủ kiteOut ms.
    var sinceStrike = now() - lastStrikeAt, wasOut = outAt > lastStrikeAt;
    var running = !winding && lastStrikeAt > 0 && sinceStrike < KITE_RUN_TIMEOUT_MS &&
      !(wasOut && now() - outAt >= cfg.kiteOut);
    // Đứng ngoài tầm địch mà vẫn phải trong tầm mình thì mới đánh được.
    var near = null, why = [];
    function zone(x, y, base, body, swinging, resting, name) {
      var mine = myReach + (body || 0), outrange = mine > base + 4;
      // Khoảng cách đặt lớn hơn quãng lùi được thì thu lại cho vừa, không bỏ hẳn hit & run.
      var gap = Math.min(cfg.kiteGap, maxStep * KITE_GAP_SHARE);
      var r = outrange ? Math.min(base + gap, mine - 2) : base + gap;
      var d = dist(me.x, me.y, x, y);
      if (d >= r + KITE_SCAN) return;
      if (!near || d < near.d) near = { d: d, r: r, name: name };
      if (base - d > maxStep) { // chính tầm đánh của nó đã xa hơn quãng lùi được: đứng đánh
        why.push(name + ': tầm đánh ' + Math.round(base) + 'px, lùi tối đa ' + Math.round(maxStep) + 'px không ra kịp → đứng đánh');
        return;
      }
      if (swinging || (!resting && !winding && (running || outrange))) danger.push({ x: x, y: y, x2: x, y2: y, r: r });
      else if (resting) why.push(name + ' đang hồi đòn → đứng đánh');
    }
    mobsAlive(g).forEach(function (m) {
      if ((isBoss(m) || isWorldBoss(g, m)) && !(now() < (st.reviveGraceUntil || 0) && me.hp / (me.hpMax || 1) < 0.40)) return; // Tuyệt đối không thêm vùng né đòn đánh thường & va chạm của Boss (trừ lúc vừa gượng dậy máu thấp)
      if (!(m.def.contactDmg > 0)) return;
      var swinging = m.attackState === 'telegraph';
      var cdMs = (m.def.hitCooldown || 1) * 1000;
      var resting = !swinging && m._ttSwing && now() - m._ttSwing < cdMs - KITE_SAFE_MS;
      zone(m.x, m.y, mobBaseReach(g, m), m.def.bodyRadius, swinging, resting, m.def.name || 'Quái');
    });
    hostilePlayers(g).forEach(function (r) {
      var reach = (PL.reachOf ? PL.reachOf(r.cfg) : g.P.CONFIG.PLAYER.REACH) + BODY_R;
      zone(r.x, r.y, reach, 0, r.state === 'attack', false, r.name || 'Người chơi');
    });
    // Ra tới ngoài tầm địch trong nhịp lùi: bắt đầu đếm thời gian đứng ngoài.
    var outNow = !inHazard(danger, me.x, me.y);
    if (running && outNow && !wasOut) { outAt = now(); wasOut = true; }
    var phase = winding ? ' · đang vung đòn' : !running ? '' :
      wasOut ? ' · đứng ngoài ' + Math.round(now() - outAt) + '/' + cfg.kiteOut + 'ms' : ' · đang lùi ra';
    kiteNow = (near ? near.name + ' cách ' + Math.round(near.d) + 'px, vùng né ' + Math.round(near.r) + 'px' : 'Không có địch gần') +
      ' · tầm mình ' + Math.round(myReach) + ' · lùi tối đa ' + Math.round(maxStep) + 'px' + phase;
    // Đang đi tới chỗ lùi mà chỗ đó vẫn ổn thì đi tiếp; đi quá lâu (bị thân quái chặn) thì tính lại.
    var t = st.kiteTo;
    var going = st.kiting && t && me.path && me.path.length && now() - st.kiteAt < KITE_REPLAN_MS &&
      !inHazard(danger, t.x, t.y);
    if (!going && !winding && tickCorner(g, danger)) return true;
    if (!inHazard(danger, me.x, me.y)) {
      if (going) return true;
      if (running && why.length) klog(why[0]);
      st.kiting = false;
      // Đòn / chiêu vừa ra thì không áp vào ngay; hết thời gian đứng ngoài mới tính chỗ đứng đánh.
      if (winding || running) return false;
      if (st.looting) { kiteNow += ' · đang đi nhặt đồ'; return false; }
      return tickEngage(g, myReach, maxStep);
    }
    st.engaging = false;
    if (going) return true;
    var r = kiteRetreat(g, danger, maxStep, v);
    if (!r) { klog('Không còn đường lùi (tường / cổng / địch vây kín) → đứng đánh'); return false; }
    klog(r.label + ' ' + Math.round(dist(me.x, me.y, r.to.x, r.to.y)) + 'px' + (near ? ' khỏi ' + near.name : '') +
      (r.open != null ? ' · chỗ tới thoáng ' + Math.round(r.open * 100) + '%' : ''));
    moveFighting(g, r.path);
    st.kiteTo = r.to;
    st.kiteAt = now();
    if (!st.kiting) st.kiteSince = now();
    st.kiting = true;
    return true;
  }

  // Lùi sau đòn: trước hết lùi ngắn (trong quãng lùi được) tới chỗ thoáng; nếu chỗ lùi ngắn
  // nào cũng hẹp / không có thì chạy thoát vây ra chỗ rộng, tới trước địch lâu nhất.
  var KITE_MIN_OPEN = 0.6;   // chỗ lùi ngắn hẹp hơn thế thì tính đường thoát xa
  // Độ thoáng nặng hơn thời gian đi: tới gần tường thì lùi vòng sang bên ra chỗ rộng thay vì lùi
  // thẳng (quái luôn đuổi từ một phía, lùi thẳng mãi là bị ép vào tường rồi vào góc).
  var KITE_W_ROOM = 2.0, FAR_W_ROOM = 2.5;

  // Quái bị kéo ra quá leashRange quanh chỗ sinh thì bỏ đuổi, chạy về chỗ cũ; mình đuổi theo là
  // chém hụt và mất mục tiêu. Chỗ đứng / chỗ lùi phải nằm trong vùng đó của mục tiêu.
  var LEASH_PAD = 40;        // px chừa trong mép vùng hoạt động của quái
  function leashKeep(g, t) {
    if (!t || !t.def || !isFinite(t.homeX) || !isFinite(t.homeY)) return null;
    var L = (t.def.leashRange || g.P.CONFIG.ENEMY.LEASH_RANGE || 260) - LEASH_PAD;
    return function (x, y) { return dist(x, y, t.homeX, t.homeY) <= L; };
  }
  function both(a, b) { return b ? function (x, y) { return a(x, y) && b(x, y); } : a; }

  function kiteRetreat(g, danger, maxStep, v) {
    var threats = threatsOf(g), hz = hazards(g), keep = leashKeep(g, kiteTarget(g)), tw = towerAvoid(g);
    function outside(x, y) { return !inHazard(danger, x, y) && !inHazard(tw, x, y); }
    function tryGoal(goal) {
      var r = planEscape(g, threats, goal, { maxTime: (maxStep + KITE_SEARCH_PAD) / v, avoid: hz, wT: 1, wO: KITE_W_ROOM, wM: 0.25 });
      if (r && r.open >= KITE_MIN_OPEN) { r.label = 'Lùi'; return r; }
      var far = planEscape(g, threats, goal, { avoid: hz, wT: 0.3, wO: FAR_W_ROOM, wM: 0.8 });
      if (far) { far.label = 'Thoát vây, chạy'; return far; }
      if (r) { r.label = 'Lùi'; return r; }
      return null;
    }
    // Ưu tiên giữ quái trong vùng của nó; hết chỗ thì an toàn của mình trước.
    var r = (keep && tryGoal(both(outside, keep))) || tryGoal(outside);
    if (r) return r;
    var e = escapePath(g, danger.concat(hz, tw), maxStep + KITE_SEARCH_PAD, 12);
    if (e) e.label = 'Lùi';
    return e;
  }

  // Đứng chỗ hẹp (sát tường, trong góc) mà địch đang áp tới: chạy ra chỗ rộng trước khi bị vây.
  var CORNER_SCAN = 90;      // px ngoài tầm với của địch vẫn tính là đang áp tới
  var CORNER_OPEN = 0.55;    // thoáng dưới mức này là chỗ hẹp
  var CROWD_OPEN = 0.8;      // bị nhiều con áp thì đòi chỗ thoáng hơn
  var CROWD_N = 3;
  var SPACIOUS = 0.75;       // chỗ chạy tới phải thoáng ít nhất chừng này
  var CORNER_COOLDOWN_MS = 1500;
  function tickCorner(g, danger) {
    if (now() < st.cornerUntil) return false;
    var me = g.me, sc = spotCheck(g), here = openAt(g, sc, me.x, me.y), threats = threatsOf(g);
    var close = threats.filter(function (m) { return dist(me.x, me.y, m.x, m.y) < m.reach + CORNER_SCAN; }).length;
    // Một con đuổi thì đứng chỗ hẹp vẫn đánh được (map hang động chỗ nào cũng hẹp, chạy ra chạy vào chỉ mất nhịp đánh).
    if (close < 2 || !((here < CORNER_OPEN) || (close >= CROWD_N && here < CROWD_OPEN))) return false;
    var tw = towerAvoid(g);
    var roomy = function (x, y) { return !inHazard(danger, x, y) && !inHazard(tw, x, y) && openAt(g, sc, x, y) >= SPACIOUS; };
    var keep = leashKeep(g, kiteTarget(g)), opt = { avoid: hazards(g), wT: 0.4, wO: FAR_W_ROOM, wM: 0.6 };
    var r = (keep && planEscape(g, threats, both(roomy, keep), opt)) || planEscape(g, threats, roomy, opt);
    st.cornerUntil = now() + CORNER_COOLDOWN_MS;
    if (!r || r.open <= here + 0.15) return false;
    klog('Bị dồn ' + (close >= CROWD_N ? close + ' con' : 'góc') + ' (thoáng ' + Math.round(here * 100) + '%) → chạy ra chỗ rộng ' +
      Math.round(dist(me.x, me.y, r.to.x, r.to.y)) + 'px (thoáng ' + Math.round(r.open * 100) + '%)');
    moveFighting(g, r.path);
    st.kiteTo = r.to;
    st.kiteAt = now();
    if (!st.kiting) st.kiteSince = now();
    st.kiting = true;
    st.engaging = false;
    return true;
  }

  /* --- áp vào đúng tầm để xả chiêu / chém --- */
  // Có chiêu sẵn sàng (cùng cách chọn với auto / tối ưu chiêu) thì đứng trong tầm chiêu đó; tầm …
  var SKILL_RANGE_PAD = 8;   // đứng lọt vào trong tầm chiêu chừng này cho chắc trúng
  var ENGAGE_REPLAN_MS = 600;

  function kiteTarget(g) {
    var me = g.me, R = g.P.CONFIG.TARGET ? g.P.CONFIG.TARGET.RANGE : 400;
    var picks = [st.farmTarget, me.castTarget, me.attackTarget];
    // Con đang chạy về chỗ cũ (bị kéo quá xa) thì đuổi vô ích: chọn con khác.
    for (var i = 0; i < picks.length; i++) {
      var t = picks[i];
      if (t && !t.dead && !t.downed && t.state !== 'return' && isFinite(t.x) && dist(me.x, me.y, t.x, t.y) <= R) return t;
    }
    var best = null, bd = R;
    mobsAlive(g).concat(hostilePlayers(g)).forEach(function (m) {
      if (m.state === 'return') return;
      var d = dist(me.x, me.y, m.x, m.y);
      if (d < bd) { bd = d; best = m; }
    });
    return best;
  }

  function enemyReach(g, t) {
    if (t.def) return mobBaseReach(g, t);
    var PL = g.P.Player;
    return (PL.reachOf ? PL.reachOf(t.cfg) : g.P.CONFIG.PLAYER.REACH) + BODY_R;
  }

  // Chiêu auto sắp dùng lên mục tiêu này (chưa xét khoảng cách).
  function plannedSkill(g, t) {
    var S = g.P.Skills, me = g.me;
    if (!S || !S.autoRotation) return null;
    if (cfg.optimize && t.def) { var c = choose(g, t, 0); return c.best ? c.best.def : null; }
    var list = S.autoRotation();
    for (var i = 0; i < list.length; i++) {
      var def = list[i], cost = skillCost(g, def);
      if (S.ready(me, def) && (me.mp || 0) >= cost.mp && (me.sp || 0) >= cost.sp) return def;
    }
    return null;
  }

  // Đánh thường bằng vũ khí đánh lan: tới chỗ trúng nhiều con nhất. true = đang đi tới, false = đã
  // đứng đúng chỗ (để auto ra đòn), null = không áp dụng (để cách đứng thường lo).
  function splashMove(g, t) {
    var me = g.me, sp = splashSpot(g, t);
    if (!sp) return null;
    kiteNow += ' · đánh lan ' + sp.count + ' con (tầm lan ' + (sp.explore ? 'đang đo, tạm ' : '') + Math.round(sp.r) + 'px)';
    if (sp.here) { if (st.engaging && me.path && me.path.length) me.path.length = 0; st.engaging = false; return false; }
    var e0 = st.engageTo;
    if (st.engaging && e0 && me.path && me.path.length && now() - st.engageAt < ENGAGE_REPLAN_MS && dist(e0.x, e0.y, sp.x, sp.y) < 24) return true;
    var sr = spotCheck(g).route(sp.x, sp.y);
    if (!sr) return null;
    klog((sp.explore ? 'Chưa biết tầm lan → vào ' : 'Đứng chỗ đánh lan ') + 'trúng ' + sp.count + ' con (tầm lan ' + (sp.explore ? 'tạm ' : '') + Math.round(sp.r) + 'px, ' + sp.threats + ' con cắn tới được)');
    moveFighting(g, sr.path);
    st.engaging = true; st.engageTo = sr.to; st.engageAt = now();
    return true;
  }

  function tickEngage(g, myReach, maxStep) {
    var me = g.me, t = kiteTarget(g);
    if (!t) { st.engaging = false; return false; }
    var d = dist(me.x, me.y, t.x, t.y), name = t.def ? t.def.name || 'Quái' : t.name || 'Người chơi';
    var safe = enemyReach(g, t) + Math.min(cfg.kiteGap, maxStep * KITE_GAP_SHARE);
    var def = plannedSkill(g, t), lo, hi, what, K = +cfg.keepDist || 0;
    if (K > 0) { lo = Math.max(0, K - 12); hi = K + 12; what = 'giữ cách ' + name + ' ' + K + 'px (bạn đặt)'; }
    else if (def) {
      var R = skillRange(g, def) - SKILL_RANGE_PAD, sk = def.short || def.name;
      if (R > safe + 8) { lo = safe; hi = R; what = 'tung ' + sk + ' từ ngoài tầm ' + name; }
      else { lo = 0; hi = Math.max(8, R); what = 'áp sát tung ' + sk; }
    } else {
      var sm = splashMove(g, t);
      if (sm !== null) return sm;
      var mine = myReach + (t.def && t.def.bodyRadius || 0) - 2;
      if (mine > safe + 4) { lo = safe; hi = mine; what = 'chém từ ngoài tầm ' + name; }
      else { lo = 0; hi = mine; what = 'áp sát chém ' + name; }
    }
    kiteNow += ' · ' + what + ' (đứng ' + Math.round(lo) + '–' + Math.round(hi) + 'px, đang ' + Math.round(d) + 'px)';
    // Đúng tầm: dừng bước của mình để auto ra đòn tại chỗ.
    if (d >= lo && d <= hi) {
      if (st.engaging && me.path && me.path.length) me.path.length = 0;
      st.engaging = false;
      return false;
    }
    // Áp sát (lo = 0) thì auto tự đi tới và ra đòn khi vào tầm; chỉ cần lo khi phải đứng ngoài tầm địch.
    if (lo === 0) { st.engaging = false; return false; }
    var e = st.engageTo;
    if (st.engaging && e && me.path && me.path.length && now() - st.engageAt < ENGAGE_REPLAN_MS) {
      var ed = dist(e.x, e.y, t.x, t.y);
      if (ed >= lo - 6 && ed <= hi + 6) return true;
    }
    // Tránh chiêu đang chờ nổ, tầm với của các địch khác và tầm bắn của trụ (trừ trụ đang đánh).
    var avoid = hazards(g).concat(towerZones(g, isTower(t) ? t : null));
    mobsAlive(g).concat(hostilePlayers(g)).forEach(function (m) {
      if (m === t || (m.def && !(m.def.contactDmg > 0))) return;
      avoid.push({ x: m.x, y: m.y, x2: m.x, y2: m.y, r: enemyReach(g, m) });
    });
    var keep = leashKeep(g, t);
    var p = (keep && ringPath(g, t, lo, hi, avoid, keep)) || ringPath(g, t, lo, hi, avoid);
    if (!p) { klog('Không tìm được chỗ đứng ' + Math.round(lo) + '–' + Math.round(hi) + 'px quanh ' + name + ' → để auto tự đánh'); st.engaging = false; return false; }
    klog((d > hi ? 'Áp vào ' : 'Giãn ra ') + Math.round(dist(p.to.x, p.to.y, t.x, t.y)) + 'px: ' + what);
    moveFighting(g, p.path);
    st.engaging = true;
    st.engageTo = p.to;
    st.engageAt = now();
    return true;
  }

  /* ================= Tối ưu chiêu ================= */
  var MELEE = '_melee';
  var hooked = false;

  function mobsAlive(g) {
    var U = g.P.TamLoUI, tl = U && U.laDichDon && U.dangTrongTran && U.dangTrongTran();
    return (g.sw.enemies || []).filter(function (m) {
      return m && !m.dead && !(m.def && (m.def.human || m.def.tieuXa || (m.def.tranMach && !cfg.tmTru))) && !(tl && m.def && m.def.tamLo && !U.laDichDon(m));
    });
  }
  function isBoss(m) { return !!(m && ((m.def && (m.def.isBoss || m.def.boss || /Yêu Thú Cấp/.test(m.def.name || ''))) || m.isBoss || m.boss)); }
  function isLastHitOnly(m) {
    if (!m) return false;
    if (m.def && m.def.human) return false;
    var tp = m.type || (m.def && m.def.type) || '';
    if (/thach_quy|xuyen_son_giap|sau_truc|son_chuot|lon_rung/.test(tp)) return false;
    if (m.def && m.def.lootLastHitOnly) return true;
    if (m.lootLastHitOnly) return true;
    if (/xong_chuong|bach_ho_tuyet|xich_nhan_nguu|xich_ma|ngan_mao_hong|yl_hac_tien|duoc_linh_thu|thach_mach_vuong|u_minh_cu_mang|xich_mang_vuong/.test(tp)) return true;
    var nm = m.name || (m.def && m.def.name) || '';
    return /xổng chuồng|xong chuong/i.test(nm);
  }

  function skillCost(g, def) {
    if (def.thunder) return { mp: g.P.CONFIG.THUNDER.MP_COST || 0, sp: 0 };
    var c = g.P.Skills.spellCost ? g.P.Skills.spellCost(g.me, def) : def;
    return { mp: c.mp || 0, sp: c.sp || 0 };
  }

  // Cùng công thức tầm đánh với Skills.pickAuto.
  function skillRange(g, def) {
    if (def.thunder) return g.P.CONFIG.THUNDER.RANGE;
    return def.shape === 'aura' ? Math.min(def.range, 0.8 * def.blastR) : def.range;
  }

  function dotOf(g, def) {
    var ef = g.P.Skills.effectOf ? g.P.Skills.effectOf(def) : null, sum = 0;
    [].concat(ef || []).forEach(function (e) { if (e && e.dps > 0 && e.time > 0) sum += e.dps * e.time; });
    return sum;
  }

  // Những con quái một chiêu sẽ trúng, giống Skills.blastTargets.
  function skillHits(g, def, target, mobs) {
    var R = def.thunder ? (g.P.CONFIG.THUNDER && g.P.CONFIG.THUNDER.RADIUS) || 0 : def.blastR || 0;
    if (!(R > 0)) return [target];
    var c = def.shape === 'aura' ? g.me : target, hit = [];
    mobs.forEach(function (m) {
      var d = dist(m.x, m.y, c.x, c.y);
      if (d <= R) hit.push({ m: m, d: d });
    });
    if (def.shape !== 'aura' && !hit.some(function (h) { return h.m === target; })) hit.push({ m: target, d: 0 });
    hit.sort(function (a, b) { return a.d - b.d; });
    if (def.maxTargets) hit.length = Math.min(hit.length, def.maxTargets);
    return hit.map(function (h) { return h.m; });
  }

  // Sát thương một lần trúng của chiêu. Lôi Chưởng: THUNDER_DEF không có coef (dmgOf ra 1) → game tính powerDmg(THUNDER.COEF).
  function skillDmg(g, def) {
    var S = g.P.Skills, TH = g.P.CONFIG.THUNDER || {};
    if (def.thunder) return S.powerDmg && TH.COEF ? S.powerDmg(TH.COEF) : (S.dmgOf ? S.dmgOf(def) : 0);
    return S.dmgOf ? S.dmgOf(def) : (def.coef ? def.coef * 50 : 0);
  }
  function evalSkill(g, def, target, d, mobs) {
    var S = g.P.Skills, me = g.me;
    var per = skillDmg(g, def), dot = dotOf(g, def), hits = skillHits(g, def, target, mobs), eff = 0;
    // Chiêu nhiều viên (Phong Nhẫn 3, Băng Châm 5): game chia tổng sát thương cho các viên (Skills.shotShare) → không nhân.
    hits.forEach(function (m) { eff += Math.min(per + dot, Math.max(0, m.hp != null ? m.hp : 100)); });
    if (eff <= 0 && btCcSec(def) > 0) eff = 15; // Đảm bảo chiêu thuần khống chế vẫn có điểm hiệu dụng trong combat
    var c = skillCost(g, def), range = skillRange(g, def), cd = S.coolLeft(me, def);
    var why = '';
    if (!S.ready(me, def)) why = cd > 0 ? 'hồi ' + cd.toFixed(1) + 's' : 'không dùng được';
    else if ((me.mp || 0) < c.mp) why = 'thiếu linh lực';
    else if ((me.sp || 0) < c.sp) why = 'thiếu thần thức';
    else if (d > range) why = 'xa (' + Math.round(range) + ')';
    return { def: def, per: per, dot: dot, n: hits.length, eff: eff, mp: c.mp, sp: c.sp, ok: !why, why: why };
  }

  // Chuỗi chiêu: thử mọi thứ tự PLAN_DEPTH chiêu trong PLAN_H giây (nhịp chung 1,2 giây, Lôi Chưởng chen giữa), lấy chuỗi mạnh nhất.
  var PLAN_H = 7, PLAN_DEPTH = 4;
  function spellGap(g) { var C = g.P.CONFIG && g.P.CONFIG.PLAYER; return (C && C.SPELL_GAP) || 1.2; }
  function poseLen(g, def) { var c = def.thunder ? (g.P.CONFIG.THUNDER.CAST || 0.34) : (def.cast || 0.5); return 1.4 * c + 0.14; }
  function fullCd(g, def) {
    if (def.thunder) return g.P.CONFIG.THUNDER.COOLDOWN || 5;
    var PL = g.P.Player;
    return PL.linhCanHoiChieu ? PL.linhCanHoiChieu(g.me, def.cooldown || 0) : (def.cooldown || 0);
  }
  function ownCd(g, def) { var me = g.me; return Math.max(0, def.thunder ? me.thunderCd || 0 : (me.spellCds && me.spellCds[def.id]) || 0); }
  function planSkills(g, rows) {
    var me = g.me, G = spellGap(g), gap0 = Math.max(0, me.spellCd || 0);
    var c = rows.filter(function (r) { return r.eff > 0 && (r.ok || /^hồi/.test(r.why)); }).map(function (r) {
      return { r: r, th: !!r.def.thunder, cd0: ownCd(g, r.def), cd: fullCd(g, r.def), pose: poseLen(g, r.def), mp: r.mp || 0, sp: r.sp || 0, eff: r.eff };
    });
    if (!c.length) return null;
    var n = c.length, cds = c.map(function (x) { return x.cd0; }), best = null;
    function step(depth, t, gap, mp, sp, top) {
      var hi = 0;
      for (var i = 0; i < n; i++) {
        var x = c[i];
        if (mp < x.mp || sp < x.sp) continue;
        var s0 = Math.max(t, cds[i], x.th ? 0 : gap);
        if (s0 >= PLAN_H) continue;
        var keep = cds[i]; cds[i] = s0 + x.cd;
        var v = x.eff * (1 - s0 / (PLAN_H * 3)) + (depth > 1 ? step(depth - 1, s0 + x.pose, x.th ? gap : s0 + G, mp - x.mp, sp - x.sp, false) : 0);
        cds[i] = keep;
        if (v > hi) hi = v;
        if (top && (!best || v > best.v)) best = { v: v, first: x.r, at: s0 };
      }
      return hi;
    }
    step(PLAN_DEPTH, 0, gap0, me.mp || 0, me.sp || 0, true);
    return best;
  }
  // Mọi chiêu để chọn: bật "dùng cả chiêu chưa tick" thì lấy mọi chiêu đã học, không thì bảng Tự Động của game.
  function skillPool(g) {
    var S = g.P.Skills, out = S.autoRotation ? S.autoRotation().slice() : [];
    if (cfg.bossAllSkills && S.learnedSlots && S.slotDef) {
      S.learnedSlots().forEach(function (k) { var d = S.slotDef(k); if (d && !d.playerTargetOnly && !d.bienHinh && out.indexOf(d) < 0) out.push(d); });
    }
    return out;
  }

  function isPlayer(t) {
    return !!(t && (t.isPlayer || (!t.def && (t.name != null || t.id != null))));
  }

  // Chấm điểm toàn bộ chiêu (bảng Tự Động, hoặc mọi chiêu đã học) cho một mục tiêu.
  function choose(g, target, d) {
    var S = g.P.Skills, me = g.me, mobs = mobsAlive(g);
    var rows = skillPool(g).map(function (def) { return evalSkill(g, def, target, d, mobs); });
    var boss = isBoss(target);
    var player = isPlayer(target);
    var mpPct = me.mpMax ? me.mp / me.mpMax * 100 : 0;
    var melee = g.P.Player.meleeDamage ? g.P.Player.meleeDamage() : 0;
    // Trụ: đứng trong tầm là ăn đạn, gãy càng nhanh càng đỡ máu → dồn sát thương như boss.
    // Người chơi: PK sinh tử chớp nhoáng → LUÔN dồn sát thương tối đa, không bao giờ rơi vào eco hay save mana.
    // Săn Thú Xổng & Thương Đội: quái hồi máu theo số người chơi săn (lên đến 100 người) → BẮT BUỘC KHÔ MÁU 'dmg', không bao giờ hạ xuống 'save'/'eco'.
    var isBurstTarget = player || boss || isTower(target) || target.ctRecover > 0 ||
      !!(st.xc || st.td || st.bh || isLastHitOnly(target) || isTdMob(target));
    var mode = isBurstTarget || mpPct >= cfg.mpFull ? 'dmg' : mpPct < cfg.mpReserve ? 'save' : 'eco';
    var best = null, why, lh = (!player) ? lastHitPick(g, target, rows) : null, wait = null;
    if (lh && lh.best) return { rows: rows, best: lh.best, mode: 'dmg', why: lh.why, melee: melee, boss: boss, isBurstTarget: isBurstTarget };
    if (player) {
      // PK ĐỐI KHÁNG NGƯỜI CHƠI: Smart CC Chaining + Burst dồn nén
      var targetCC = (target.stunT || 0) > 0.3 || (target.freezeT || 0) > 0.3 || (target.rootT || 0) > 0.3;
      rows.forEach(function (r) {
        if (!r.ok || !(r.eff > 0)) return;
        var ccSec = btCcSec(r.def);
        if (!targetCC && ccSec > 0) {
          // Địch chưa bị khống chế: Thưởng cực lớn để mở combat bằng CC
          r.score = r.eff * (1 + ccSec * 2.5);
        } else if (targetCC && ccSec > 0) {
          // Địch đã bị khống chế: Giảm nhẹ điểm chiêu CC trùng lặp, nhường chỗ cho chiêu sát thương dồn
          r.score = r.eff * 0.75;
        } else {
          r.score = r.eff;
        }
        if (!best || r.score > best.score || (r.score === best.score && r.mp < best.mp)) best = r;
      });
      why = best ? ('PK đối kháng → ' + (btCcSec(best.def) > 0 ? 'Khống chế mục tiêu' : 'Dồn sát thương')) : 'Đánh thường';
    } else if (mode === 'dmg') {
      var pl = planSkills(g, rows.filter(function (r) { return !(lh && lh.exclude === r); }));
      if (pl && pl.at <= 0.05 && pl.first.ok) best = pl.first; else if (pl) wait = pl;
    } else if (mode !== 'save') {
      rows.forEach(function (r) {
        if (!r.ok || !(r.eff > 0) || (lh && lh.exclude === r)) return;
        r.score = mode === 'dmg' ? r.eff : r.eff / Math.max(1, r.mp);
        if (!best || r.score > best.score || (r.score === best.score && r.mp < best.mp)) best = r;
      });
    }
    if (player) {
      // Không áp dụng noOverkill cho người chơi vì đối thủ có khiên, phù máu, hộ tâm
    } else if (mode === 'save') why = 'Linh lực < ' + cfg.mpReserve + '% → đánh thường, giữ linh lực';
    else if (best && cfg.noOverkill && !boss && !isBurstTarget && target.hp <= melee && best.n < 2) { best = null; why = 'Một đòn thường là chết → không phí chiêu'; }
    else if (!best && wait) why = 'Chờ ' + (wait.first.def.short || wait.first.def.name) + ' (' + wait.at.toFixed(1) + 's) mở chuỗi mạnh nhất → đánh thường';
    else if (!best) why = 'Không chiêu nào dùng được lúc này → đánh thường';
    else why = (mode === 'dmg' ? (isBurstTarget ? (boss ? 'Boss' : (st.xc || isLastHitOnly(target)) ? 'Thú Xổng' : (st.td || isTdMob(target)) ? 'Thương Đội' : 'Mục tiêu đặc biệt') + ' → Khô máu dồn DPS' : 'Linh lực dồi dào → dồn sát thương') : 'Tiết kiệm → sát thương / linh lực cao nhất') +
      (best.n > 1 ? ' · trúng ' + best.n + ' con' : '');
    if (lh && lh.exclude) why = lh.why + ' · ' + why;
    return { rows: rows, best: best, mode: mode, why: why, melee: melee, boss: boss, isBurstTarget: isBurstTarget };
  }

  function targetAt(g, d) {
    var best = null, gap = 3, me = g.me;
    mobsAlive(g).forEach(function (m) {
      var k = Math.abs(dist(me.x, me.y, m.x, m.y) - d);
      if (k < gap) { gap = k; best = m; }
    });
    // Tìm trong người chơi thù địch ở gần
    hostilePlayers(g).forEach(function (r) {
      if (!r || !isFinite(r.x)) return;
      var k = Math.abs(dist(me.x, me.y, r.x, r.y) - d);
      if (k < gap) { gap = k; best = r; }
    });
    // Tìm theo người chơi đang bị khoá bởi Targeting
    if (!best && g.P && g.P.Targeting) {
      var Tg = g.P.Targeting, kn = Tg.khoaNguoi;
      if (kn && g.P.Gateway && g.P.Gateway.remotes) {
        var locked = g.P.Gateway.remotes[kn];
        if (locked && isFinite(locked.x)) {
          var k = Math.abs(dist(me.x, me.y, locked.x, locked.y) - d);
          if (k < 10) best = locked;
        }
      }
    }
    return best;
  }

  // Thay chỗ Skills.pickAuto: undefined = để game tự chọn, null = đánh thường.
  function optPick(p, d) {
    var g = game();
    if (!g || p !== g.me) return undefined;
    var t = targetAt(g, d);
    if (!t) return undefined;
    var bp = burstPick(g, t, d);
    if (bp !== undefined) return bp;
    if (!cfg.optimize) return undefined;
    var c = choose(g, t, d);
    if (!c.best) return null;
    var ix = g.P.Skills.autoRotation().indexOf(c.best.def);
    return { def: c.best.def, idx: ix < 0 ? 0 : ix };
  }

  /* ================= Xả chiêu vào boss ================= */
  // Auto của game chỉ thử ra chiêu ngay sau mỗi nhát chém, chỉ dùng chiêu đã tick Tự Động, và đo tầm tới TÂM mục tiêu …
  var BURST_APPROACH_MS = 500;
  function burstSkills(g) {
    var S = g.P.Skills;
    return skillPool(g).filter(function (d) { return skillDmg(g, d) > 1 || dotOf(g, d) > 0; });
  }
  // Mục tiêu đáng xả: boss đang khoá, hộ vệ của boss thế giới đang phải hạ trước, thú xổng, hoặc thương đội.
  function burstTarget(g) {
    var t = st.farmTarget, me = g.me;
    if (!t || t.dead || !t.def || t.hp <= 0 || (g.sw.enemies || []).indexOf(t) < 0 || dist(me.x, me.y, t.x, t.y) > 420) return null;
    if (isBoss(t) || isLastHitOnly(t) || isTdMob(t)) return t;
    if (st.xc && st.xc.target === t) return t;
    if (st.td && st.td.target === t) return t;
    var wb = worldBossNear(g) || (st.bh && st.bh.boss) || anyBossNear(g) || nearBoss(g);
    return wb && wb.def && wb.def.hoVe === t.type ? t : null;
  }
  // Chọn chiêu xả vào boss t ở khoảng cách d: {row, lh, rows} (row = chiêu tung được lúc này, có thể null).
  function burstChoice(g, t, d) {
    var rows = burstSkills(g).map(function (def) { return evalSkill(g, def, t, d, mobsAlive(g)); });
    var lh = lastHitPick(g, t, rows), best = lh && lh.best && lh.best.ok ? lh.best : null, wait = null;
    if (!best) {
      var pl = planSkills(g, rows.filter(function (r) { return !(lh && lh.exclude === r); }));
      if (pl && pl.at <= 0.05 && pl.first.ok) best = pl.first; else if (pl) wait = pl;
    }
    return { row: best, lh: lh, rows: rows, wait: wait };
  }
  // Chỗ game chọn chiêu cho auto (gọi ngay khi vừa vung / niệm xong): đang đánh boss thì đưa chiêu xả. undefined = không áp dụng.
  function burstPick(g, t, d) {
    if (!cfg.bossBurst || t !== burstTarget(g) || (st.ll && st.ll.hold > now())) return undefined;
    var c = burstChoice(g, t, d);
    if (!c.row) return c.wait ? null : undefined; // đang chờ chiêu mạnh hồi: đánh thường chứ không tung chiêu yếu
    var list = g.P.Skills.autoRotation(), idx = list.indexOf(c.row.def);
    st.burstWhy = c.lh && c.lh.best ? 'kết liễu' : '';
    return { def: c.row.def, idx: idx < 0 ? 0 : idx };
  }
  function tickBossBurst(g) {
    if (!cfg.bossBurst || !enabled || st.contest) return false;
    var P = g.P, S = P.Skills, PL = P.Player, me = g.me;
    if (!S || !S.dmgOf || !PL || !PL.castSpell || me.downed || me.state === 'sit' || st.healing || st.dodging) return false;
    if (st.ll && st.ll.hold > now()) return false; // Lãm Làng đang giữ chỗ hợp lực (Tà Soái bất hoại lúc Trận Nhãn)
    var t = burstTarget(g);
    if (!t || g.P.Input.hasManualMove()) { st.burstStep = false; return false; }
    var d = dist(me.x, me.y, t.x, t.y), ch = burstChoice(g, t, d), rows = ch.rows, lh = ch.lh, best = ch.row;
    if (best) {
      // Auto đang bật: game tự tung đúng chiêu này qua pickAuto ngay khi đòn đang ra xong. Auto tắt (vừa bước vào) thì tự tung.
      if (g.sw.autoOn && st.burstStep !== true) return false;
      if (me.state === 'attack' || me.state === 'pose') return false; // để đòn đang ra xong đã
      me.dir = dirToward(t.x - me.x, t.y - me.y);
      me.castTarget = t;
      var ok = best.def.thunder ? PL.castThunder(me) : PL.castSpell(me, best.def);
      if (ok !== true) { me.castTarget = null; return false; }
      klog('[Xả chiêu] ' + (best.def.short || best.def.name) + ' → ' + mobLabel(t) + ' (' + num(t.hp) + '/' + num(t.hpMax) + ')' + (lh && lh.best ? ' · kết liễu' : ''));
      st.burstStep = false;
      return true;
    }
    // Chiêu mạnh hồi xong, đủ linh lực mà chỉ thiếu tầm (đo tới tâm boss): bước sát vào cho vừa tầm.
    var near = rows.filter(function (r) { return !r.ok && /^xa/.test(r.why) && r.eff > 0 && !(lh && lh.exclude === r); })
      .sort(function (a, b) { return b.eff - a.eff; })[0];
    if (!near) return false;
    var R = skillRange(g, near.def), want = Math.max(8, R - 10);
    if (d <= want) return false;
    // Auto của game đứng ở tầm chém và dừng mọi bước khác → tạm tắt auto, bước vào, tung xong auto tự bật lại.
    st.burstStep = true;
    setAuto(g, false);
    if (me.path && me.path.length && now() - (st.burstMoveAt || 0) < BURST_APPROACH_MS) return true;
    var k = (d - want) / d, r2 = spotCheck(g).route(me.x + (t.x - me.x) * k, me.y + (t.y - me.y) * k);
    if (!r2) { st.burstStep = false; return false; }
    st.burstMoveAt = now();
    moveFighting(g, r2.path);
    kiteNow = 'Xả chiêu: bước vào cho vừa tầm ' + (near.def.short || near.def.name) + ' (' + Math.round(R) + 'px)';
    return true;
  }

  /* --- đo sát thương thực tế --- */
  function statOf(id) { return stats.skill[id] || (stats.skill[id] = { casts: 0, dmg: 0, hits: 0, mp: 0 }); }

  // Gán cú đánh cho hành động gần nhất của mình (chiêu hoặc đòn thường) trong 3 giây.
  function noteHit(m, dmg) {
    if (!(dmg > 0)) return;
    var act = st.lastAct && now() - st.lastAct.at < 3000 ? st.lastAct.id : MELEE;
    var s = statOf(act);
    s.dmg += dmg; s.hits++;
    stats.dmg += dmg;
    if (act === MELEE) { noteSwingHit(); splashHit(m); }
    if (m && isBoss(m)) bossHitAt.set(m, now());
    if (m) {
      if (!m._ttFirst || now() - m._ttLast > 8000) m._ttFirst = now();
      m._ttLast = now();
    }
  }

  function hookGame(P) {
    if (hooked || !P.Skills || !P.Skills.pickAuto || !P.Player || !P.SceneWorld) return;
    hooked = true;
    var S = P.Skills, PL = P.Player, SW = P.SceneWorld;
    var pick = S.pickAuto;
    S.pickAuto = function (p, d) {
      var r = enabled && (cfg.optimize || cfg.bossBurst) ? optPick(p, d) : undefined;
      return r === undefined ? pick.apply(this, arguments) : r;
    };
    function wrapCast(name, defOf) {
      var orig = PL[name];
      if (!orig) return;
      PL[name] = function (pl) {
        var g = game(), def = defOf(arguments), cost = g && def ? skillCost(g, def) : null;
        var r = orig.apply(this, arguments);
        if (r === true && g && pl === g.me && def) {
          lastStrikeAt = now();
          st.lastAct = { id: def.id, at: now() };
          var s = statOf(def.id);
          s.casts++; s.mp += cost.mp; stats.mp += cost.mp;
        }
        return r;
      };
    }
    wrapCast('castSpell', function (a) { return a[1]; });
    wrapCast('castThunder', function () {
      var list = S.autoRotation();
      for (var i = 0; i < list.length; i++) if (list[i].thunder) return list[i];
      return { id: 'thunder', thunder: true };
    });
    var atk = PL.attack;
    if (atk) PL.attack = function (pl, target) {
      var g = game();
      // Quái sắp ra khỏi tầm lúc đòn trúng: không vung hụt, đuổi tới chỗ nó sắp tới.
      if (enabled && cfg.kite && g && pl === g.me && pl.state !== 'attack' && pl.state !== 'pose' && !(target && target.def && target.def.tieuXa)) {
        var miss = swingWouldMiss(g, pl, target);
        if (miss) { chaseTo(g, target, miss); return false; }
      }
      var r = atk.apply(this, arguments);
      if (r !== false && g && pl === g.me && pl.state === 'attack') {
        st.lastAct = { id: MELEE, at: now() };
        statOf(MELEE).casts++;
      }
      return r;
    };
    // Online: máy chủ báo số sát thương mình gây ra qua đây.
    var fx = SW.showHitFx;
    if (fx) SW.showHitFx = function (m, dmg) {
      noteHit(m, +dmg || 0);
      return fx.apply(this, arguments);
    };
  }

  // Offline không có báo cáo từ máy chủ: máu quái tụt chính là sát thương mình gây ra.
  // Mỗi tick cũng đếm quái mình đánh đã chết và EXP nhận được.
  var lastHp = new WeakMap(), lastExp = null;
  function tickStats(g) {
    trackBossHp(g);
    var online = !!(g.P.Gateway && g.P.Gateway.connected);
    (g.sw.enemies || []).forEach(function (m) {
      if (!m) return;
      var prev = lastHp.get(m);
      if (!online && prev != null && m.hp < prev) noteHit(m, prev - Math.max(0, m.hp));
      lastHp.set(m, m.dead ? 0 : m.hp);
      if (m.dead && m._ttLast && now() - m._ttLast < 3000) {
        stats.kills++;
        stats.killSec += (m._ttLast - m._ttFirst) / 1000;
        m._ttLast = 0;
      }
    });
    var exp = g.P.Progress && g.P.Progress.exp;
    if (typeof exp === 'number') {
      if (lastExp != null && exp > lastExp) stats.exp += exp - lastExp;
      lastExp = exp;
    }
  }

  /* ================= Hồi sinh ================= */
  function tickRevive(g) {
    var me = g.me;
    if (!me.downed) { st._wasDowned = false; return false; }
    if (tlIn(g) || vnIn(g)) { st.healing = false; st.travel = null; return true; } // Tam Lộ & Vết Nứt: game tự hồi sinh ở sảnh/căn cứ
    st.healing = false;
    st.travel = null;
    if (!st._wasDowned) {
      st._wasDowned = true;
      st.recentDeaths = (st.recentDeaths || []).filter(function (t) { return now() - t < 30000; }); // mở rộng 30s để bắt trọn vòng lặp gục liên tiếp
      st.recentDeaths.push(now());
    }
    if (!cfg.autoRevive) return true;
    var isBossContext = !!(st.bh || worldBossNear(g) || anyBossNear(g) || nearBoss(g) || now() - (st.bossSeenAt || -1e9) < 60000 || now() < (st.wbLootUntil || 0));
    var deathStreak = (st.recentDeaths || []).length;
    // Chống vòng lặp hồi sinh tự sát: hoãn ít nhất 2.0s (3.5s nếu gục liên tiếp) để dứt đòn quét/AOE của Boss
    var rdelay = isBossContext ? (deathStreak >= 2 ? 3.5 : 2.0) : (st.td && st.td.seen) ? 0 : cfg.reviveDelay;
    if ((me.downTime || 0) < rdelay) return true;
    var minReviveInterval = isBossContext ? (deathStreak >= 2 ? 5000 : 3000) : 3000;
    if (st.lastRevive > 0 && now() - st.lastRevive < minReviveInterval) return true;
    st.lastRevive = now();
    var ok = false;
    // Trong PK / cướp tiêu: nếu có địch thù địch đứng canh xác (< 380px) mà vừa gục liên tiếp >= 2 lần trong 30s, không gượng dậy tại chỗ nạp mạng
    var pkCamped = (st.ct || !isBossContext) && hostilePlayers(g).some(function (p) { return dist(me.x, me.y, p.x, p.y) < 380; });
    var canSpotRevive = me.reviveLeft !== 0 && (!pkCamped || deathStreak < 2);
    // Đang săn / đánh boss: ưu tiên gượng dậy tại chỗ nếu còn lượt và an toàn
    if ((isBossContext || cfg.reviveMode === 'spot') && canSpotRevive) {
      ok = !!g.sw.reviveOnSpot();
      if (ok) {
        var inBc = inDungeon2(g);
        say(inBc ? 'Bí cảnh: Gượng dậy tại chỗ!' : 'Gượng dậy tại chỗ ngay!');
        klog((inBc ? 'Bí cảnh' : 'Chiến đấu') + ': Gượng dậy tại chỗ để tiếp tục gây sát thương');
        if (cfg.autoShield) {
          if (!talUse(g, 'kim_long', 'gượng dậy chiến đấu')) talUse(g, 'kim_giap', 'gượng dậy chiến đấu');
        }
        if (cfg.autoMpTal) talUse(g, 'thanh_tam', 'gượng dậy chiến đấu');
        st.lastEat = 0;
        tickEat(g);
        st.reviveGraceUntil = now() + 3500; // 3.5s đệm an toàn sau khi gượng dậy để không sốc chết ngay lập tức
        if (inBc) {
          // Trong bí cảnh sau khi gượng dậy với máu thấp: rút lui an toàn thiền hồi máu trước khi vào lại
          say('Bí cảnh: Gượng dậy → lùi ra thiền hồi phục');
          klog('Bí cảnh: Gượng dậy tại chỗ, máu thấp → an toàn thiền hồi phục');
          st.healing = true;
          st.healMoving = false;
        } else {
          // Boss / PK: giữ Auto chiến đấu
          setAuto(g, true);
        }
      }
    }
    if (!ok && g.sw.reviveAtHome) {
      st.stayFarmPaused = false;
      g.sw.reviveAtHome();
      say('Hồi sinh về làng');
    }
    return true;
  }

  /* ================= Sát thương đang nhận ================= */
  // Ghi lại máu tụt trong vài giây gần nhất để biết đang mất bao nhiêu máu mỗi giây. Máu tụt
  // khi đang đứng trong tầm với của quái thì coi như con đó vừa chém: nó đang hồi đòn.
  var INCOMING_WIN = 4000;   // ms cửa sổ tính máu mất mỗi giây
  var SWING_DMG_SHARE = 0.5; // mất ít nhất phần này của sát thương chạm mới tính là bị chém (giáp có thể đỡ bớt)
  var hpLog = [], lastMyHp = null;

  function tickIncoming(g) {
    var me = g.me, t = now();
    if (lastMyHp != null && !me.downed && me.hp < lastMyHp) {
      var lost = lastMyHp - me.hp;
      hpLog.push({ t: t, d: lost });
      // Chỉ cú mất máu cỡ một đòn cắn mới là quái vừa chém; độc / bỏng nhỏ giọt không tính.
      mobsAlive(g).forEach(function (m) {
        if (!(m.def.contactDmg > 0) || lost < m.def.contactDmg * SWING_DMG_SHARE) return;
        if (dist(me.x, me.y, m.x, m.y) <= mobBaseReach(g, m) + 20) markSwing(m);
      });
    }
    lastMyHp = me.downed ? null : me.hp;
    while (hpLog.length && t - hpLog[0].t > INCOMING_WIN) hpLog.shift();
  }

  // Máu mất mỗi giây: lấy lớn hơn giữa số đo thật và ước tính từ quái đang áp sát
  // (sát thương chạm / thời gian hồi đòn của từng con).
  function incomingDps(g) {
    var me = g.me, sum = 0;
    hpLog.forEach(function (e) { sum += e.d; });
    var measured = sum / (INCOMING_WIN / 1000), est = 0;
    mobsAlive(g).forEach(function (m) {
      if (!(m.def.contactDmg > 0)) return;
      if (dist(me.x, me.y, m.x, m.y) <= mobBaseReach(g, m) + KITE_SCAN) est += m.def.contactDmg / (m.def.hitCooldown || 1);
    });
    return Math.max(measured, est);
  }

  /* ================= Thiền hồi máu ================= */
  var HEAL_SEARCH = 800;     // px tìm chỗ an toàn quanh mình (cách cũ, khi tìm theo lưới không ra)
  var HEAL_PLAN_R = 20;      // ô quanh mình tìm chỗ thiền theo lưới
  var HEAL_MIN_ROOM = 0.65;  // chỗ thiền nên thoáng ít nhất chừng này (cách tường ≥ 1–2 ô)
  var HEAL_LEAD_PAD = 0.8;   // giây cộng thêm vào thời gian chạy ra chỗ an toàn (quay người, né vật cản)
  var HEAL_REPLAN_MS = 6000; // đi tới chỗ thiền lâu hơn chừng này thì tìm chỗ khác
  var SIT_KEEP = 0.8;        // đang ngồi thì quái phải vào sâu hơn mới đứng dậy dời chỗ

  // Vùng không nên ngồi: quanh quái hung hăng (tự lao vào) hoặc quái đang đuổi / đang chém,
  // rộng bằng tầm phát hiện của nó nếu tầm đó lớn hơn healSafe; cộng thêm vùng chiêu.
  function healDanger(g) {
    var out = [];
    mobsAlive(g).forEach(function (m) {
      if (!(m.def.contactDmg > 0)) return;
      if (!(m.def.aggro > 0) && m.state !== 'chase' && m.attackState !== 'telegraph') return;
      var r = Math.max(cfg.healSafe, (m.def.aggro || 0) + 40);
      out.push({ x: m.x, y: m.y, x2: m.x, y2: m.y, r: r });
    });
    return out.concat(hazards(g), towerZones(g));
  }

  // Trả về true khi đang đi ra chỗ an toàn (chưa ngồi).
  function healMove(g) {
    var me = g.me, danger = healDanger(g), keep = me.state === 'sit' ? SIT_KEEP : 1;
    var unsafe = danger.some(function (h) { return segDist(h, me.x, me.y) < h.r * keep; });
    if (!unsafe) { st.healMoving = false; st.healTo = null; return false; }
    var t = st.healTo;
    if (st.healMoving && t && me.path && me.path.length && now() - st.healAt < HEAL_REPLAN_MS &&
      !inHazard(danger, t.x, t.y)) return true;
    // Chỗ thiền: ưu tiên hẳn chỗ rộng (ngồi trong góc là bị vây không đường chạy); không có mới lấy chỗ hẹp.
    var threats = threatsOf(g), outside = function (x, y) { return !inHazard(danger, x, y); };
    var hopt = { radius: HEAL_PLAN_R, avoid: hazards(g), wT: 0.3, wO: FAR_W_ROOM, wM: 0.6 };
    var r = planEscape(g, threats, outside, Object.assign({ minRoom: HEAL_MIN_ROOM }, hopt)) ||
      planEscape(g, threats, outside, hopt) || escapePath(g, danger, HEAL_SEARCH, 40);
    if (!r) {
      if (st.healMoving) say('Không tìm được chỗ an toàn → thiền tại chỗ');
      st.healMoving = false;
      return false;
    }
    moveFighting(g, r.path);
    st.healTo = r.to;
    st.healAt = now();
    if (!st.healMoving) say('Ra chỗ an toàn để thiền');
    st.healMoving = true;
    return true;
  }

  // Boss thế giới (Xích Long, Linh Hổ, Song Dực Ma Báo…; không phải boss bí cảnh): đồ chia theo sát
  // thương gây lên boss, nên đang đánh thì không ngồi thiền, đang ngồi thì đứng dậy đánh tiếp.
  var WORLD_BOSS_R = 600;
  function isWorldBoss(g, m) {
    if (!m || !m.def || inDungeon(g)) return false;
    return BOSS_TABLE.some(function (b) { return b.type === m.type; }) || m.type === 'nhen_bach_ngoc' || (isBoss(m) && (m.def.respawnSec || 0) >= 3600);
  }
  // Đồ boss bốc thăm (máy chủ, 04/10): có vé khi đánh ≥ ngưỡng (≈1% máu boss), còn sống, đứng trong ~22 ô quanh chỗ …
  function bossCapped(g, wb) {
    var cb = wb && bossShare(wb);
    if (!cb) return false;
    if (cb.st === 1) return true; // Trạng thái 1 của CongBossUI chính là "ĐỦ điều kiện nhận đồ"
    var target = cb.ng || cb.tr || 0;
    return target > 0 && (cb.my || 0) >= target;
  }
  function worldBossNear(g) {
    var me = g.me;
    return mobsAlive(g).filter(function (m) { return isWorldBoss(g, m) && dist(me.x, me.y, m.x, m.y) <= WORLD_BOSS_R; })[0] || null;
  }

  function tickHeal(g) {
    if (tlIn(g)) { st.healing = false; return; } // Tam Lộ cấm đả tọa: phần Tam Lộ tự về suối
    if (vnIn(g)) { // Vết Nứt Không Gian cấm thiền: phải chạy liên tục tranh cửa và bảo vật
      if (st.healing || g.me.state === 'sit') {
        st.healing = false; st.healMoving = false;
        if (g.me.state === 'sit') g.P.Input.pressMeditate();
      }
      return;
    }
    if (st.ll && st.ll.hold > now()) { // Lãm Làng đang Huyết Ấn / Xích / Trận Nhãn: phải đứng đúng chỗ, không ngồi
      if (st.healing || g.me.state === 'sit') { st.healing = false; st.healMoving = false; if (g.me.state === 'sit') g.P.Input.pressMeditate(); }
      return;
    }
    var inBc = inDungeon2(g);
    var wb = !inBc && (worldBossNear(g) || (st.bh && st.bh.boss) || anyBossNear(g) || nearBoss(g));
    var isBurstHunt = !inBc && (wb || st.xc || st.td || (st.farmTarget && !st.farmTarget.dead && (isLastHitOnly(st.farmTarget) || isTdMob(st.farmTarget))));
    if (isBurstHunt && cfg.bossNoSit) {
      if (st.healing || g.me.state === 'sit') {
        st.healing = false; st.healMoving = false;
        if (g.me.state === 'sit') g.P.Input.pressMeditate();
        klog('Đang dồn sát thương mục tiêu đặc biệt (Boss/Thú Xổng/Thương Đội) → không thiền, liên tục dồn tối đa sát thương');
      }
      return;
    }
    if (!cfg.healSit) { st.healing = false; return; }
    var me = g.me;
    if (!me.hpMax) return;
    var pct = me.hp / me.hpMax * 100;
    var sitting = me.state === 'sit';

    if (!st.healing && me.canMeditate) {
      if (pct < cfg.healLow) {
        st.healing = true;
        say('Máu ' + pct.toFixed(0) + '% → ngồi thiền');
      } else if (cfg.healEarly && pct < cfg.healHigh) {
        // Thời gian cần để chạy ra khỏi vùng nguy hiểm rộng nhất quanh mình.
        var dps = incomingDps(g), far = 0;
        healDanger(g).forEach(function (h) { far = Math.max(far, h.r - segDist(h, me.x, me.y)); });
        var C = g.P.CONFIG.PLAYER, v = (me.speed || C.SPEED) * (g.P.Input.run ? C.RUN_MULT || 1 : 1);
        var lead = far > 0 ? far / Math.max(1, v) + HEAL_LEAD_PAD : 0;
        var floor = me.hpMax * cfg.healLow / 100;
        if (dps > 0 && lead > 0 && me.hp - dps * lead <= floor) {
          st.healing = true;
          say('Mất ~' + Math.round(dps) + ' máu/giây, cần ' + lead.toFixed(1) + 's chạy ra → rút sớm (' + pct.toFixed(0) + '%)');
        }
      }
    }
    if (!st.healing) return;
    // Player.sit tự hạ cánh nếu đang bay, nên phải nhớ trước lúc ngồi.
    if (me.flying) { st.reFly = true; st.flyTries = 0; }

    if (pct >= cfg.healHigh) {
      st.healing = false;
      st.healMoving = false;
      if (sitting) g.P.Input.pressMeditate();
      say('Máu ' + pct.toFixed(0) + '% → đi tiếp');
      return;
    }
    setAuto(g, false);
    if (healMove(g)) return;
    if (me.path && me.path.length) me.stop();
    // Chặn ngồi thiền nạp mạng khi có quái hung hăng hoặc Boss sát người trong tầm healSafe
    var closeDanger = healDanger(g).some(function (h) { return segDist(h, me.x, me.y) < cfg.healSafe; });
    var hasBossThreat = mobsAlive(g).some(function (m) { return isBoss(m) && dist(me.x, me.y, m.x, m.y) < 350; });
    if (closeDanger || hasBossThreat) {
      if (sitting) { g.P.Input.pressMeditate(); say('Có quái/boss áp sát → đứng dậy!'); }
      if (cfg.autoShield) { if (!talUse(g, 'kim_long', 'nguy hiểm không thiền')) talUse(g, 'kim_giap', 'nguy hiểm không thiền'); }
      return;
    }
    // Vừa bị người đánh thì game khoá thiền vài giây — chờ rồi thử lại.
    if (!sitting && !(me.meditatePvpLock > 0) && !g.sw.autoOn && now() - st.lastSitPress > 700) {
      st.lastSitPress = now();
      g.P.Input.pressMeditate();
    }
  }

  /* ================= Bay lại sau khi thiền ================= */
  // Bấm Phi Hành (= phím F) như người chơi. Ở vùng cấm bay hoặc chưa đủ cảnh giới / chưa đeo
  // pháp khí bay thì chờ; bấm vài lần không lên được thì thôi.
  var FLY_RETRY_MS = 1500;   // giữa hai lần bấm phi hành
  var FLY_MAX_TRIES = 4;

  // Luôn bay: chưa bay thì bấm Phi Hành, trừ lúc thiền / đi ra chỗ thiền, lúc câu cá, chặt cây, …
  var ALWAYS_FLY_REST_MS = 15000;
  var alwaysFlyRestUntil = 0, alwaysFlyTries = 0;
  function tickAlwaysFly(g) {
    var me = g.me, PL = g.P.Player, sw = g.sw;
    if (!cfg.alwaysFly || vtActive(g) || st.vt) return;
    if (me.flying) { alwaysFlyTries = 0; return; }
    if (st.healing || me.state === 'sit' || me.downed || st.reFly) return;
    if (sw.fishing || sw.fishingAuto || sw.chopping || chan || (st.looting && st.looting.hold)) return;
    if (busyUI(g.P) || now() < alwaysFlyRestUntil) return;
    if (PL.canFly && !PL.canFly(me)) return;
    if (PL.inNoFlyZone && PL.inNoFlyZone(me, sw.map)) return;
    if (now() - st.lastFlyPress < FLY_RETRY_MS) return;
    if (alwaysFlyTries >= FLY_MAX_TRIES) {
      alwaysFlyTries = 0;
      alwaysFlyRestUntil = now() + ALWAYS_FLY_REST_MS;
      say('Luôn bay: bấm Phi Hành không lên được → thử lại sau ' + ALWAYS_FLY_REST_MS / 1000 + 's');
      return;
    }
    alwaysFlyTries++;
    st.lastFlyPress = now();
    g.P.Input.pressFlyToggle();
  }

  // Nhận xe thì game tự hạ cánh và cấm bay suốt chuyến. Nhớ lúc trước đó có đang bay không; chuyến xong (giao / bị cướp / huỷ)
  // thì dọn trạng thái áp tiêu cũ (st.vt còn sót làm "Luôn bay" tưởng vẫn đang áp tiêu) và bay lại.
  function tickVtFly(g) {
    var ch = vtChuyen(g.P), me = g.me;
    if (!ch && me.flying) st.flySeenAt = now();
    if (ch && !st.vtHad) { st.vtHad = true; st.vtFly = cfg.alwaysFly || now() - (st.flySeenAt || -1e9) < 8000; }
    else if (!ch && st.vtHad) {
      st.vtHad = false;
      if (st.vt && !(cfg.vtRun || planIs('vt'))) st.vt = null;
      if (st.vtFly && !me.flying) { st.reFly = true; st.flyTries = 0; say('Vận tiêu xong → lên phi kiếm lại'); klog('[Vận Tiêu] Xong chuyến → lên phi kiếm lại'); }
      st.vtFly = false;
    }
  }
  function tickReFly(g) {
    if (!st.reFly || st.healing) return;
    if (vtActive(g)) { st.reFly = false; return; }
    var me = g.me, PL = g.P.Player;
    if (!cfg.reFly || me.flying) {
      if (me.flying && cfg.reFly) say('Thiền xong → bay lại');
      st.reFly = false;
      return;
    }
    if (me.state === 'sit' || me.downed) return;
    if (PL.canFly && !PL.canFly(me)) { st.reFly = false; return; }
    if (PL.inNoFlyZone && PL.inNoFlyZone(me, g.sw.map)) return;
    if (now() - st.lastFlyPress < FLY_RETRY_MS) return;
    if (st.flyTries >= FLY_MAX_TRIES) { st.reFly = false; say('Không bay lại được'); return; }
    st.flyTries++;
    st.lastFlyPress = now();
    g.P.Input.pressFlyToggle();
  }

  /* ================= Nhặt đồ ================= */
  // Nhặt đồ không chủ: đi tới tận nơi (auto vẫn đánh dọc đường), tới thì đứng yên chờ máy chủ cho nhặt.
  var LOOT_FIGHT_R = 400;     // px: còn quái trong khoảng này thì chưa đi nhặt
  var LOOT_FIGHT_R_DUNGEON = 900;
  var LOOT_WAIT_MS = 1200;    // đứng trên đồ chừng này mà chưa nhặt được thì bước vào đúng chỗ đồ
  var LOOT_GIVEUP_MS = 5000;  // đi mãi không tới thì bỏ qua món đó một lúc
  var LOOT_SKIP_MS = 20000;
  var lootSkip = {};

  function inDungeon(g) {
    var G = g.P.Gateway;
    return !!(HUYET_MAPS[g.mapId] || (G && G.party && G.party.activeRunId));
  }

  // Còn địch phải đánh quanh mình (quái đang về chỗ cũ thì thôi, nó không quay lại đánh).
  function stillFighting(g) {
    var me = g.me, R = inDungeon(g) ? LOOT_FIGHT_R_DUNGEON : LOOT_FIGHT_R;
    if (mobsAlive(g).some(function (m) {
      return m.def.contactDmg > 0 && m.state !== 'return' && dist(me.x, me.y, m.x, m.y) <= R;
    }) || hostilePlayers(g).some(function (r) { return dist(me.x, me.y, r.x, r.y) <= R; })) return true;
    if (st.ct && st.ct.cart && !st.ct.cart.dead) return true;
    if (st.farmTarget && !st.farmTarget.dead && dist(me.x, me.y, st.farmTarget.x, st.farmTarget.y) <= R + 60) return true;
    if (me.attackTarget && !me.attackTarget.dead && dist(me.x, me.y, me.attackTarget.x, me.attackTarget.y) <= R + 60) return true;
    if (now() - lastStrikeAt < 4000) return true;
    return false;
  }

  function dropName(g, r) {
    var it = r.itemId && g.P.ITEMS && g.P.ITEMS[r.itemId];
    return it ? it.name : r.name || r.itemId || 'vật phẩm';
  }

  // Bảo vật Hư Thiên (ht + vanMs) không nhặt ngay: đứng yên trong Loot.PICK_R thì game tự gửi lệnh
  // vận (HuThienUI.dungTrenBaoVat), vận hỏng thì game tự chờ (htBo) rồi mới cho thử lại.
  function channelDrop(r) { return !!(r && r.ht && r.vanMs > 0); }

  // Đếm mạch khoáng / linh thảo nhặt được (resource.harvest thành công) cho thống kê.
  function hookHarvestStats(P) {
    var G = P.Gateway;
    if (!G || G._ttHv || !G.cmd) return;
    G._ttHv = true;
    var cmd = G.cmd;
    G.cmd = function (name, args, cb) {
      if (name === 'resource.harvest' && args && args.propId) {
        var pid = args.propId, cb0 = cb;
        cb = function (res) { noteHarvest(game(), pid, res); if (cb0) cb0.apply(this, arguments); };
      }
      return cmd.call(this, name, args, cb);
    };
  }

  // Đồ của mình: sau Loot.AUTO_SECS game tự gửi lệnh nhặt, đồ bay về dù đứng đâu.
  function ownPull(P, r) {
    var L = P.Loot, G = P.Gateway;
    return !!(r && r.kind === 'item' && L && L.autoPull && L.AUTO_SECS != null && L.autoPull(r, G && G.selfId, L.AUTO_SECS));
  }

  function lootable(g, r, force) {
    var P = g.P, G = P.Gateway, L = P.Loot, self = G && G.selfId;
    if (!r || r.state !== 'ground' || r.granted) return false;
    if (r.lootId != null && lootSkip[r.lootId] > now()) return false;
    if (r.ht) return channelDrop(r) && !(r.htBo > Date.now());
    if (r.kind === 'item') {
      if (!lootFilterOk(P, r.itemId)) return false;
      if (L && L.canPick && G && G.connected && !L.canPick(r, self, r.age)) return false;
      // Đồ của mình: game tự hút về sau vài giây; bật "Chạy nhặt ngay" hoặc ép nhặt (force=true khi rời map / săn boss / xổng chuồng) thì vẫn chạy tới nhặt luôn cho khỏi chờ.
      if (!cfg.runLoot && !force && ownPull(P, r)) return false;
      if (P.Inventory && P.Inventory.canFit && !P.Inventory.canFit(r.itemId)) return false;
    }
    return true;
  }

  // Hút vật phẩm rơi: nhiều món quanh mình thì vạch một đường đi qua đúng chỗ từng món (món gần …
  var SWEEP_MIN = 2;          // từ chừng này món trở lên mới quét một vòng
  var SWEEP_PAD_MS = 2500;    // thời gian quét = quãng đường / tốc độ + chừng này
  var SWEEP_NEAR = 24;        // đi ngang cách tâm món chừng này là đủ: còn ở trong 40px ~0.5s, dư cho máy chủ trễ

  // Thứ tự đi: món gần nhất kế tiếp, rồi gỡ các đoạn chéo nhau (2-opt) cho đường ngắn lại.
  function sweepOrder(x0, y0, list) {
    var rest = list.slice(), order = [], x = x0, y = y0;
    while (rest.length) {
      rest.sort(function (a, b) { return dist(x, y, a.x, a.y) - dist(x, y, b.x, b.y); });
      var r = rest.shift(); order.push(r); x = r.x; y = r.y;
    }
    function pt(k) { return k < 0 ? { x: x0, y: y0 } : order[k]; }
    for (var pass = 0, better = true; better && pass < 20; pass++) {
      better = false;
      for (var a = 0; a < order.length - 1; a++) {
        for (var b = a + 1; b < order.length; b++) {
          var A = pt(a - 1), B = order[a], Cc = order[b], D = order[b + 1];
          var before = dist(A.x, A.y, B.x, B.y) + (D ? dist(Cc.x, Cc.y, D.x, D.y) : 0);
          var after = dist(A.x, A.y, Cc.x, Cc.y) + (D ? dist(B.x, B.y, D.x, D.y) : 0);
          if (after + 0.5 < before) { order = order.slice(0, a).concat(order.slice(a, b + 1).reverse(), order.slice(b + 1)); better = true; }
        }
      }
    }
    return order;
  }

  function lootSweep(g, cands) {
    var list = cands.filter(function (r) { return !channelDrop(r); });
    if (list.length < SWEEP_MIN) return false;
    var me = g.me, P = g.P, map = g.sw.map, C = P.CONFIG.PLAYER, T = P.CONFIG.TILE || 32;
    var hw = C.HITBOX_W / 2, hh = C.HITBOX_H, sc = spotCheck(g);
    var order = [], path = [], x = me.x, y = me.y, len = 0;
    function walk(pt) { len += dist(x, y, pt.x, pt.y); x = pt.x; y = pt.y; path.push(pt); }
    sweepOrder(me.x, me.y, list).forEach(function (r) {
      var d = dist(x, y, r.x, r.y);
      if (d <= SWEEP_NEAR) { order.push(r); return; }
      // Điểm dừng: trên đường tới món đồ, cách tâm SWEEP_NEAR.
      var k = (d - SWEEP_NEAR) / d, tx = x + (r.x - x) * k, ty = y + (r.y - y) * k;
      if (map.lineClear ? map.lineClear(x, y, tx, ty, hw, hh) : true) {
        if (sc.portals.length && pathCrosses({ me: { x: x, y: y } }, [{ x: tx, y: ty }], sc.portals)) return;
        walk({ x: tx, y: ty });
      } else {
        var seg = P.Pathfinder.route(map, x, y, r.x, r.y, hw, hh);
        if (!seg || !seg.length) return;
        var end = seg[seg.length - 1];
        if (dist(end.x, end.y, r.x, r.y) > T || pathCrosses({ me: { x: x, y: y } }, seg, sc.portals)) return;
        seg.forEach(walk);
        if (dist(x, y, r.x, r.y) > SWEEP_NEAR) walk({ x: r.x, y: r.y });
      }
      order.push(r);
    });
    if (order.length < SWEEP_MIN || !path.length) return false;
    var v = Math.max(1, (me.speed || C.SPEED) * (P.Input.run ? C.RUN_MULT || 1 : 1));
    moveFighting(g, path);
    st.looting = { sweep: true, list: order, at: now(), ms: len / v * 1000 + SWEEP_PAD_MS, drop: order[0] };
    klog('Quét nhặt ' + order.length + ' món quanh đây (' + Math.round(len) + 'px, ~' + (len / v).toFixed(1) + 's)');
    say('Quét nhặt ' + order.length + ' vật phẩm rơi');
    return true;
  }

  // Còn đồ rơi nhặt được (đồ không chủ quanh đây thì chạy tới nhặt; đồ của mình ở đâu trong khu cũng …
  var LEAVE_LOOT_MAX_MS = 20000;  // chờ nhặt tối đa chừng này rồi mới đi (máy chủ không cho nhặt thì thôi)
  var LEAVE_LOOT_R = 800;         // px: trước khi rời đi / dọn bãi / boss / xổng chuồng thì nhặt cả món xa trong tầm nhìn
  function dropsLeft(g) {
    if (!cfg.autoLoot) return [];
    var P = g.P, G = P.Gateway, L = P.Loot, self = G && G.selfId, me = g.me;
    var R = Math.max(cfg.lootRadius, LEAVE_LOOT_R);
    return (g.sw.drops || []).filter(function (r) {
      if (!r || (r.state !== 'ground' && r.state !== 'fall') || r.granted || !isFinite(r.x)) return false;
      if (r.lootId != null && lootSkip[r.lootId] > now()) return false;
      if (dist(me.x, me.y, r.x, r.y) > R && !ownPull(P, r)) return false;
      if (r.ht) return channelDrop(r) && !(r.htBo > Date.now());
      if (r.kind !== 'item' || r.task) return false; // đồ nhiệm vụ (cành Dược Mộc…) việc đó tự lo
      if (!lootFilterOk(P, r.itemId)) return false;
      if (L && L.canPick && G && G.connected && !L.canPick(r, self, r.age)) return false;
      return !(P.Inventory && P.Inventory.canFit && !P.Inventory.canFit(r.itemId));
    });
  }
  // true = đang nhặt / chờ đồ bay về, chưa được đi.
  var HUNT_DROP_WAIT_MS = 1500;
  var HUNT_ITEMS = { pham_hon: 1, oan_hon: 1, chinh_khi: 1, hiep_nghia_lenh: 1 };
  function huntDrops(g) {
    var P = g.P, G = P.Gateway, L = P.Loot, self = G && G.selfId;
    return (g.sw.drops || []).filter(function (r) {
      if (!r || r.kind !== 'item' || !HUNT_ITEMS[r.itemId] || r.granted || (r.state !== 'ground' && r.state !== 'fall')) return false;
      if (r.lootId != null && lootSkip[r.lootId] > now()) return false;
      return !(L && L.canPick && G && G.connected && !L.canPick(r, self, r.age));
    });
  }
  function lootBeforeLeave(g) {
    if (vtActive(g)) return false; // đang áp tiêu: hạn giờ gấp
    var left = dropsLeft(g), hd = huntDrops(g).filter(function (r) { return left.indexOf(r) < 0; });
    left = left.concat(hd);
    if (!left.length && now() - (st.huntKillAt || -1e9) < HUNT_DROP_WAIT_MS) { setAuto(g, false); if (g.me.path && g.me.path.length) g.me.path.length = 0; return true; }
    if (!left.length) { st.leaveLootAt = 0; return false; }
    if (!st.leaveLootAt) { st.leaveLootAt = now(); klog('Còn ' + left.length + ' món rơi chưa nhặt → nhặt xong mới đổi khu / rời map'); }
    if (now() - st.leaveLootAt > LEAVE_LOOT_MAX_MS) {
      if (!st.leaveLootGaveUp) { st.leaveLootGaveUp = true; klog('Chờ nhặt ' + LEAVE_LOOT_MAX_MS / 1000 + 's chưa được (máy chủ chưa cho) → đi tiếp'); }
      return false;
    }
    st.leaveLootGaveUp = false;
    setAuto(g, false);
    if (!tickLoot(g, true) && !st.looting) {
      // Tắt Tự nhặt: hồn không chủ thì tự đi tới nhặt; hồn của mình thì đứng chờ game hút về.
      var me = g.me, free = hd.filter(function (r) { return !r.owner && !ownPull(g.P, r); })[0];
      if (free && dist(me.x, me.y, free.x, free.y) > 16) { if (!(me.path && me.path.length && now() - (st.huntDropRouteAt || 0) < 600)) { var rr = spotCheck(g).route(free.x, free.y); if (rr) { me.setPath(rr.path); st.huntDropRouteAt = now(); } } }
      else if (me.path && me.path.length) me.path.length = 0; // đồ đang tự bay về: đứng chờ
    }
    return true;
  }

  /* --- Boss / mini boss / sự kiện: chia thưởng theo sát thương hay rơi đồ ra đất --- */
  // Theo hướng dẫn game: boss ngoài map, boss thế giới, Thương Đội (Loot.BOC_THAM_TUI), Nhện Bạch Ngọc, Huyết Xích, Yên Lặng …
  var CL_TICKET_R = 600;       // px: giữ mình trong vòng có vé (22 ô ≈ 700px, chừa lề)
  var CL_SEEK_R = 700;         // px: đồ trong vòng này quanh mình thì chạy tới tranh
  var CL_PICK_MS = 250;        // gọi lệnh nhặt liên tục mỗi chừng này
  var CL_PRE_S = 4;            // đồ người khác giữ còn chừng này giây là thành đồ chung → tới đứng sẵn
  function dmgOnly(g) {
    var P = g.P;
    if (tlIn(g) || vtActive(g)) return true;
    if (P.LamLang && g.mapId === P.LamLang.MAP) return true;
    if (vnIn(g)) { var L = vnSt(P); return !(L && (L.tt === 'HOM' || L.homMo)); }
    return false;
  }
  // Mục tiêu đang tranh: boss / mini boss / quái Thương Đội đang đánh hoặc ở gần.
  function clFoe(g) {
    var me = g.me, t = st.farmTarget;
    if (t && !t.dead && t.hp > 0 && (isBoss(t) || (g.P.Loot && g.P.Loot.BOC_THAM_TUI && g.P.Loot.BOC_THAM_TUI[t.type]))) return t;
    return mobsAlive(g).filter(function (m) { return isBoss(m) && dist(me.x, me.y, m.x, m.y) <= 500; })[0] || null;
  }
  // Gọi lệnh nhặt liên tục (game tự gửi loot.pick đúng một lần mỗi món). Chỉ gửi khi đã đứng trong tầm nhặt.
  function spamPick(g, r) {
    var G = g.P.Gateway, L = g.P.Loot, R = (L && L.PICK_R) || 40, me = g.me;
    if (!r || r.kind !== 'item' || r.ht || r.lootId == null || !G || !G.connected || !G.cmd) return false;
    var waitMs = (st.contest && st.contest.drop === r) ? 100 : CL_PICK_MS;
    if (dist(me.x, me.y, r.x, r.y) > R + 6 || now() - (r._ttPickAt || 0) < waitMs) return false;
    r._ttPickAt = now(); r.asked = true;
    G.cmd('loot.pick', { id: r.lootId }, function (res) { if (!(res && res.ok)) r.asked = false; });
    return true;
  }
  function clLockLeft(g, r) { var L = g.P.Loot, k = (r.khoa || (L && L.OWNER_SECS) || 20); return Math.max(0, k - (r.age || 0)); }
  function clCands(g) {
    var P = g.P, G = P.Gateway, L = P.Loot, self = G && G.selfId, me = g.me, out = [];
    (g.sw.drops || []).forEach(function (r) {
      if (!r || r.kind !== 'item' || r.ht || r.task || r.granted || r.state !== 'ground' || !isFinite(r.x)) return;
      if (r.lootId != null && lootSkip[r.lootId] > now()) return;
      if (dist(me.x, me.y, r.x, r.y) > CL_SEEK_R) return;
      if (L && L.expired && L.expired(r.age || 0, r)) return;
      if (ownPull(P, r)) return; // trúng thăm: game tự hút về sau 5 giây
      if (!lootFilterOk(P, r.itemId) || (P.Inventory && P.Inventory.canFit && !P.Inventory.canFit(r.itemId))) return;
      var can = !(L && L.canPick && G && G.connected) || L.canPick(r, self, r.age || 0);
      if (can) out.push({ r: r, wait: 0 });
      else if (r.owner && r.owner !== self && clLockLeft(g, r) <= CL_PRE_S) out.push({ r: r, wait: clLockLeft(g, r) });
    });
    return out;
  }
  function tickContest(g) {
    if (!cfg.autoLoot || g.P.Input.hasManualMove() || g.me.downed || dmgOnly(g) || vnIn(g)) { st.contest = null; return false; }
    var me = g.me, cands = clCands(g);
    if (!cands.length) {
      if (st.contest) { klog('[Tranh đồ] Xong (' + (st.contest.n || 0) + ' lệnh nhặt) → đánh tiếp'); st.contest = null; }
      // Không có gì để tranh: đang đánh boss rơi đồ thì đứng trong vòng có vé (≤ 22 ô quanh boss).
      var f = clFoe(g);
      if (f && dist(me.x, me.y, f.x, f.y) > CL_TICKET_R && !st.dodging) {
        var rr = spotCheck(g).route(f.x + (me.x - f.x) * 0.4, f.y + (me.y - f.y) * 0.4);
        if (rr && !(me.path && me.path.length && now() - (st.clBackAt || 0) < 800)) { moveFighting(g, rr.path); st.clBackAt = now(); kiteNow = 'Vào lại vòng có vé (≤ 22 ô quanh ' + mobLabel(f) + ')'; }
      }
      return false;
    }
    // Sắp xếp ưu tiên: vật phẩm giá trị cao (gradeScore) luôn được ưu tiên hàng đầu,
    // sau đó tính thời gian chờ mở khóa (wait) và khoảng cách (dist).
    cands.sort(function (a, b) {
      var scA = (cfg.smartPriority && a.r.kind === 'item') ? gradeScore(g.P, a.r.itemId) : 0;
      var scB = (cfg.smartPriority && b.r.kind === 'item') ? gradeScore(g.P, b.r.itemId) : 0;
      return (a.wait - b.wait) * 400 - (scA - scB) * 0.2 + dist(me.x, me.y, a.r.x, a.r.y) - dist(me.x, me.y, b.r.x, b.r.y);
    });
    var c = cands[0], r = c.r, d = dist(me.x, me.y, r.x, r.y), R = (g.P.Loot && g.P.Loot.PICK_R) || 40;
    if (!st.contest || st.contest.drop !== r) {
      st.contest = { drop: r, at: now(), n: (st.contest && st.contest.n) || 0 };
      klog('[Tranh đồ] ' + dropName(g, r) + (c.wait > 0 ? ' còn ' + c.wait.toFixed(1) + 's thành đồ chung → tới đứng sẵn' : (r.owner ? ' (của mình / đã thành đồ chung)' : ' (không chủ)') + ' → chạy tới nhặt'));
    }
    if (now() - st.contest.at > 15000) { if (r.lootId != null) lootSkip[r.lootId] = now() + LOOT_SKIP_MS; st.contest = null; return false; }
    setAuto(g, false);
    if (d > R - 8) {
      var scItem = (r.kind === 'item') ? gradeScore(g.P, r.itemId) : 0;
      if (scItem >= 5000 && d > 60 && cfg.autoHaste) {
        talUse(g, 'toc_hanh', 'tranh bảo vật ' + dropName(g, r));
      }
      if (!(me.path && me.path.length && now() - (st.contest.routeAt || 0) < 500)) {
        var p = spotCheck(g).route(r.x, r.y);
        if (p) { if (me.state === 'sit') g.P.Player.stand(me); moveFighting(g, p.path); st.contest.routeAt = now(); }
        else { if (r.lootId != null) lootSkip[r.lootId] = now() + LOOT_SKIP_MS; st.contest = null; return false; }
      }
    } else if (me.path && me.path.length && d <= 10) me.path.length = 0;
    else if (d > 10 && !(me.path && me.path.length)) moveFighting(g, [{ x: r.x, y: r.y }]);
    if (c.wait <= 0.15 && spamPick(g, r)) st.contest.n++;
    kiteNow = 'Tranh đồ: ' + dropName(g, r) + (c.wait > 0 ? ' (còn ' + c.wait.toFixed(1) + 's)' : '') + ' · ' + Math.round(d) + 'px';
    return true;
  }

  function tickLoot(g, force) {
    if (!cfg.autoLoot || g.P.Input.hasManualMove()) { st.looting = null; return false; }
    var me = g.me, drops = g.sw.drops || [], cur = st.looting;
    // Đang đứng vận bảo vật: đứng yên tới khi nhặt được / hết giờ.
    if (cur && cur.hold) {
      if (drops.indexOf(cur.drop) >= 0 && cur.drop.state === 'ground' && !(cur.drop.htBo > Date.now()) && now() - cur.at < cur.ms) {
        if (me.path && me.path.length) me.path.length = 0;
        return true;
      }
      klog(drops.indexOf(cur.drop) >= 0 && cur.drop.state === 'ground' ? 'Vận ' + dropName(g, cur.drop) + ' không thành, thử lại sau' : 'Đã nhặt ' + dropName(g, cur.drop));
      st.looting = null;
      return false;
    }
    var L = g.P.Loot, pickR = L && L.PICK_R || 40;
    // Quái kéo tới giữa chừng: bỏ món đang đi nhặt, quay lại đánh (trừ lúc nhặt nốt trước khi rời đi).
    if (!force && !cfg.runLoot && stillFighting(g)) {
      if (cur) { klog('Còn quái quanh đây → đánh xong mới nhặt'); st.looting = null; }
      return false;
    }
    // Đang quét một vòng qua nhiều món: đi hết đường rồi mới tính lại (món sót nhặt từng món sau).
    if (cur && cur.sweep) {
      var left = cur.list.filter(function (r) { return drops.indexOf(r) >= 0 && r.state === 'ground' && !r.granted; });
      if (left.length && me.path && me.path.length && now() - cur.at < cur.ms) return true;
      klog('Quét xong vòng: nhặt ' + (cur.list.length - left.length) + '/' + cur.list.length + ' món' + (left.length ? ', còn ' + left.length + ' món nhặt lại từng món' : ''));
      st.looting = null;
      cur = null;
    }
    // Đang đi tới một món / đứng trên món đó chờ máy chủ cho nhặt.
    if (cur) {
      var r0 = cur.drop, gone = drops.indexOf(r0) < 0 || r0.state === 'fly' || r0.granted;
      if (gone) {
        klog('Đã nhặt ' + dropName(g, r0) + (cur.arrived ? ' (đứng chờ ' + Math.round(now() - cur.arrived) + 'ms)' : ''));
        st.looting = null;
      } else if (!lootable(g, r0, force)) {
        st.looting = null;
      } else {
        var d0 = dist(me.x, me.y, r0.x, r0.y);
        if (d0 <= pickR - 4) {
          // Tới nơi: đứng yên cho vị trí trên máy chủ bắt kịp, game tự gửi lệnh nhặt.
          if (!cur.arrived) {
            cur.arrived = now();
            if (me.path && me.path.length) me.path.length = 0;
            g.sw.tuChiDuong = false;
          }
          spamPick(g, r0);
          if (now() - cur.arrived < (cfg.runLoot ? 250 : LOOT_WAIT_MS)) return true;
          if (!cur.stepped && d0 > 4) {
            // Chờ lâu vẫn chưa nhặt được: bước vào đúng chỗ món đồ.
            cur.stepped = true;
            cur.arrived = now();
            moveFighting(g, [{ x: r0.x, y: r0.y }]);
            return true;
          }
          if (r0.lootId != null) lootSkip[r0.lootId] = now() + LOOT_SKIP_MS;
          klog('Đứng trên ' + dropName(g, r0) + ' mà máy chủ chưa cho nhặt → bỏ qua 20s');
          st.looting = null;
          return false;
        }
        if (now() - cur.at < LOOT_GIVEUP_MS) {
          if (me.path && me.path.length) return true;
          // Đường dừng hơi xa món đồ (Pathfinder kéo về giữa ô): đi thẳng nốt đoạn cuối.
          moveFighting(g, [{ x: r0.x, y: r0.y }]);
          return true;
        }
        if (r0.lootId != null) lootSkip[r0.lootId] = now() + LOOT_SKIP_MS;
        klog('Đi mãi không tới ' + dropName(g, r0) + ' → bỏ qua 20s');
        st.looting = null;
      }
    }
    var danger = hazards(g), towers = towerZones(g), sc = spotCheck(g), best = null, cands = [];
    drops.forEach(function (r) {
      if (!lootable(g, r, force) || inHazard(danger, r.x, r.y) || inHazard(towers, r.x, r.y)) return;
      var d = dist(me.x, me.y, r.x, r.y);
      if (d > (force ? Math.max(cfg.lootRadius, LEAVE_LOOT_R) : cfg.lootRadius)) return;
      cands.push(r);
      var sc2 = cfg.smartPriority && r.kind === 'item' ? gradeScore(g.P, r.itemId) : 0;
      var netScore = sc2 >= 8000 ? (sc2 - d * 0.1) : (sc2 - d * 0.6);
      if (!best || netScore > best.score) best = { r: r, d: d, s: sc2, score: netScore };
    });
    if (!best) return false;
    // Bỏ qua sweep nếu có vật phẩm cực phẩm (>= 8000) để lao thẳng tới nhặt không độ trễ
    if (cfg.lootSweep && (!best || best.s < 8000) && lootSweep(g, cands)) return true;
    if (channelDrop(best.r) && best.d <= pickR - 8) {
      if (me.path && me.path.length) me.path.length = 0;
      g.sw.tuChiDuong = false;
      st.looting = { drop: best.r, at: now(), hold: true, ms: best.r.vanMs + 3000 };
      klog('Đứng yên vận ' + dropName(g, best.r) + ' (' + (best.r.vanMs / 1000).toFixed(1) + 's)');
      return true;
    }
    var p = sc.route(best.r.x, best.r.y);
    if (!p) {
      if (best.r.lootId != null) lootSkip[best.r.lootId] = now() + LOOT_SKIP_MS;
      klog('Không có đường tới ' + dropName(g, best.r) + ' → bỏ qua 20s');
      return false;
    }
    if (best.s >= 8000 && best.d > pickR && best.d <= 140 && cfg.autoDash) {
      talUse(g, 'toc_hanh', 'lướt nhặt ' + dropName(g, best.r));
    }
    moveFighting(g, p.path);
    st.looting = { drop: best.r, at: now() };
    say('Đi nhặt ' + dropName(g, best.r) + ' (' + Math.round(best.d) + 'px)');
    klog('Đi nhặt ' + dropName(g, best.r) + ' (' + Math.round(best.d) + 'px)');
    return true;
  }

  /* ================= Thu hoạch điểm tài nguyên trong bí cảnh ================= */
  // Huyết Xích Cấm Địa (Bích Ngọc, Trấn Thần Thạch, Địa Linh Quả, Trúc Cơ Thảo) và Yên Lãng Sơn …
  var HARVEST_TYPES = { bich_ngoc_chop: 1, tran_than_thach: 1, dia_linh_qua: 1, truc_co_thao: 1 };
  var HUYET_MAPS = { rung_mang_xa: 1, mach_dat_dong: 1, dam_lay_boss: 1 };
  var HARVEST_CLEAR_R = 220;      // còn quái trong vòng này quanh điểm thì đánh xong mới thu
  var HARVEST_REPLY_MS = 2500;    // gửi lệnh mà máy chủ chưa báo bắt đầu vận thì gửi lại
  var HARVEST_TRIES = 3;
  var HARVEST_WALK_MS = 12000;
  var HARVEST_SKIP_MS = 20000;
  var HARVEST_DONE_MS = 30 * 60 * 1000;
  var harvestSkip = {};
  var chan = null;                // máy chủ báo đang vận: {propId, at, ms}
  var chanWhy = '';

  // Máy chủ báo bắt đầu / huỷ vận qua HuyetSacUI (dùng chung cho Yên Lãng).
  function hookHarvest(P) {
    var H = P.HuyetSacUI;
    if (!H || H._ttHooked || !H.batDauThu) return;
    H._ttHooked = true;
    var bat = H.batDauThu, huy = H.huyThu;
    H.batDauThu = function (e) {
      chan = { propId: String(e && e.propId), at: now(), ms: Math.max(0, Number(e && e.ms) || 3000) };
      return bat.apply(this, arguments);
    };
    if (huy) H.huyThu = function (e) {
      chan = null;
      chanWhy = e && e.why || 'bị huỷ';
      return huy.apply(this, arguments);
    };
  }

  function harvestKey(g, p) { return g.mapId + ':' + p.id; }
  function propName(p) { return p.name || p.type || String(p.id); }

  function harvestSpots(g) {
    var P = g.P, out = [];
    var huyet = HUYET_MAPS[g.mapId] && P.HuyetSacUI && !(P.HuyetSacUI.sealed && P.HuyetSacUI.sealed());
    var yl = P.YenLangUI && P.YenLangUI.st && P.YenLangUI.st.linhThaoMo;
    if (!huyet && !yl) return out;
    (g.sw.map.props || []).forEach(function (p) {
      if (!p || p.hidden || !isFinite(p.x) || !isFinite(p.y)) return;
      if (!((huyet && HARVEST_TYPES[p.type]) || (yl && /^yl_thao_\d$/.test(String(p.id))))) return;
      if (harvestSkip[harvestKey(g, p)] > now()) return;
      out.push(p);
    });
    return out;
  }

  // Cùng phép đo với game khi chạm vào vật: từ chân mình tới giữa ô của vật.
  function propCenter(g, p) { return { x: p.x, y: p.y - (g.P.CONFIG.TILE || 32) / 2 }; }
  function propReach(g, p) {
    var T = g.P.Targeting;
    return T && T.propReach ? T.propReach(p) : (p.r || 40) + 24;
  }
  function inPropReach(g, p) {
    var c = propCenter(g, p);
    return dist(g.me.x, g.me.y, c.x, c.y) <= propReach(g, p) - 2;
  }

  // Đường tới một chỗ đứng trong tầm vật; vật thường chắn lối nên thử vòng quanh nó.
  function harvestRoute(g, p, maxR) {
    var c = propCenter(g, p), R = maxR || propReach(g, p) - 6, sc = spotCheck(g), me = g.me;
    var a0 = Math.atan2(me.y - c.y, me.x - c.x), tries = [c];
    for (var k = 0; k < 12; k++) {
      var a = a0 + (k % 2 ? 1 : -1) * Math.ceil(k / 2) * Math.PI / 6;
      tries.push({ x: c.x + Math.cos(a) * R * 0.7, y: c.y + Math.sin(a) * R * 0.7 });
    }
    for (var i = 0; i < tries.length; i++) {
      var r = sc.route(tries[i].x, tries[i].y);
      if (r && dist(r.to.x, r.to.y, c.x, c.y) <= R) return r;
    }
    return null;
  }

  function harvestBlocked(g, p) {
    var c = propCenter(g, p);
    return mobsAlive(g).some(function (m) {
      return m.def.contactDmg > 0 && dist(m.x, m.y, c.x, c.y) <= HARVEST_CLEAR_R;
    }) || inHazard(towerZones(g), c.x, c.y); // vận 3s trong tầm trụ là bị bắn đứt
  }

  // Trong bí cảnh (Huyết Xích / Yên Lãng) tự lo dọn quái trước: chỉ chờ khi có quái cắn ở sát (quái canh xa / đang ngủ trong
  // vòng 900px không chặn việc hái — trước đây đứng chờ mãi cạnh bụi linh thảo).
  function harvestFightBusy(g) {
    if (!((st.hx && st.hx.inside) || (st.yl && st.yl.inside))) return stillFighting(g);
    var me = g.me;
    return mobsAlive(g).some(function (m) { return m.def.contactDmg > 0 && !m.asleep && m.state !== 'return' && dist(me.x, me.y, m.x, m.y) <= 240; });
  }
  function skipHarvest(g, p, ms, why) {
    harvestSkip[harvestKey(g, p)] = now() + ms;
    st.harvest = null;
    if (why) klog(why);
  }

  function tickHarvest(g) {
    if (!(cfg.harvest || (st.hx && st.hx.inside) || (st.yl && st.yl.inside)) || g.P.Input.hasManualMove()) { st.harvest = null; return false; }
    var me = g.me, h = st.harvest;
    if (h) {
      var p = h.prop;
      if (p.hidden) { say('Đã thu ' + propName(p)); klog('Đã thu ' + propName(p)); st.harvest = null; chan = null; return false; }
      // Đang vận: đứng yên, tắt auto cho khỏi tự đi đánh.
      if (chan && chan.propId === String(p.id)) {
        if (me.path && me.path.length) me.path.length = 0;
        setAuto(g, false);
        if (now() - chan.at < chan.ms + 1500) return true;
        // Hết giờ vận mà vật chưa ẩn: thường là đã thu xong (Yên Lãng không ẩn ngay).
        chan = null;
        skipHarvest(g, p, HARVEST_DONE_MS, 'Vận xong ' + propName(p));
        return false;
      }
      if (chanWhy) { klog('Thu ' + propName(p) + ' không được: ' + chanWhy); chanWhy = ''; h.sentAt = 0; }
      if (harvestFightBusy(g) || harvestBlocked(g, p)) { st.harvest = null; return false; }
      if (inPropReach(g, p)) {
        if (h.sentAt && now() - h.sentAt < HARVEST_REPLY_MS) return true;
        if (h.tries >= HARVEST_TRIES) { skipHarvest(g, p, HARVEST_SKIP_MS, 'Thu ' + propName(p) + ' ' + HARVEST_TRIES + ' lần không được → bỏ qua 20s'); return false; }
        if (me.state === 'attack' || me.state === 'pose') return true;
        setAuto(g, false);
        if (me.path && me.path.length) me.path.length = 0;
        g.sw.tuChiDuong = false;
        // Như chạm vào vật: tới tầm thì game tự gửi lệnh thu.
        g.sw.approach = { obj: p, until: g.P.Game.time + 2 };
        h.sentAt = now();
        h.tries++;
        klog('Thu ' + propName(p) + ' (lần ' + h.tries + ')');
        return true;
      }
      if (now() - h.at > HARVEST_WALK_MS) { skipHarvest(g, p, HARVEST_SKIP_MS, 'Đi mãi không tới ' + propName(p) + ' → bỏ qua 20s'); return false; }
      if (me.path && me.path.length && now() - h.routeAt < 3000) return true;
      var again = harvestRoute(g, p);
      if (!again) { skipHarvest(g, p, HARVEST_SKIP_MS, 'Không có đường tới ' + propName(p) + ' → bỏ qua 20s'); return false; }
      moveFighting(g, again.path);
      h.routeAt = now();
      return true;
    }
    if (harvestFightBusy(g)) return false;
    var best = null;
    harvestSpots(g).forEach(function (p) {
      if (harvestBlocked(g, p)) return;
      var c = propCenter(g, p), d = dist(me.x, me.y, c.x, c.y);
      if (!best || d < best.d) best = { p: p, d: d };
    });
    if (!best) return false;
    var r = inPropReach(g, best.p) ? { path: [] } : harvestRoute(g, best.p);
    if (!r) { skipHarvest(g, best.p, HARVEST_SKIP_MS, 'Không có đường tới ' + propName(best.p) + ' → bỏ qua 20s'); return false; }
    if (r.path.length) moveFighting(g, r.path);
    st.harvest = { prop: best.p, at: now(), routeAt: now(), sentAt: 0, tries: 0 };
    chanWhy = '';
    say('Đi thu ' + propName(best.p) + ' (' + Math.round(best.d) + 'px)');
    klog('Đi thu ' + propName(best.p) + ' (' + Math.round(best.d) + 'px)');
    return true;
  }

  /* ================= Chọn mục tiêu khi farm ================= */
  // Chọn mục tiêu: EXP / thời gian (đi + đánh), chia theo số con bị kéo theo; bỏ con chạy về / trong vùng chiêu / không đường.
  var SMART_CROWD_W = 0.5;     // mỗi con bị kéo theo chia điểm thêm phần này
  var SMART_CHASE_R = 260;     // con đang đuổi trong khoảng này: tính là đang nhắm mình
  var SMART_CHASE_BONUS = 1.5;
  var SMART_TOWER_DIV = 3;     // con đứng trong tầm trụ (không đuổi mình) chia điểm chừng này
  var SMART_SWITCH = 1.3;      // con mới phải hơn con đang nhắm chừng này lần mới đổi
  var SMART_EVERY_MS = 300;
  var SMART_NOROUTE_MS = 5000;
  var noRoute = new WeakMap();

  function smartActive(g) {
    if (!cfg.smartTarget || !g.sw.autoOn) return false;
    var H = g.P.Hotbar, pr = H && H.uuTien ? H.uuTien() : 'auto';
    if (pr !== 'auto') return false;
    if (g.P.Gateway && g.P.Gateway.duel) return false;
    return !hostilePlayers(g).length; // PK thì để game / hit & run lo
  }

  function releaseTarget(g) {
    var T = g && g.P.Targeting, f = st.farmTarget;
    if (f && T && T.key === 'foe:' + f.id) T.manual = false;
    st.farmTarget = null;
  }

  function farmRows(g) {
    var me = g.me, P = g.P, C = P.CONFIG.PLAYER, R = P.CONFIG.TARGET ? P.CONFIG.TARGET.RANGE : 400;
    var v = (me.speed || C.SPEED) * (P.Input.run ? C.RUN_MULT || 1 : 1);
    var reach = P.Player.reach ? P.Player.reach() : C.REACH;
    var dps = Math.max(1, P.Player.meleeDamage ? P.Player.meleeDamage() : 10) / (C.ATTACK_TIME || 0.8);
    var mobs = mobsAlive(g), hz = hazards(g), towers = towerZones(g), rows = [];
    mobs.forEach(function (m) {
      if (m.state === 'return' || m.state === 'flee' || !isFinite(m.x) || !m.def) return;
      var d = dist(me.x, me.y, m.x, m.y);
      if (d > R || inHazard(hz, m.x, m.y) || noRoute.get(m) > now()) return;
      var chasing = (m.state === 'chase' || m.state === 'attack') && d <= SMART_CHASE_R;
      var crowd = 0;
      mobs.forEach(function (o) {
        if (o === m || !(o.def.contactDmg > 0) || !(o.def.aggro > 0) || o.state === 'chase' || o.state === 'attack') return;
        if (dist(o.x, o.y, m.x, m.y) <= o.def.aggro) crowd++;
      });
      var travel = chasing ? 0 : Math.max(0, d - reach) / Math.max(1, v);
      var kill = Math.max(1, m.hp) / dps;
      var s = (m.def.exp > 0 ? m.def.exp : 1) / (travel + kill + 0.6) / (1 + SMART_CROWD_W * crowd);
      // Đứng trong tầm trụ mà không đuổi mình thì phải vào tận nơi ăn đạn: trừ điểm.
      if (!isTower(m) && !chasing && inHazard(towers, m.x, m.y)) s /= SMART_TOWER_DIV;
      rows.push({ m: m, s: chasing ? s * SMART_CHASE_BONUS : s, d: d, crowd: crowd, chasing: chasing, far: d > reach + 40 });
    });
    rows.sort(function (a, b) { return b.s - a.s; });
    return rows;
  }

  function mobLabel(m) { return (m.def && m.def.name || 'Quái').split('·')[0].trim(); }

  // Chọn + khoá mục tiêu (không di chuyển). Chạy trước hit & run để hit & run lùi / áp theo nó.
  function tickTarget(g) {
    var pin = st.pin;
    if (pin && pin.t && !pin.t.dead && now() - pin.at < EV_PIN_MS) {
      var Tp = g.P.Targeting, kp = 'foe:' + pin.t.id;
      st.farmTarget = pin.t;
      if (Tp && Tp.list && Tp.list.some(function (e) { return e.key === kp; })) { Tp.key = kp; Tp.manual = true; }
      return;
    }
    // Có boss gần (và không PK / tỉ thí): nhắm boss cho đủ ngưỡng nhận đồ.
    var boss = (cfg.bossFocus || st.bh) && g.sw.autoOn && !(g.P.Gateway && g.P.Gateway.duel) && !hostilePlayers(g).length ? nearBoss(g) : null;
    if (boss) {
      // Dồn sát thương: đánh boss mãi không ra sát thương mà hộ vệ còn sống → hạ hộ vệ trước.
      var guard = cfg.bossMaxDmg && isWorldBoss(g, boss) ? bossGuardTarget(g, boss) : null;
      if (guard) {
        if (st.farmTarget !== guard) { st.farmTarget = guard; klog('Đánh ' + mobLabel(boss) + ' chưa ra sát thương → hạ hộ vệ ' + mobLabel(guard) + ' trước'); }
        boss = guard;
      } else if (st.farmTarget !== boss) {
        st.farmTarget = boss;
        var cb = bossShare(boss);
        klog('Nhắm boss ' + mobLabel(boss) + (cb ? ' · ' + bossShareText(cb) : ''));
      }
      var Tb = g.P.Targeting, kb = 'foe:' + boss.id;
      if (Tb && Tb.list && Tb.list.some(function (e) { return e.key === kb; })) { Tb.key = kb; Tb.manual = true; }
      return;
    }
    if (st.farmTarget && isBoss(st.farmTarget) && !smartActive(g)) releaseTarget(g);
    if (!smartActive(g)) { if (st.farmTarget) releaseTarget(g); return; }
    var cur = st.farmTarget;
    if (cur && (cur.dead || cur.state === 'return' || cur.state === 'flee')) { releaseTarget(g); cur = null; }
    if (!cur || now() - st.farmPickAt >= SMART_EVERY_MS) {
      st.farmPickAt = now();
      var rows = farmRows(g), best = null, curRow = null, sc = null;
      rows.forEach(function (r) { if (r.m === cur) curRow = r; });
      for (var i = 0; i < rows.length && i < 4; i++) {
        var r = rows[i];
        if (r.m !== cur && r.far) {
          sc = sc || spotCheck(g);
          if (!sc.route(r.m.x, r.m.y)) { noRoute.set(r.m, now() + SMART_NOROUTE_MS); continue; }
        }
        best = r;
        break;
      }
      if (curRow && best && best.m !== cur && (cur.hp < cur.hpMax || best.s < curRow.s * SMART_SWITCH)) best = curRow;
      if (!best) { if (cur) releaseTarget(g); return; }
      if (best.m !== cur) {
        st.farmTarget = best.m;
        klog('Nhắm ' + mobLabel(best.m) + ' (' + Math.round(best.d) + 'px, máu ' + Math.max(0, Math.round(best.m.hp)) +
          (best.chasing ? ', đang đuổi mình' : '') + (best.crowd ? ', kéo thêm ' + best.crowd + ' con' : '') + ')');
      }
    }
    var T = g.P.Targeting, key = 'foe:' + st.farmTarget.id;
    if (T && T.list && T.list.some(function (e) { return e.key === key; })) { T.key = key; T.manual = true; }
  }

  // Không có việc gì khác thì đi tới mục tiêu đã chọn (auto chỉ tự đi tới con gần nhất).
  // Trong tầm thì đặt approach để auto đánh / ra chiêu vào đúng con đang khoá.
  function smartMove(g) {
    var me = g.me;
    if (now() < (st.wbLootUntil || 0) && st.wbLootPos && g.mapId === st.wbLootPos.map && !g.P.Input.hasManualMove()) {
      if (dist(me.x, me.y, st.wbLootPos.x, st.wbLootPos.y) > 150) {
        if (!(me.path && me.path.length && g.sw.tuChiDuong)) {
          var rw = spotCheck(g).route(st.wbLootPos.x, st.wbLootPos.y);
          if (rw) { moveFighting(g, rw.path); return true; }
        }
      }
      return false;
    }
    var t = st.farmTarget;
    if (!t || !(smartActive(g) || (cfg.bossFocus && isBoss(t))) || g.P.Input.hasManualMove()) return false;
    var T = g.P.Targeting, key = 'foe:' + t.id;
    if (!T || T.key !== key) return false;
    var reach = (g.P.Player.reach ? g.P.Player.reach() : g.P.CONFIG.PLAYER.REACH) + (t.def && t.def.bodyRadius || 0) - 2;
    var d = dist(me.x, me.y, t.x, t.y), def = plannedSkill(g, t);
    // Vừa gượng dậy tại chỗ trước mặt boss, máu thấp (< 45%): giữ khoảng cách đệm (180px) không áp sát hitbox chết tức thì
    if (now() < (st.reviveGraceUntil || 0) && isBoss(t) && me.hp / (me.hpMax || 1) < 0.45) {
      reach = Math.max(reach, 180);
    }
    // Giai đoạn kết liễu boss (máu boss <= 10%): nếu máu bản thân thấp (< 35%), lùi giữ tầm xa (180px) để bảo toàn mạng sống, chắc chắn đủ điều kiện bốc thăm nhận thưởng
    if (isBoss(t) && t.hpMax > 0 && (t.hp / t.hpMax) <= 0.10 && (me.hp / (me.hpMax || 1)) < 0.35) {
      reach = Math.max(reach, 180);
      if (cfg.autoShield) talUse(g, 'kim_giap', 'bảo vệ cuối trận boss');
    }
    // Săn yêu thú xổng chuồng hoặc tranh Last-Hit: luôn áp sát chạm mục tiêu (reach = 2), không đứng từ xa tung chiêu
    var hugClose = !!(st.xc || isLastHitOnly(t));
    if (hugClose) reach = 2;
    else if (def && d <= skillRange(g, def)) reach = Math.max(reach, d);
    if (d <= reach) {
      if (!g.sw.approach) g.sw.approach = { key: key, until: g.P.Game.time + 2 };
      return false;
    }
    if (me.path && me.path.length && g.sw.tuChiDuong) return false;
    var r = spotCheck(g).route(t.x, t.y);
    if (!r) { noRoute.set(t, now() + SMART_NOROUTE_MS); releaseTarget(g); return false; }
    moveFighting(g, r.path);
    return true;
  }

  /* ================= Dược Công (việc hằng ngày ở Đại Phu) ================= */
  // Dược Công: đi bộ / chạm NPC / chọn nút như người chơi. Đại Phu → Sổ Dược Công → Nhận Việc → tên việc → Nhận Việc Này.
  var DC_TASKS = [
    ['duoc_moc', 'Thu Gom Dược Mộc'], ['cau_ca', 'Câu Cá Làm Dược Liệu'], ['ho_tong_chau', 'Đưa Người Về Làng'],
    ['truc_gia', 'Trúc Tâm Dẫn Dược'], ['linh_chi', 'Linh Chi Dưới Chân Núi'], ['dai_hoi', 'Thắng Trận Đại Hội']
  ];
  var DC_NPC = 'dai_phu', DC_ESCORT_NPC = 'su_phu';
  var DC_WATERS = ['ho_bich_thuy_cong', 'suoi_duoc_coc'];
  var DC_DLG_MS = 8000;        // hộp thoại phải mở trong khoảng này sau khi chạm NPC
  var DC_REPLY_MS = 4000;      // chạm vật mà game chưa phản hồi (chặt / hái / câu) thì chạm lại
  var DC_TRIES = 4;
  var DC_RETRY_MS = 3000;      // lỗi thì chờ chừng này × số lần lỗi rồi làm lại (tối đa DC_RETRY_MAX_MS)
  var DC_RETRY_MAX_MS = 20000;
  var DC_TASK_FAILS = 6;       // một việc lỗi liền chừng này lần thì bỏ qua việc đó hôm nay
  var DC_STALL_MS = 30000;     // đứng yên không tiến triển chừng này thì coi là kẹt, làm lại
  var DC_STALL_FISH_MS = 90000;
  var dcSkip = {};             // taskId → ngày bỏ qua (lỗi mãi)
  var dcDlg = null;            // { want, task, until } — hộp thoại script đang chờ để bấm
  var dcCloseNextUntil = 0;    // bấm xong nút cuối: hộp thoại kế tiếp (quầy hạt…) thì đóng luôn
  var propMapCache = {};

  function dcLog(msg) { klog('[Dược Công] ' + msg); say('Dược Công: ' + msg); }

  // Hộp thoại: script chỉ bấm khi chính nó vừa chạm NPC / mặt nước (dcDlg còn hạn).
  function hookDialog(P) {
    var H = P.HUD;
    if (!H || H._ttDlg || !H.openDialog) return;
    H._ttDlg = true;
    var open = H.openDialog;
    H.openDialog = function (title, text, o) {
      var r = open.apply(this, arguments), seq = (H._ttSeq = (H._ttSeq || 0) + 1);
      if (enabled && (dcDlg && now() < dcDlg.until || now() < dcCloseNextUntil)) {
        setTimeout(function () { if (H._ttSeq === seq && H.dialogOpen) dcAnswer(H, title, text, o || {}); }, 300);
      }
      return r;
    };
  }

  function dcAnswer(H, title, text, o) {
    if (!dcDlg || now() >= dcDlg.until) {
      if (now() < dcCloseNextUntil) { dcCloseNextUntil = 0; H.closeDialog(); }
      return;
    }
    var w = dcDlg, act = o.actionLabel || '', choices = (o.choices || []).filter(function (c) { return c && !c.disabled; });
    var ACT = { start: /^Nhận Việc Này/, turnin: /^Giao (Nguyên Liệu|Ba Cá)/, escort: /^Bẩm Thầy Ông Nội/ };
    if (ACT[w.want] && ACT[w.want].test(act) && o.onAction) {
      H.closeDialog();
      dcDlg = null;
      dcCloseNextUntil = now() + 1500;
      o.onAction();
      return;
    }
    function pick(re) { for (var i = 0; i < choices.length; i++) if (re.test(String(choices[i].label || ''))) return choices[i]; return null; }
    var c = null;
    if (w.want === 'fish') c = pick(/^Tự động câu/);
    else if (w.want === 'close') { dcDlg = null; H.closeDialog(); return; }
    else if (w.want === 'diemdanh') { c = pick(/^Điểm Danh Hôm Nay/); if (c) { dcDlg = null; dcCloseNextUntil = now() + 2500; } }
    else if (w.want === 'vtnhan') { c = pick(/^Nhận Tiêu/); if (c) dcDlg = null; }
    else if (w.want === 'vtgiao') { c = pick(/^Giao Hàng/); if (c) { dcDlg = null; dcCloseNextUntil = now() + 2500; } }
    else if (w.want === 'thinh') { c = pick(/^Thỉnh Hồn Phiên/); if (c) dcDlg = null; }
    else if (w.want === 'cung') { c = pick(/^Cúng tới sạch nghiệp/) || pick(/^Cúng mười nén/) || pick(/^Cúng một nén/); if (c) dcDlg = null; }
    else if (w.want === 'sow') { var seeds = choices.filter(function (x) { return /^Gieo /.test(String(x.label || '')); }); c = seeds[seeds.length - 1] || null; if (c) dcDlg = null; }
    else if (w.want === 'start') c = (w.name && pick(new RegExp('^' + w.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '$'))) ||
      pick(/^Nhận Việc Dược Công/) || pick(/^Sổ Dược Công/);
    else if (w.want === 'turnin') c = pick(/^Sổ Dược Công/);
    if (c) { H.closeDialog(); c.onChoose && c.onChoose(); return; }
    // Hộp thoại không như mong đợi (thiếu cảnh giới, hết lượt…): ghi lại, đóng.
    dcDlg = null;
    H.closeDialog();
    dcFail('Hộp thoại "' + String(title || '') + '" không có nút cần bấm: ' + String(text || '').replace(/\s+/g, ' ').slice(0, 90));
  }

  // Map chứa vật / NPC có id này (dò trong dữ liệu bản đồ của game).
  function propMap(P, id) {
    if (propMapCache[id]) return propMapCache[id];
    var MD = P.MapData || {}, found = null;
    Object.keys(MD).some(function (k) {
      var m = MD[k];
      if (!m || typeof m !== 'object' || typeof m.id !== 'string') return false;
      return ['props', 'flatProps', 'interactables'].some(function (f) {
        return Array.isArray(m[f]) && m[f].some(function (p) { return p && p.id === id && (found = m.id); });
      });
    });
    if (found) propMapCache[id] = found;
    return found;
  }

  function findHere(g, id) {
    var m = g.sw.map, lists = [m.props || [], m.flatProps || [], m.interactables || []];
    for (var i = 0; i < lists.length; i++) for (var j = 0; j < lists[i].length; j++) if (lists[i][j] && lists[i][j].id === id) return lists[i][j];
    return null;
  }

  // Đi sang map có vật id. Trả về true khi đang đi (chưa tới map).
  function dcGoMap(g, mapId) {
    var d = st.dc;
    if (!mapId) { dcFail('Không biết vật cần tới nằm ở map nào'); return true; }
    if (g.mapId === mapId) { if (st.travel) stopTravel(); return false; }
    if (!st.travel || st.travel.map !== mapId) {
      if (++d.travels > 6) { dcFail('Không đi được tới ' + mapName(mapId)); return true; }
      startTravel(mapId, null, null, 'Dược Công: đi tới ' + mapName(mapId));
    }
    tickTravel(g);
    return true;
  }

  // Chạm vật thì game cho từ (r||40)+24, nhưng đang chặt (Trúc Già, Cổ Thụ) mà cách giữa ô vật quá
  // (r||40)+16 là game huỷ lần chặt. Nên đi vào hẳn trong (r||40)+10 rồi mới chạm.
  var DC_STAND_PAD = 10;
  function dcReach(g, p) { return Math.min(propReach(g, p) - 2, (p.r || 40) + DC_STAND_PAD); }

  // Đi tới trong tầm vật rồi chạm vào nó như bấm chuột. 'walk' | 'sent' | 'fail'.
  // d: trạng thái của việc đang làm (touches, touchAt, routeAt).
  function dcTouch(g, p) { return touchProp(g, st.dc, p); }
  function touchProp(g, d, p) {
    var me = g.me, c = propCenter(g, p), R = dcReach(g, p);
    setAuto(g, false);
    if (dist(me.x, me.y, c.x, c.y) <= R) {
      if (d.touchAt && now() - d.touchAt < DC_REPLY_MS) return 'sent';
      if (++d.touches > DC_TRIES) return 'fail';
      if (me.path && me.path.length) me.path.length = 0;
      g.sw.tuChiDuong = false;
      g.sw.approach = { obj: p, until: g.P.Game.time + 2 };
      d.touchAt = now();
      return 'sent';
    }
    if (me.path && me.path.length && now() - d.routeAt < 3000) return 'walk';
    var r = harvestRoute(g, p, R - 4);
    if (!r) return 'fail';
    if (me.state === 'sit') g.P.Player.stand(me);
    me.setPath(r.path);
    d.routeAt = now();
    return 'walk';
  }

  function dcStep(name) {
    var d = st.dc;
    if (d.step !== name) { d.step = name; d.touches = 0; d.touchAt = 0; d.stepAt = now(); }
  }

  function dcStop(msg) {
    if (msg) dcLog(msg);
    st.dc = null;
    dcDlg = null;
    cfg.dcRun = false;
    save();
    if (ui.root) syncInputs();
  }

  function dcToday() { return new Date(Date.now() + 7 * 3600e3).toISOString().slice(0, 10); }

  // Lỗi giữa chừng: dọn trạng thái dở (đường đi, hộp thoại, lệnh chạm), chờ một lúc rồi làm lại.
  // Một việc lỗi liền nhiều lần thì bỏ qua việc đó hôm nay, sang việc khác.
  function dcFail(msg) {
    var d = st.dc, g = game();
    if (!d) return;
    d.fails++;
    d.taskFails++;
    var wait = Math.min(DC_RETRY_MAX_MS, DC_RETRY_MS * d.fails);
    dcLog(msg + ' → thử lại sau ' + Math.round(wait / 1000) + 's (lần ' + d.fails + ')');
    if (d.task && d.taskFails >= DC_TASK_FAILS) {
      dcSkip[d.task] = dcToday();
      dcLog('Việc ' + d.task + ' lỗi ' + d.taskFails + ' lần liền → bỏ qua hôm nay');
      d.taskFails = 0;
    }
    if (st.travel) stopTravel();
    dcDlg = null;
    if (g) {
      if (g.sw.approach) g.sw.approach = null;
      if (g.me.path && g.me.path.length) g.me.path.length = 0;
      var H = g.P.HUD;
      if (H && H.dialogOpen && H.closeDialog) H.closeDialog();
    }
    d.step = ''; d.touches = 0; d.touchAt = 0; d.travels = 0; d.prop = null;
    d.waitUntil = now() + wait;
    d.seenAt = now();
  }

  // Xong hết: về chỗ farm lúc bật Dược Công, tới nơi thì bật lại auto.
  function dcFinish(msg) {
    var back = cfg.dcReturn;
    dcStop(msg);
    if (back && back.map) goBack(back.map, back.x, back.y, 'Xong Dược Công → về chỗ farm ' + mapName(back.map), 'dc', back.khu);
  }

  // Kẹt: không đổi bước, không đổi chỗ, không thêm nguyên liệu trong một lúc lâu.
  function dcWatch(g, t) {
    var d = st.dc, Q = g.P.Quest, me = g.me;
    var sig = [d.step, g.mapId, Math.round(me.x / 24), Math.round(me.y / 24), t ? t.id : '', t ? Q.seedQuestProgress() : '',
    st.travel ? st.travel.map : ''].join('|');
    if (sig !== d.sig) { d.sig = sig; d.seenAt = now(); return false; }
    if (d.step.indexOf('chờ') === 0) return false;
    var fishing = g.sw.fishing || g.sw.fishingAuto, limit = fishing ? DC_STALL_FISH_MS : DC_STALL_MS;
    if (now() - d.seenAt < limit) return false;
    if (fishing && g.sw.stopFishing) g.sw.stopFishing();
    dcFail('Kẹt ' + Math.round(limit / 1000) + 's ở bước "' + (d.step || '—') + '"');
    return true;
  }

  // Việc Đại Hội: chỉ nhận khi bật Tự đánh Đại Hội và kỳ này đang mở sổ mà mình đủ tư cách (nhận rồi thì giữ tới khi thắng).
  function dcDhPending(Q) { return cfg.dhRun && cfg.dc_dai_hoi !== false && dcSkip.dai_hoi !== dcToday() && Q.seedTaskRunsLeft('dai_hoi') > 0; }
  function dcDhNow() { var g = game(), L = g && dhLich(g.P); return !!(cfg.dhRun && L && L.giaiDoan === 'DANG_KY' && dhBang(g, L)); }
  function dcNextTask(Q) {
    for (var i = 0; i < DC_TASKS.length; i++) {
      var id = DC_TASKS[i][0];
      if (cfg['dc_' + id] !== false && dcSkip[id] !== dcToday() && Q.seedTaskRunsLeft(id) > 0 && (id !== 'dai_hoi' || dcDhNow())) return id;
    }
    return null;
  }

  // Nói chuyện với NPC để bấm một chuỗi nút; xong khi done() đúng.
  function dcTalk(g, npcId, want, name, done) {
    var d = st.dc;
    if (done()) return 'done';
    if (dcGoMap(g, propMap(g.P, npcId))) return 'busy';
    var npc = findHere(g, npcId);
    if (!npc) { dcFail('Không thấy ' + npcId + ' trong map'); return 'busy'; }
    if (g.P.HUD && g.P.HUD.dialogOpen) return 'busy';
    var r = dcTouch(g, npc);
    if (r === 'fail') { dcFail('Không nói chuyện được với ' + (npc.name || npcId)); return 'busy'; }
    if (r === 'sent' && (!dcDlg || dcDlg.at !== d.touchAt)) dcDlg = { want: want, name: name, until: now() + DC_DLG_MS, at: d.touchAt };
    return 'busy';
  }

  function dcCollect(g, t) {
    var d = st.dc, Q = g.P.Quest, sw = g.sw, me = g.me;
    if (t.id === 'duoc_moc') {
      if (dcGoMap(g, propMap(g.P, 'co_thu_linh_moc'))) return;
      // Cành đã rụng thì nhặt trước (đi vào trong Loot.PICK_R là game tự nhặt).
      var branch = (sw.drops || []).filter(function (r) { return r.task === t.id && r.state === 'ground'; })
        .sort(function (a, b) { return dist(me.x, me.y, a.x, a.y) - dist(me.x, me.y, b.x, b.y); })[0];
      if (branch) {
        dcStep('nhặt cành');
        if (me.path && me.path.length && now() - d.routeAt < 3000) return;
        var pr = spotCheck(g).route(branch.x, branch.y);
        me.setPath(pr ? pr.path : [{ x: branch.x, y: branch.y }]);
        d.routeAt = now();
        return;
      }
      if ((sw.drops || []).some(function (r) { return r.task === t.id; })) return; // cành đang rơi
      if (sw.chopping) { dcStep('chặt cây'); return; }
      if (!Q.chopAvailable(t.id)) return;
      var tree = findHere(g, 'co_thu_linh_moc');
      if (!tree) return dcFail('Không thấy Cổ Thụ trong map');
      dcStep('chặt cây ' + Q.seedQuestProgress());
      if (dcTouch(g, tree) === 'fail') dcFail('Không chặt được Cổ Thụ');
      return;
    }
    // Linh Chi (hái) / Trúc Già (chặt): chạm lần lượt từng vật còn hiện.
    if (dcGoMap(g, propMap(g.P, t.propIds[0]))) return;
    if (sw.chopping) return;
    var list = t.propIds.map(function (id) { return findHere(g, id); }).filter(function (p) { return p && !p.hidden && !p.harvestPending; });
    var p = d.prop && list.indexOf(d.prop) >= 0 ? d.prop : list.sort(function (a, b) {
      return dist(me.x, me.y, a.x, a.y) - dist(me.x, me.y, b.x, b.y);
    })[0];
    if (!p) { dcStep('chờ ' + t.itemName + ' mọc lại'); return; }
    if (p !== d.prop) { d.prop = p; dcStep(t.itemName + ' ' + p.id); }
    if (dcTouch(g, p) === 'fail') { d.prop = null; d.touches = 0; }
  }

  function dcFish(g, t) {
    var d = st.dc, sw = g.sw, T = g.P.Targeting;
    if (sw.fishing || sw.fishingAuto) { dcStep('đang câu ' + g.P.Quest.seedQuestProgress() + '/' + t.need); setAuto(g, false); return; }
    var id = DC_WATERS.filter(function (w) { return propMap(g.P, w); })[0];
    if (dcGoMap(g, propMap(g.P, id))) return;
    var w = findHere(g, id);
    if (!w) return dcFail('Không thấy chỗ câu cá');
    if (g.P.HUD && g.P.HUD.dialogOpen) return;
    dcStep('thả câu');
    setAuto(g, false);
    // Mặt nước là cảnh vật: bấm E khi đang chọn nó thì game mở "Thả câu / Tự động câu".
    if (!inPropReach(g, w)) {
      if (g.me.path && g.me.path.length && now() - d.routeAt < 3000) return;
      var r = harvestRoute(g, w);
      if (!r) return dcFail('Không có đường tới chỗ câu cá');
      g.me.setPath(r.path);
      d.routeAt = now();
      return;
    }
    if (d.touchAt && now() - d.touchAt < DC_REPLY_MS) return;
    if (++d.touches > DC_TRIES) return dcFail('Không thả câu được');
    var key = 'scn:' + w.id;
    if (T && T.list && T.list.some(function (e) { return e.key === key; })) { T.key = key; T.manual = true; }
    if (!T || T.key !== key) return;
    if (g.me.path && g.me.path.length) g.me.path.length = 0;
    d.touchAt = now();
    dcDlg = { want: 'fish', until: now() + DC_DLG_MS, at: d.touchAt };
    g.P.Input.pressInteract();
  }

  function tickDuocCong(g) {
    if (!cfg.dcRun) { if (st.dc) st.dc = null; return false; }
    if (cfg.planRun && !planIs('dc')) return false; // Lịch đang làm việc khác: không chạy chen
    if (st.bh || st.bd || st.xc || st.td) return false; // tạm dừng khi đang đi đánh boss / quái biến dị
    var P = g.P, Q = P.Quest;
    if (!Q || !Q.seedTaskInfo || !Q.startSeedQuest) { dcStop('Bản game này không có việc Dược Công'); return false; }
    if (Q.canOpenSeedMenu && !Q.canOpenSeedMenu()) { dcStop('Chưa mở việc Dược Công (cần làm tới đoạn gặp Đại Phu)'); return false; }
    if (g.P.Input.hasManualMove()) return true;
    var d = st.dc || (st.dc = {
      step: '', touches: 0, touchAt: 0, routeAt: 0, stepAt: now(), travels: 0, task: null, prop: null,
      fails: 0, taskFails: 0, waitUntil: 0, sig: '', seenAt: now(), prog: null
    });
    // Làm Dược Công thì không đánh quái: auto luôn tắt (né chiêu / thiền vẫn chạy trước phần này).
    setAuto(g, false);
    if (now() < d.waitUntil) return true;
    var t = Q.seedTaskInfo();
    if (dcWatch(g, t)) return true;
    if (t && t.kind === 'tournament') {
      if (!cfg.dhRun) { dcStop('Đang giữ việc Đại Hội — bật "Tự đánh Đại Hội" hoặc huỷ ở Đại Phu rồi bật lại'); return false; }
      st.dc = null; return false; // thắng một trận Đại Hội là game tự ghi công
    }
    if (!t) {
      var next = dcNextTask(Q);
      if (!next && dcDhPending(Q)) { if (!d.dhWait) { d.dhWait = 1; dcLog('Còn việc Thắng Trận Đại Hội → chờ kỳ Đại Hội mở sổ mới nhận'); } d.step = 'chờ Đại Hội mở sổ để nhận việc'; return false; }
      if (!next) { dcFinish('Đã làm hết các việc được chọn hôm nay'); return false; }
      var def = DC_TASKS.filter(function (x) { return x[0] === next; })[0];
      if (d.task !== next) { d.task = next; d.travels = 0; d.taskFails = 0; d.fails = 0; dcStep('nhận ' + def[1]); dcLog('Đi nhận việc ' + def[1] + ' (còn ' + Q.seedTaskRunsLeft(next) + ' lượt)'); }
      dcTalk(g, DC_NPC, 'start', def[1], function () { return !!Q.seedTaskInfo(); });
      return true;
    }
    if (d.task !== t.id) { d.task = t.id; d.travels = 0; d.prop = null; d.taskFails = 0; }
    var prog = Q.seedQuestProgress();
    if (prog !== d.prog) { d.prog = prog; d.fails = 0; d.taskFails = 0; }
    if (t.kind === 'escort') {
      dcStep('đưa cháu về làng');
      var r = dcTalk(g, DC_ESCORT_NPC, 'escort', null, function () { return !Q.seedTaskInfo(); });
      if (r === 'done') dcLog('Xong ' + t.shortName);
      return true;
    }
    if (Q.seedQuestComplete()) {
      if (g.sw.fishing || g.sw.fishingAuto) { g.sw.stopFishing && g.sw.stopFishing(); return true; }
      if (d.step.indexOf('giao') !== 0) { d.travels = 0; dcStep('giao ' + t.shortName); }
      dcTalk(g, DC_NPC, 'turnin', null, function () { return !Q.seedTaskInfo(); });
      return true;
    }
    if (t.kind === 'fishing') dcFish(g, t);
    else dcCollect(g, t);
    return true;
  }

  /* ================= Đi nhặt nguyên liệu chế tạo (mạch khoáng, linh thảo) ================= */
  // Vật nhặt được trên bản đồ: chạm vào là máy chủ cho luôn (resource.harvest), vật ẩn đi rồi mọc …
  var GATHER_TYPES = [
    ['mach_han_tinh', 'han_tinh_thach', 'Hàn Tinh Thạch'], ['mach_tu_tinh', 'tu_tinh_thach', 'Tử Tinh Thạch'],
    ['mach_luc_tinh', 'luc_tinh_thach', 'Lục Tinh Thạch'], ['phong_tinh_mach', 'phong_tinh_thach', 'Phong Tinh Thạch'],
    ['phong_linh_thao', 'phong_linh_thao', 'Phong Linh Thảo'], ['ling_chi_prop', 'nam_linh_chi', 'Nấm Linh Chi']
  ];
  var GA_KHU_REVISIT_MS = 4 * 60000;  // khu vừa vét trong chừng này thì chưa quay lại (vật chưa kịp mọc)
  var GA_MAP_REST_MS = 3 * 60000;     // map vét hết mọi khu: nghỉ chừng này mới quay lại
  var GA_PROP_SKIP_MS = 60000;        // chạm mãi không được: bỏ vật đó một lúc
  var GA_KHU_WAIT_MS = 10000;         // chọn khu rồi mà chưa sang được thì thử lại
  var GA_SETTLE_MS = 2500;           // vào map / đổi khu xong chờ máy chủ gửi trạng thái vật
  var GA_FIGHT_R = 140;               // quái đang đuổi trong khoảng này: đánh trước (nếu bật)
  var gaVisited = {};                 // 'map:khu' → lúc vét xong
  var gaMapRest = {};                 // map → nghỉ tới lúc
  var gaPropSkip = {};                // 'map:khu:id' → bỏ tới lúc
  var gaMapsCache = null;
  var khuList = null;                 // {mapId, dem[], toiDa, tran[]}: số người mỗi khu (khi Bảng Khu mở)
  var khuListAt = 0;                  // lúc nhận danh sách đó
  var khuOpenAt = 0;                  // lúc Bảng Khu được mở gần nhất (ai mở cũng tính)
  var KHU_LIST_WAIT_MS = 1500;        // Bảng Khu mở rồi chờ danh sách số người chừng này rồi mới chọn

  function gaLog(msg) { klog('[Nhặt NL] ' + msg); say('Nhặt nguyên liệu: ' + msg); }
  function gaTypeOf(type) { for (var i = 0; i < GATHER_TYPES.length; i++) if (GATHER_TYPES[i][0] === type) return GATHER_TYPES[i]; return null; }
  function gaKhu(P) { return P.KhuUI && P.KhuUI.khu || 1; }
  function gaSoKhu(P) { return P.KhuUI && P.KhuUI.soKhu || 1; }

  // Danh sách số người mỗi khu chỉ về khi Bảng Khu mở: nghe lại để tránh chọn khu đầy.
  function hookKhu(P) {
    var K = P.KhuUI;
    if (!K || K._ttHooked || !K.onList) return;
    K._ttHooked = true;
    var on = K.onList;
    K.onList = function (t) { if (t && t.mapId) { khuList = t; khuListAt = now(); } return on.apply(this, arguments); };
    if (K.open) { var op = K.open; K.open = function () { khuOpenAt = now(); return op.apply(this, arguments); }; }
  }

  // Map nào có những loại vật nào (đếm trong dữ liệu bản đồ của game).
  function gaMaps(P) {
    if (gaMapsCache) return gaMapsCache;
    var out = {}, MD = P.MapData || {};
    Object.keys(MD).forEach(function (k) {
      var m = MD[k];
      if (!m || typeof m !== 'object' || typeof m.id !== 'string' || out[m.id]) return;
      var types = {}, n = 0;
      ['props', 'flatProps'].forEach(function (f) {
        (m[f] || []).forEach(function (p) { if (p && gaTypeOf(p.type)) { types[p.type] = (types[p.type] || 0) + 1; n++; } });
      });
      if (n) out[m.id] = { id: m.id, types: types };
    });
    if (Object.keys(out).length) gaMapsCache = out;
    return out;
  }

  // Loại nào đã đủ mục tiêu hoặc túi không còn chỗ chứa thì tắt luôn loại đó, sang nhặt loại khác.
  function gaOffFull(P) {
    if (st.gaOverride) return;
    var inv = P.Inventory, off = [];
    GATHER_TYPES.forEach(function (t) {
      if (cfg['ga_' + t[0]] === false) return;
      var have = inv && inv.count ? inv.count(t[1]) : 0;
      if (cfg.gatherGoal > 0 && have >= cfg.gatherGoal) off.push([t, 'đủ ' + have + '/' + cfg.gatherGoal]);
      else if (inv && inv.canFit && !inv.canFit(t[1])) off.push([t, 'túi đầy']);
    });
    off.forEach(function (o) { cfg['ga_' + o[0][0]] = false; gaLog(o[0][2] + ': ' + o[1] + ' → tắt, nhặt loại khác'); });
    if (off.length) { save(); if (ui.root) syncInputs(); }
  }

  // Loại vật đang cần: được chọn, chưa đủ mục tiêu, túi còn chỗ.
  function gaWanted(P) {
    var inv = P.Inventory, out = {};
    // Đang nhặt cho việc tông môn: chỉ các loại việc đó cần, tới khi đủ số.
    if (st.gaOverride) {
      var o = st.gaOverride, have = 0;
      (o.items || []).forEach(function (id) { have += inv && inv.count ? inv.count(id) : 0; });
      if (have < o.until) (o.types || []).forEach(function (ty) { var t = gaTypeOf(ty); if (t && !(inv && inv.canFit && !inv.canFit(t[1]))) out[ty] = t; });
      return out;
    }
    GATHER_TYPES.forEach(function (t) {
      if (cfg['ga_' + t[0]] === false) return;
      if (cfg.gatherGoal > 0 && inv && inv.count && inv.count(t[1]) >= cfg.gatherGoal) return;
      if (inv && inv.canFit && !inv.canFit(t[1])) return;
      out[t[0]] = t;
    });
    return out;
  }

  function gaVisible(g, wanted) {
    var key = g.mapId + ':' + gaKhu(g.P) + ':', tw = towerZones(g);
    return (g.sw.map.props || []).concat(g.sw.map.flatProps || []).filter(function (p) {
      return p && wanted[p.type] && !p.hidden && !p.off && !p.harvestPending && isFinite(p.x) &&
        !(gaPropSkip[key + p.id] > now()) && !inHazard(tw, p.x, p.y);
    });
  }

  // Map đích: ở map hiện tại nếu còn việc, không thì map có nhiều vật cần nhất mà đi được tới.
  function gaPickMap(g, wanted) {
    var maps = gaMaps(g.P), graph = mapGraph(g.P), best = null;
    Object.keys(maps).forEach(function (id) {
      var n = 0;
      Object.keys(maps[id].types).forEach(function (t) { if (wanted[t]) n += maps[id].types[t]; });
      if (!n || gaMapRest[id] > now()) return;
      if (id !== g.mapId && !nextHop(graph, g.mapId, id)) return; // bí cảnh, không có cổng tới
      var score = n + (id === g.mapId ? 1000 : 0);
      if (!best || score > best.score) best = { id: id, score: score, n: n };
    });
    return best;
  }

  // Khu kế tiếp: lâu chưa ghé nhất (chưa ghé bao giờ là tốt nhất), bỏ khu đầy, ít người hơn thì hơn.
  function gaNextKhu(g) {
    var P = g.P, cur = gaKhu(P), n = gaSoKhu(P), best = null;
    var list = khuList && khuList.mapId === g.mapId ? khuList : null;
    for (var k = 1; k <= n; k++) {
      if (k === cur) continue;
      var dem = list && list.dem ? list.dem[k - 1] | 0 : 0, cap = list ? (list.tran && list.tran[k - 1]) || list.toiDa || 0 : 0;
      if (cap && dem >= cap) continue;
      var ago = now() - (gaVisited[g.mapId + ':' + k] || -1e12);
      var score = ago - dem * 1000;
      if (!best || score > best.score) best = { khu: k, ago: ago, score: score };
    }
    return best;
  }

  function gaStep(name) {
    var a = st.ga;
    if (a.step !== name) { a.step = name; a.touches = 0; a.touchAt = 0; a.seenAt = now(); }
  }

  function gaFail(msg) {
    var a = st.ga, g = game();
    if (!a) return;
    a.fails++;
    var wait = Math.min(DC_RETRY_MAX_MS, DC_RETRY_MS * a.fails);
    gaLog(msg + ' → thử lại sau ' + Math.round(wait / 1000) + 's');
    if (st.travel) stopTravel();
    if (g) { if (g.sw.approach) g.sw.approach = null; if (g.me.path && g.me.path.length) g.me.path.length = 0; }
    if (g && g.P.KhuUI && g.P.KhuUI.isOpen && g.P.KhuUI.isOpen()) g.P.KhuUI.close();
    a.step = ''; a.touches = 0; a.touchAt = 0; a.prop = null; a.khuWant = 0; a.travels = 0;
    a.waitUntil = now() + wait;
  }

  function gaStop(msg) {
    if (msg) gaLog(msg);
    st.ga = null;
    cfg.gatherRun = false;
    save();
    if (ui.root) syncInputs();
  }

  function gaGoMap(g, mapId) {
    var a = st.ga;
    if (g.mapId === mapId) { if (st.travel) stopTravel(); return false; }
    if (!st.travel || st.travel.map !== mapId) {
      if (++a.travels > 6) {
        gaMapRest[mapId] = now() + 10 * 60000;
        gaFail('Không đi được tới ' + mapName(mapId) + ' (có thể chưa đủ cảnh giới) → bỏ map này 10 phút');
        return true;
      }
      startTravel(mapId, null, null, 'Nhặt nguyên liệu: đi tới ' + mapName(mapId));
    }
    tickTravel(g);
    return true;
  }

  // Đổi khu: tới Bảng Khu gần nhất, chạm vào (game mở bảng chọn khu), chọn số khu như bấm tay.
  function gaSwitchKhu(g, want) {
    var a = st.ga, P = g.P, K = P.KhuUI;
    if (gaKhu(P) === want) { a.khuWant = 0; a.waitUntil = now() + GA_SETTLE_MS; return true; }
    if (!a.khuAt && lootBeforeLeave(g)) { gaStep('nhặt đồ rơi trước khi đổi khu'); return true; }
    if (a.khuWant === want && a.khuAt) {
      if (now() - a.khuAt < GA_KHU_WAIT_MS) return true;
      gaFail('Chọn khu ' + want + ' mà chưa sang được');
      return true;
    }
    var boards = (g.sw.map.props || []).filter(function (p) { return p && p.type === 'khu_board'; });
    if (!boards.length) { gaFail('Map này không có Bảng Khu'); return true; }
    var me = g.me, board = boards.sort(function (x, y) { return dist(me.x, me.y, x.x, x.y) - dist(me.x, me.y, y.x, y.y); })[0];
    if (K && K.isOpen && K.isOpen()) {
      // Bảng vừa mở thì game hỏi số người từng khu: chờ danh sách về rồi chọn lại khu cho đúng.
      if (!a.boardAt) a.boardAt = now();
      if (khuListAt < a.boardAt && now() - a.boardAt < KHU_LIST_WAIT_MS) return true;
      var nb = gaNextKhu(g);
      if (nb) want = nb.khu;
      a.boardAt = 0;
      var G = P.Gateway;
      if (!G || !G.connected || !G.send || !G.send({ op: 'khu', act: 'chon', khu: want })) { gaFail('Không gửi được lệnh đổi khu (mất kết nối?)'); return true; }
      K.close();
      a.khuWant = want; a.khuAt = now();
      gaLog('Đổi sang khu ' + want);
      return true;
    }
    gaStep('tới Bảng Khu → khu ' + want);
    var r = touchProp(g, a, board);
    if (r === 'fail') gaFail('Không chạm được Bảng Khu');
    return true;
  }

  function gaWatch(g) {
    var a = st.ga, me = g.me;
    var sig = [a.step, g.mapId, gaKhu(g.P), Math.round(me.x / 24), Math.round(me.y / 24), st.travel ? st.travel.map : ''].join('|');
    if (sig !== a.sig) { a.sig = sig; a.seenAt = now(); return false; }
    if (a.step.indexOf('chờ') === 0 || now() - a.seenAt < DC_STALL_MS) return false;
    gaFail('Kẹt ' + DC_STALL_MS / 1000 + 's ở bước "' + (a.step || '—') + '"');
    return true;
  }

  function tickGather(g) {
    if (!cfg.gatherRun && !st.gaOverride) { if (st.ga) st.ga = null; return false; }
    if (cfg.planRun && !planIs('gather') && !st.gaOverride) return false; // Lịch đang làm việc khác: không chạy chen
    if (st.bh || st.bd || st.xc || st.td) return false; // tạm dừng khi đang đi đánh boss / quái biến dị
    if (g.P.Input.hasManualMove()) return true;
    var P = g.P, me = g.me;
    var a = st.ga || (st.ga = {
      step: '', touches: 0, touchAt: 0, routeAt: 0, prop: null, fails: 0, waitUntil: 0,
      sig: '', seenAt: now(), khuWant: 0, khuAt: 0, travels: 0, got: 0, target: null
    });
    // Quái đang đuổi sát: để auto + hit & run đánh trước (nếu bật), xong nhặt tiếp.
    var chased = cfg.gatherFightOn && mobsAlive(g).some(function (m) {
      return m.def.contactDmg > 0 && (m.state === 'chase' || m.state === 'attack') && dist(me.x, me.y, m.x, m.y) <= GA_FIGHT_R;
    });
    if (chased) { if (st.travel) stopTravel(); setAuto(g, true); return false; }
    setAuto(g, false);
    if (now() < a.waitUntil) return true;
    if (gaWatch(g)) return true;
    gaOffFull(P);
    var wanted = gaWanted(P);
    if (!Object.keys(wanted).length) {
      if (st.gaOverride) { st.gaOverride = null; st.ga = null; return false; }
      gaStop(cfg.gatherGoal > 0 ? 'Đã đủ ' + cfg.gatherGoal + ' mỗi loại (hoặc túi đầy) → dừng' : 'Không còn loại nào để nhặt (chưa chọn loại nào / túi đầy) → dừng');
      return false;
    }
    // Đang chờ sang khu mới.
    if (a.khuWant && gaSwitchKhu(g, a.khuWant)) return true;
    // Vật phẩm rơi quanh mình (quái vừa chết, người khác bỏ lại): hút trước rồi nhặt mạch tiếp.
    if (cfg.autoLoot && !a.prop && tickLoot(g)) { gaStep('nhặt vật phẩm rơi'); return true; }
    var target = gaPickMap(g, wanted);
    if (!target) {
      var soonest = Object.keys(gaMapRest).reduce(function (m, k) { return Math.min(m, gaMapRest[k]); }, Infinity);
      gaStep('chờ vật mọc lại' + (isFinite(soonest) ? ' (~' + Math.max(0, Math.round((soonest - now()) / 1000)) + 's)' : ''));
      return true;
    }
    if (a.target !== target.id) { a.target = target.id; a.travels = 0; gaLog('Map nhặt: ' + mapName(target.id) + ' (' + target.n + ' điểm cần nhặt)'); }
    if (gaGoMap(g, target.id)) { gaStep('đi tới ' + mapName(target.id)); return true; }
    var here = g.mapId + ':' + gaKhu(P);
    if (a.here !== here) { a.here = here; a.prop = null; a.waitUntil = now() + GA_SETTLE_MS; gaStep('vào ' + mapName(g.mapId) + ' khu ' + gaKhu(P)); return true; }
    // Vật vừa chạm: ẩn đi là nhặt được.
    if (a.prop) {
      var p = a.prop;
      if (p.hidden || p.off) {
        a.got++; a.fails = 0;
        var tp = gaTypeOf(p.type);
        klog('[Nhặt NL] +1 ' + (tp ? tp[2] : p.type) + (P.Inventory && P.Inventory.count && tp ? ' (có ' + P.Inventory.count(tp[1]) + ')' : ''));
        a.prop = null;
      } else if (p.harvestPending) {
        return true;
      } else {
        var r0 = touchProp(g, a, p);
        if (r0 === 'fail') { gaPropSkip[g.mapId + ':' + gaKhu(P) + ':' + p.id] = now() + GA_PROP_SKIP_MS; a.prop = null; a.touches = 0; }
        return true;
      }
    }
    var list = gaVisible(g, wanted);
    if (list.length) {
      var pick = list.sort(function (x, y) { return dist(me.x, me.y, x.x, x.y) - dist(me.x, me.y, y.x, y.y); })[0];
      var tp2 = gaTypeOf(pick.type);
      a.prop = pick;
      gaStep('nhặt ' + (tp2 ? tp2[2] : pick.type) + ' · khu ' + gaKhu(P) + ' · còn ' + list.length + ' điểm');
      if (touchProp(g, a, pick) === 'fail') { gaPropSkip[g.mapId + ':' + gaKhu(P) + ':' + pick.id] = now() + GA_PROP_SKIP_MS; a.prop = null; }
      return true;
    }
    // Khu này hết vật: ghi lại, sang khu lâu chưa ghé nhất; ghé hết rồi thì nghỉ map này.
    var vk = g.mapId + ':' + gaKhu(P);
    if (!(now() - (gaVisited[vk] || 0) < 5000)) { gaVisited[vk] = now(); gaLog('Khu ' + gaKhu(P) + ' ở ' + mapName(g.mapId) + ' đã hết vật'); }
    var next = gaSoKhu(P) > 1 ? gaNextKhu(g) : null;
    if (next && next.ago >= GA_KHU_REVISIT_MS) { gaSwitchKhu(g, next.khu); return true; }
    gaMapRest[g.mapId] = now() + GA_MAP_REST_MS;
    gaLog(mapName(g.mapId) + ': các khu vừa vét hết → sang map khác / chờ mọc lại');
    a.target = null;
    return true;
  }

  /* ================= Bùa tự động (Kim Long / Kim Giáp, Thanh Tâm, Tốc Hành, Thổ Độn) ================= */
  // Dùng qua nút bùa của game (TalismanBar.use = bấm ô bùa); game tự xét hồi chiêu, Thần Thức, còn …
  var TAL_GAP_MS = 800;       // giữa hai lần dùng bùa (bất kỳ)
  var talLastAt = -1e9;
  function talOk(P, me, id) {
    var T = P.Talismans, TB = P.TalismanBar;
    if (!T || !TB || !TB.use || !T.defOf || !T.canUse) return false;
    var def = T.defOf(id);
    if (!def) return false;
    var r = T.canUse(me, def, P);
    return r === true || !!(r && r.ok);
  }
  function talUse(g, id, why) {
    if (now() - talLastAt < TAL_GAP_MS || !talOk(g.P, g.me, id) || ((cfg.ylRun || planIs('yl')) && ylPhase(g.P))) return false;
    talLastAt = now();
    g.P.TalismanBar.use(id);
    var def = g.P.Talismans.defOf(id);
    klog('Dùng ' + (def && def.name || id) + ': ' + why);
    return true;
  }
  function tickTalismans(g) {
    var me = g.me;
    if (me.downed || !g.P.TalismanBar || fishingCalm(g)) return;
    var hpPct = me.hpMax ? me.hp / me.hpMax * 100 : 100, hurt = incomingDps(g) > 0;
    if (cfg.autoShield && hpPct < cfg.shieldHp && hurt) {
      if (!talUse(g, 'kim_long', 'máu ' + Math.round(hpPct) + '%')) talUse(g, 'kim_giap', 'máu ' + Math.round(hpPct) + '%');
    }
    if (now() - (st.kimKiemAt || -1e9) < 2500) {
      if (!talUse(g, 'kim_long', 'Kim Quang Cự Kiếm khoá mình')) talUse(g, 'kim_giap', 'Kim Quang Cự Kiếm khoá mình');
    }
    var curT = (st.farmTarget && !st.farmTarget.dead) ? st.farmTarget : (me.attackTarget || kiteTarget(g));
    var isBurstFight = !!(st.xc || st.td || st.bh || st.ct || (curT && (isBoss(curT) || isLastHitOnly(curT) || isTdMob(curT) || (curT.def && curT.def.tieuXaHang))));
    var mpThreshold = isBurstFight ? 0.35 : 0.15;
    if (cfg.autoMpTal && me.mpMax > 0 && me.mp / me.mpMax < mpThreshold && (hurt || stillFighting(g))) {
      talUse(g, 'thanh_tam', (isBurstFight ? 'dồn DPS ' : '') + 'linh lực ' + Math.round(me.mp) + '/' + Math.round(me.mpMax));
    }
    if (cfg.autoHaste && !(me.hasteT > 0) && (st.healMoving || (st.dodging && st.dodgeFar))) {
      talUse(g, 'toc_hanh', st.healMoving ? 'chạy ra chỗ thiền' : 'né chiêu xa');
    }
    if (cfg.autoDash && me.rootT > 0 && (hurt || inHazard(hazards(g), me.x, me.y))) talUse(g, 'tho_don', 'bị trói chân');
    if (cfg.bossMaxDmg) bossTalismans(g);
  }

  /* ================= Trận bàn tự dựng ================= */
  // Trận pháp (FormationUI.blocked kiểm đủ điều kiện): Tụ Linh khi thiếu linh lực; trận sát thương dưới chân boss / cụm quái.
  var TRAN_DMG = ['tu_tuong', 'dao_gia', 'ma_dao', 'loan_loi_hoa', 'liet_hoa'], TRAN_GAP_MS = 1200;
  function tranOwned(P, def) { return !!(def && P.Inventory && P.Inventory.count && P.Inventory.count(def.item) > 0); }
  function tranBegin(g, def, pt) {
    var P = g.P, U = P.FormationUI, F = P.Formations, G = P.Gateway, me = g.me;
    var why = U.blocked(def, me);
    if (why) return false;
    var req = G.formationBegin(def.id, F.fullBudget ? F.fullBudget(def) : 0, pt);
    if (!req) return false;
    var c = pt || { x: me.x, y: me.y };
    U.pending = { requestId: req, at: performance.now(), defId: def.id, x: c.x, y: c.y, radius: def.radius || 96, windupMs: def.windupMs || 900 };
    return true;
  }
  function isTdMob(m) {
    if (!m) return false;
    var tp = m.type || (m.def && m.def.type) || '';
    if (tp === 'tieu_su' || tp === 'kiep_tac' || tp === 'thuong_nhan' || tp === 'tieu_xa' || /tieu_xa|tieu_su|kiep_tac|thuong_nhan/.test(tp)) return true;
    if (m.def && m.def.hon === 'oan_hon' && /tieu_phu|thuong_nhan|tieu_su|kiep_tac/.test(tp)) return true;
    var nm = m.name || (m.def && m.def.name) || '';
    return /tiêu sư|tieu su|kiếp tặc|kiep tac|thương nhân|thuong nhan|tiêu xa|tieu xa/i.test(nm);
  }
  function isXcMob(m) {
    if (!m || !m.def || m.def.human) return false;
    var tp = m.type || (m.def && m.def.type) || '';
    if (/thach_quy|xuyen_son_giap|sau_truc|son_chuot|lon_rung/.test(tp)) return false;
    if (m.def.lootLastHitOnly || m.lootLastHitOnly) {
      if (/son_tac|tieu_phu|thuong_nhan|tieu_su/.test(tp)) return false;
      return true;
    }
    if (/xong_chuong|bach_ho_tuyet|xich_nhan_nguu|xich_ma|ngan_mao_hong|yl_hac_tien|duoc_linh_thu|thach_mach_vuong|u_minh_cu_mang|xich_mang_vuong/.test(tp)) return true;
    var nm = m.name || (m.def && m.def.name) || '';
    return /xổng chuồng|xong chuong/i.test(nm);
  }
  function isTranBossTarget(g, m) {
    if (!m || m.dead || !m.def) return false;
    // 1. Boss Thế Giới (Bạch Ngọc, Thạch Giáp Yêu, Linh Hổ, Song Dực, v.v.)
    if (isWorldBoss(g, m) || (st.bh && st.bh.boss === m)) return true;
    // 2. Quái Thương Đội (chỉ khi bot đang săn Thương Đội hoặc đúng xe tiêu / tiêu sư / cướp tiêu)
    if (isTdMob(m) && (st.td || (m.def && m.def.tieuXaHang) || /tieu_xa|tieu_su|kiep_tac|thuong_nhan/.test(m.type || ''))) return true;
    // 3. Yêu Thú Xổng Chuồng
    if (st.xc && (st.xc.target === m || (st.xc.types && st.xc.types.indexOf(m.type) >= 0))) return true;
    if (isXcMob(m)) return true;
    // 4. Boss lớn / Boss Bí Cảnh / Boss Sỹ Sách Điện
    if (isBoss(m)) return true;
    return false;
  }
  function isTranAllowed(g, t) {
    if (cfg.tranOnlyBossTd === false) return true;
    var me = g && g.me;
    var curT = t || (me && me.attackTarget);
    // 1. Săn Boss World: bot đang chạy bh, hoặc mục tiêu là boss thế giới, hoặc có boss thế giới trong tầm 320px
    var isWb = !!(st.bh || (curT && isWorldBoss(g, curT)) || (worldBossNear(g) && dist(me.x, me.y, worldBossNear(g).x, worldBossNear(g).y) <= 320));
    if (isWb) return true;
    // 2. Săn Thương Đội: bot đang chạy td, hoặc mục tiêu là quái thương đội, hoặc có quái thương đội trong tầm 320px
    var isTd = !!(st.td || (curT && isTdMob(curT)) || (tdTargets(g) && tdTargets(g)[0] && dist(me.x, me.y, tdTargets(g)[0].x, tdTargets(g)[0].y) <= 320));
    if (isTd) return true;
    // 3. Săn Thú Xổng Chuồng: bot đang chạy xc, hoặc mục tiêu là thú xổng chuồng, hoặc có thú xổng trong tầm 320px
    var isXc = !!(st.xc || (curT && isXcMob(curT)) || (mobsAlive(g).some(function (m) { return isXcMob(m) && dist(me.x, me.y, m.x, m.y) <= 320; })));
    if (isXc) return true;
    // 4. Boss lớn / Bí Cảnh / Sỹ Sách Điện
    if (curT && isBoss(curT)) return true;
    return false;
  }
  function tickTran(g) {
    var P = g.P, F = P.Formations, U = P.FormationUI, G = P.Gateway, me = g.me;
    if (fishingCalm(g)) return;
    if (!cfg.autoTran || !F || !F.DEFS || !U || !U.blocked || !G || !G.formationBegin || me.downed || me.state === 'sit') return;
    if (now() - (st.tranAt || -1e9) < TRAN_GAP_MS || (U.realmOk && !U.realmOk(me))) return;
    if (U.activeId || U.pending) return; // trận cũ còn vận / đang chờ máy chủ
    var fighting = stillFighting(g) || incomingDps(g) > 0, mpPct = me.mpMax ? me.mp / me.mpMax * 100 : 100;
    var t = st.farmTarget && !st.farmTarget.dead && (g.sw.enemies || []).indexOf(st.farmTarget) >= 0 ? st.farmTarget : kiteTarget(g);
    if (t && (t.dead || !t.def || (g.sw.enemies || []).indexOf(t) < 0 || dist(me.x, me.y, t.x, t.y) > 320)) t = null;
    if (!t || (cfg.tranOnlyBossTd !== false && !isTranBossTarget(g, t))) {
      var wb = worldBossNear(g) || (st.bh && st.bh.boss);
      if (wb && dist(me.x, me.y, wb.x, wb.y) <= 320) t = wb;
      else if (st.td) {
        var tds = tdTargets(g);
        if (tds && tds[0] && dist(me.x, me.y, tds[0].x, tds[0].y) <= 320) t = tds[0];
      } else if (st.xc) {
        var xcs = mobsAlive(g).filter(function (m) { return isTranBossTarget(g, m) && dist(me.x, me.y, m.x, m.y) <= 320; });
        if (xcs && xcs[0]) t = xcs[0];
      } else {
        var anyBoss = (g.sw.enemies || []).filter(function (m) { return isTranBossTarget(g, m) && dist(me.x, me.y, m.x, m.y) <= 320; })[0];
        if (anyBoss) t = anyBoss;
      }
    }
    // Giới hạn phạm vi: chỉ cho phép dựng trận khi Săn Boss World, Thương Đội hoặc Thú Xổng Chuồng
    if (!isTranAllowed(g, t)) return;

    var boss = isTranBossTarget(g, t);
    // Khóa chặn đa tầng: khi bật tranOnlyBossTd, tuyệt đối không dựng trận nếu không phải Boss / Thương Đội / Thú Xổng
    if (cfg.tranOnlyBossTd !== false && !boss) return;

    var tl = F.DEFS.tu_linh;
    if (cfg.tran_tu_linh && tl && tranOwned(P, tl) && fighting && mpPct < cfg.tranMp && (boss || cfg.tranOnlyBossTd === false) && tranBegin(g, tl, null)) {
      st.tranAt = now();
      klog('[Trận] Dựng ' + tl.name + ': linh lực ' + Math.round(mpPct) + '% (hồi ' + (tl.restoreMp || 0) + '/giây trong ' + Math.round(tl.durationMs / 1000) + 's)');
      return;
    }
    if (!t || !fighting) return;
    var mobs = mobsAlive(g);
    for (var i = 0; i < TRAN_DMG.length; i++) {
      var def = F.DEFS[TRAN_DMG[i]];
      if (!def || cfg['tran_' + def.id] === false || !tranOwned(P, def)) continue;
      var R = def.radius || 96, n = mobs.filter(function (m) { return dist(m.x, m.y, t.x, t.y) <= R; }).length;
      if (!boss && (cfg.tranOnlyBossTd !== false || n < cfg.tranMobs)) continue;
      var pt = null;
      if (def.aim === (F.AIM && F.AIM.POINT || 'point')) {
        var d = dist(me.x, me.y, t.x, t.y), rg = (def.range || 112) - 6, k = d > rg ? rg / d : 1;
        pt = { x: me.x + (t.x - me.x) * k, y: me.y + (t.y - me.y) * k };
      }
      if (tranBegin(g, def, pt)) {
        st.tranAt = now();
        klog('[Trận] Dựng ' + def.name + ' dưới chân ' + mobLabel(t) + (boss ? ' (boss/thú xổng/thương đội)' : ' (' + n + ' con trong vòng)'));
        return;
      }
    }
  }

  /* ================= Khôi Lỗi / Thi Khôi tự triệu hồi ================= */
  // Gọi qua nút của game (KhoiLoiUI.batTat); KhoiLoi.xetGoi báo lý do không gọi được (chưa Trúc Cơ, …
  var KL_PREF = {
    auto: ['khoi_loi_yeu_cot', 'khoi_loi_huyen_thiet', 'thi_khoi_bach', 'thi_khoi_dong', 'khoi_loi_bich_moc', 'thi_khoi_thanh'],
    dps: ['khoi_loi_yeu_cot', 'thi_khoi_bach', 'khoi_loi_bich_moc', 'thi_khoi_thanh', 'khoi_loi_huyen_thiet', 'thi_khoi_dong'],
    tank: ['khoi_loi_huyen_thiet', 'thi_khoi_dong', 'khoi_loi_bich_moc', 'thi_khoi_thanh', 'khoi_loi_yeu_cot', 'thi_khoi_bach']
  };
  var KL_FIGHT_R = 350, KL_GAP_MS = 2500;
  function tickKhoiLoi(g) {
    if (fishingCalm(g)) return;
    if (!cfg.autoKhoiLoi || st.dc || (st.ga && !cfg.gatherFightOn)) return;
    var P = g.P, K = P.KhoiLoi, KU = P.KhoiLoiUI, G = P.Gateway, me = g.me;
    if (!K || !KU || !KU.batTat || !KU.dangRaDs || !G || !G.connected || !G.ready || me.downed) return;
    if (K.dungDuoc && !K.dungDuoc(P)) return;
    if (K.mapCam && K.mapCam(g.sw.map && g.sw.map.data)) return;
    if (now() - (st.klAt || 0) < KL_GAP_MS) return;
    var out = KU.dangRaDs();
    if (out.length >= (K.TRAN || 2)) return;
    var boss = null;
    var fight = mobsAlive(g).some(function (m) {
      if (dist(me.x, me.y, m.x, m.y) > KL_FIGHT_R) return false;
      if (isBoss(m)) boss = m;
      return K.danhDuoc ? K.danhDuoc(m.def) : m.def.contactDmg > 0;
    });
    if (!fight) return;
    var pref = cfg.khoiLoiPref === 'auto' && boss ? 'dps' : cfg.khoiLoiPref;
    var list = KL_PREF[pref] || KL_PREF.auto;
    for (var i = 0; i < list.length; i++) {
      var id = list[i];
      if (out.indexOf(id) >= 0 || (K.xetGoi && K.xetGoi(P, id, out, me.sp))) continue;
      st.klAt = now();
      var def = K.byId ? K.byId(id) : null;
      KU.batTat(id, function (res) { if (res && res.ok === false) klog('Gọi khôi lỗi không được: ' + (res.why || '')); });
      klog('Triệu hồi ' + (def && def.ten || id) + (boss ? ' đánh boss' : ''));
      return;
    }
  }


  /* ================= Bí Tịch Hóa Thân (Biến hình) ================= */
  // Kim Cương Hóa Thân (Chính Đạo), Xích Ma Hóa Thân (Ma Đạo), Bàn Thạch Hộ Thể (Thể Tu)
  // Kích hoạt khi: Săn Boss, PK đối kháng, hoặc máu nguy hiểm (<= 50%) để nhận Giáp, Tốc chạy và Tốc đánh hút máu.
  function formSkillDef(g) {
    var S = g.P.Skills;
    if (!S || !S.learnedSlots || !S.slotDef) return null;
    var slots = S.learnedSlots();
    for (var i = 0; i < slots.length; i++) {
      var d = S.slotDef(slots[i]);
      if (d && d.bienHinh) return d;
    }
    return null;
  }

  function isFormActive(g) {
    var me = g.me, P = g.P;
    if (!me) return false;
    if (P.Player && P.Player.formDef && P.Player.formDef(me)) return true;
    return !!(me.hinhT > 0 && me.hinhId);
  }

  function tickHoaThan(g) {
    if (cfg.autoHoaThan === false || !enabled || g.me.downed || g.me.state === 'sit' || busyUI(g.P) || fishingCalm(g)) return false;
    var def = formSkillDef(g);
    if (!def) return false;
    if (isFormActive(g)) return false; // đang biến hình: đợi hết giờ

    var P = g.P, S = P.Skills, PL = P.Player, me = g.me;
    if (!PL || !PL.castSpell || !S) return false;
    if (S.ready && !S.ready(me, def)) return false;
    if (me.spellCd > 0 || (me.spellCds && me.spellCds[def.id] > 0)) return false;
    if (me.mp < (def.mp || 0) || (def.sp && me.sp < def.sp)) return false;

    // Điều kiện kích hoạt:
    // 1. PK: có người thù địch trong vòng 350px
    var pkThreat = hostilePlayers(g).some(function (r) { return isFinite(r.x) && dist(me.x, me.y, r.x, r.y) <= 350; });
    // 2. Boss: đang nhắm boss hoặc boss đang gần (450px)
    var t = st.farmTarget;
    var bossFight = (t && !t.dead && isBoss(t) && dist(me.x, me.y, t.x, t.y) <= 450) ||
      (st.bh && st.bh.boss) || (worldBossNear(g) && dist(me.x, me.y, worldBossNear(g).x, worldBossNear(g).y) <= 450) ||
      (st.bd && st.bd.target);
    // 3. Khẩn cấp: máu tụt dưới 50% khi đang giao tranh
    var emergency = stillFighting(g) && me.hpMax > 0 && (me.hp / me.hpMax <= 0.50);

    if (pkThreat || bossFight || emergency) {
      if (me.state === 'attack' || me.state === 'pose') return false; // đợi nhịp chém hiện tại kết thúc
      var why = pkThreat ? 'PK đối kháng' : bossFight ? 'Săn boss' : 'Khẩn cấp (máu ≤ 50%)';
      var ok = PL.castSpell(me, def);
      if (ok === true) {
        var bh = def.bienHinh || {};
        var spdBonus = bh.speed ? Math.round((bh.speed - 1) * 100) : 0;
        klog('[Hóa Thân] Kích hoạt ' + (def.short || def.name) + ' (' + why + ') · Giáp +' + (me.hinhGiap || 0) + ' · Tốc chạy +' + spdBonus + '% · Tốc đánh 0.5s');
        say('Hóa Thân: ' + (def.short || def.name));
        return true;
      }
    }
    return false;
  }

  /* ================= Boss: điều kiện nhận đồ, last-hit, lịch boss, radar ================= */
  // Máy chủ báo phần sát thương của mình trên boss qua CongBossUI.st: my (sát thương), ng (ngưỡng …
  var BOSS_TABLE = [ // từ bảng Hoạt Động của game: spawn id → loại quái, map
    { spawn: 'ttxl_1', type: 'than_thu_xich_long', map: 'long_uyen' },
    { spawn: 'boss_linh_ho_tran_son', type: 'linh_ho_tran_son', map: 'thach_phong_thung_lung' },
    { spawn: 'boss_song_duc_ma_bao', type: 'song_duc_ma_bao', map: 'mo_linh_thach' },
    { spawn: 'boss_nhen_bach_ngoc', type: 'nhen_bach_ngoc', map: 'bai_da_hang_gio', khu: 1 } // một con duy nhất, mặc định ở khu 1
  ];
  var BOSS_POLL_MS = 30000;
  var bossHp = new WeakMap();  // boss → [{t, hp}] trong 2 giây gần nhất (đo máu boss tụt mỗi giây)

  function bossShare(boss) {
    var cb = window.PNTT && window.PNTT.CongBossUI && window.PNTT.CongBossUI.st;
    if (!cb || cb.het || (boss && cb.id != null && cb.id !== boss.id)) return null;
    return cb;
  }
  function bossShareText(cb) {
    if (!cb) return '';
    var stt = ['chưa đủ ngưỡng', 'ĐỦ điều kiện nhận đồ', 'đứng quá xa', 'đang gục'][cb.st] || '';
    return 'Sát thương ' + num(cb.my) + (cb.ng ? '/' + num(cb.ng) + ' ngưỡng' : '') + ' · trúng ' + (cb.ch / 10).toFixed(1) + '% · ' + stt;
  }
  function dyingBossNear(g, maxR) {
    if (!g || !g.me) return null;
    var me = g.me, R = maxR || ((g.P.CONFIG.TARGET ? g.P.CONFIG.TARGET.RANGE : 400) * 1.5), best = null;
    mobsAlive(g).forEach(function (m) {
      if ((!isBoss(m) && !isLastHitOnly(m)) || m.state === 'return') return;
      var d = dist(me.x, me.y, m.x, m.y);
      if (d > R) return;
      var pct = m.hpMax > 0 ? (m.hp / m.hpMax) : 1;
      var lho = isLastHitOnly(m);
      var dying = pct <= (lho ? 0.28 : 0.20) || (m.hp != null && m.hp <= (lho ? 15000 : 10000));
      if (!dying) return;
      // Điểm ưu tiên: máu % càng thấp càng ưu tiên số 1, cùng máu thì con gần hơn
      var score = pct * 1000 + d;
      if (!best || score < best.score) best = { m: m, score: score, d: d, pct: pct };
    });
    return best && best.m;
  }
  function nearBoss(g) {
    var me = g.me, R = (g.P.CONFIG.TARGET ? g.P.CONFIG.TARGET.RANGE : 400) * 1.5;
    if (cfg.lastHitScan !== false) {
      var dying = dyingBossNear(g, R);
      if (dying) return dying;
    }
    var best = null;
    mobsAlive(g).forEach(function (m) {
      if (!isBoss(m) || m.state === 'return') return;
      var d = dist(me.x, me.y, m.x, m.y);
      if (d <= R && (!best || d < best.d)) best = { m: m, d: d };
    });
    return best && best.m;
  }
  // Radar: boss thế giới thấy tận mắt lần cuối ở map / khu nào (máy chủ không báo khu). Lần sau đi săn
  // thì tới thẳng khu đó trước.
  var radarSeen = {};
  // Tin trên kênh thế giới / thông báo hệ thống có tên boss kèm số khu ("Xích Long khu 3", "linh ho k2"…):
  var CHAT_HINT_MS = 10 * 60000;
  var BOSS_KEYS = { than_thu_xich_long: /xich long/, linh_ho_tran_son: /linh ho/, song_duc_ma_bao: /ma bao|song duc/, nhen_bach_ngoc: /nhen bach ngoc|nhen ngoc/ };
  var chatHint = {};
  function plainVi(t) { return String(t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').toLowerCase(); }
  function readChatHint(text, who) {
    var t = plainVi(text), m = /(?:^|[^a-z])(?:khu|k)\s*\.?\s*(\d{1,2})(?!\d)/.exec(t);
    if (!m) return;
    Object.keys(BOSS_KEYS).forEach(function (type) {
      if (!BOSS_KEYS[type].test(t)) return;
      var dead = /bi ha|da ha|tieu diet|chet|ngoem|xong roi/.test(t);
      chatHint[type] = { khu: +m[1], at: now(), dead: dead, who: who || '', text: String(text).slice(0, 80) };
      klog('[Boss] Chat' + (who ? ' (' + who + ')' : '') + ': ' + (BH_NAMES[type] || type) + (dead ? ' đã bị hạ ở' : ' ở') + ' khu ' + m[1]);
      if (!dead) st.bossPollAt = -1e9; // hỏi lại lịch ngay
    });
  }
  function hookChat(P) {
    var C = P.Chat;
    if (!C || C._ttHint) return;
    C._ttHint = true;
    if (C.line) {
      var line = C.line;
      C.line = function (text, kind, o) {
        try {
          var who = o && (o.whoPlain || o.who);
          if (kind === 'world' || kind === 'sys' || kind === 'clan-sys' || kind === 'map') readChatHint(text, who);
          var isTd = (o && o.authorId === 'thien_dao') || (who && plainVi(who) === 'thien dao') || /^(?:\[?(?:thien dao|he thong|thong bao)\]?|thien dao:|he thong:|thong bao:)/i.test(plainVi(text));
          if (isTd || (kind === 'sys' && !who) || ((kind === 'world' || kind === 'map') && /xong chuong|thuong doi|bien di|xuat hien o/i.test(plainVi(text)))) readServerNews(text);
        } catch (e) { }
        return line.apply(this, arguments);
      };
    }
    if (C.pushWorldSay) {
      var pws = C.pushWorldSay;
      C.pushWorldSay = function (id, name, text, tuyen) {
        try {
          var who = plainVi(name || '');
          var txtP = plainVi(text || '');
          if (who === 'thien dao' || id === 'thien_dao' || /^(?:\[?(?:thien dao|he thong|thong bao)\]?|thien dao:|he thong:|thong bao:)/i.test(txtP) || /xong chuong|thuong doi|bien di|xuat hien o/i.test(txtP)) {
            readServerNews(text);
          }
        } catch (e) { }
        return pws.apply(this, arguments);
      };
    }
  }
  function bossHint(type) { var h = chatHint[type]; return h && now() - h.at < CHAT_HINT_MS ? h : null; }
  /* ================= Dọn dẹp định kỳ bộ nhớ cache (lootSkip, chatHint) ================= */
  var lastCacheCleanAt = 0;
  var CACHE_CLEAN_INTERVAL_MS = 30000; // dọn rác bộ nhớ mỗi 30s
  function cleanCaches(force) {
    var t = now();
    if (!force && t - lastCacheCleanAt < CACHE_CLEAN_INTERVAL_MS) return;
    lastCacheCleanAt = t;
    // Dọn lootSkip: các mục có lootSkip[id] <= t (đã hết thời gian skip)
    if (lootSkip) {
      for (var id in lootSkip) {
        if (lootSkip.hasOwnProperty(id) && lootSkip[id] <= t) {
          delete lootSkip[id];
        }
      }
    }
    // Dọn chatHint: các mục quá hạn CHAT_HINT_MS (10 phút)
    if (chatHint) {
      for (var type in chatHint) {
        if (chatHint.hasOwnProperty(type)) {
          var h = chatHint[type];
          if (!h || t - h.at >= CHAT_HINT_MS) {
            delete chatHint[type];
          }
        }
      }
    }
  }
  var lastActiveWb = null;
  function trackBossHp(g) {
    var t = now(), currentWb = null;
    mobsAlive(g).forEach(function (m) {
      if (!isBoss(m)) return;
      if (BOSS_TABLE.some(function (b) { return b.type === m.type; })) radarSeen[m.type] = { map: g.mapId, khu: gaKhu(g.P), at: t };
      if (isWorldBoss(g, m)) {
        st.bossSeenAt = t;
        currentWb = m;
        lastActiveWb = { id: m.id, type: m.type, map: g.mapId, x: m.x, y: m.y, at: t };
      }
      var a = bossHp.get(m) || [];
      a.push({ t: t, hp: m.hp });
      while (a.length > 2 && t - a[0].t > 2000) a.shift();
      bossHp.set(m, a);
    });
    // Boss thế giới vừa bị hạ (vừa thấy ở tick trước, tick này không còn trong map):
    if (!currentWb && lastActiveWb && lastActiveWb.map === g.mapId && t - lastActiveWb.at < 2500) {
      st.wbLootUntil = t + BH_LOOT_MS;
      st.wbLootPos = { x: lastActiveWb.x, y: lastActiveWb.y, map: lastActiveWb.map };
      lastActiveWb = null;
      klog('[Boss] Boss thế giới đã bị hạ → giữ vị trí & chờ bốc thăm quà ' + (BH_LOOT_MS / 1000) + 's (server bốc thăm lúc 20s)');
    }
  }
  function bossDps(m) {
    var a = bossHp.get(m);
    if (!a || a.length < 2) return 0;
    var dt = (a[a.length - 1].t - a[0].t) / 1000, dh = a[0].hp - a[a.length - 1].hp;
    return dt > 0.15 && dh > 0 ? dh / dt : 0;
  }
  // Hệ số an toàn cho ngưỡng last-hit: máu boss tụt thêm trong lúc chiêu mình bay tới (theo tốc độ tụt
  // máu đo được) + người chơi quanh boss cùng dồn chiêu. Tắt tự động thì dùng hệ số đặt tay.
  var LH_DELAY_S = 0.3;
  function bossMargin(g, boss, burst) {
    if (!cfg.autoHpMargin) return Math.max(1, (cfg.hpMarginPct || 110) / 100);
    var people = 0, R = g.P.Gateway && g.P.Gateway.remotes;
    if (R) Object.keys(R).forEach(function (id) { var r = R[id]; if (r && !r.downed && dist(r.x, r.y, boss.x, boss.y) <= 500) people++; });
    var m = 1.02 + bossDps(boss) * LH_DELAY_S / Math.max(1, burst) + Math.min(0.2, people * 0.012);
    return Math.min(1.8, Math.max(1.03, m));
  }
  // Last-hit trong phần chọn chiêu: máu boss ≤ chiêu mạnh nhất × hệ số → tung chiêu đó; ≤ (mạnh nhất …
  function lastHitPick(g, target, rows) {
    if (!cfg.lastHitBoss || !isBoss(target)) return null;
    var all = rows.filter(function (r) { return r.per > 0; }).sort(function (a, b) { return b.per - a.per; });
    if (!all.length) return null;
    var top = all[0], second = all[1] || null;
    var burst = top.per + (cfg.lastHitDouble && second ? second.per : 0), m = bossMargin(g, target, burst);
    var name = function (r) { return r.def.short || r.def.name; };
    if (top.ok && target.hp <= top.per * m) return { best: top, why: 'Last-hit: ' + name(top) + ' kết liễu (máu ' + num(target.hp) + ' ≤ ' + num(top.per * m) + ', hệ số x' + m.toFixed(2) + ')' };
    if (cfg.lastHitDouble && second && second.ok && top.ok && target.hp <= (top.per + second.per) * m) {
      return { best: second, why: 'Combo last-hit: ' + name(second) + ' trước, giữ ' + name(top) + ' kết liễu' };
    }
    if (target.hp <= burst * m * 1.35) return { exclude: top, why: 'Boss sắp tới ngưỡng → giữ ' + name(top) + ' để kết liễu' };
    return null;
  }

  function tickBossPoll(g) {
    var G = g.P.Gateway;
    if (!G || !G.connected || !G.cmd || now() - (st.bossPollAt || -1e9) < BOSS_POLL_MS) return;
    st.bossPollAt = now();
    G.cmd('hoatdong.xem', {}, function (res) { if (res && res.ok) { st.bossList = res; st.bossListAt = now(); } });
  }
  function bossTimers(g) {
    var res = st.bossList, out = [];
    if (!res) return out;
    var el = (now() - st.bossListAt) / 1000, D = g.P.ENEMY_DEFS || {};
    BOSS_TABLE.forEach(function (b) {
      var nm = (D[b.type] && D[b.type].name || b.type).split('·')[0].trim();
      if (b.type === 'song_duc_ma_bao' && res.maBao) {
        var mb = res.maBao;
        out.push(nm + ': ' + (mb.dangSong ? 'đang xuất hiện · còn ' + fmtSec(Math.max(0, mb.conLaiGiay - el)) : mb.daHa ? 'hôm nay đã bị hạ' : 'ngẫu nhiên 11h–21h'));
        return;
      }
      var row = (res.boss || []).filter(function (x) { return x.id === b.spawn; })[0];
      if (!row) return;
      var con = row.con > 0 ? Math.max(0, row.con - el) : 0;
      var rs = radarSeen[b.type];
      var chh = bossHint(b.type);
      out.push(nm + ' (' + mapName(b.map) + '): ' + (!row.dead ? 'đang xuất hiện' : con > 0 ? 'hồi sau ' + fmtSec(con) : 'sắp xuất hiện') +
        (rs ? ' · thấy ở khu ' + rs.khu + ' ' + fmtSec((now() - rs.at) / 1000) + ' trước' : '') +
        (chh ? ' · chat: ' + (chh.dead ? 'bị hạ ở' : 'ở') + ' khu ' + chh.khu : ''));
    });
    return out;
  }
  // Ngày/tháng theo giờ Việt Nam (UTC+7) — tự tính, không dựa vào ngayVN của game (bản 25/10 đổi từ chuỗi sang số ngày).
  function ddmmVN(ms) { var d = new Date((Number(ms) || 0) + 7 * 3600000); return ('0' + d.getUTCDate()).slice(-2) + '/' + ('0' + (d.getUTCMonth() + 1)).slice(-2); }
  function fmtSec(s) { s = Math.round(s); var m = Math.floor(s / 60); return (m ? m + 'p' : '') + (s % 60 < 10 && m ? '0' : '') + (s % 60) + 's'; }

  /* ================= Thống kê vật phẩm nhặt được ================= */
  // Đếm theo gói máy chủ báo đã nhặt (loot_gone với người nhặt là mình): gồm đồ đi tới nhặt, đồ
  // tự hút về; cộng thêm mạch khoáng / linh thảo (resource.harvest thành công).
  var lootStats = { since: Date.now(), total: 0, stones: 0, items: {}, history: [] };
  function recordLoot(g, itemId, qty) {
    if (!itemId) return;
    qty = Math.max(1, qty | 0);
    var it = g && g.P.ITEMS && g.P.ITEMS[itemId], name = it ? it.name : itemId;
    if (itemId === 'linh_thach') lootStats.stones += qty; else lootStats.total += qty;
    lootStats.items[name] = (lootStats.items[name] || 0) + qty;
    lootStats.history.unshift({ at: new Date(), name: name, qty: qty });
    if (lootStats.history.length > 30) lootStats.history.pop();
  }
  function hookLootStats(P) {
    var SW = P.SceneWorld;
    if (SW && !SW._ttStats && SW.onServerLootGone) {
      SW._ttStats = true;
      var gone = SW.onServerLootGone;
      SW.onServerLootGone = function (id, by) {
        var G = P.Gateway;
        if (by && G && by === G.selfId) {
          var r = (SW.drops || []).filter(function (x) { return x.lootId === id; })[0];
          if (r && !r.granted) recordLoot(game(), r.itemId, r.n);
        }
        return gone.apply(this, arguments);
      };
    }
  }
  // Nhặt tức thì: máy chủ vừa gửi đồ rơi xuống (SceneWorld.onServerLoot) mà món nằm trong tầm nhặt, nhặt được (không chủ /
  // của mình / hết giờ giữ) thì gửi loot.pick ngay, không chờ vòng nhặt của game. Yêu Đan ghi vào nhật ký.
  function hookFastLoot(P) {
    var SW = P.SceneWorld;
    if (!SW || SW._ttFastLoot || !SW.onServerLoot) return;
    SW._ttFastLoot = true;
    var orig = SW.onServerLoot;
    SW.onServerLoot = function (items) {
      var ret = orig.apply(this, arguments);
      try {
        var G = P.Gateway, L = P.Loot, pl = SW.player, self = G && G.selfId, R = ((L && L.PICK_R) || 40) + 12;
        if (!enabled || !Array.isArray(items) || !G || !G.cmd || !pl) return ret;
        // Sắp xếp gửi lệnh nhặt theo giá trị giảm dần: vật phẩm quý hiếm được gửi qua socket trước
        var sorted = items.slice().sort(function (a, b) {
          var idA = (a && (a.item || a.itemId)) || ((SW.drops || []).filter(function (x) { return x && x.lootId === (a && a.id); })[0] || {}).itemId;
          var idB = (b && (b.item || b.itemId)) || ((SW.drops || []).filter(function (x) { return x && x.lootId === (b && b.id); })[0] || {}).itemId;
          return gradeScore(P, idB) - gradeScore(P, idA);
        });
        sorted.forEach(function (e) {
          if (!e || e.id == null || e.ht) return;
          var dr = (SW.drops || []).filter(function (x) { return x && x.lootId === e.id; })[0];
          var itemId = (dr && dr.itemId) || e.item || e.itemId;
          if (!dr || dr.asked || e._ttAsked || dist(pl.x, pl.y, e.x, e.y) > R) return;
          if (L && L.canPick && !L.canPick(dr, self, dr.age || 0)) return;
          if (!lootFilterOk(P, itemId)) return;
          dr.asked = true;
          G.cmd('loot.pick', { id: e.id }, function (res) { if (!(res && res.ok)) dr.asked = false; });
          if (gradeScore(P, itemId) >= 5000) klog('[Nhặt tức thì] ' + (dr ? dropName(game(), dr) : itemId) + ' vừa rơi → gửi lệnh nhặt ngay (0ms)');
        });
      } catch (err) { }
      return ret;
    };
  }
  function noteHarvest(g, propId, res) {
    if (!res || !res.ok || !g) return;
    var p = findHere(g, propId), t = p && (gaTypeOf(p.type) || (p.type === 'ling_chi_prop' ? [0, 'nam_linh_chi'] : null));
    if (t) recordLoot(g, t[1], 1);
  }

  // Bảng phân cấp giá trị vật phẩm toàn diện cho TẤT CẢ Boss & Hoạt Động (Tier 0 -> Tier 5)
  var LOOT_SPECIAL_SCORES = {
    // ===== TIER 0: CỰC PHẨM ĐỘC NHẤT THIÊN HẠ (Score 60,000+) =====
    van_xich_nhat_tuyen: 65000,         // Vân Xích Nhất Tuyến (Đỉnh cao Hư Thiên)
    toai_khong_linh_chi: 60000,         // Toái Không Linh Chi (Vết Nứt Hư Không)

    // ===== TIER 1: BOSS THẾ GIỚI CHỐT HẠ, PHÁP BẢO HIẾM & Y PHỤC HOÀNG KIM (Score 20,000 - 35,000) =====
    yeu_dan_cap_6: 35000,               // Song Dực Ma Báo (Last Hit)
    yeu_dan_cap_5: 30000,               // Nhện Bạch Ngọc
    tam_yeu_linh_boi: 29000,            // Tam Yêu Linh Bội (Pháp bảo chốt hạ cả 3 Đại Boss Thế Giới)
    ruong_phi_hanh: 28000,              // Rương Phi Hành (Song Dực Ma Báo)
    toc_truong_y: 27500,                // Tộc Trưởng Y (Cực hiếm 0.1% Tộc Trưởng Biến Dị)
    long_tuong_y: 27000,                // Long Tướng Thanh Ngọc Bào (Huyết Sắc Boss)
    xich_long_huyet: 26000,             // Yêu Huyết Cấp 3 (Thần Thú Xích Long)
    bach_nguyet_hong_lien: 25500,       // Bạch Nguyệt Hồng Liên Y (Pháp bảo Xích Long/Linh Hổ)
    van_lo_lao_ma_bao: 25500,           // Vạn Lộ Lão Ma Bào (Pháp bảo Xích Long/Linh Hổ)
    ngua_hac_tho: 25000,                // Hắc Thổ Linh Mã (Tọa kỵ Linh Hổ Trấn Sơn)
    hoang_lan_giap: 24000,              // Hoàng Lân Giáp (Thần Thú Xích Long)
    tuyet_son_kiem_y: 23500,            // Tuyết Sơn Kiếm Y (Song Dực Ma Báo)
    than_kiem_y: 23500,                 // Thần Kiếm Y (Song Dực Ma Báo)
    man_ho_tu_y: 23000,                 // Mạn Hổ Tử Y (Song Dực Ma Báo)
    thanh_tam_y: 23000,                 // Thanh Tàm Y (Song Dực Ma Báo)
    quan_dui: 22500,                    // Quần Đùi Ma Báo (Song Dực Ma Báo)
    yeu_dan_cap_4: 22000,               // Yêu Đan Cấp 4 (Linh Hổ Trấn Sơn)
    yeu_huyet_cap_6: 21500,             // Yêu Huyết Cấp 6 (Song Dực Ma Báo)
    phong_song_duc: 21000,              // Phong Song Dực (Song Dực Ma Báo rơi giữa trận)
    hu_anh_phi_hanh: 20500,             // Hư Ảnh Phi Hành (Nhện Bạch Ngọc rơi giữa trận 1%)
    lan_thanh_trum_dau: 20000,          // Trùm Đầu Lan Thánh (Trang bị hiếm Địa phẩm thượng)

    // ===== TIER 2: BÍ TỊCH CAM/ĐỎ, VŨ KHÍ HIẾM & BẢO VẬT TRẤN PHÁI (Score 15,000 - 19,500) =====
    bi_tich_van_kiem_quy_tong: 19500,   // Vạn Kiếm Quy Tông (World Boss rơi giữa trận)
    bi_tich_kim_quang_cu_kiem: 19000,   // Kim Quang Cự Kiếm (Song Dực Ma Báo)
    bi_tich_huyet_liem_tram: 18800,     // Huyết Liêm Trảm (Yên Lãng Sơn / Nhện Bạch Ngọc)
    bi_tich_huyet_buc_chuong: 18600,    // Huyết Bức Chưởng (Huyết Sắc Boss)
    bi_tich_thanh_an_ho_the: 18500,     // Thánh Ấn Hộ Thế (Địa phẩm thượng - Nho Tu)
    bi_tich_thien_thu_giang_the: 18500, // Thiên Thư Giáng Thế (Địa phẩm thượng - Nho Tu)
    bi_tich_ma_bao_an: 18500,           // Ma Bạo Ấn (World Boss rơi giữa trận)
    tong_mon_lenh: 18200,               // Tông Môn Lệnh (Thần Thú Xích Long / Linh Hổ / Ma Báo)
    bi_tich_chu_phe_dinh_toi: 18200,    // Chu Phê Định Tội (Địa phẩm thượng - Nho Tu)
    bi_tich_thien_quan_truy: 18000,     // Thiên Quân Chùy (World Boss rơi giữa trận)
    bi_tich_hao_nhien_thuan: 18000,     // Hạo Nhiên Thuẫn (Địa phẩm thượng - Nho Tu)
    bi_tich_huyet_te_ma_dong: 18000,    // Huyết Tế Ma Đồng (Địa phẩm thượng - Huyết Tu)
    bi_tich_mong_diep_me_tran: 17800,   // Mộng Điệp Mê Trận (World Boss rơi giữa trận)
    van_khuc_thu: 17800,                // Văn Khúc Thư (Pháp bảo trấn phái Nho Tu)
    huyet_phach_chau: 17800,            // Huyết Phách Châu (Pháp bảo trấn phái Huyết Tu)
    bi_tich_nguyet_quang: 17700,        // Thái Âm Nguyệt Quang (Song Dực Ma Báo 0.5%)
    bi_tich_ngu_sac_than_chuong: 17600, // Ngũ Sắc Thần Chưởng (Song Dực Ma Báo 0.5%)
    bi_tich_huyet_nguyet_luan_liem: 17500, // Huyết Nguyệt Luân Liêm (Huyết Tu)
    bi_tich_thien_dia_vi_ky: 17500,     // Thiên Địa Vi Kỳ (Địa phẩm - Nho Tu)
    bi_tich_luc_tinh_truc_kiem: 17500,  // Lục Tinh Trúc Kiếm (Hư Thiên)
    bi_tich_thanh_long_ngam: 17200,     // Thanh Long Ngâm
    bi_tich_huyet_mau_xuyen_tam: 17200, // Huyết Mâu Xuyên Tâm (Linh phẩm thượng - Huyết Tu)
    bi_tich_huyet_hai_phien_thien: 17200, // Huyết Hải Phiên Thiên (Linh phẩm thượng - Huyết Tu)
    bi_tich_phi_long_tai_thien: 17000,  // Phi Long Tại Thiên (Song Dực Ma Báo)
    bi_tich_cuu_u_ma_trao: 16800,       // Cửu U Ma Trảo (Song Dực Ma Báo)
    bi_tich_huyen_anh_ma_tram: 16600,   // Huyễn Ảnh Ma Trảm (Song Dực Ma Báo)
    mac_tu: 16500,                      // Mặc Tự (Địa phẩm thượng - Nho Tu)
    huyet_hon: 16500,                   // Huyết Hồn (Địa phẩm thượng - Huyết Tu)
    bi_tich_ngoc_luu_chan_am: 16500,    // Ngọc Lưu Chân Âm (Nho Tu)
    bi_tich_cuu_thien_lien_am: 16400,   // Cửu Thiên Liên Âm
    bi_tich_thien_ma_lien_vu: 16200,    // Thiên Ma Liên Vũ (Song Dực Ma Báo)
    bang_linh_kiem: 16000,              // Băng Linh Kiếm (Ma Báo / Nhện Bạch Ngọc)
    bi_tich_cuu_u_hac_trao: 16000,      // Cửu U Hắc Trảo (Song Dực Ma Báo)
    hoang_loi_thuong: 16000,            // Hoàng Lôi Thương (Cực hiếm Sỹ Sách Đỉnh / Ma Báo)
    hoa_kim_thuong: 16000,              // Hoả Kim Thương (Cực hiếm Sỹ Sách Đỉnh / Nhện Bạch Ngọc)
    bich_linh_ho: 16000,                // Bích Linh Hồ (Cực hiếm Sỹ Sách Đỉnh)
    huyen_bang_kinh: 16000,             // Huyền Băng Kính (Cực hiếm Sỹ Sách Đỉnh)
    bi_tich_huyet_lien_ky: 15800,       // Huyết Liên Kỳ
    bi_tich_ma_hon_phe: 15600,          // Ma Hồn Phệ (Song Dực Ma Báo)
    bi_tich_huyet_co_phe_tam: 15500,    // Huyết Cổ Phệ Tâm (Huyết Tu)
    bi_tich_huyet_anh_tam_cham: 15500,  // Huyết Ảnh Tam Châm (Huyết Tu)
    bi_tich_truc_gian_tam_tinh: 15500,  // Trúc Giản Tam Tỉnh (Nho Tu)
    bi_tich_hoa_dia_vi_lao: 15500,      // Hoạ Địa Vi Lao (Nho Tu)
    bi_tich_mac_truc_binh_phong: 15500, // Mặc Trúc Bình Phong (Nho Tu)
    bi_tich_thanh_long_ngam_nho: 15500, // Mặc Long Ngâm (Nho Tu)
    bi_tich_son_ha_nhap_hoa_nho: 15500, // Sơn Hà Nhập Hoạ (Nho Tu)
    bi_tich_bich_nguc_giang_dao: 15500, // Bích Ngục Giáng Đao
    bi_tich_hong_tu_doat_menh: 15400,   // Hồng Tơ Đoạt Mệnh (Song Dực Ma Báo)
    bi_tich_loi_thuong_quan_dia: 15300, // Lôi Thương Quán Địa (Song Dực Ma Báo)
    bi_tich_ngu_loi_thuong_vu: 15300,   // Ngũ Lôi Thương Vũ (Song Dực Ma Báo)
    bi_tich_huyet_nguyet_am_thuc: 15300,// Huyết Nguyệt Ám Thực (Song Dực Ma Báo)
    bi_tich_am_huyet_ma_chuong: 15300,  // Ám Huyết Ma Chưởng (Song Dực Ma Báo)
    bi_tich_ngu_hoa_thuong_vu: 15300,   // Ngũ Hoả Thương Vũ (Song Dực Ma Báo)
    bi_tich_ham_thien_thu: 15200,       // Hám Thiên Thủ (Song Dực Ma Báo)
    bi_tich_bang_son_quyen: 15000,      // Băng Sơn Quyền (Song Dực Ma Báo)
    yeu_huyet_cap_4: 15000,             // Yêu Huyết Cấp 4 (Linh Hổ Trấn Sơn)
    thu_tuong_giap: 10000,              // Thụ Tượng Giáp (Sỹ Sách Đỉnh)
    hoang_lan_giap: 10000,              // Hoàng Lân Giáp (Sỹ Sách Đỉnh)
    phong_song_duc: 10000,              // Phong Song Dực (Sỹ Sách Đỉnh)
    manh_yeu_dan_cap_3: 8000,           // Mảnh Yêu Đan Cấp 3 (Hư Thiên Điện)
    ruong_khoi_loi: 7500,               // Rương Khôi Lỗi (Chiến Trường / Hư Thiên)

    // ===== TIER 3: NGUYÊN LIỆU ĐỘT PHÁ BIẾN DỊ, YÊU ĐAN 3, VŨ KHÍ & BÍ TỊCH HIẾM (Score 8,000 - 14,800) =====
    thanh_tieu_ngoc_cam: 14800,         // Thanh Tiêu Ngọc Cầm (Nhện Bạch Ngọc)
    hac_vu_ma_phien: 14600,             // Hắc Vũ Ma Phiến (Nhện Bạch Ngọc)
    ma_tri_mac: 14500,                  // Ma Trì Mặc (Vũ khí Nho Tu)
    tu_van_phien: 14500,                // Tử Vân Phiên (Vũ khí Nho Tu)
    pha_son_chuy: 14400,                // Phá Sơn Chuỳ (Nhện Bạch Ngọc)
    huyet_lien_tram: 14300,             // Huyết Liên Trâm (Nhện Bạch Ngọc)
    thanh_minh_kiem: 14200,             // Thanh Minh Kiếm (Vũ khí Địa phẩm hạ)
    dan_hon_dang: 14200,                // Quỷ La Phiên (Vũ khí Địa phẩm hạ)
    hang_ma_xu: 14200,                  // Hàng Ma Xử (Vũ khí Địa phẩm hạ)
    hong_lang: 14200,                   // Hồng Lăng (Vũ khí Địa phẩm hạ)
    bach_van_phat_tran: 14200,          // Bạch Vân Phất Trần (Vũ khí Địa phẩm hạ)
    huyet_dao: 14200,                   // Huyết Ẩm Đao (Vũ khí Địa phẩm hạ)
    bi_tich_xich_nhat_quyen_an: 14200,  // Xích Nhật Quyền Ấn (Song Dực Ma Báo)
    bi_tich_khai_bi_chuong: 14100,      // Khai Tí Chưởng (Song Dực Ma Báo)
    bi_tich_ho_diep_phe_tam: 14050,     // Hồ Điệp Phệ Tâm (Song Dực Ma Báo)
    yeu_dan_cap_3: 14000,               // Yêu Đan Cấp 3 (Thần Thú Xích Long)
    bi_tich_diep_anh_bo: 13900,         // Điệp Ảnh Bộ (Song Dực Ma Báo)
    bi_tich_toan_phong_thoi: 13800,     // Toàn Phong Thối (Hoàng Cửu Bảo)
    bi_tich_cu_thach_thien_giang: 13700,// Cự Thạch Thiên Giáng (Hoàng Cửu Bảo)
    bi_tich_nhiep_hon_linh: 13600,      // Nhiếp Hồn Linh (Hoàng Cửu Bảo)
    xich_diem_quy_dan: 13500,           // Xích Diễm Quy Đan (Thạch Quy Biến Dị)
    bi_tich_mi_huong_dan: 13400,        // Mị Hương Đàn (Hoàng Cửu Bảo)
    bi_tich_hoanh_tao_mac_ngan: 13300,  // Hoành Tảo Mặc Ngân (Hoàng Cửu Bảo)
    bi_tich_son_ha_nhap_hoa: 13200,     // Sơn Hà Nhập Họa (Hoàng Cửu Bảo)
    bi_tich_tu_van_cuong_phong: 13100,  // Tử Vân Cuồng Phong (Hoàng Cửu Bảo)
    bi_tich_tu_van_ma_vuc: 13000,       // Tử Vân Ma Vực (Hoàng Cửu Bảo)
    quy_tuc_thuy_chau: 12900,           // Quy Tức Thủy Châu (Thạch Quy Biến Dị)
    tu_tinh_duong_than_boi: 12800,      // Tử Tinh Dưỡng Thần Bội (Huyết Sắc Boss)
    xich_phi_kiem: 12500,               // Xích Phi Kiếm (Huyết Sắc Boss)
    hao_nhien_truc_gian: 12500,         // Hạo Nhiên Trúc Giản (Linh phẩm thượng - Nho Tu)
    huyet_kich: 12500,                  // Huyết Sát Kích (Linh phẩm thượng - Huyết Tu)
    huyen_thiet_phu: 12000,             // Huyền Thiết Phủ (Linh phẩm thượng - Thể Tu)
    luc_phi_kiem: 12000,                // Lục Phi Kiếm (Hoàng Cửu Bảo)
    xuyen_son_thiet_giap: 11500,        // Xuyên Sơn Thiết Giáp (Nhện Bạch Ngọc rơi giữa trận)
    huyen_quy_giap_phien: 11000,        // Huyền Quy Giáp Phiến (Thạch Quy Biến Dị)
    huyet_ma_phu: 10800,                // Huyết Ma Phủ (Nhện Bạch Ngọc rơi giữa trận)
    thuy_mach_bi_phien: 10500,          // Mảnh Bia Thủy Mạch (Thạch Quy Biến Dị)
    xich_viem_song_kich: 10000,         // Xích Viêm Song Kích (Nhện Bạch Ngọc / Huyết Sắc)
    nanh_ho: 9500,                      // Nanh Hổ (Bạch Hổ Tuyết - Boss Xổng Chuồng)
    nguu_sung: 9000,                    // Ngưu Sừng (Xích Nhãn Ngưu - Boss Xổng Chuồng)
    hac_tien: 8800,                     // Hạc Tiên (Phi hành Cấp 2 Yên Lãng)
    huyet_nguyet_ung: 8800,             // Huyết Nguyệt Ưng (Phi hành Cấp 2 Yên Lãng)
    pha_canh_dan: 8500,                 // Phá Cảnh Đan (World Boss rơi giữa trận)
    truc_co_dan: 8000,                  // Trúc Cơ Đan

    // ===== TIER 4: TRANG SỨC GIỚI NGOẠ, BẢO HỘ HỘ PHÁP, YÊU ĐAN 1-2 & ĐAN DƯỢC (Score 3,000 - 7,800) =====
    nhan_xich_viem: 7800,               // Xích Viêm Giới (Giới Ngoạ Boss)
    nhan_huyen_nham: 7800,              // Huyền Nham Giới (Giới Ngoạ Boss)
    nhan_thanh_moc: 7800,               // Thanh Mộc Giới (Giới Ngoạ Boss)
    giay_xich_viem: 7600,               // Hồi Phong Ngoa (Giới Ngoạ Boss)
    giay_thanh_moc: 7600,               // Lưu Ngân Ngoa (Giới Ngoạ Boss)
    giay_huyen_nham: 7600,              // Định Sơn Ngoa (Giới Ngoạ Boss)
    xuyen_son_giap_phien: 7200,         // Xuyên Sơn Giáp Phiến (Xuyên Sơn Giáp Biến Dị)
    yeu_dan_cap_2: 7000,                // Yêu Đan Cấp 2 (Huyết Sắc Boss / Ngân Mao Hống)
    giay_van_bo: 6500,                  // Giày Vân Bộ (Hộ Pháp Ngân Mao Hống)
    giap_moc_tam: 6500,                 // Giáp Mộc Tâm (Hộ Pháp Ngân Mao Hống)
    mu_bach_van: 6000,                  // Mũ Bạch Vân (Hộ Pháp Ngân Mao Hống)
    mu_tieu_dao: 6000,                  // Mũ Tiêu Dao (Hộ Pháp Ngân Mao Hống)
    mu_tu_lien: 6000,                   // Mũ Tử Liên (Hộ Pháp Ngân Mao Hống)
    mu_nguyet_bach: 6000,               // Mũ Nguyệt Bạch (Hộ Pháp Ngân Mao Hống)
    tu_linh_ngoc_boi: 6000,             // Tụ Linh Ngọc Bội (Hộ Pháp Ngân Mao Hống)
    mu_tieu_dao_linh: 5800,             // Tiêu Dao Linh Quan (Đồ hiếm rơi)
    moc_linh_giap: 5800,                // Mộc Linh Giáp (Đồ hiếm rơi)
    thanh_huyen_kiem: 5600,             // Thanh Huyền Kiếm (Vũ khí rơi)
    phi_hanh_ho_lo: 5500,               // Kim Vân Hồ Lô (Yêu Quái Hạ Phẩm)
    nhan_tu_than: 5400,                 // Tụ Thần Linh Giới (Đồ hiếm rơi)
    ngung_than_boi: 5200,               // Ngưng Thần Bội (Đồ hiếm rơi)
    yeu_dan_cap_1: 5000,                // Yêu Đan Cấp 1 (Boss Xổng Chuồng Cấp 1)
    tay_tam_dan: 4500,                  // Tẩy Tâm Đan (World Boss rơi giữa trận)
    tran_ban_tu_linh: 4000,             // Tụ Linh Trận Bàn (World Boss rơi giữa trận)
    tran_ban_liet_hoa: 3800,            // Liệt Hoả Trận Bàn (World Boss rơi giữa trận)
    bich_nguc_ta_dao: 3500,             // Bích Ngục Tà Đao (Linh Hổ / Song Dực giữa trận)
    phi_dao: 3200,                      // Phi Đao Trúc Cơ (Linh Hổ / Song Dực giữa trận)
    oan_hon: 3000,                      // Oán Hồn (Thương Đội Tiêu Sư)

    // ===== TIER 5: NGUYÊN LIỆU PHỤ TRỢ, CÁC LOẠI PHÙ CHÚ & VẬT PHẨM RƠI KHÁC (Score 500 - 2,500) =====
    co_bich_moc: 2500,                  // Cổ Bích Mộc (Nhện Bạch Ngọc rơi giữa trận)
    tran_than_thach: 2500,              // Trấn Thần Thạch (Nhện Bạch Ngọc rơi giữa trận)
    huyen_thiet_khoang: 1800,           // Huyền Thiết Khoáng (Thạch Giáp Yêu)
    doc_dang_doc_dich: 1200,            // Độc Đằng Độc Dịch (Độc Đằng Yêu)
    phu_kim_long: 1000,                 // Kim Long Phù
    phu_kim_o: 1000,                    // Kim Ô Phù
    phu_thanh_tam: 800,                 // Thanh Tâm Phù (World Boss rơi giữa trận)
    phu_toc_hanh: 750,                  // Tốc Hành Phù (World Boss rơi giữa trận)
    phu_kim_giap: 700,                  // Kim Giáp Phù (World Boss rơi giữa trận)
    phu_han_bang: 650,                  // Hàn Băng Phù (World Boss rơi giữa trận)
    phu_hoa: 600,                       // Hoả Phù (World Boss rơi giữa trận)
    phu_tho_don: 550,                   // Thổ Độn Phù (World Boss rơi giữa trận)
    phu_loi_dong: 500                   // Lôi Động Phù (World Boss rơi giữa trận)
  };

  // Phẩm cấp thật của vật phẩm (ITEMS.grade): Thiên > Địa > Linh > Phàm, thượng > trung > hạ.
  function gradeScore(P, itemId) {
    if (!itemId) return 0;
    if (LOOT_SPECIAL_SCORES[itemId]) return LOOT_SPECIAL_SCORES[itemId];
    if (/^bi_tich_/.test(itemId)) return 12000;
    if (/^yeu_dan_/.test(itemId)) return 5000;
    var gr = String(P.ITEMS && P.ITEMS[itemId] && P.ITEMS[itemId].grade || '');
    var s = /^Thiên/.test(gr) ? 5000 : /^Địa/.test(gr) ? 3000 : /^Linh/.test(gr) ? 1200 : /^Phàm/.test(gr) ? 200 : 50;
    return s + (/thượng/.test(gr) ? 100 : /trung/.test(gr) ? 60 : /hạ/.test(gr) ? 20 : 0) + (itemId === 'linh_thach' ? 10 : 0);
  }
  // Danh sách "chỉ nhặt" (để trống = nhặt hết): khớp mã vật phẩm hoặc một phần tên, không phân biệt hoa thường.
  function lootFilterOk(P, itemId) {
    var f = String(cfg.lootOnly || '').toLowerCase().split(/[,;\n]/).map(function (s) { return s.trim(); }).filter(Boolean);
    if (!f.length || !itemId) return true;
    var id = String(itemId).toLowerCase(), nm = String(P.ITEMS && P.ITEMS[itemId] && P.ITEMS[itemId].name || '').toLowerCase();
    return f.some(function (k) { return id.indexOf(k) >= 0 || nm.indexOf(k) >= 0; });
  }

  /* ================= Chăm vườn (Luống Thuốc) ================= */
  // Như người chơi: tới vườn, chạm từng luống cần làm. Luống chín → game thu luôn; luống trống → …
  var FA_CHECK_MS = 60000, FA_TOUCH_WAIT_MS = 1500;
  function faPlots(g) { return (g.sw.map.props || []).filter(function (p) { return p && p.type === 'herb_plot'; }); }
  function faNeeds(P, id) {
    var F = P.Farm, I = P.Inventory;
    if (!F) return '';
    if (F.ready && F.ready(id)) return 'thu';
    if (F.isEmpty && F.isEmpty(id) && F.seedsInBag && F.seedsInBag().length) return 'gieo';
    if (F.canWater && F.canWater(id) && ((F.hasWaterAccess && F.hasWaterAccess()) || (I && I.has && I.has('linh_tuyen_thuy', 1)))) return 'tưới';
    return '';
  }
  function faWork(P) {
    var F = P.Farm, n = 0;
    if (!F || !F.PLOT_COUNT) return 0;
    for (var i = 1; i <= F.PLOT_COUNT; i++) if (faNeeds(P, 'plot_' + i)) n++;
    return n;
  }
  function faStart(why) {
    var g = game();
    if (!g || !g.P.Farm) { say('Chưa vào game / game chưa có vườn'); return; }
    if (!faWork(g.P)) { say('Vườn chưa có việc gì (chưa chín, hết hạt, chưa có nước)'); return; }
    st.fa = {
      step: '', touches: 0, touchAt: 0, routeAt: 0, done: {}, plot: null, travels: 0, at: now(),
      back: st.fa && st.fa.back || takeBack(g), got: { thu: 0, gieo: 0, 'tưới': 0 }
    };
    if (!enabled) setEnabled(true);
    klog('[Vườn] Đi chăm vườn' + (why ? ' (' + why + ')' : '') + ': ' + faWork(g.P) + ' luống cần làm');
  }
  function faFinish(g, msg) {
    var a = st.fa, back = a && a.back;
    st.fa = null;
    klog('[Vườn] ' + msg);
    say('Vườn: ' + msg);
    if (back && back.map && g && (g.mapId !== back.map || dist(g.me.x, g.me.y, back.x, back.y) > 60 || (back.khu && gaKhu(g.P) !== back.khu))) goBack(back.map, back.x, back.y, 'Chăm vườn xong → về chỗ cũ', 'fa', back.khu);
  }
  function tickFarmCare(g) {
    var P = g.P;
    if (st.bh || st.bd || st.xc || st.td) return false;
    if (!st.fa) {
      if (cfg.farmAuto && !cfg.planRun && P.Farm && !cfg.dcRun && !st.travel && now() - (st.faCheckAt || -1e9) > FA_CHECK_MS) {
        st.faCheckAt = now();
        if (faWork(P) && !stillFighting(g)) faStart('tự động');
      }
      if (!st.fa) return false;
    }
    var a = st.fa, me = g.me;
    if (g.P.Input.hasManualMove()) return true;
    setAuto(g, false);
    if (now() - a.at > 5 * 60000) { faFinish(g, 'Quá 5 phút chưa xong → dừng'); return false; }
    var mapId = propMap(P, 'plot_1');
    if (!mapId) { faFinish(g, 'Không tìm thấy vườn trong dữ liệu bản đồ'); return false; }
    if (g.mapId !== mapId) {
      if (!st.travel || st.travel.map !== mapId) {
        if (++a.travels > 6) { faFinish(g, 'Không đi được tới vườn'); return false; }
        startTravel(mapId, null, null, 'Đi chăm vườn ở ' + mapName(mapId));
      }
      tickTravel(g);
      return true;
    }
    if (st.travel) stopTravel();
    if (P.HUD && P.HUD.dialogOpen) return true;
    // Đang làm một luống: đi tới, chạm, chờ game xử lý một chút rồi sang luống khác.
    if (a.plot) {
      var r = a.touchAt ? 'sent' : touchProp(g, a, a.plot);
      // Mỗi việc (thu / gieo / tưới) của một luống chỉ thử một lần; luống vừa thu xong thì gieo luôn, vừa gieo thì tưới
      // luôn — làm hết trong một lần vào vườn, không ra rồi vào lại.
      if (r === 'fail' || (a.touchAt && now() - a.touchAt >= FA_TOUCH_WAIT_MS)) { a.done[a.plot.id + ':' + a.job] = true; a.plot = null; }
      return true;
    }
    var list = faPlots(g).filter(function (p) { var j = faNeeds(P, p.id); return j && !a.done[p.id + ':' + j]; });
    if (!list.length) {
      faFinish(g, 'Xong: thu ' + (a.got.thu || 0) + ' · gieo ' + (a.got.gieo || 0) + ' · tưới ' + (a.got['tưới'] || 0) + ' luống');
      return false;
    }
    var p = list.sort(function (x, y) { return dist(me.x, me.y, x.x, x.y) - dist(me.x, me.y, y.x, y.y); })[0];
    var job = faNeeds(P, p.id);
    a.plot = p; a.job = job; a.touches = 0; a.touchAt = 0;
    a.step = job + ' ' + (p.name || p.id);
    a.got[job] = (a.got[job] || 0) + 1;
    if (job === 'gieo') dcDlg = { want: 'sow', until: now() + 8000, at: now() };
    touchProp(g, a, p);
    return true;
  }

  /* ================= Đánh tự động: sang khu ít người ================= */
  // Không tự chạy đi xem nữa: chỉ khi Bảng Khu được mở (người chơi tự mở, hoặc bấm "Tìm khu ít người ngay" — script chạy …
  var FK_ASK_WAIT_MS = 3000, FK_SWITCH_WAIT_MS = 10000;
  function fkLog(msg) { klog('[Khu] ' + msg); say('Khu: ' + msg); }
  function fkBoard(g) {
    var me = g.me, b = (g.sw.map.props || []).filter(function (p) { return p && p.type === 'khu_board'; });
    return b.sort(function (x, y) { return dist(me.x, me.y, x.x, x.y) - dist(me.x, me.y, y.x, y.y); })[0] || null;
  }
  // Khu ít người nhất (bỏ khu đầy) so với khu đang đứng; null nếu khu đang đứng đã ít người nhất.
  function fkBest(g) {
    var P = g.P, cur = gaKhu(P), n = gaSoKhu(P), L = khuList && khuList.mapId === g.mapId ? khuList : null;
    if (!L || !L.dem) return null;
    var mine = Math.max(0, (L.dem[cur - 1] | 0) - 1), best = null;
    for (var k = 1; k <= n; k++) {
      if (k === cur) continue;
      var dem = L.dem[k - 1] | 0, cap = (L.tran && L.tran[k - 1]) || L.toiDa || 0;
      if (cap && dem >= cap) continue;
      if (!best || dem < best.dem) best = { khu: k, dem: dem };
    }
    return best && best.dem < mine ? { khu: best.khu, dem: best.dem, mine: mine } : { khu: 0, mine: mine };
  }
  function fkStart(why) {
    var g = game();
    if (!g) return;
    if (gaSoKhu(g.P) <= 1) { if (why === 'bấm nút') say('Map này không chia khu'); st.fkCheckAt = now(); return; }
    var fb = cfg.farm && cfg.farm.map === g.mapId ? { x: cfg.farm.x, y: cfg.farm.y, map: g.mapId } : { x: g.me.x, y: g.me.y, map: g.mapId };
    st.fk = { step: 'board', at: now(), askAt: 0, touches: 0, touchAt: 0, routeAt: 0, want: 0, back: fb };
    if (!enabled) setEnabled(true);
  }
  function fkDone(g, msg) {
    var f = st.fk;
    st.fk = null;
    st.fkCheckAt = now();
    if (msg) fkLog(msg);
    if (g && g.P.KhuUI && g.P.KhuUI.isOpen && g.P.KhuUI.isOpen() && !(f && f.manual)) g.P.KhuUI.close(); // tự mở thì để bảng cho người chơi
    if (f && f.back && g && g.mapId === f.back.map && dist(g.me.x, g.me.y, f.back.x, f.back.y) > 60) startTravel(f.back.map, f.back.x, f.back.y, 'Về chỗ farm ở khu mới');
  }
  // Đang thật sự đánh nhau: có quái đang đuổi / cắn mình, hoặc mình đang mất máu. (Bãi farm lúc nào cũng có quái đứng
  // gần, nên không lấy "có quái quanh đây" làm lý do chờ — trước đây vì thế mà không bao giờ tới lượt đổi khu.)
  function fkEngaged(g) { return !!engagedBy(g); }
  // Quái / người đang đánh chính mình (game không báo quái đang đuổi ai): quái hung hăng đang đuổi / vồ mà người gần nó
  // nhất là mình (quái đuổi người chơi khác đứng cạnh thì không tính), hoặc mình vừa mất máu mà có quái hung hăng sát bên.
  function mobOnMe(g, m) {
    var me = g.me, dm = dist(me.x, me.y, m.x, m.y), R = g.P.Gateway && g.P.Gateway.remotes || {};
    return !Object.keys(R).some(function (id) { var r = R[id]; return r && !r.downed && isFinite(r.x) && dist(r.x, r.y, m.x, m.y) + 30 < dm; });
  }
  function engagedBy(g) {
    var me = g.me, mobs = mobsAlive(g).filter(function (m) { return m.def.contactDmg > 0 && m.state !== 'return'; });
    var chasing = mobs.filter(function (m) { return (m.state === 'chase' || m.state === 'attack') && dist(me.x, me.y, m.x, m.y) <= 260 && mobOnMe(g, m); });
    var hit = 0;
    hpLog.forEach(function (e) { hit += e.d; });
    if (hit >= Math.max(1, (me.hpMax || 100) * 0.005)) {
      var near = mobs.filter(function (m) { return dist(me.x, me.y, m.x, m.y) <= mobBaseReach(g, m) + 60; });
      if (near.length) chasing = chasing.concat(near);
    }
    var foe = hostilePlayers(g).filter(function (r) { return dist(me.x, me.y, r.x, r.y) <= 260; })[0];
    if (foe) return foe;
    return chasing.sort(function (a, b) { return dist(me.x, me.y, a.x, a.y) - dist(me.x, me.y, b.x, b.y); })[0] || null;
  }
  // Đang câu yên ổn (không ai đánh mình): các phần tự động khác (bùa, trận, khôi lỗi, gọi Âm Hồn) không được động vào.
  function fishingCalm(g) { return !!((g.sw.fishing || g.sw.fishingAuto) && !engagedBy(g)); }
  function tickFarmKhu(g) {
    var P = g.P, G = P.Gateway, K = P.KhuUI;
    if (!st.fk) {
      // Bảng Khu vừa được mở (mỗi lần mở xét một lần): đọc số người, có khu vắng hơn thì sang.
      var opened = K && K.isOpen && K.isOpen() && khuOpenAt && khuOpenAt !== st.fkOpenSeen;
      st.fkWhy = !cfg.farmKhu ? 'đang tắt' : gaSoKhu(P) <= 1 ? 'map này không chia khu' : 'chờ mở Bảng Khu';
      if (!opened) {
        // Tự xem định kỳ: cứ farmKhuMin phút (lúc rảnh, đang tự đánh) chạy ra Bảng Khu, xong về đúng chỗ farm.
        if (!cfg.farmKhuAuto || gaSoKhu(P) <= 1) return false;
        var why = !g.sw.autoOn ? 'Tự Động đang tắt' : st.bh ? 'đang đi boss' : st.bd || st.xc || st.td ? 'đang săn sự kiện' : st.hon ? 'đang săn hồn' :
          st.dc ? 'đang làm Dược Công' : st.ga ? 'đang nhặt nguyên liệu' : st.fa ? 'đang chăm vườn' : st.travel ? 'đang đi đường' : st.healing ? 'đang thiền' : '';
        if (!why && now() - (st.fkCheckAt || -1e9) < cfg.farmKhuMin * 60000) why = 'chờ tới lượt xem';
        if (!why && fkEngaged(g)) why = 'đang bị quái đuổi đánh, đánh xong đã';
        if (!why && dropsLeft(g).length) why = 'đang chờ nhặt đồ rơi';
        st.fkWhy = why;
        if (why) return false;
        fkStart('định kỳ');
        if (!st.fk) return false;
        fkLog('Tới lượt xem (mỗi ' + cfg.farmKhuMin + ' phút) → ra Bảng Khu tìm khu ít người');
      } else {
        st.fkOpenSeen = khuOpenAt;
        if (!cfg.farmKhu || gaSoKhu(P) <= 1) return false;
        fkStart('mở bảng');
        if (!st.fk) return false;
        st.fk.at = khuOpenAt - 50; // danh sách có thể về ngay sau lúc mở
        st.fk.back = null;         // người chơi tự mở bảng: không kéo về chỗ farm
        st.fk.manual = true;
      }
    }
    var f = st.fk;
    if (!f || P.Input.hasManualMove()) return false;
    if (!G || !G.connected) { fkDone(g, 'Mất kết nối → để lần sau'); return false; }
    if (now() - f.at > 60000) { fkDone(g, 'Quá 1 phút chưa xong → để lần sau'); return false; }
    // Đang bị đánh thì để đánh xong (trừ lúc đã chọn khu, đang chờ sang).
    if (f.step !== 'wait' && fkEngaged(g)) return false;
    setAuto(g, false);
    if (f.step === 'board') {
      if (K && K.isOpen && K.isOpen()) {
        if (!f.openAt) f.openAt = now();
        // Bảng mở là game hỏi máy chủ ngay; ping thấp thì danh sách về trước cả nhịp kiểm tra kế (150ms) → tính mọi danh …
        if (khuListAt >= f.at && khuList && khuList.mapId === g.mapId) { f.step = 'decide'; fkLog('Đứng ở Bảng Khu, xem số người từng khu'); }
        else if (now() - f.openAt < FK_ASK_WAIT_MS * (f.asked ? 2 : 1)) return true;
        else if (!f.asked && G.send) { f.asked = true; G.send({ op: 'khu', act: 'xem' }); return true; } // hỏi lại một lần
        else { fkDone(g, 'Bảng Khu không báo số người → để lần sau'); return false; }
      } else {
        var b = fkBoard(g);
        if (!b) { fkDone(g, 'Map này không có Bảng Khu'); return false; }
        if (touchProp(g, f, b) === 'fail') { fkDone(g, 'Không chạm được Bảng Khu'); return false; }
        st.fkWhy = 'tới Bảng Khu xem số người';
        return true;
      }
    }
    if (f.step === 'decide') {
      var best = fkBest(g);
      if (!best || !best.khu) { fkDone(g, 'Khu ' + gaKhu(P) + ' đã ít người nhất' + (best ? ' (' + best.mine + ' người khác)' : '')); return false; }
      f.want = best.khu;
      fkLog('Khu ' + gaKhu(P) + ' có ' + best.mine + ' người khác, khu ' + best.khu + ' có ' + best.dem + ' → sang khu ' + best.khu);
      f.step = 'switch'; f.touches = 0; f.touchAt = 0;
    }
    if (f.step === 'switch') {
      if (gaKhu(P) === f.want) { fkDone(g, 'Đã sang khu ' + f.want); return false; }
      if (lootBeforeLeave(g)) return true;
      if (K && K.isOpen && K.isOpen()) {
        if (!G.send || !G.send({ op: 'khu', act: 'chon', khu: f.want })) { fkDone(g, 'Không gửi được lệnh đổi khu'); return false; }
        K.close();
        f.step = 'wait'; f.waitAt = now();
        return true;
      }
      var b2 = fkBoard(g);
      if (!b2) { fkDone(g, 'Map này không có Bảng Khu'); return false; }
      if (touchProp(g, f, b2) === 'fail') { fkDone(g, 'Không chạm được Bảng Khu'); return false; }
      return true;
    }
    if (f.step === 'wait') {
      if (gaKhu(P) === f.want) { fkDone(g, 'Đã sang khu ' + f.want + (f.back ? ' → về chỗ farm đánh tiếp' : '')); return false; }
      if (now() - f.waitAt < FK_SWITCH_WAIT_MS) return true;
      fkDone(g, 'Chọn khu ' + f.want + ' mà chưa sang được → để lần sau');
      return false;
    }
    return true;
  }

  /* ================= Vũ khí đánh lan: tự đo tầm lan, chọn chỗ đứng trúng nhiều con ================= */
  // Đo tầm lan đòn đánh thường theo gói "hit" của máy chủ (20px một ô), rồi chọn chỗ đứng trúng nhiều con nhất.
  var SPLASH_BIN = 20;          // px mỗi ô khoảng cách
  var SPLASH_WAIT_MS = 800;     // chờ gói trúng từ máy chủ sau nhát đánh
  var SPLASH_MIN_SEEN = 3;      // một ô cần chừng này mẫu mới tin
  var SPLASH_SINGLE_N = 10;     // chừng này mẫu không trúng con nào ngoài mục tiêu → vũ khí đánh đơn
  var SPLASH_THREAT_COST = 25;  // điểm trừ mỗi con cắn tới được chỗ đứng (1 con trúng thêm = 100)
  var pendingSplash = null, splashSaveAt = 0;

  function weaponId(P) { var w = P.Player && P.Player.weaponDef && P.Player.weaponDef(); return w ? w.id : 'tay_khong'; }
  function weaponName(P) { var w = P.Player && P.Player.weaponDef && P.Player.weaponDef(); return w ? w.name : 'Tay không'; }
  function attackOrigin(P) { return P.CONFIG.PLAYER && P.CONFIG.PLAYER.ATTACK_ORIGIN || 14; }
  function dirVec(dir) { return { x: dir === 1 ? -1 : dir === 2 ? 1 : 0, y: dir === 0 ? 1 : dir === 3 ? -1 : 0 }; }
  // Hướng game quay mặt khi đánh mục tiêu: trục lớn hơn của vector tới mục tiêu.
  function dirToward(dx, dy) { return Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 2 : 1) : (dy > 0 ? 0 : 3); }

  // Những con mà nhát đánh từ chỗ p (quay mặt dir) có thể trúng nếu vũ khí đánh lan: trong tầm R
  // (từ điểm ra đòn) và ở nửa phía trước.
  function frontInReach(g, px, py, dir, R) {
    var v = dirVec(dir), o = attackOrigin(g.P), ox = px + v.x * o, oy = py + v.y * o;
    return mobsAlive(g).filter(function (m) {
      var d = dist(ox, oy, m.x, m.y);
      if (d > R + (m.def && m.def.bodyRadius || 0)) return false;
      return dist(px, py, m.x, m.y) <= 2 || (m.x - px) * v.x + (m.y - py) * v.y > 0;
    }).map(function (m) { return { m: m, d: dist(ox, oy, m.x, m.y) }; });
  }

  function splashLearn(w) {
    var L = cfg.splashLearn2 || (cfg.splashLearn2 = {});
    return L[w] || (L[w] = { b: {}, sw: 0 });
  }
  function splashFinalize() {
    var p = pendingSplash;
    if (!p) return;
    pendingSplash = null;
    if (!p.hits.has(p.target)) return; // nhát hụt / mục tiêu ngoài tầm: không tính
    var L = splashLearn(p.w);
    L.sw++;
    p.cands.forEach(function (c) {
      if (c.m === p.target) return;
      var k = Math.floor(c.d / SPLASH_BIN), b = L.b[k] || (L.b[k] = [0, 0]);
      b[0]++;
      if (p.hits.has(c.m)) b[1]++;
    });
    if (now() - splashSaveAt > 10000) { splashSaveAt = now(); save(); }
  }
  function splashSwing(g) {
    splashFinalize();
    var me = g.me, t = me.attackTarget;
    if (!t || !t.def) return;
    var R = g.P.Player.reach ? g.P.Player.reach() : 26;
    pendingSplash = { at: now(), w: weaponId(g.P), target: t, hits: new Set(), cands: frontInReach(g, me.x, me.y, me.dir, R) };
  }
  function splashHit(m) { if (pendingSplash && m && now() - pendingSplash.at < SPLASH_WAIT_MS) pendingSplash.hits.add(m); }
  function tickSplash() { if (pendingSplash && now() - pendingSplash.at >= SPLASH_WAIT_MS) splashFinalize(); }

  // Tầm lan đã đo của vũ khí: null = chưa đủ mẫu; 0 = đánh đơn; > 0 = con cách điểm ra đòn tới …
  var SPLASH_NEAR_SHARE = 0.55;
  function splashEstimate(w, reach) {
    var L = cfg.splashLearn2 && cfg.splashLearn2[w];
    if (!L) return { r: null, n: 0, sw: 0, nearN: 0 };
    var keys = Object.keys(L.b).map(Number).sort(function (a, b) { return a - b; }), n = 0, r = 0, nearN = 0, nearHit = 0, hit = 0;
    var nearMax = (reach || 240) * SPLASH_NEAR_SHARE;
    keys.forEach(function (k) {
      n += L.b[k][0]; hit += L.b[k][1];
      if ((k + 1) * SPLASH_BIN <= nearMax) { nearN += L.b[k][0]; nearHit += L.b[k][1]; }
    });
    if (nearN >= SPLASH_SINGLE_N && nearHit === 0) return { r: 0, n: n, sw: L.sw, nearN: nearN, hit: hit };
    for (var i = 0; i < keys.length; i++) {
      var b = L.b[keys[i]];
      if (b[0] < SPLASH_MIN_SEEN) continue;
      var ratio = b[1] / b[0];
      if (ratio >= 0.5) r = (keys[i] + 1) * SPLASH_BIN;
      else if (ratio < 0.25 && r > 0) break;
    }
    return { r: r > 0 ? r : null, n: n, sw: L.sw, nearN: nearN, hit: hit };
  }
  // Tầm lan dùng để chọn chỗ đứng. Chưa đo ra thì với vũ khí tầm xa tạm coi là nửa tầm (vào gần
  // hơn vừa đánh vừa đo); đo ra "đánh đơn" thì 0.
  var SPLASH_EXPLORE_MIN_REACH = 80;
  // Theo mã game (Player.singleTargetWeapon): mọi vũ khí trừ Trúc Kiếm chỉ đánh một mục tiêu; online
  // máy mình cũng chỉ gửi đúng một targetId. Vũ khí như vậy không đi đo (không vào gần vô ích).
  function gameSingleTarget(g) {
    var PL = g.P.Player;
    try { return !!(PL && PL.singleTargetWeapon && PL.singleTargetWeapon(g.me)); } catch (e) { return false; }
  }
  function splashR(g) {
    var reach = g.P.Player.reach ? g.P.Player.reach() : 26;
    if (cfg.splashManual > 0) return { r: Math.min(cfg.splashManual, reach) };
    var e = splashEstimate(weaponId(g.P), reach);
    if (e.r > 0) return { r: Math.min(e.r, reach) };
    if (e.r === 0 || gameSingleTarget(g)) return { r: 0 };
    return reach >= SPLASH_EXPLORE_MIN_REACH ? { r: Math.round(reach * 0.5), explore: true } : { r: 0 };
  }

  // Chỗ đứng đánh lan tốt nhất quanh mục tiêu t: {x, y, count, r, here}; null nếu không đáng (chưa
  // biết tầm lan, vũ khí đánh đơn, hoặc quanh mục tiêu không có con nào khác).
  function splashSpot(g, t) {
    if (!cfg.splashPos || !t || !t.def) return null;
    var ri = splashR(g), r = ri.r;
    if (!(r > 0)) return null;
    var P = g.P, me = g.me, reach = P.Player.reach ? P.Player.reach() : 26, o = attackOrigin(P);
    var mobs = mobsAlive(g), near = mobs.filter(function (m) { return dist(m.x, m.y, t.x, t.y) <= r * 2 + 40; });
    if (near.length < 2) return null;
    var sc = spotCheck(g), avoid = hazards(g).concat(towerAvoid(g)), keep = leashKeep(g, t);
    function evalAt(px, py) {
      var dir = dirToward(t.x - px, t.y - py), v = dirVec(dir);
      if (dist(px + v.x * o, py + v.y * o, t.x, t.y) > reach + (t.def.bodyRadius || 0) - 2) return null; // mục tiêu phải trong tầm
      var count = frontInReach(g, px, py, dir, r).length;
      var threats = mobs.filter(function (m) { return m.def.contactDmg > 0 && dist(px, py, m.x, m.y) <= mobBaseReach(g, m) + 4; }).length;
      return { x: px, y: py, count: count, threats: threats, score: count * 100 - threats * SPLASH_THREAT_COST - dist(me.x, me.y, px, py) * 0.25 };
    }
    var here = evalAt(me.x, me.y), best = here;
    var maxR = Math.min(r, reach) - 4;
    for (var rr = 16; rr <= maxR; rr += 16) {
      for (var k = 0; k < 16; k++) {
        var a = k / 16 * Math.PI * 2, x = t.x + Math.cos(a) * rr, y = t.y + Math.sin(a) * rr;
        if (!sc.standable(x, y) || inHazard(avoid, x, y) || (keep && !keep(x, y))) continue;
        var c = evalAt(x, y);
        if (c && (!best || c.score > best.score)) best = c;
      }
    }
    if (!best || best.count < 2) return null;
    if (here && here.count >= best.count) return { x: me.x, y: me.y, count: here.count, r: r, here: true, explore: ri.explore };
    best.r = r;
    best.explore = ri.explore;
    return best;
  }

  /* ================= Tự đi đánh boss thế giới theo giờ ================= */
  // Theo lịch boss toàn máy chủ (hoatdong.xem, như bảng Hoạt Động): boss đang sống hoặc sắp ra trong …
  var BH_NEAR = 260;            // px quanh chỗ boss hồi sinh coi là đã tới
  var BH_LOOT_MS = 25000;       // boss chết rồi đứng thêm 25s (server bốc thăm quà lúc 20s, bán kính 700px)
  var BH_SKIP_MS = 3 * 60000;   // vừa đánh xong một boss: chừng này mới xét lại boss đó (lịch còn cũ)
  var BH_MAX_MS = 15 * 60000;   // tối đa 15 phút săn một boss thế giới (quá hạn tự hủy tránh treo)
  var BH_FAIL_SKIP_MS = 30 * 60000;
  var BH_LOOK_MS = 2500;        // vào khu rồi mà lịch báo boss đang sống, chừng này chưa thấy thì sang khu khác
  var BH_SPAWN_GRACE = 15;      // giây sau giờ hồi sinh mới tính là boss phải có mặt
  var BH_NOKHU_MS = 60000;      // map không chia khu: boss phải có mà chừng này không thấy thì thôi
  var bhSkip = {};
  var bossSpawnCache = {};
  function bhLog(msg) { klog('[Boss] ' + msg); say('Boss: ' + msg); }
  // Chỗ boss hồi sinh: tìm trong danh sách quái của dữ liệu bản đồ theo id điểm hồi sinh.
  function bossSpawnPos(P, b) {
    if (bossSpawnCache[b.spawn]) return bossSpawnCache[b.spawn];
    var MD = P.MapData || {}, T = P.CONFIG.TILE || 32, found = null;
    Object.keys(MD).some(function (k) {
      var m = MD[k];
      if (!m || typeof m !== 'object' || m.id !== b.map || !Array.isArray(m.enemies)) return false;
      return m.enemies.some(function (e) { if (e && e.id === b.spawn) { found = { x: (e.tx + 0.5) * T, y: (e.ty + 1) * T }; return true; } return false; });
    });
    if (found) bossSpawnCache[b.spawn] = found;
    return found;
  }
  var BH_NAMES = { than_thu_xich_long: 'Thần Thú Xích Long', linh_ho_tran_son: 'Linh Hổ Trấn Sơn', song_duc_ma_bao: 'Song Dực Ma Báo', nhen_bach_ngoc: 'Nhện Bạch Ngọc' };
  // Boss mới máy chủ thêm vào bảng Hoạt Động (vd. Nhện Bạch Ngọc ở Bãi Đá): tra id điểm sinh trong dữ liệu bản đồ ra loại quái + map.
  var bossDynCache = {};
  function bossDyn(P) {
    var res = st.bossList, out = [];
    if (!res || !res.boss) return out;
    res.boss.forEach(function (row) {
      if (!row || !row.id || BOSS_TABLE.some(function (b) { return b.spawn === row.id; })) return;
      var hit = spawnLookup(P, row.id);
      if (hit) out.push(hit);
    });
    return out;
  }
  function spawnLookup(P, id) {
    if (!(id in bossDynCache)) {
      var MD = P.MapData || {}, hit = null;
      Object.keys(MD).some(function (k) {
        var m = MD[k];
        if (!m || typeof m !== 'object' || typeof m.id !== 'string' || !Array.isArray(m.enemies)) return false;
        return m.enemies.some(function (e) { if (e && e.id === id && e.type) { hit = { spawn: id, type: e.type, map: m.id, dyn: true }; return true; } return false; });
      });
      if (!hit && !Object.keys(MD).length) return null; // dữ liệu bản đồ chưa nạp: tra lại sau
      bossDynCache[id] = hit;
    }
    return bossDynCache[id];
  }
  // Bảng cứng ghi map theo dữ liệu hiện tại; máy chủ dời chỗ sinh sang map khác thì theo dữ liệu bản đồ.
  function bossAll(P) {
    BOSS_TABLE.forEach(function (b) { var h = spawnLookup(P, b.spawn); if (h && h.map !== b.map) b.map = h.map; });
    return BOSS_TABLE.concat(bossDyn(P));
  }
  function bhName(P, b) { var D = P.ENEMY_DEFS || {}; return BH_NAMES[b.type] || (D[b.type] && D[b.type].name || b.type).split('|')[0].trim(); }
  // Boss nên đi đánh lúc này: đang sống trước, rồi sắp ra sớm nhất.
  function bhPick(g) {
    var res = st.bossList, best = null;
    if (!res) return null;
    var el = (now() - st.bossListAt) / 1000;
    bossAll(g.P).forEach(function (b) {
      if (cfg['bh_' + b.type] === false || bhSkip[b.type] > now()) return;
      var wait = null;
      if (b.type === 'song_duc_ma_bao') { if (res.maBao && res.maBao.dangSong) wait = 0; }
      else {
        var row = (res.boss || []).filter(function (x) { return x.id === b.spawn; })[0];
        if (row) wait = !row.dead ? 0 : row.con > 0 ? Math.max(0, row.con - el) : 0;
      }
      if (wait === null || wait > cfg.bossLead) return;
      if (!best || wait < best.wait) best = { b: b, wait: wait };
    });
    return best;
  }
  function bhAlive(g, b) {
    var res = st.bossList;
    if (!res) return true;
    if (b.type === 'song_duc_ma_bao') return !!(res.maBao && res.maBao.dangSong);
    var row = (res.boss || []).filter(function (x) { return x.id === b.spawn; })[0];
    return !row || !row.dead || (row.con - (now() - st.bossListAt) / 1000) <= cfg.bossLead;
  }
  // Theo lịch: boss lúc này phải đang có mặt (đang sống, hoặc đã quá giờ hồi sinh).
  function bhShouldBeUp(b) {
    var res = st.bossList;
    if (!res) return false;
    if (b.type === 'song_duc_ma_bao') return !!(res.maBao && res.maBao.dangSong);
    var row = (res.boss || []).filter(function (x) { return x.id === b.spawn; })[0];
    return !!row && (!row.dead || (row.con - (now() - st.bossListAt) / 1000) <= -BH_SPAWN_GRACE);
  }
  // Khu kế tiếp để tìm boss: khu radar thấy lần cuối trước, rồi lần lượt các khu chưa xem.
  function bhNextKhu(g, h) {
    var P = g.P, so = gaSoKhu(P), cur = gaKhu(P), seen = h.khuSeen, r = radarSeen[h.b.type], c = bossHint(h.b.type);
    if (c && c.dead && c.khu <= so) seen[c.khu] = true;
    if (c && !c.dead && c.khu !== cur && !seen[c.khu] && c.khu <= so) return c.khu;
    if (h.b.khu && h.b.khu !== cur && !seen[h.b.khu] && h.b.khu <= so) return h.b.khu; // boss có khu cố định
    if (r && r.map === h.b.map && r.khu !== cur && !seen[r.khu] && r.khu <= so) return r.khu;
    for (var i = 1; i < so; i++) {
      var k = ((cur - 1 + i) % so) + 1;
      if (!seen[k]) return k;
    }
    return 0;
  }
  function bhFinish(g, msg, skipMs) {
    var h = st.bh;
    st.bh = null;
    if (h) bhSkip[h.b.type] = now() + (skipMs || BH_SKIP_MS);
    st.bossPollAt = -1e9; // hỏi lịch mới ngay
    bhLog(msg);
    if (h && h.back) goBack(h.back.map, h.back.x, h.back.y, 'Đánh boss xong → về chỗ farm', 'bh', h.back.khu);
  }
  // Theo dõi boss đang săn (chạy mỗi nhịp, kể cả lúc đang thiền): thấy boss → đánh; đã thấy mà
  // không còn → boss chết, bắt đầu đếm giờ hút đồ. Trả về con boss nếu đang thấy.
  function bhObserve(g) {
    var h = st.bh;
    if (!h) return null;
    var b = h.b, boss = mobsAlive(g).filter(function (m) { return m.type === b.type; })[0] || null;
    if (boss) {
      h.seen = true;
      h.seenAt = now();
      h.lastBossPos = { x: boss.x, y: boss.y };
      if (h.phase !== 'loot') h.phase = 'fight';
    }
    else if (h.seen && h.phase === 'fight' && g.mapId === b.map) {
      h.phase = 'loot'; h.killAt = now();
      st.wbLootUntil = now() + BH_LOOT_MS;
      st.wbLootPos = h.lastBossPos ? { x: h.lastBossPos.x, y: h.lastBossPos.y, map: b.map } : null;
      bhLog(bhName(g.P, b) + ' đã bị hạ → giữ vị trí & chờ bốc thăm quà (' + BH_LOOT_MS / 1000 + 's, server bốc thăm lúc 20s)');
    }
    return boss;
  }

  function tickBossHunt(g) {
    var P = g.P, me = g.me;
    if (!st.bh) {
      if (!cfg.bossHunt || !enabled || me.downed || vtBusy(g)) return false;
      var pk = bhPick(g);
      if (!pk) return false;
      var pos = bossSpawnPos(P, pk.b);
      if (!pos) { bhSkip[pk.b.type] = now() + BH_FAIL_SKIP_MS; bhLog('Không tìm được chỗ hồi sinh của ' + bhName(P, pk.b)); return false; }
      var back = st.bd ? st.bd.back : st.xc ? st.xc.back : st.td ? st.td.back : st.back ? takeBack(g) : st.travel ? { map: st.travel.map, x: st.travel.x, y: st.travel.y } : takeBack(g);
      st.bd = null;
      st.xc = null;
      st.td = null;
      st.bh = {
        b: pk.b, pos: pos, back: back, at: now(), phase: 'go', fails: 0, seen: false, killAt: 0,
        touches: 0, touchAt: 0, routeAt: 0, khuWant: 0, khuAt: 0, khuSeen: {}, lookAt: 0, step: ''
      };
      bhLog((pk.wait > 0 ? bhName(P, pk.b) + ' ra sau ~' + Math.round(pk.wait) + 's' : bhName(P, pk.b) + ' đang xuất hiện') + ' → đi ' + mapName(pk.b.map) + ' đánh');
    }
    var h = st.bh, b = h.b;
    if (now() - h.at > BH_MAX_MS) { bhFinish(g, 'Quá ' + Math.round(BH_MAX_MS / 60000) + ' phút chưa xong ' + bhName(P, b) + ' → về', BH_SKIP_MS); return false; }
    var boss = bhObserve(g);
    if (h.phase === 'loot') {
      var elapsed = now() - h.killAt;
      if (elapsed < BH_LOOT_MS) {
        // Luôn đứng trong bán kính 150px quanh vị trí boss chết (server yêu cầu <= 700px để đủ điều kiện bốc thăm)
        if (h.lastBossPos && dist(me.x, me.y, h.lastBossPos.x, h.lastBossPos.y) > 150) {
          if (!(me.path && me.path.length && now() - h.routeAt < 1200)) {
            var rb = spotCheck(g).route(h.lastBossPos.x, h.lastBossPos.y);
            if (rb) { moveFighting(g, rb.path); h.routeAt = now(); }
          }
        }
        return false; // Trong 25s chờ bốc thăm: giữ chân nhân vật tại map, không chuyển map hay về chỗ farm
      }
      bhFinish(g, 'Đã nhận xong quà bốc thăm ' + bhName(P, b) + ' → về chỗ farm', BH_SKIP_MS);
      return false;
    }
    // Chưa thấy mà lịch báo boss đã chết (người khác hạ trước) và lâu mới ra: thôi.
    if (!boss && !bhAlive(g, b) && now() - st.bossListAt < 60000 && st.bossListAt > (h.seenAt || h.at)) {
      var rowD = (st.bossList && st.bossList.boss || []).filter(function (x) { return x.id === b.spawn; })[0], conD = rowD && rowD.con > 0 ? Math.round((rowD.con - (now() - st.bossListAt) / 1000) / 60) : 0;
      bhFinish(g, bhName(P, b) + ' đã bị hạ' + (conD ? ' (hồi sau ~' + conD + ' phút)' : '') + ' → thôi chờ, về chỗ farm', BH_SKIP_MS); return false;
    }
    // Thấy boss: đang đánh (có thể bị kéo ra xa) hoặc vừa đổi khu đứng ở Bảng Khu → còn xa thì tự đi tới.
    if (boss && g.mapId === b.map && h.phase === 'fight') {
      if (st.travel) stopTravel();
      h.khuWant = 0; h.step = '';
      setAuto(g, true); // Giữ Auto để linh hồn / kiếm linh / quyền ảnh / mị điệp và combo xả liên tục
      var hpPct = boss.hpMax > 0 ? (boss.hp / boss.hpMax) : 1;
      var d = dist(me.x, me.y, boss.x, boss.y);
      var bReach = (P.Player.reach ? P.Player.reach() : 26) + (boss.def && boss.def.bodyRadius || 24);

      // Khi boss sắp gục (<= 4% máu hoặc <= 50.000 hp): chủ động dồn burst và áp sát chạm tâm boss px = 0 (<= 2px) đón đầu nhặt đồ Frame 0
      if (hpPct <= 0.04 || (boss.hp != null && boss.hp <= 50000)) {
        huntBurst(g, boss, d, bReach);
        if (d > 2 && !(me.path && me.path.length && now() - h.routeAt < 400)) {
          var rbClose = spotCheck(g).route(boss.x, boss.y);
          if (rbClose) { moveFighting(g, rbClose.path); h.routeAt = now(); }
        }
      } else {
        huntBurst(g, boss, d, bReach);
        var myHpPct = me.hp / (me.hpMax || 1);
        var inGrace = now() < (st.reviveGraceUntil || 0) && myHpPct < 0.45;
        var isCappedSafe = bossCapped(g, boss) && (!cfg.bossMaxDmg || myHpPct < 0.50);
        if (inGrace || isCappedSafe) {
          // Bảo toàn mạng: giữ cự ly an toàn 140-200px quanh boss (trong bán kính bốc thăm 700px và tầm chiêu)
          if (d < 120 && myHpPct < 0.40) {
            var awayX = me.x + (me.x - boss.x) / (d || 1) * 60, awayY = me.y + (me.y - boss.y) / (d || 1) * 60;
            var rbSafe = spotCheck(g).route(awayX, awayY);
            if (rbSafe) { moveFighting(g, rbSafe.path); h.routeAt = now(); }
          } else if (d > 200 && !(me.path && me.path.length && now() - h.routeAt < 800)) {
            var rbHold = spotCheck(g).route(boss.x + (me.x - boss.x) / (d || 1) * 160, boss.y + (me.y - boss.y) / (d || 1) * 160);
            if (rbHold) { moveFighting(g, rbHold.path); h.routeAt = now(); }
          }
        } else if (d > bReach && !(me.path && me.path.length && now() - h.routeAt < 800)) {
          // Áp sát thẳng vào tầm đánh thực tế của vũ khí/chiêu thức (không đứng xa ngoài tầm)
          var rb = spotCheck(g).route(boss.x, boss.y);
          if (rb) { moveFighting(g, rb.path); h.routeAt = now(); }
        }
      }
      return false;
    }
    if (g.mapId !== b.map) { h.khuWant = 0; h.searching = false; h.fixedKhu = false; }
    // Boss có khu cố định (Nhện Bạch Ngọc ở khu 1): vào map mà đứng sai khu thì sang đúng khu trước, kể cả lúc còn chờ boss hồi;
    // sang xong thì đi tới ổ chờ / đánh như thường.
    else if (b.khu && gaSoKhu(P) >= b.khu && !h.khuWant && !h.fixedKhu && gaKhu(P) !== b.khu) {
      if (st.travel) stopTravel();
      h.fixedKhu = true; h.searching = true; h.phase = 'wait'; h.khuSeen = {};
      h.khuWant = b.khu; h.khuAt = 0; h.touches = 0; h.touchAt = 0;
      h.step = 'sang khu ' + b.khu + ' (' + bhName(P, b) + ' ở khu ' + b.khu + ')';
      bhLog(bhName(P, b) + ' ở khu ' + b.khu + ' mà đang đứng khu ' + gaKhu(P) + ' → sang khu ' + b.khu);
    } else if (h.fixedKhu && h.searching && !h.khuWant && gaKhu(P) === b.khu) { h.searching = false; h.fixedKhuOk = true; }
    // Vừa vào map boss mà chat / radar đã chỉ khu khác: đổi khu ngay, khỏi chạy tới chỗ hồi sinh ở khu này trước.
    else if (!h.searching && !h.khuWant && gaSoKhu(P) > 1 && bhShouldBeUp(b)) {
      var hc0 = bossHint(b.type), hr0 = radarSeen[b.type], cur0 = gaKhu(P);
      if ((hc0 && !hc0.dead && hc0.khu !== cur0) || (hr0 && hr0.map === b.map && hr0.khu !== cur0)) {
        if (st.travel) stopTravel();
        h.searching = true; h.phase = 'wait'; h.lookAt = 0;
      }
    }
    var lairSweep = !!(h.lair && h.lair.active && h.lair.key === b.map + '#' + gaKhu(P)); // đang dò quanh ổ: không kéo về chỗ hồi sinh
    if (g.mapId !== b.map || (!h.khuWant && !h.searching && !lairSweep && dist(me.x, me.y, h.pos.x, h.pos.y) > BH_NEAR)) {
      if (!st.travel || st.travel.map !== b.map) {
        if (++h.fails > 6) { bhFinish(g, 'Không đi được tới ' + mapName(b.map) + ' (có thể chưa đủ cảnh giới) → bỏ ' + bhName(P, b) + ' 30 phút', BH_FAIL_SKIP_MS); return false; }
        startTravel(b.map, h.pos.x, h.pos.y, 'Đi đánh ' + bhName(P, b) + ' ở ' + mapName(b.map));
      }
      tickTravel(g);
      h.phase = 'go';
      return true;
    }
    if (st.travel && !h.khuWant) stopTravel();
    if (h.phase === 'go') { h.phase = 'wait'; h.lookAt = now(); bhLog('Tới chỗ ' + bhName(P, b) + (boss ? ' → đánh' : ' → chờ boss ra, đánh hộ vệ')); }
    // Đang đổi khu tìm boss.
    if (h.khuWant) {
      if (khuGo(g, h, '[Boss]')) return true;
      h.lookAt = now();
      h.step = 'xem khu ' + gaKhu(P);
      return true;
    }
    // Lịch báo boss đang có mặt mà khu này không thấy: sang khu khác tìm (khu radar thấy lần cuối trước).
    if (!boss && h.phase === 'wait' && bhShouldBeUp(b)) {
      var so = gaSoKhu(P), name = bhName(P, b);
      if (so <= 1) {
        if (now() - h.lookAt > BH_NOKHU_MS) { bhFinish(g, 'Lịch báo ' + name + ' đang có mà ' + BH_NOKHU_MS / 1000 + 's không thấy → về', BH_SKIP_MS); return false; }
        return false;
      }
      // Chat / radar chỉ khu khác thì đi luôn, khỏi đứng nhìn khu này.
      var hc = bossHint(b.type), hr = radarSeen[b.type];
      var hinted = (hc && !hc.dead && hc.khu !== gaKhu(P) && !h.khuSeen[hc.khu]) || (hr && hr.map === b.map && hr.khu !== gaKhu(P) && !h.khuSeen[hr.khu]);
      if (!hinted && now() - h.lookAt < BH_LOOK_MS) { h.step = 'xem khu ' + gaKhu(P); return h.searching; }
      // Boss có thể bị người khác kéo khỏi ổ (tối đa tầm dây xích của nó): dò quanh ổ trước khi kết luận khu này không có.
      if (!hinted) {
        var lk = b.map + '#' + gaKhu(P), D0 = P.ENEMY_DEFS || {}, lr = ((D0[b.type] && D0[b.type].leashRange) || 400) + 200;
        if (!h.lair || h.lair.key !== lk) h.lair = { key: lk, pts: sweepPlan(g, [h.pos], { x: h.pos.x, y: h.pos.y, r: lr }, true) };
        h.lair.active = sweepStep(g, h, h.lair.pts);
        if (h.lair.active) { setAuto(g, false); h.step = 'dò quanh ổ ' + name + ' · khu ' + gaKhu(P) + ' (còn ' + h.lair.pts.length + ' chỗ)'; return true; }
      }
      h.khuSeen[gaKhu(P)] = true;
      var next = bhNextKhu(g, h);
      if (!next) { bhFinish(g, 'Tìm ' + Object.keys(h.khuSeen).length + ' khu không thấy ' + name + ' (có thể vừa bị hạ) → về', BH_SKIP_MS); return false; }
      h.khuSeen[next] = true;
      h.khuWant = next; h.khuAt = 0; h.touches = 0; h.touchAt = 0; h.searching = true;
      h.step = 'tìm boss · sang khu ' + next;
      var r0 = radarSeen[b.type], c0 = bossHint(b.type);
      bhLog('Khu ' + gaKhu(P) + ' không có ' + name + ' → sang khu ' + next +
        (c0 && !c0.dead && c0.khu === next ? ' (chat báo ở đây)' : r0 && r0.khu === next ? ' (radar thấy ở đây lần trước)' : ''));
      return khuGo(g, h, '[Boss]') || true;
    }
    return false; // tới nơi: để auto / hit & run / nhắm boss lo đánh
  }

  /* ================= Radar quái biến dị (Thiên Đạo báo trên kênh Thế Giới) ================= */
  // Quái biến dị (Thiên Đạo báo map, không kèm khu): tới map, dò từng khu ở Bảng Khu tìm con mang cờ bienDi rồi đánh.
  var BD_EVENT_MS = 15 * 60000, BD_LOOK_MS = 2500, BD_MAX_MS = 12 * 60000;
  var bdEvents = [];           // {type, map, at, done}
  function bdLog(msg) { klog('[Biến dị] ' + msg); say('Biến dị: ' + msg); }
  function bdName(P, type) { var D = P.ENEMY_DEFS || {}; return String(D[type] && D[type].name || type).split('·')[0].trim() + ' biến dị'; }
  function bdTypeByName(P, txt) {
    var D = P.ENEMY_DEFS || {}, t = plainVi(txt);
    if (/thach\s*qu[y|i]/i.test(t)) return 'thach_quy';
    if (/xuyen\s*son/i.test(t)) return 'xuyen_son_giap';
    if (/nhen/i.test(t)) return 'nhen_bach_ngoc';
    return Object.keys(D).filter(function (k) {
      if (!D[k] || !D[k].bienDi) return false;
      var rawName = plainVi(String(D[k].name || k).split('·')[0].trim());
      var words = rawName.split(/\s+/);
      var shortName = words.slice(0, 2).join(' ');
      return t.indexOf(rawName) >= 0 || rawName.indexOf(t) >= 0 || (shortName && t.indexOf(shortName) >= 0);
    })[0] || null;
  }
  var MAP_ALIASES = {
    bai_da: 'bai_da_hang_gio',
    'bai da': 'bai_da_hang_gio',
    'bai da hang gio': 'bai_da_hang_gio',
    thung_lung: 'thach_phong_thung_lung',
    'thung lung': 'thach_phong_thung_lung',
    thach_phong_thung_lung: 'thach_phong_thung_lung',
    'thach phong thung lung': 'thach_phong_thung_lung',
    thach_tran: 'thach_tran',
    'thach tran': 'thach_tran',
    mo_linh_thach: 'mo_linh_thach',
    'mo linh thach': 'mo_linh_thach',
    tan_vien: 'tan_vien',
    'tan vien': 'tan_vien',
    'chan nui tan vien': 'tan_vien',
    thao_duoc_coc: 'thao_duoc_coc',
    'thao duoc coc': 'thao_duoc_coc',
    long_uyen: 'long_uyen',
    'long uyen': 'long_uyen',
    'long uyen coc': 'long_uyen',
    dam_lay: 'dam_lay_boss',
    'dam lay': 'dam_lay_boss',
    'dam lay u am': 'dam_lay_boss'
  };
  function mapByName(P, txt) {
    if (typeof P === 'string' && txt === undefined) { txt = P; P = null; }
    P = P || (typeof window !== 'undefined' && (window.PNTT || (typeof unsafeWindow !== 'undefined' && unsafeWindow.PNTT)));
    var t = plainVi(txt).replace(/[!.\s]+$/, '').trim();
    if (MAP_ALIASES[t]) return MAP_ALIASES[t];
    var gph = mapGraph(P), ids = Object.keys(gph);
    return ids.filter(function (id) { return plainVi(gph[id].name) === t; })[0] ||
      ids.filter(function (id) { var n = plainVi(gph[id].name); return n && (t.indexOf(n) >= 0 || n.indexOf(t) >= 0); })[0] || null;
  }
  // Tin của Thiên Đạo: con biến dị xuất hiện / bị hạ, Thương Đội, yêu thú xổng chuồng… Tin có "– khu N" thì đi thẳng
  // khu đó, khỏi dò. Mọi tin đều được ghi vào Nhật ký Thiên Đạo (lưu lại giữa các lần tải trang).
  var NEWS_KHU = /^(.+?)(?:\s*[-–—,]\s*|\s+)khu\s*(\d+)\s*$/i;
  function newsPlace(P, txt) {
    var m = NEWS_KHU.exec(String(txt).replace(/[!.\s]+$/, '').trim());
    return { map: mapByName(P, m ? m[1] : txt), khu: m ? +m[2] : 0 };
  }
  var _lastNewsText = '', _lastNewsAt = 0;
  function readServerNews(text) {
    var raw = String(text || '').trim();
    if (!raw || (raw === _lastNewsText && now() - _lastNewsAt < 2500)) return;
    _lastNewsText = raw;
    _lastNewsAt = now();
    var info = { kind: 'khac' };
    try { readNews(raw, info); } finally { tdnAdd(raw, info); }
  }
  function readNews(text, info) {
    var P = window.PNTT;
    if (!P) return;
    var t = plainVi(text);
    // Chuẩn hoá gỡ tiền tố thông báo nếu có ("Thiên Đạo:", "[Thiên Đạo]", "[Hệ thống]:", "Thông báo:", "[Kênh Thế Giới]")
    while (/^(?:\[?(?:thien dao|he thong|thong bao|kenh the gioi|the gioi)\]?|\(thien dao\)|\(he thong\))[\s:–-]*/i.test(t)) {
      t = t.replace(/^(?:\[?(?:thien dao|he thong|thong bao|kenh the gioi|the gioi)\]?|\(thien dao\)|\(he thong\))[\s:–-]*/i, '').trim();
    }
    var m;
    if (/trung tham/.test(t)) info.kind = 'loot';
    else if (Object.keys(BOSS_KEYS).some(function (k) { return BOSS_KEYS[k].test(t); })) info.kind = 'boss';

    var delayM_bd = /(?:trong|sau|\()?(\d+)\s*giay(?:\s*nua)?\)?/i.exec(t);
    var spawnDelay_bd = delayM_bd ? +delayM_bd[1] : (/sap\s+(?:xuat\s+hien|giang\s+the)/i.test(t) ? 20 : 0);
    var cleanT_bd = t.replace(/\s*\((?:\d+\s*giay(?:\s*nua)?|\d+s)\)/ig, '').replace(/[!.]+$/, '').trim();

    if ((m = /(?:mot con\s+)?(.+?)\s+(?:vua|sap|da)?\s*(?:xuat\s+hien|giang\s+the)\s+(?:tai|o)\s+(.+?)$/i.exec(cleanT_bd)) && /bien di/.test(m[1])) {
      var type = bdTypeByName(P, m[1]), pl = newsPlace(P, m[2]), map = pl.map;
      if (type && map) {
        var spawnAt = spawnDelay_bd ? now() + spawnDelay_bd * 1000 : 0;
        info.kind = 'bd'; info.map = map; info.khu = pl.khu; info.what = bdName(P, type); info.spawnAt = spawnAt;
        var isDupBd = bdEvents.some(function (e) {
          return e.type === type && e.map === map && (!pl.khu || !e.khu || e.khu === pl.khu) && (now() - e.at < 30000);
        });
        if (!isDupBd) {
          bdEvents.push({ type: type, map: map, khu: pl.khu, at: now(), spawnAt: spawnAt, done: false });
          if (bdEvents.length > 20) bdEvents.shift();
          klog('[Biến dị] Thiên Đạo: ' + bdName(P, type) + (spawnDelay_bd ? ' sắp xuất hiện (' + spawnDelay_bd + 's nữa)' : ' vừa xuất hiện') + ' ở ' + mapName(map) + (pl.khu ? ' khu ' + pl.khu : ''));
          if (tgReady() && cfg.tgEv_bd !== false) {
            var gNow = game(), who = gNow ? myName(gNow) : 'Nhân vật';
            var actMsg = (st.bd ? ' → đang tới đón đầu' : (cfg.bdHunt ? ' → đang xuất phát' : ' (chưa bật tự săn)'));
            tgSend('👾 [Thiên Đạo] ' + bdName(P, type) + (spawnDelay_bd ? ' sắp xuất hiện (' + spawnDelay_bd + 's nữa)' : ' vừa xuất hiện') + ' ở ' + mapName(map) + (pl.khu ? ' (Khu ' + pl.khu + ')' : '') + '\n👤 ' + who + actMsg);
          }
        }
      }
    } else if (tdParse(P, t)) {
      var tp0 = tdParse(P, t), tmap = tp0.map;
      info.kind = 'td'; info.map = tmap; info.khu = tp0.khu;
      var isDupTd = tdEvents.some(function (e) { return tdSame(e, tmap, tp0.khu) && now() - e.at < 60000; });
      tdEvents.push({ map: tmap, khu: tp0.khu, at: now(), done: false });
      if (tdEvents.length > 20) tdEvents.shift();
      klog('[Thương Đội] Thiên Đạo: Thương Đội đi qua ' + mapName(tmap) + (tp0.khu ? ' khu ' + tp0.khu : '') + ' (Tiêu Sư / Thương Nhân → Oán Hồn · Kiếp Tặc → Hiệp Nghĩa Lệnh)');
      if (!isDupTd && tgReady() && cfg.tgEv_td !== false) {
        var gNow = game(), who = gNow ? myName(gNow) : 'Nhân vật';
        var actMsg = (st.td ? ' → đang xuất phát săn' : (cfg.tdHunt ? (tdWant(P) ? ' → đang chuẩn bị đi' : ' → chưa cần Oán Hồn (bỏ qua)') : ' (chưa bật tự săn)'));
        tgSend('🐫 [Thiên Đạo] Thương Đội vừa lên đường qua ' + mapName(tmap) + (tp0.khu ? ' (Khu ' + tp0.khu + ')' : '') + '\n👤 ' + who + actMsg);
      }
    } else if ((m = /^(.+?)\s+(?:vua|sap|da)?\s*(?:xong chuong|xuat hien|giang the|tu tap)\s+(?:tai|o)\s+(.+?),?\s*khu\s+(\d+)/.exec(t))) {
      var delayM = /\((\d+)\s*giay\s*nua\)/.exec(t);
      var spawnDelay = delayM ? +delayM[1] : 0;
      var spawnAt = spawnDelay ? now() + spawnDelay * 1000 : 0;
      var xcMap = mapByName(P, m[2]);
      info.kind = 'xc'; info.khu = +m[3]; info.map = xcMap; info.what = m[1];
      xcNews(P, m[1], m[2], +m[3], spawnAt);
      if (tgReady() && cfg.tgEv_xc !== false) {
        var gNow = game(), who = gNow ? myName(gNow) : 'Nhân vật';
        var actMsg = (st.xc ? ' → đang tới săn' : (cfg.xcHunt ? ' → đang xuất phát' : ' (chưa bật tự săn)'));
        var xcMobNames = (m[1] || '').split(/\s+va\s+/i).map(function (s) {
          return s.trim().replace(/(^|\s)\S/g, function (l) { return l.toUpperCase(); });
        }).join(' và ');
        tgSend('🐂 [Thiên Đạo] ' + (xcMobNames || m[1]) + (spawnDelay ? ' sắp' : '') + ' xổng chuồng tại ' + (xcMap ? mapName(xcMap) : m[2]) + ' (Khu ' + m[3] + ')' + (delayM ? ' (' + delayM[1] + 's nữa)' : '') + '\n👤 ' + who + actMsg);
      }
    } else if (tdDoneText(t)) {
      info.kind = 'td_xong'; info.map = mapByName(P, t); info.khu = newsKhu(t);
      tdMarkDone(P, t);
      if (tgReady() && cfg.tgEv_td !== false) {
        var mapK = mapByName(P, t), kK = newsKhu(t);
        var doneKey = (mapK || '') + '_' + (kK || 0);
        if (!st.tdDoneTg || st.tdDoneTg !== doneKey || now() - (st.tdDoneTgAt || 0) > 60000) {
          st.tdDoneTg = doneKey; st.tdDoneTgAt = now();
          tgSend('🐫 [Thiên Đạo] Thương Đội tại ' + (mapK ? mapName(mapK) : 'bản đồ') + (kK ? ' (Khu ' + kK + ')' : '') + ' đã kết thúc (bị hạ / cướp / tới nơi).');
        }
      }
    } else if ((m = /^(.+?)\s+da\s+ha\s+(.+?)!/.exec(t))) {
      var tp = bdTypeByName(P, m[2]);
      if (!tp || !/bien di/.test(m[2])) return;
      info.kind = 'bd_ha'; info.what = bdName(P, tp);
      var ev = bdEvents.filter(function (e) { return !e.done && e.type === tp; })[0];
      if (ev) { ev.done = true; info.map = ev.map; }
      klog('[Biến dị] Thiên Đạo: ' + m[1] + ' đã hạ ' + bdName(P, tp));
    } else if (/(?:tim (?:thay|duoc)|da mo|phat hien)\s+cua|cua\s+(?:da\s+)?mo|thong!|loi .*thong/i.test(t)) {
      info.kind = 'vn_cua';
      if (st.vn) {
        st.vn.doorFound = true;
        st.vn.doorFoundAt = now();
        var CONG_MAP = { kim: 0, moc: 1, thuy: 2, hoa: 3, tho: 4 };
        for (var cn in CONG_MAP) {
          if (t.indexOf(cn) >= 0) {
            st.vn.doorLane = CONG_MAP[cn];
            st.vn.lane = CONG_MAP[cn];
            break;
          }
        }
        klog('[Vết Nứt] Nhận tin: ' + text + ' → bỏ qua toàn bộ quái trên đường, chạy tới cửa');
        say('Vết Nứt: tìm được cửa → bỏ quái, chạy tới cửa');
      }
    }
  }
  function newsKhu(t) { var m = /khu\s*(\d+)/.exec(t); return m ? +m[1] : 0; }
  // Tên map nằm trong câu (lấy tên dài nhất khớp: "Thạch Phong Thung Lũng" thắng "Thung Lũng").
  function mapInText(P, t) {
    var gph = mapGraph(P), best = null, bl = 0;
    Object.keys(gph).forEach(function (id) { var n = plainVi(gph[id].name || ''); if (n.length > bl && t.indexOf(n) >= 0) { best = id; bl = n.length; } });
    return best;
  }
  // Tin Thương Đội: mẫu chuẩn "… lên đường qua <map> – khu N"; câu viết khác ("tại <map> (khu N)", "khu N của <map>", …
  function tdParse(P, t) {
    if (tdDoneText(t)) return null;
    var m = TD_NEWS_RE.exec(t), pl = m ? newsPlace(P, m[1]) : null;
    if (!pl || !pl.map) {
      if (!/thuong doi/.test(t) || !/len duong|xuat phat|di qua|dang qua|xuat hien|hien ra|ghe qua|tien vao|di ngang|sap/.test(t)) return null;
      var mp = mapInText(P, t);
      if (!mp) return null;
      pl = { map: mp, khu: 0 };
    }
    if (!pl.khu) pl.khu = newsKhu(t);
    return pl;
  }

  /* ================= Nhật ký Thiên Đạo ================= */
  // Ghi mọi tin Thiên Đạo (giờ, nội dung, loại, map, khu) vào localStorage để sau này xem quy luật: map / khu / giờ
  // Thương Đội, biến dị, yêu thú xổng chuồng hay ra. Tab Boss & sự kiện có bảng tổng hợp và nút sao chép.
  var TDN_KEY = 'ttbot.thiendao.v1', TDN_MAX = 500, TDN_DUP_MS = 60000;
  var TDN_KIND = { td: 'Thương Đội', td_xong: 'Thương Đội xong', bd: 'Biến dị', bd_ha: 'Biến dị bị hạ', xc: 'Xổng chuồng', boss: 'Boss', loot: 'Trúng thăm', khac: 'Khác' };
  var tdNews = (function () { try { var a = JSON.parse(localStorage.getItem(TDN_KEY) || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; } })();
  function tdnAdd(text, info) {
    var tx = String(text || '').replace(/\s+/g, ' ').trim(), ts = Date.now();
    if (!tx || tdNews.some(function (r) { return r.text === tx && ts - r.ts < TDN_DUP_MS; })) return null;
    var r = { ts: ts, text: tx.slice(0, 240), kind: info && info.kind || 'khac' };
    if (info && info.map) r.map = info.map;
    if (info && info.khu) r.khu = info.khu;
    if (info && info.what) r.what = String(info.what).slice(0, 60);
    tdNews.push(r);
    if (tdNews.length > TDN_MAX) tdNews.splice(0, tdNews.length - TDN_MAX);
    try { localStorage.setItem(TDN_KEY, JSON.stringify(tdNews)); } catch (e) { }
    return r;
  }
  // Tổng hợp theo loại: số lần, map hay ra (kèm khu), giờ hay ra (giờ VN của máy).
  function tdnStats(kind) {
    var rows = tdNews.filter(function (r) { return r.kind === kind; }), maps = {}, hours = {};
    rows.forEach(function (r) {
      if (r.map) { var x = maps[r.map] || (maps[r.map] = { n: 0, khu: {} }); x.n++; if (r.khu) x.khu[r.khu] = (x.khu[r.khu] || 0) + 1; }
      var h = new Date(r.ts).getHours();
      hours[h] = (hours[h] || 0) + 1;
    });
    return { n: rows.length, maps: maps, hours: hours, last: rows[rows.length - 1] || null };
  }
  function bdPending() { return bdEvents.filter(function (e) { return !e.done && now() - e.at < BD_EVENT_MS; }); }
  function bdVisible(g, type) {
    return (g.sw.enemies || []).filter(function (m) { return m && !m.dead && m.bienDi && (!type || m.type === type); });
  }
  function bdFinish(g, msg) {
    var d = st.bd;
    st.bd = null;
    bdLog(msg);
    if (st.farmTarget && st.farmTarget.bienDi) releaseTarget(g);
    if (d && d.back && (g.mapId !== d.back.map || dist(g.me.x, g.me.y, d.back.x, d.back.y) > BACK_NEAR || (d.back.khu && gaKhu(g.P) !== d.back.khu))) goBack(d.back.map, d.back.x, d.back.y, 'Xong quái biến dị → về chỗ farm', 'bd', d.back.khu);
    return false;
  }
  function tickBienDi(g) {
    var P = g.P, me = g.me;
    if (!cfg.bdHunt || me.downed) { if (st.bd) st.bd = null; return false; }
    if (!st.bd && (vtActive(g) || st.vt)) return false;
    if (st.bh) return false; // boss thế giới ưu tiên trước
    if (!st.bd) {
      var ev = bdPending()[0], here = bdVisible(g)[0];
      if (!ev && !here) return false;
      var back = st.back ? takeBack(g) : st.travel ? { map: st.travel.map, x: st.travel.x, y: st.travel.y, khu: st.travel.khu || gaKhu(g.P) } : takeBack(g);
      st.bd = {
        ev: here ? null : ev, type: here ? here.type : ev.type, map: here ? g.mapId : ev.map, back: back, at: now(), khuSeen: {},
        lookAt: 0, khuWant: 0, khuAt: 0, touches: 0, touchAt: 0, routeAt: 0, travels: 0, target: null, seen: false, step: ''
      };
      bdLog(here ? 'Thấy ' + bdName(P, here.type) + ' ngay đây → đánh' : 'Đi ' + mapName(ev.map) + ' tìm ' + bdName(P, ev.type));
    }
    var d = st.bd, name = bdName(P, d.type);
    if (now() - d.at > BD_MAX_MS) return bdFinish(g, 'Quá ' + BD_MAX_MS / 60000 + ' phút chưa xong ' + name + ' → về');
    if (d.ev && d.ev.done && !d.target) return bdFinish(g, 'Thiên Đạo báo đã có người hạ ' + name + ' → về');
    var t = d.target && !d.target.dead && d.target.bienDi && (g.sw.enemies || []).indexOf(d.target) >= 0 ? d.target : bdVisible(g, d.type)[0];
    if (t) {
      if (d.target !== t) bdLog('Thấy ' + name + ' ở khu ' + gaKhu(P) + ' → đánh');
      d.target = t; d.seen = true; d.khuWant = 0;
      d.step = 'đánh ' + name + ' · ' + num(t.hp) + '/' + num(t.hpMax) + ' · khu ' + gaKhu(P);
      if (st.travel) stopTravel();
      var T = P.Targeting, key = 'foe:' + t.id;
      if (T && T.list && T.list.some(function (e) { return e.key === key; })) { T.key = key; T.manual = true; }
      st.farmTarget = t;
      setAuto(g, true);
      var reach = (P.Player.reach ? P.Player.reach() : 26) + (t.def && t.def.bodyRadius || 0) - 2;
      var hpPct = t.hpMax > 0 ? (t.hp / t.hpMax) : 1;
      // Khi quái biến dị sắp gục (<= 8% máu): áp sát tâm rơi px = 0 (<= 2px) để nhặt ngay Yêu Đan / Mảnh Bia
      if (hpPct <= 0.08) {
        if (dist(me.x, me.y, t.x, t.y) > 2 && !(me.path && me.path.length && now() - d.routeAt < 400)) {
          var rClose = spotCheck(g).route(t.x, t.y);
          if (rClose) { moveFighting(g, rClose.path); d.routeAt = now(); }
        }
      } else if (dist(me.x, me.y, t.x, t.y) > Math.max(reach, 140)) {
        if (!(me.path && me.path.length && now() - d.routeAt < 600)) {
          var r = spotCheck(g).route(t.x, t.y);
          if (r) { moveFighting(g, r.path); d.routeAt = now(); }
        }
        return true;
      }
      if (!g.sw.approach) g.sw.approach = { key: key, until: P.Game.time + 2 };
      return false; // trong tầm: để auto / hit & run / né chiêu đánh như quái thường
    }
    if (d.seen) {
      if (lootBeforeLeave(g)) { d.step = 'nhặt Yêu Đan / đồ rơi của ' + name; return true; }
      if (d.ev) d.ev.done = true;
      return bdFinish(g, 'Đã hạ ' + name + ' → về chỗ farm');
    }
    if (g.mapId !== d.map) {
      d.khuWant = 0;
      d.step = 'đi tới ' + mapName(d.map);
      if (!st.travel || st.travel.map !== d.map) {
        if (++d.travels > 6) return bdFinish(g, 'Không đi được tới ' + mapName(d.map));
        startTravel(d.map, null, null, 'Đi ' + mapName(d.map) + ' tìm ' + name);
      }
      tickTravel(g);
      return true;
    }
    if (st.travel && st.travel.map === d.map && !d.khuWant) stopTravel();
    // Thiên Đạo báo kèm khu: chỉ xem đúng khu đó (khỏi dò các khu khác).
    if (d.ev && d.ev.khu && !d.khuDirect) {
      d.khuDirect = true;
      for (var kk = 1; kk <= gaSoKhu(P); kk++) d.khuSeen[kk] = true;
      if (gaKhu(P) !== d.ev.khu) { d.khuWant = d.ev.khu; d.khuAt = 0; d.touches = 0; d.touchAt = 0; bdLog('Thiên Đạo báo khu ' + d.ev.khu + ' → sang thẳng khu đó'); }
    }
    if (d.khuWant) {
      if (khuGo(g, d, '[Biến dị]')) return true;
      d.lookAt = now();
      return true;
    }
    if (!d.lookAt) d.lookAt = now();
    var khu = gaKhu(P), so = gaSoKhu(P);
    if (d.ev && d.ev.spawnAt && now() < d.ev.spawnAt) {
      var remainSec = Math.ceil((d.ev.spawnAt - now()) / 1000);
      d.step = 'chờ ' + name + ' xuất hiện (' + remainSec + 's) · khu ' + khu;
      return true;
    }
    if (now() - d.lookAt < BD_LOOK_MS) { d.step = 'tìm ' + name + ' · xem khu ' + khu; return true; }
    if (scanKhu(g, d, function (def, e) { return e.type === d.type; })) { setAuto(g, false); d.step = 'tìm ' + name + ' khắp khu ' + khu + ' (còn ' + d.scan.pts.length + ' chỗ)'; return true; }
    d.khuSeen[khu] = true;
    var next = 0;
    for (var i = 1; i < so && !next; i++) { var k = ((khu - 1 + i) % so) + 1; if (!d.khuSeen[k]) next = k; }
    if (!next) {
      if (d.ev) d.ev.done = true;
      return bdFinish(g, 'Dò ' + Object.keys(d.khuSeen).length + ' khu ở ' + mapName(d.map) + ' không thấy ' + name + ' (có thể đã bị hạ) → về');
    }
    d.khuSeen[next] = true;
    d.khuWant = next; d.khuAt = 0; d.touches = 0; d.touchAt = 0;
    d.step = 'tìm ' + name + ' · sang khu ' + next;
    klog('[Biến dị] Khu ' + khu + ' không có ' + name + ' → sang khu ' + next);
    return khuGo(g, d, '[Biến dị]') || true;
  }

  /* ================= Yêu thú xổng chuồng (Thiên Đạo báo map + khu) ================= */
  // "Ba Xích Nhãn Ngưu và ba Bạch Hổ Tuyết vừa xổng chuồng tại Thảo Dược Cốc, khu 6!": yêu thú thả ra (napQuai của …
  var XC_EVENT_MS = 20 * 60000, XC_MAX_MS = 15 * 60000, XC_LOOT_MS = 3000;
  var xcEvents = [];
  function xcLog(m) { klog('[Xổng chuồng] ' + m); say('Xổng chuồng: ' + m); }
  function xcMapDef(P, mapId) {
    var MD = P.MapData || {}, out = null;
    Object.keys(MD).some(function (k) { var m = MD[k]; if (m && typeof m === 'object' && m.id === mapId) { out = m; return true; } return false; });
    return out;
  }
  function xcNews(P, what, mapTxt, khu, spawnAt) {
    var map = mapByName(P, mapTxt);
    if (!map) return;
    var D = P.ENEMY_DEFS || {}, whatP = plainVi(what);
    var types = Object.keys(D).filter(function (k) {
      var n = D[k] && D[k].name || k;
      var p = plainVi(String(n).split('·')[0].trim());
      return p.length >= 3 && whatP.indexOf(p) >= 0;
    });
    if (!types.length) {
      var md = xcMapDef(P, map);
      if (md && md.napQuai) types = md.napQuai.slice();
    }
    if (!types.length) return;
    var names = types.map(function (k) { return String(D[k] && D[k].name || k).split('·')[0].trim(); }).join(', ');
    xcEvents.push({ map: map, khu: khu, types: types, what: names, at: now(), spawnAt: spawnAt || 0, done: false });
    if (xcEvents.length > 20) xcEvents.shift();
    klog('[Xổng chuồng] Thiên Đạo: ' + names + (spawnAt ? ' sắp xổng chuồng' : ' xổng chuồng') + ' ở ' + mapName(map) + ' khu ' + khu);
  }
  function xcPending() { return xcEvents.filter(function (e) { return !e.done && now() - e.at < XC_EVENT_MS; }); }
  function xcVisible(g, types) {
    return mobsAlive(g).filter(function (m) { return types.indexOf(m.type) >= 0 && m.state !== 'return'; });
  }
  function xcFinish(g, msg) {
    var d = st.xc;
    st.xc = null;
    st.pin = null;
    xcLog(msg);
    if (d && d.back && (g.mapId !== d.back.map || dist(g.me.x, g.me.y, d.back.x, d.back.y) > BACK_NEAR || (d.back.khu && gaKhu(g.P) !== d.back.khu))) goBack(d.back.map, d.back.x, d.back.y, 'Xong yêu thú xổng chuồng → về chỗ farm', 'xc', d.back.khu);
    return false;
  }
  // Chọn mục tiêu Xổng chuồng thông minh: cướp Last-Hit nếu có boss khác sắp gục (máu <= 28% hoặc <= 15000 HP)
  function pickXcTarget(g, d, list) {
    if (!list || !list.length) return null;
    var me = g.me;
    var cur = d && d.target && !d.target.dead && list.indexOf(d.target) >= 0 ? d.target : null;
    var curPct = cur && cur.hpMax > 0 ? (cur.hp / cur.hpMax) : 1;
    var curDying = cur && (curPct <= 0.28 || (cur.hp != null && cur.hp <= 15000));

    // Quét cướp Last-Hit tự động
    if (cfg.lastHitScan !== false) {
      var dyingMobs = [];
      list.forEach(function (m) {
        if (m.state === 'return') return;
        var distM = dist(me.x, me.y, m.x, m.y);
        if (distM > 650) return;
        var pct = m.hpMax > 0 ? (m.hp / m.hpMax) : 1;
        var dying = pct <= 0.28 || (m.hp != null && m.hp <= 15000);
        if (dying) dyingMobs.push({ m: m, pct: pct, dist: distM, score: pct * 1000 + distM });
      });

      if (dyingMobs.length) {
        dyingMobs.sort(function (a, b) { return a.score - b.score; });
        var bestDying = dyingMobs[0].m;
        // Nếu mục tiêu hiện tại đã hấp hối: giữ nguyên để dứt điểm trừ khi con kia máu tụt còn dưới một nửa con hiện tại
        if (cur && curDying) {
          var bestPct = dyingMobs[0].pct;
          if (cur === bestDying || bestPct >= curPct * 0.5) return cur;
          return bestDying;
        }
        // Mục tiêu hiện tại chưa hấp hối, có con khác đang hấp hối: LẬP TỨC CƯỚP MỤC TIÊU!
        return bestDying;
      }
    }

    if (cur) return cur;

    // Ưu tiên con ít máu hơn và gần hơn thay vì chỉ lấy con gần nhất
    var candidates = list.map(function (m) {
      var pct = m.hpMax > 0 ? (m.hp / m.hpMax) : 1;
      var dM = dist(me.x, me.y, m.x, m.y);
      return { m: m, score: (pct * 100) + (dM / 20) };
    });
    candidates.sort(function (a, b) { return a.score - b.score; });
    return candidates[0] ? candidates[0].m : null;
  }
  function tickXongChuong(g) {
    var P = g.P, me = g.me;
    if (!cfg.xcHunt || me.downed) { if (st.xc && !cfg.xcHunt) st.xc = null; return false; }
    if (st.bh || st.bd) return false;
    if (!st.xc) {
      if (vtActive(g) || st.vt || (st.td && st.td.seen)) return false;
      var ev = xcPending()[0];
      if (!ev) return false;
      var back = st.td ? st.td.back : st.back ? takeBack(g) : st.travel ? { map: st.travel.map, x: st.travel.x, y: st.travel.y, khu: st.travel.khu || gaKhu(g.P) } : takeBack(g);
      st.td = null;
      st.xc = {
        ev: ev, back: back, at: now(), khuWant: 0, khuAt: 0, touches: 0, touchAt: 0, routeAt: 0, travels: 0, pts: null, kills: 0,
        target: null, lastSeen: 0, step: ''
      };
      xcLog('Đi ' + mapName(ev.map) + ' khu ' + ev.khu + ' săn ' + ev.what);
    }
    var d = st.xc, e = d.ev, name = mapName(e.map) + ' khu ' + e.khu;
    if (now() - d.at > XC_MAX_MS) { e.done = true; return xcFinish(g, 'Quá ' + XC_MAX_MS / 60000 + ' phút ở ' + name + ' → về'); }
    if (g.mapId !== e.map) {
      d.khuWant = 0; d.step = 'đi tới ' + mapName(e.map);
      if (!st.travel || st.travel.map !== e.map) {
        if (++d.travels > 6) { e.done = true; return xcFinish(g, 'Không đi được tới ' + mapName(e.map)); }
        startTravel(e.map, null, null, 'Xổng chuồng: đi ' + name);
      }
      tickTravel(g);
      return true;
    }
    if (st.travel && st.travel.map === e.map) stopTravel();
    if (gaKhu(P) !== e.khu && (gaSoKhu(P) >= e.khu || !gaSoKhu(P) || gaSoKhu(P) <= 1)) {
      if (!d.khuWant) { d.khuWant = e.khu; d.khuAt = 0; d.touches = 0; d.touchAt = 0; }
      d.step = 'đổi sang khu ' + e.khu;
      if (khuGo(g, d, '[Xổng chuồng]')) return true;
      if (gaKhu(P) !== e.khu) { e.done = true; return xcFinish(g, 'Không đổi sang được khu ' + e.khu + ' → về'); }
    }
    d.khuWant = 0;
    // Yêu thú xổng chuồng rơi đồ: gom toàn bộ đồ rơi (Yêu Đan, Nanh Hổ, Ngưu Sừng, Linh Thạch, phù chú, trang bị...)
    // trong phạm vi 800px quanh mình hoặc trên map -> chủ động áp sát nhặt ngay trước khi chuyển sang săn con khác.
    var dl = dropsLeft(g);
    var nearDrops = dl.filter(function (r) {
      if (!r || !r.itemId) return false;
      return dist(g.me.x, g.me.y, r.x, r.y) <= 800;
    });
    if (nearDrops.length > 0 && tickLoot(g, true)) {
      d.lastSeen = now();
      d.step = 'tiến tới nhặt đồ rơi xổng chuồng (' + nearDrops.length + ' món)';
      return true;
    }
    var list = xcVisible(g, e.types);
    if (d.target && d.target.dead) { d.kills++; d.target = null; }
    var t = pickXcTarget(g, d, list);
    if (t) {
      if (d.target !== t) {
        var prev = d.target;
        d.target = t;
        var tPct = t.hpMax > 0 ? (t.hp / t.hpMax) : 1;
        if (prev && !prev.dead && (tPct <= 0.28 || (t.hp != null && t.hp <= 15000))) {
          xcLog('CƯỚP LAST-HIT: Chuyển mục tiêu sang ' + mobLabel(t) + ' sắp gục (' + evPct(t) + ')');
        } else {
          xcLog('Thấy ' + mobLabel(t) + ' → đánh (giữ chiêu mạnh nhất kết liễu)');
        }
      }
      d.lastSeen = now();
      d.pts = null; // hạ xong con này thì tuần lại cả map
      d.step = 'đánh ' + mobLabel(t) + ' ' + evPct(t) + ' · còn thấy ' + list.length + ' con · ' + name;
      return evEngage(g, d, t);
    }
    if (!list.length && e.spawnAt && now() < e.spawnAt) {
      d.step = 'chờ yêu thú xổng chuồng (' + Math.max(1, Math.round((e.spawnAt - now()) / 1000)) + 's nữa) · ' + name;
      return true;
    }
    // Vừa hạ xong / còn đồ rơi: chủ động tiến tới nhặt sạch đồ rơi trước khi tuần tiếp map
    if ((d.lastSeen > 0 && now() - d.lastSeen < XC_LOOT_MS) || nearDrops.length > 0 || dl.length > 0) {
      if (tickLoot(g, true)) {
        d.lastSeen = now();
        d.step = 'tiến tới nhặt đồ rơi xổng chuồng';
        return true;
      }
      if (d.lastSeen > 0 && now() - d.lastSeen < XC_LOOT_MS) {
        d.step = 'chờ nhặt đồ xổng chuồng';
        return true;
      }
    }
    if (!d.pts) d.pts = sweepPlan(g, spawnPts(P, e.map, function (def, en) { return e.types.indexOf(en.type) >= 0; }), null, true);
    if (!sweepStep(g, d, d.pts)) {
      // Nếu tuần hết 1 lượt nhưng chưa đủ 60s kể từ lúc xổng chuồng: tuần tiếp lượt nữa tránh quái spawn trễ / chạy lăng xăng
      var timeSinceSpawn = e.spawnAt ? (now() - e.spawnAt) : (now() - d.at);
      if (timeSinceSpawn < 60000) {
        d.pts = sweepPlan(g, spawnPts(P, e.map, function (def, en) { return e.types.indexOf(en.type) >= 0; }), null, true);
        if (sweepStep(g, d, d.pts)) {
          setAuto(g, false);
          d.step = 'dò lại khắp ' + name + ' (còn ' + d.pts.length + ' chỗ)';
          return true;
        }
      }
      if (lootBeforeLeave(g)) { d.step = 'nhặt Yêu Đan / đồ rơi trước khi về'; return true; }
      e.done = true;
      return xcFinish(g, d.kills ? 'Đã hạ ' + d.kills + ' con ở ' + name + ', tuần hết map không còn → về' : 'Tuần hết ' + name + ' không thấy con nào (có thể đã bị hạ) → về');
    }
    setAuto(g, false);
    d.step = 'dò khắp ' + name + ' (còn ' + d.pts.length + ' chỗ)';
    return true;
  }

  /* ================= Hồn Phiên (Ma Đạo): săn hồn, giữ Sát Nghiệp, luyện / gọi Âm Hồn ================= */
  // Hồn Phiên (LuyenQuy): hạ người phàm lấy Phàm / Oán Hồn (+Sát Nghiệp), dừng trước mốc tên đỏ; đủ thì luyện, đánh thì gọi Âm Hồn.
  var HON_KILL_NGHIEP = { pham_hon: 1, oan_hon: 3 };
  var HON_RESUME = 10;          // chạm mốc nghiệp thì chờ giảm chừng này điểm mới săn lại
  var HON_SWITCH_MS = 25000;    // trong khu không còn người phàm cần săn chừng này thì đổi khu
  var HON_LUYEN_GAP_MS = 4000, HON_GOI_GAP_MS = 1500;
  var honMapsCache = null;
  function honLog(msg) { klog('[Hồn] ' + msg); say('Hồn Phiên: ' + msg); }
  function honState(P) {
    var U = P.HonPhienUI, L = P.LuyenQuy;
    if (!L) return null;
    if (U && U.trangThai) return U.trangThai();
    var I = P.Inventory, c = function (id) { return I && I.count ? I.count(id) : 0; };
    return {
      phien: L.coPhien(P) ? 1 : 0, am: c(L.AM_HON), dang: 0, tran: L.tranAmHon(P), pham: c(L.PHAM_HON), oan: c(L.OAN_HON),
      tuSi: c(L.TU_SI_HON), thu3: c(L.THU_HON_3), thu4: c(L.THU_HON_4), thu6: c(L.THU_HON_6), nghiep: L.satNghiep(P), moc: { tenDo: L.moc('ten_do', P) }
    };
  }
  function honHave(s, id) {
    return { pham_hon: s.pham, oan_hon: s.oan, tu_si_hon: s.tuSi, thu_hon_3: s.thu3, thu_hon_4: s.thu4, thu_hon_6: s.thu6 }[id] | 0;
  }
  // Nguyên liệu con Âm Hồn kế tiếp: [{id, ten, can, co}]; null nếu phiên đã đầy.
  function honNext(P, s) {
    var L = P.LuyenQuy, k = (s.am | 0) + (s.dang | 0) + 1;
    if (k > (s.tran || L.tranAmHon(P))) return null;
    return L.congThucCon(k).map(function (x) { return { id: x.id, ten: x.ten, can: x.can, co: honHave(s, x.id) }; });
  }
  // Map nào có những người phàm cho loại hồn nào (đếm điểm sinh trong dữ liệu bản đồ).
  function honMaps(P) {
    if (honMapsCache) return honMapsCache;
    var out = {}, MD = P.MapData || {}, D = P.ENEMY_DEFS || {};
    Object.keys(MD).forEach(function (k) {
      var m = MD[k];
      if (!m || typeof m !== 'object' || typeof m.id !== 'string' || out[m.id] || !Array.isArray(m.enemies)) return;
      var c = {};
      // Chỗ sinh của Thương Đội (thuongDoi) chỉ có người khi đoàn đi qua: không tính.
      m.enemies.forEach(function (e) { var d = e && !e.thuongDoi && D[e.type]; if (d && d.human && HON_KILL_NGHIEP[d.hon]) c[d.hon] = (c[d.hon] || 0) + 1; });
      if (Object.keys(c).length) out[m.id] = c;
    });
    if (Object.keys(out).length) honMapsCache = out;
    return out;
  }
  function honCanHit(P, m) { return !m.dead && m.def && m.def.human && (!P.ChinhDao || !P.ChinhDao.danhDuoc || P.ChinhDao.danhDuoc(m.def)); }

  // Loại hồn cần săn lúc này (theo con kế tiếp) mà chưa chạm mốc nghiệp. Oán Hồn chỉ rơi từ Thương Nhân / …
  function honSellTarget(s, need, id) {
    var extra = cfg.honSell ? Math.max(0, +(id === 'oan_hon' ? cfg.honSellOan : cfg.honSellPham) || 0) : 0;
    if (!extra) return 0;
    var x = need && need.filter(function (r) { return r.id === id; })[0];
    return (x ? x.can : 0) + extra;
  }
  function honWanted(P, s) {
    var need = honNext(P, s), out = {}, cap = (s.moc && s.moc.tenDo) || 20;
    var capped = false, oanThieu = false, sell = false;
    (need || []).forEach(function (x) {
      if (!HON_KILL_NGHIEP[x.id] || x.co >= x.can) return;
      if (x.id === 'oan_hon') { oanThieu = true; return; }
      if (!cfg.honAllowRed && (s.nghiep | 0) + HON_KILL_NGHIEP[x.id] >= cap) { capped = true; return; }
      out[x.id] = x;
    });
    ['pham_hon', 'oan_hon'].forEach(function (id) {
      var tgt = honSellTarget(s, need, id), co = honHave(s, id);
      if (!tgt || co >= tgt || out[id]) return;
      if (id === 'oan_hon') { oanThieu = sell = true; return; }
      if (!cfg.honAllowRed && (s.nghiep | 0) + HON_KILL_NGHIEP[id] >= cap) { capped = true; return; }
      out[id] = { id: id, ten: 'Phàm Hồn (dư bán chợ)', can: tgt, co: co, sell: true };
      sell = true;
    });
    return { out: out, capped: capped, need: need, oanThieu: oanThieu, sell: sell };
  }

  function honTalk(g, a, npcId, want) { return npcTalk(g, a, npcId, want, honLog); }

  // Bấm nút "Thỉnh Hồn Phiên": tới Sứ Giả Ma Đạo, chọn thỉnh (game tự kiểm điều kiện, trừ Linh Thạch).
  function honBuyStart() {
    var g = game(), P = g && g.P, L = P && P.LuyenQuy;
    if (!L) { say('Game chưa có hệ thống Hồn Phiên'); return; }
    var why = L.xetThinhPhien ? L.xetThinhPhien(P) : null;
    if (why) { honLog('Chưa thỉnh được: ' + why); return; }
    st.honBuy = { touches: 0, touchAt: 0, routeAt: 0, travels: 0, at: now() };
    if (!enabled) setEnabled(true);
    honLog('Đi thỉnh Hồn Phiên ở ' + mapName(propMap(P, L.NPC) || L.MAP) + ' (' + L.GIA_PHIEN + ' Linh Thạch)');
  }
  function tickHonBuy(g) {
    var a = st.honBuy, L = g.P.LuyenQuy;
    if (!a) return false;
    if (L.coPhien(g.P)) { st.honBuy = null; dcDlg = null; honLog('Đã có Hồn Phiên'); return false; }
    if (now() - a.at > 5 * 60000 || !honTalk(g, a, L.NPC, 'thinh')) { st.honBuy = null; honLog('Thỉnh Hồn Phiên chưa xong → dừng'); return false; }
    setAuto(g, false);
    return true;
  }

  // ================= Pháp Bảo Phe Phái (Đa Phái): Hồn Phiên, Kiếm Hạp, Thiết Hoàn, Loan Kết =================
  // Xác định bảo vật của từng phe: Ma Đạo (Âm Hồn), Chính Đạo (Kiếm Linh), Thể Tu (Quyền Ảnh), Hợp Hoan (Mị Điệp)
  function factionArtifact(P, s) {
    if (!s) return null;
    var dao = s.dao || (s.hap ? 'chinh' : s.hoan ? 'the' : s.ket ? 'hop' : s.phien ? 'ma' : '');
    if (dao === 'chinh' || s.hap) {
      return { dao: 'chinh', ten: 'Kiếm Linh', baoVat: 'Tụ Linh Kiếm Hạp', co: s.kl | 0, tran: s.tranKl | (P.ChinhDao && P.ChinhDao.tran ? P.ChinhDao.tran(P) : 0), mod: P.ChinhDao };
    }
    if (dao === 'the' || s.hoan) {
      return { dao: 'the', ten: 'Quyền Ảnh', baoVat: 'Trấn Thân Thiết Hoàn', co: s.qa | 0, tran: s.tranQa | (P.TheTu && P.TheTu.tran ? P.TheTu.tran(P) : 0), mod: P.TheTu };
    }
    if (dao === 'hop' || s.ket) {
      return { dao: 'hop', ten: 'Mị Điệp', baoVat: 'Hồng Loan Kết', co: s.md | 0, tran: s.tranMd | (P.HopHoan && P.HopHoan.tran ? P.HopHoan.tran(P) : 0), mod: P.HopHoan };
    }
    if (dao === 'ma' || s.phien) {
      return { dao: 'ma', ten: 'Âm Hồn', baoVat: 'Vạn Hồn Phiên', co: (s.am | 0) + (s.dang | 0), tran: s.tran | (P.LuyenQuy && P.LuyenQuy.tranAmHon ? P.LuyenQuy.tranAmHon(P) : 0), mod: P.LuyenQuy };
    }
    return null;
  }

  // Tự động luyện / mở khiếu con kế tiếp cho MỌI PHE PHÁI khi đủ nguyên liệu.
  // LƯU Ý CHIẾN ĐẤU: Cả 4 phe phái khi bật Tự Động (Auto On), game engine và máy chủ TỰ ĐỘNG điều phối
  // [Âm Hồn / Kiếm Linh / Quyền Ảnh / Mị Điệp] xuất kích, không tốn Linh Lực. Bot tuyệt đối KHÔNG gửi lệnh gọi thủ công
  // để tránh bị máy chủ từ chối và hiện lỗi 'Không được: Âm Hồn tự ra đánh khi bật Tự Động'.
  function tickHonCraft(g) {
    var P = g.P, G = P.Gateway;
    if (!G || !G.connected || !G.cmd) return;
    var s = honState(P);
    if (!s) return;
    var art = factionArtifact(P, s);
    if (!art || !art.mod) return;

    var wantCraft = cfg.honLuyen && (cfg.honRun || (cfg.planRun && cfg.plan_hon) || art.dao !== 'ma' || !cfg.honRun);
    if (wantCraft && now() - (st.honLuyenAt || 0) > HON_LUYEN_GAP_MS) {
      var nextIdx = (art.co | 0) + 1;
      if (art.tran > 0 && nextIdx <= art.tran && art.mod.congThucCon) {
        var reqs = art.mod.congThucCon(nextIdx) || [];
        var enough = reqs.length > 0;
        var I = P.Inventory;
        for (var i = 0; i < reqs.length; i++) {
          var r = reqs[i], have = 0;
          if (P.ChinhDao && r.id === P.ChinhDao.CHINH_KHI) have = s.ck | 0;
          else if (P.ChinhDao && r.id === P.ChinhDao.HIEP_NGHIA) have = s.hn | 0;
          else if (P.ChinhDao && r.id === P.ChinhDao.TRU_MA) have = s.tm | 0;
          else if (P.LuyenQuy && r.id === P.LuyenQuy.PHAM_HON) have = s.pham | 0;
          else if (P.LuyenQuy && r.id === P.LuyenQuy.OAN_HON) have = s.oan | 0;
          else if (P.LuyenQuy && r.id === P.LuyenQuy.TU_SI_HON) have = s.tuSi | 0;
          else if (P.LuyenQuy && r.id === P.LuyenQuy.THU_HON_3) have = s.thu3 | 0;
          else if (P.LuyenQuy && r.id === P.LuyenQuy.THU_HON_4) have = s.thu4 | 0;
          else if (P.LuyenQuy && r.id === P.LuyenQuy.THU_HON_6) have = s.thu6 | 0;
          else if (I && I.count) have = I.count(r.id);
          if (have < r.can) { enough = false; break; }
        }
        if (enough && (!art.mod.xetLuyen || !art.mod.xetLuyen(null, P, s.dang | 0))) {
          st.honLuyenAt = now();
          G.cmd('hon.luyen', { congThuc: 'tiep' }, function (res) {
            if (res && res.hon && P.HonPhienUI && P.HonPhienUI.dat) P.HonPhienUI.dat(res.hon);
            if (res && res.ok !== false) {
              klog('[Bảo bối] Luyện thành công ' + art.ten + ' thứ ' + nextIdx + '/' + art.tran + ' (' + art.baoVat + ')');
              say(art.baoVat + ': Luyện thành ' + art.ten + ' thứ ' + nextIdx);
            } else {
              klog('[Bảo bối] Luyện không được: ' + (res && res.why || ''));
            }
          });
        }
      }
    }
  }

  // Săn người phàm lấy hồn. true = đang đi / đang đuổi (chặn việc khác), false = để đánh / farm như thường.
  function tickHonFarm(g) {
    var P = g.P, L = P.LuyenQuy, me = g.me;
    // Bật "Săn thêm để bán chợ" thì lúc rảnh (không có Thương Đội / việc khác) tự đi săn số dư Phàm Hồn, đủ thì về farm.
    var honOn = cfg.planRun ? planIs('hon') || (cfg.honSell && !(st.plan && st.plan.job)) : (cfg.honRun || cfg.honSell);
    if (!honOn || !cfg.honFarm || !L || st.dc || st.bh || st.bd || st.xc || st.td || st.ga || st.fa) { if (st.hon) honStop(g); return false; }
    if (!st.hon && now() < (st.honRestUntil || 0)) return false; // vừa quét hết người phàm: farm quái chờ họ hồi
    var s = honState(P);
    if (!s || !s.phien) return false;
    var w = honWanted(P, s), want = w.out, kinds = Object.keys(want);
    var a = st.hon, cap = (s.moc && s.moc.tenDo) || 20;
    if (a && a.target && (a.target.dead || a.target.hp <= 0)) { st.huntKillAt = now(); a.target = null; }
    // Thương Nhân / Tiêu Sư (Oán Hồn) đang ở trong tầm nhìn mà còn cần Oán Hồn (con kế tiếp / dư bán chợ): đánh luôn,
    // không chờ phần Săn Thương Đội.
    var wantOan = tdWantMa(P);
    var oanVis = wantOan ? (g.sw.enemies || []).filter(function (m) { return m && m.def && m.def.hon === 'oan_hon' && honCanHit(P, m) && (m.state !== 'return' || m === (a && a.target)); }) : [];
    if (!kinds.length && oanVis.length) {
      if (!a) { a = st.hon = { touches: 0, touchAt: 0, routeAt: 0, travels: 0, at: now(), back: takeBack(g), seenAt: now(), target: null }; honLog('Thấy ' + mobLabel(oanVis[0]) + ' (Oán Hồn) trong tầm → đánh'); }
      if (huntLoot(g, a.target)) { setAuto(g, false); a.step = 'nhặt hồn rơi'; return true; }
      var to = a.target && oanVis.indexOf(a.target) >= 0 ? a.target : evNearest(g, oanVis.slice());
      if (a.target !== to) { a.target = to; a.step = 'săn ' + mobLabel(to) + ' (Oán Hồn) · khu ' + gaKhu(P); }
      a.seenAt = now();
      honStrike(g, a, to, true);
      return true;
    }
    // Đã dừng vì mốc: chờ nghiệp giảm hẳn (HON_RESUME điểm) mới săn lại, khỏi đi về mỗi 10 phút để hạ một con.
    if (w.capped) st.honCapped = true;
    else if (st.honCapped && !cfg.honAllowRed && (s.nghiep | 0) > Math.max(0, cap - HON_RESUME) && !a) { kinds = []; w.capped = true; }
    else st.honCapped = false;
    // Chạm mốc nghiệp: cúng nếu bật và đủ Linh Thạch, không thì dừng săn chờ nghiệp giảm.
    if (!kinds.length) {
      if (w.capped && cfg.honCung && (s.nghiep | 0) > 0 && (P.Progress && (P.Progress.stones | 0) >= (L.GIA_CUNG || 500))) {
        a = st.hon || (st.hon = { touches: 0, touchAt: 0, routeAt: 0, travels: 0, at: now(), back: takeBack(g), seenAt: now() });
        a.step = 'cúng gột nghiệp';
        if (!honTalk(g, a, L.NPC_CUNG || 'ong_tu_mieu', 'cung')) honStop(g, 'Không cúng được → chờ nghiệp tự giảm');
        return !!st.hon;
      }
      if (st.hon && lootBeforeLeave(g)) { st.hon.step = 'nhặt hồn rơi trước khi về'; return true; }
      if (st.hon) honStop(g, w.capped ? 'Sát Nghiệp ' + s.nghiep + '/' + cap + ' sắp tên đỏ → dừng săn, chờ nghiệp xuống ' + Math.max(0, cap - HON_RESUME) + ' (1 điểm / 10 phút)' :
        w.oanThieu ? 'Đủ Phàm Hồn · còn thiếu Oán Hồn — chỉ có từ Thương Đội (bật "Săn Thương Đội" ở tab ☁ Thiên Đạo)' :
          cfg.honSell ? 'Đủ hồn cho con kế tiếp và phần dư bán chợ (Phàm ' + (s.pham | 0) + ' · Oán ' + (s.oan | 0) + ')' :
            w.need ? 'Đủ Phàm / Oán Hồn cho con kế tiếp' : 'Phiên đã đầy Âm Hồn');
      else if (w.oanThieu && !w.capped && st.honOanNote !== s.oan) { st.honOanNote = s.oan; honLog('Còn thiếu Oán Hồn — chỉ có từ Thương Đội (bật "Săn Thương Đội" ở tab ☁ Thiên Đạo)'); }
      return false;
    }
    if (!a) {
      a = st.hon = { touches: 0, touchAt: 0, routeAt: 0, travels: 0, at: now(), back: takeBack(g), seenAt: now(), target: null };
      honLog('Đi săn ' + kinds.map(function (k) { return want[k].ten + ' ' + want[k].co + '/' + want[k].can; }).join(', ') + ' · Sát Nghiệp ' + s.nghiep);
    }
    // Map có người phàm cho loại cần: ở lại map hiện tại nếu có, không thì map có nhiều nhất.
    var maps = honMaps(P), graph = mapGraph(P), best = null;
    Object.keys(maps).forEach(function (id) {
      var n = 0;
      kinds.forEach(function (k) { n += maps[id][k] || 0; });
      if (!n || (a.mapRest && a.mapRest[id] > now()) || (id !== g.mapId && !nextHop(graph, g.mapId, id))) return;
      var sc0 = n + (id === g.mapId ? 1000 : 0);
      if (!best || sc0 > best.s) best = { id: id, s: sc0 };
    });
    if (!best && a.mapRest && a.mapRest[g.mapId] && maps[g.mapId]) best = { id: g.mapId, s: 0 }; // hết map khác → chờ ở đây
    if (!best) { a.step = 'không có map nào có người phàm đi tới được'; return false; }
    if (g.mapId !== best.id) {
      a.step = 'đi tới ' + mapName(best.id);
      if (!st.travel || st.travel.map !== best.id) {
        if (++a.travels > 6) { (a.mapRest || (a.mapRest = {}))[best.id] = now() + 10 * 60000; a.travels = 0; honLog('Không đi được tới ' + mapName(best.id) + ' → bỏ 10 phút'); return false; }
        startTravel(best.id, null, null, 'Hồn Phiên: đi săn hồn ở ' + mapName(best.id));
      }
      setAuto(g, false);
      tickTravel(g);
      return true;
    }
    if (st.travel && st.travel.map === best.id) { stopTravel(); a.arriveAt = now(); }
    if (a.khuWant) return honKhu(g, a) || cfg.honFocus;
    var list = (g.sw.enemies || []).filter(function (m) {
      return m && m.def && want[m.def.hon] && honCanHit(P, m) && (m.state !== 'return' || m === a.target);
    }).concat(oanVis);
    if (huntLoot(g, a.target)) { setAuto(g, false); a.step = 'nhặt hồn rơi · khu ' + gaKhu(P); return true; }
    a.want = want;
    if (!list.length) return honIdle(g, a, best.id);
    a.seenAt = now();
    // Giữ con đang đuổi nếu nó chưa chạy quá xa; không thì con gần nhất.
    // Oán Hồn (đoàn chỉ đi qua một lúc) trước, rồi con gần nhất.
    var t = a.target && list.indexOf(a.target) >= 0 && dist(me.x, me.y, a.target.x, a.target.y) < 360 ? a.target :
      list.sort(function (x, y) { return (x.def.hon === 'oan_hon' ? 0 : 1) - (y.def.hon === 'oan_hon' ? 0 : 1) || dist(me.x, me.y, x.x, x.y) - dist(me.x, me.y, y.x, y.y); })[0];
    if (a.target !== t) { a.target = t; a.step = 'săn ' + mobLabel(t) + ' (' + (L.TEN_HON[t.def.hon] || t.def.hon) + ') · khu ' + gaKhu(P); }
    honStrike(g, a, t, t.def.hon === 'oan_hon');
    return true;
  }

  // Đang săn (Hồn Phiên, Thương Đội): giết xong con nào nhặt hồn / đồ rơi của nó rồi mới đuổi con kế, …
  var HUNT_LOOT_R = 300;
  function huntLoot(g, t) {
    if (!cfg.autoLoot) return false;
    var me = g.me;
    if (t && !t.dead && dist(me.x, me.y, t.x, t.y) < 70) return false;
    if (st.looting) return tickLoot(g, true);
    var near = dropsLeft(g).some(function (r) { return dist(me.x, me.y, r.x, r.y) <= HUNT_LOOT_R; });
    return near && tickLoot(g, true);
  }

  // Tự đuổi và chém người phàm. Online đòn chém gửi lên máy chủ con đang KHOÁ trên Targeting …
  var HON_LEAD_S = 0.35;        // giây đón đầu: trễ mạng + lúc vung tới lúc đòn trúng
  var HON_LEAD_NEAR = 80;       // px: gần hơn thế thì đuổi thẳng, không đón đầu
  function honPin(P, t, pl) {
    var T = P.Targeting, key = 'foe:' + t.id;
    if (!T || !T.list) return;
    if (!T.list.some(function (e) { return e.key === key; })) {
      pl = pl || P.SceneWorld.player;
      T.list.push({
        key: key, kind: 'enemy', obj: t, x: t.x, y: t.y, baseY: t.y, topY: t.y - 30,
        name: t.def && t.def.name || 'Người phàm', r: P.CONFIG.PLAYER.REACH, dist: pl ? dist(pl.x, pl.y, t.x, t.y) : 0
      });
    }
    T.key = key;
    T.manual = true;
  }
  // Bỏ khỏi danh sách khoá của game: Trụ Trấn Mạch (đánh không được thì auto cứ lao vào) hoặc boss đang né
  function zoneBlock(o) { var g = game(); return o && o._ttZone > now() && g && tlRange(g) < (o.def.baoKich && o.def.baoKich.radius || 160) + 20; }
  function tgtDrop(T, pl) {
    var L = T.list || [], had = false;
    for (var i = L.length - 1; i >= 0; i--) {
      var o = L[i] && L[i].kind === 'enemy' && L[i].obj;
      if (o && o.def && ((o.def.tranMach && !cfg.tmTru) || (st.bossAvoid && st.bossAvoid[o.id] > now()) || zoneBlock(o))) { if (L[i].key === T.key) had = true; L.splice(i, 1); }
    }
    if (!had) return;
    var b = null;
    L.forEach(function (x) { if (x.kind === 'enemy' && pl && (!b || dist(pl.x, pl.y, x.x, x.y) < dist(pl.x, pl.y, b.x, b.y))) b = x; });
    T.key = b ? b.key : null; T.manual = false;
  }
  function hookTargeting(P) {
    var T = P.Targeting;
    if (!T || T._ttHon || !T.refresh) return;
    T._ttHon = true;
    var ref = T.refresh;
    T.refresh = function (pl) {
      var r = ref.apply(this, arguments);
      try { if (enabled) tgtDrop(T, pl); } catch (e) { }
      try {
        var t = enabled && huntTarget();
        if (t && !t.dead && pl && dist(pl.x, pl.y, t.x, t.y) <= 420 && !zoneBlock(t)) honPin(P, t, pl);
        // Mục tiêu sự kiện (Tà Soái…): đẩy vào danh sách khoá kể cả khi ngoài tầm chọn của game, để auto không khoá con khác.
        else if (enabled && st.pin && st.pin.t && !st.pin.t.dead && now() - st.pin.at < EV_PIN_MS && pl && dist(pl.x, pl.y, st.pin.t.x, st.pin.t.y) <= 700) honPin(P, st.pin.t, pl);
      } catch (e) { }
      return r;
    };
  }
  function honStrike(g, a, t, maxDmg) {
    var P = g.P, me = g.me;
    setAuto(g, true); // Giữ Auto để linh hồn / kiếm linh / quyền ảnh / mị điệp tự ra đánh và xả combo tối đa
    honPin(P, t, me);
    st.farmTarget = t;
    if (me.state === 'sit') P.Player.stand(me);
    var px = t.x + (t._vx || 0) * HON_LEAD_S, py = t.y + (t._vy || 0) * HON_LEAD_S;
    var dx = t.x - me.x, dy = t.y - me.y, d = Math.sqrt(dx * dx + dy * dy);

    // Luôn dồn sát thương xả full skill vào mục tiêu Thương Đội
    if (maxDmg) huntBurst(g, t, d, 26);

    // Áp sát mục tiêu Thương Đội tận tâm px = 0 (d <= 4px)
    if (d > 4) {
      if (!(me.path && me.path.length && now() - a.routeAt < 200)) {
        var sc = spotCheck(g), r = (d > HON_LEAD_NEAR && sc.route(px, py)) || sc.route(t.x, t.y);
        if (r) { me.setPath(r.path); a.routeAt = now(); }
      }
    } else {
      if (me.path && me.path.length) me.path.length = 0;
      g.sw.tuChiDuong = false;
    }

    if (me.state === 'attack' && !me.attackFired) return; // đang vung dở: để đòn ra đã

    // Tung đòn đánh thường chém liên tục nếu không đang niệm chiêu
    if (me.state !== 'attack' && me.state !== 'pose') {
      me.dir = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 2 : 1) : (dy > 0 ? 0 : 3);
      var ok = P.Player.attack ? P.Player.attack(me, t) : (g.sw.approach = { key: 'foe:' + t.id, until: P.Game.time + 2 });
      var cur = P.Targeting && P.Targeting.currentEnemy ? P.Targeting.currentEnemy() : t;
      if (ok !== false) klog('[Thương Đội] Áp sát (0px) xả skill ' + mobLabel(t) + (cur && cur !== t ? ' — khoá đang lệch sang ' + mobLabel(cur) + '!' : ''));
    }
  }

  // Dồn sát thương lên người đang săn (Thương Đội): bùa sát thương, Thanh Tâm khi linh lực < 40%, rồi chiêu có …
  function huntBurst(g, t, d, reach) {
    var P = g.P, me = g.me, S = P.Skills;
    if (me.state === 'attack' || me.state === 'pose' || st.contest) return false;
    var face = function () { me.dir = dirToward(t.x - me.x, t.y - me.y); };
    if (cfg.autoMpTal && me.mpMax > 0 && me.mp / me.mpMax < 0.4) talUse(g, 'thanh_tam', 'dồn sát thương ' + mobLabel(t) + ', linh lực ' + Math.round(me.mp));
    if (d <= 260 && talOk(P, me, 'kim_o')) { face(); talUse(g, 'kim_o', 'dồn sát thương ' + mobLabel(t)); }
    else if (d <= 120 && talOk(P, me, 'hoa_phu')) { face(); talUse(g, 'hoa_phu', 'dồn sát thương ' + mobLabel(t)); }
    if (!S || !S.autoRotation || !S.dmgOf || !P.Player.castSpell) return false;
    var mobs = mobsAlive(g), best = null;
    burstSkills(g).forEach(function (def) { // đồ Thương Đội chia theo công: dùng mọi chiêu sát thương đã học
      var r = evalSkill(g, def, t, d, mobs);
      if (r.ok && r.eff > 0 && (!best || r.eff > best.eff)) best = r;
    });
    if (!best) return false;
    face();
    me.castTarget = t;
    var ok = best.def.thunder ? P.Player.castThunder(me) : P.Player.castSpell(me, best.def);
    if (ok !== true) { me.castTarget = null; return false; }
    klog('[Thương Đội] Tung ' + (best.def.short || best.def.name) + ' vào ' + mobLabel(t) + ' (' + num(t.hp) + '/' + num(t.hpMax) + ')');
    return true;
  }

  // Khu hết người phàm: dò các điểm sinh rồi đổi khu (nhớ khu trống 5 phút), hết khu sang map khác.
  /* ================= Dò tìm mục tiêu toàn map ================= */
  // Máy chủ chỉ gửi người phàm / quái ở khá gần mình (đứng ở Bảng Khu cách chỗ sinh ~8 ô là không thấy). Muốn biết …
  var SWEEP_SEE_R = 110;         // px: tới gần điểm dò chừng này mới tính là đã xem
  var SWEEP_GRID = 260;          // px: khoảng cách lưới phủ map (tầm máy chủ gửi quái quanh mình ~200px)
  var SWEEP_DWELL_MS = 1200;     // chỗ ưu tiên: đứng nhìn chừng này cho danh sách quái kịp cập nhật
  var SWEEP_PASS_MS = 250;       // điểm lưới: đi ngang là đủ
  var SCAN_MAX_MS = 300000;      // dò một khu tối đa chừng này
  var sweepGridCache = {};
  function sweepGrid(g) {
    var id = g.mapId;
    if (sweepGridCache[id]) return sweepGridCache[id];
    var map = g.sw.map, sc = spotCheck(g), W = map.pxWidth || 1280, H = map.pxHeight || 960, out = [];
    for (var y = SWEEP_GRID / 2; y < H; y += SWEEP_GRID) for (var x = SWEEP_GRID / 2; x < W; x += SWEEP_GRID) if (sc.standable(x, y)) out.push({ x: x, y: y });
    if (out.length) sweepGridCache[id] = out;
    return out;
  }
  // Danh sách điểm dò: chỗ ưu tiên trước, rồi lưới toàn map (trừ khi chọn chỉ dò quanh chỗ sinh). area = {x, y, r} giới
  // hạn vùng; whole = luôn dò lưới (mục tiêu không có chỗ sinh cố định: xổng chuồng, Thương Đội đang đi, boss bị kéo).
  function sweepPlan(g, prio, area, whole) {
    var pts = (prio || []).map(function (q) { return { x: q.x, y: q.y, prio: true, dwell: SWEEP_DWELL_MS }; });
    if (cfg.scanMode !== 'spawn' || whole) {
      sweepGrid(g).forEach(function (q) {
        if (area && dist(q.x, q.y, area.x, area.y) > area.r) return;
        if (!pts.some(function (p) { return dist(p.x, p.y, q.x, q.y) < SWEEP_GRID * 0.5; })) pts.push({ x: q.x, y: q.y, dwell: SWEEP_PASS_MS });
      });
    }
    return pts;
  }
  // Đi dò lần lượt (chỗ ưu tiên gần nhất trước, hết thì điểm lưới gần nhất). true = còn chỗ chưa xem; false = xem hết.
  function sweepStep(g, a, pts) {
    var me = g.me;
    for (var i = pts.length - 1; i >= 0; i--) {
      var q = pts[i];
      if (dist(me.x, me.y, q.x, q.y) > SWEEP_SEE_R) { q.near = 0; continue; }
      if (!q.near) q.near = now();
      if (now() - q.near >= q.dwell) pts.splice(i, 1);
    }
    if (!pts.length) return false;
    if (pts.some(function (q) { return q.near; })) { if (me.path && me.path.length) me.path.length = 0; return true; }
    if (me.path && me.path.length && now() - (a.routeAt || 0) < 1500) return true;
    var pool = pts.filter(function (q) { return q.prio; });
    var t = evNearest(g, (pool.length ? pool : pts).slice()), r = spotCheck(g).route(t.x, t.y);
    if (!r) { pts.splice(pts.indexOf(t), 1); return true; }
    if (me.state === 'sit') g.P.Player.stand(me);
    me.setPath(r.path);
    a.routeAt = now();
    return true;
  }
  function spawnPts(P, mapId, test) {
    var MD = P.MapData || {}, D = P.ENEMY_DEFS || {}, T = P.CONFIG.TILE || 32, m = null, out = [];
    Object.keys(MD).some(function (k) { var x = MD[k]; if (x && typeof x === 'object' && x.id === mapId && Array.isArray(x.enemies)) { m = x; return true; } return false; });
    if (!m) return out;
    m.enemies.forEach(function (e) {
      if (!e || !isFinite(e.tx) || e.thuongDoi || !test(D[e.type], e)) return;
      var x = (e.tx + 0.5) * T, y = (e.ty + 0.5) * T;
      if (!out.some(function (q) { return dist(q.x, q.y, x, y) < SWEEP_SEE_R; })) out.push({ x: x, y: y });
    });
    return out;
  }
  // Dò khu đang đứng tìm loại quái test(def, e): chỗ sinh của loại đó trước rồi toàn map. true = còn đang dò.
  function scanKhu(g, a, test) {
    var key = g.mapId + '#' + gaKhu(g.P);
    if (!a.scan || a.scan.key !== key) a.scan = { key: key, pts: sweepPlan(g, spawnPts(g.P, g.mapId, test)), at: now() };
    if (now() - a.scan.at > SCAN_MAX_MS) return false;
    return sweepStep(g, a, a.scan.pts);
  }

  var HON_RESPAWN_MS = 300000, HON_SETTLE_MS = 2000;
  var HON_AVOID_R = 160;         // px: lúc đứng chờ, quái đang đuổi trong khoảng này thì tránh ra
  function honIdle(g, a, mapId) {
    var P = g.P, me = g.me, khu = gaKhu(P), so = gaSoKhu(P);
    a.target = null;
    if (st.farmTarget && st.farmTarget.def && st.farmTarget.def.human) releaseTarget(g);
    var want = a.want || {};
    if (now() - (a.arriveAt || a.at) >= HON_SETTLE_MS && scanKhu(g, a, function (d) { return d && d.human && want[d.hon]; })) {
      setAuto(g, false);
      a.step = 'tìm người phàm khắp khu ' + khu + ' (còn ' + a.scan.pts.length + ' chỗ)';
      return true;
    }
    if (!cfg.honFocus) {
      a.step = 'chờ người phàm hồi sinh (5 phút) · khu ' + khu;
      if (now() - a.seenAt > HON_SWITCH_MS && so > 1) { a.khuWant = (khu % so) + 1; a.khuAt = 0; a.touches = 0; a.touchAt = 0; honLog('Khu ' + khu + ' hết người phàm → sang khu ' + a.khuWant); return honKhu(g, a); }
      return false;
    }
    if (now() - (a.arriveAt || a.at) < HON_SETTLE_MS) { a.step = 'xem khu ' + khu; return true; }
    var seen = a.khuSeen || (a.khuSeen = {}), key = mapId + '#';
    seen[key + khu] = now();
    var next = 0;
    for (var i = 1; i < so && !next; i++) {
      var k = ((khu - 1 + i) % so) + 1;
      if (!seen[key + k] || now() - seen[key + k] >= HON_RESPAWN_MS) next = k;
    }
    if (next) { a.khuWant = next; a.khuAt = 0; a.touches = 0; a.touchAt = 0; honLog('Khu ' + khu + ' hết người phàm → sang khu ' + next); return honKhu(g, a) || true; }
    // Mọi khu của map này vừa xem đều trống: nghỉ map này tới khi khu trống sớm nhất hồi lại.
    var oldest = Infinity;
    for (var j = 1; j <= so; j++) oldest = Math.min(oldest, seen[key + j] || 0);
    var back = oldest + HON_RESPAWN_MS;
    if (!a.mapRest || !(a.mapRest[mapId] > now())) {
      (a.mapRest || (a.mapRest = {}))[mapId] = back;
      honLog(mapName(mapId) + ': ' + so + ' khu đều hết người phàm → tìm map khác');
      return true; // nhịp sau chọn map khác (nếu có)
    }
    // Không còn map nào khác: không đứng chờ. Thôi săn, về chỗ farm đánh quái; khu trống sớm nhất hồi lại thì đi săn tiếp.
    st.honRestUntil = back;
    honStop(g, 'Mọi khu / map đều vừa hết người phàm → về chỗ farm, ' + Math.max(1, Math.round((back - now()) / 60000)) + ' phút nữa săn tiếp');
    return false;
  }

  // Đổi sang khu a.khuWant: tới Bảng Khu gần nhất, chạm (game mở bảng), chọn số khu như bấm tay.
  // true = đang đổi; false = đã sang / không đổi được (a.khuWant về 0).
  function khuGo(g, a, tag) {
    var P = g.P, K = P.KhuUI, G = P.Gateway;
    setAuto(g, false);
    if (!a.khuAt && lootBeforeLeave(g)) return true;
    if (gaKhu(P) === a.khuWant) { a.khuWant = 0; a.seenAt = a.arriveAt = now(); return false; }
    if (a.khuAt) { if (now() - a.khuAt < 10000) return true; a.khuWant = 0; a.seenAt = a.arriveAt = now(); return false; }
    if (K && K.isOpen && K.isOpen()) {
      if (G && G.send && G.send({ op: 'khu', act: 'chon', khu: a.khuWant })) { a.khuAt = now(); K.close(); klog(tag + ' Chọn khu ' + a.khuWant); }
      else a.khuWant = 0;
      return true;
    }
    var b = fkBoard(g);
    if (!b || touchProp(g, a, b) === 'fail') { a.khuWant = 0; a.seenAt = a.arriveAt = now(); return false; }
    return true;
  }
  function honKhu(g, a) { a.step = 'đổi sang khu ' + a.khuWant; return khuGo(g, a, '[Hồn]'); }
  function honStop(g, msg) {
    var a = st.hon;
    st.hon = null;
    if (msg) honLog(msg);
    if (st.farmTarget && st.farmTarget.def && st.farmTarget.def.human) releaseTarget(g);
    if (a && a.back && g && (g.mapId !== a.back.map || dist(g.me.x, g.me.y, a.back.x, a.back.y) > BACK_NEAR || (a.back.khu && gaKhu(g.P) !== a.back.khu))) goBack(a.back.map, a.back.x, a.back.y, 'Thôi săn hồn → về chỗ farm', 'hon', a.back.khu);
  }

  /* ================= Nói chuyện với NPC (dùng chung) ================= */
  // Đi tới map có NPC, chạm vào (game mở hộp thoại), hộp thoại script bấm theo want. true = đang làm.
  function npcTalk(g, a, npcId, want, logf, name) {
    var mapId = propMap(g.P, npcId);
    if (!mapId) { logf('Không tìm thấy NPC ' + npcId + ' trong dữ liệu bản đồ'); return false; }
    if (g.mapId !== mapId) {
      if (!st.travel || st.travel.map !== mapId) {
        if (++a.travels > 6) { logf('Không đi được tới ' + mapName(mapId)); return false; }
        startTravel(mapId, null, null, 'Đi tới ' + mapName(mapId));
      }
      tickTravel(g);
      return true;
    }
    if (st.travel) stopTravel();
    var npc = findHere(g, npcId);
    if (!npc) { logf('Không thấy NPC trong map'); return false; }
    if (g.P.HUD && g.P.HUD.dialogOpen) return true;
    var r = touchProp(g, a, npc);
    if (r === 'fail') { logf('Không nói chuyện được với ' + (npc.name || npcId)); return false; }
    if (r === 'sent' && (!dcDlg || dcDlg.at !== a.touchAt)) dcDlg = { want: want, name: name, until: now() + DC_DLG_MS, at: a.touchAt };
    return true;
  }
  function npcNear(g, npcId) {
    var npc = findHere(g, npcId);
    if (!npc) return false;
    var c = propCenter(g, npc);
    return dist(g.me.x, g.me.y, c.x, c.y) <= dcReach(g, npc) + 6;
  }
  // Tới đứng cạnh NPC (không mở hộp thoại): 'here' | 'walk' | 'fail'.
  function atNpc(g, a, npcId, logf) {
    if (g.mapId === propMap(g.P, npcId) && npcNear(g, npcId)) {
      if (st.travel) stopTravel();
      if (g.me.path && g.me.path.length) g.me.path.length = 0;
      return 'here';
    }
    return npcTalk(g, a, npcId, 'close', logf) ? 'walk' : 'fail';
  }
  function jobGo(g, a, mapId, why, logf) {
    if (!st.travel || st.travel.map !== mapId) {
      if (++a.travels > 6) { logf('Không đi được tới ' + mapName(mapId)); return false; }
      startTravel(mapId, null, null, why);
    }
    tickTravel(g);
    return true;
  }

  /* ================= Điểm danh · Rút Tàng Kinh miễn phí ================= */
  function dailyLog(tag, msg) { klog('[' + tag + '] ' + msg); say(tag + ': ' + msg); }
  // Điểm Danh 30 Ngày (Sự Kiện · Phúc Lợi, phucloi.diemdanh): đủ Luyện Khí 7 và hôm nay đã vào đài Đại Hội ít nhất một trận.
  function ddAvail(P) { var D = P.DiemDanh; return !!(D && D.coTheNhan && P.Gateway && P.Gateway.connected && D.coTheNhan(P)); }
  function ddText(P) {
    var D = P.DiemDanh, o = D && D.trangThai && D.trangThai(P);
    return !o ? 'Game chưa có điểm danh' : o.daNhan ? '✓ Đã điểm danh hôm nay (' + o.tong + ' ngày)' : !D.duCanhGioi(P) ? '• Điểm danh: cần ' + D.tenCanhGioi(P) :
      D.duDaiHoi(P) ? '• Chưa điểm danh hôm nay (ô ' + o.keTiep + ')' : '• Điểm danh: hôm nay chưa vào đài Đại Hội' + (cfg.dhRun ? ' → kỳ tới tự ghi danh' : ' (bật Tự đánh Đại Hội)');
  }
  // 'busy' (đang làm) · 'done' (xong / không cần) · 'fail' (không làm được, để sau)
  function tickDiemDanh(g) {
    var P = g.P, D = P.DiemDanh;
    if (!ddAvail(P)) { st.dd = null; return 'done'; }
    var a = st.dd || (st.dd = { at: now(), sent: 0 });
    if (now() - a.at > 60000) { st.dd = null; dailyLog('Điểm danh', 'Chưa điểm danh được → để sau'); return 'fail'; }
    if (now() - a.sent > 8000) {
      a.sent = now();
      P.Gateway.cmd('phucloi.diemdanh', {}, function (res) {
        if (!res || !res.ok) { dailyLog('Điểm danh', 'Không được: ' + (res && res.why || 'lỗi')); return; }
        var o = D.trangThai(P);
        if (!o.daNhan) P.Quest.flags[D.FLAG] = { ngay: D.ngayVN(), tong: o.tong + 1 }; // như nút của game
        dailyLog('Điểm danh', 'Ngày ' + res.ngay + ': ' + (D.moTa ? D.moTa(res.qua, P) : ''));
        if (P.SuKienUI && P.SuKienUI.capNhatNut) P.SuKienUI.capNhatNut();
      });
    }
    return 'busy';
  }

  /* ================= Đại Hội Tu Tiên ================= */
  // Tournament.lich: mở sổ 16 phút trước giờ khai, chốt sổ 1 phút trước thì máy chủ tự đưa vào phòng chờ, rồi gọi lên đài tỉ
  // thí 90 giây (ai gây nhiều sát thương hơn thắng). Ghi danh khi hôm nay chưa vào đài (Điểm Danh 30 Ngày) / đang giữ việc
  // Dược Công "Thắng Trận Đại Hội" / bật dự mọi kỳ. Chốt sổ thì đứng yên chờ, lên đài dồn đánh đối thủ, xong kỳ về chỗ cũ.
  var DH_MAPS = { dai_hoi_cho: 1, dai_hoi_dau: 1 };
  function dhLog(m) { klog('[Đại Hội] ' + m); say('Đại Hội: ' + m); }
  function dhDcTask(P) { var Q = P.Quest, t = Q && Q.seedTaskInfo && Q.seedTaskInfo(); return !!(t && t.kind === 'tournament'); }
  function dhToday(P) { var T = P.Tournament, f = P.Quest && P.Quest.flags; return !!(T && f && f[(P.DiemDanh && P.DiemDanh.DAI_HOI_FLAG) || 'dai_hoi_ngay'] === T.ngayVN()); }
  function dhLich(P) { var G = P.Gateway, T = P.Tournament; return T && T.lich ? T.lich(G && G.gioMayChu && G.gioMayChu() || Date.now()) : null; }
  function dhBang(g, L) { var T = g.P.Tournament, b = L && T.bangCua && T.bangCua(g.me.realmId || (g.P.Progress && g.P.Progress.realmId), L); return b && b.bang ? b : null; }
  function dhState(P, L) { var G = P.Gateway, s = G && G.daiHoiState || (P.DaiHoiUI && P.DaiHoiUI.state); return s && s.lich && L && s.lich.id === L.id ? s : null; }
  function tickDaiHoi(g) {
    var P = g.P, G = P.Gateway, T = P.Tournament;
    if (!cfg.dhRun || !T || !G || !G.daiHoi || !G.ready) { st.dh = null; return false; }
    if (ddAvail(P) && !st.oneShot) tickDiemDanh(g); // vừa vào đài xong: điểm danh luôn (không phải đi đâu)
    var L = dhLich(P), cur = dhState(P, L), reg = !!(cur && cur.daGhiDanh), inDai = !!DH_MAPS[g.mapId];
    var done = reg && (cur.trangThai === 'BI_LOAI' || cur.trangThai === 'VO_DICH' || cur.kyXong), a = st.dh;
    var want = (cfg.dhAll || !dhToday(P) || dhDcTask(P)) && dhBang(g, L);
    if (L && L.giaiDoan !== 'CHUA_MO' && (want || reg || inDai) && now() - (st.dhXemAt || -1e9) > (inDai || reg ? 8000 : 30000)) { st.dhXemAt = now(); G.daiHoi('xem'); }
    var hold = inDai || (reg && !done && L && (L.giaiDoan === 'PHONG_CHO' || L.giaiDoan === 'DANG_DAU'));
    if (!a && hold) a = st.dh = { at: now(), back: takeBack(g), step: '' };
    if (inDai) {
      if (st.travel) stopTravel();
      if (!reg || done) {
        a.pk = false; a.step = 'xong kỳ → về làng';
        if (now() - (a.roiAt || -1e9) > 6000) {
          a.roiAt = now(); G.daiHoi('roi');
          if (!a.said) { a.said = 1; dhLog('Xong kỳ' + (cur ? ': ' + (cur.trangThai === 'VO_DICH' ? 'VÔ ĐỊCH' : 'thắng ' + (cur.thangMayVong | 0) + ' vòng') : '') + ' → về làng'); }
        }
        setAuto(g, false);
        return true;
      }
      var foe = G.duel && G.remotes && G.remotes[G.duel.id], me = g.me;
      a.pk = !!foe;
      if (foe && !foe.downed && isFinite(foe.x)) {
        a.step = 'đấu ' + (foe.name || cur.doiThu || 'đối thủ') + ' · sát thương ' + (G.duel.damage | 0) + ' – ' + (G.duel.foeDamage | 0);
        if (!a.foe) { a.foe = 1; dhLog('Lên đài đấu ' + (foe.name || cur.doiThu || 'đối thủ')); }
        setAuto(g, true);
        if (dist(me.x, me.y, foe.x, foe.y) > 160 && !(me.path && me.path.length && now() - (a.routeAt || 0) < 700)) { var r = spotCheck(g).route(foe.x, foe.y); if (r) { moveFighting(g, r.path); a.routeAt = now(); } }
        return true;
      }
      a.foe = 0;
      a.step = cur.dangDau ? 'chờ vào đài' + (cur.doiThu ? ' · đối thủ ' + cur.doiThu : '') : 'phòng chờ · chờ trọng tài gọi · đã thắng ' + (cur.thangMayVong | 0) + ' vòng';
      setAuto(g, false);
      return true;
    }
    if (hold) { a.step = 'đã ghi danh · chờ máy chủ đưa vào phòng chờ'; if (st.travel) stopTravel(); setAuto(g, false); return true; }
    if (a) { st.dh = null; if (a.back && (a.back.map !== g.mapId || dist(g.me.x, g.me.y, a.back.x, a.back.y) > BACK_NEAR || (a.back.khu && gaKhu(g.P) !== a.back.khu))) goBack(a.back.map, a.back.x, a.back.y, 'Đại Hội xong → về chỗ cũ', 'dh', a.back.khu); return false; }
    if (want && L.giaiDoan === 'DANG_KY' && !reg && now() - (st.dhGhiAt || -1e9) > 10000) {
      st.dhGhiAt = now(); G.daiHoi('ghi_danh');
      dhLog('Ghi danh kỳ ' + T.gioDoc(L.batDauLuc) + ' (bảng ' + (T.BANG && T.BANG[want.bang] ? T.BANG[want.bang].ten : want.bang) + ')' + (dhDcTask(P) ? ' · việc Dược Công Thắng Trận Đại Hội' : !dhToday(P) ? ' · cho Điểm Danh 30 Ngày' : ''));
    }
    return false;
  }
  function dhText(g) {
    var P = g.P, T = P.Tournament, L = T && dhLich(P);
    if (!L) return 'Game chưa có Đại Hội';
    var cur = dhState(P, L), b = dhBang(g, L);
    return (cfg.dhRun ? '' : '✗ Tự đánh Đại Hội đang tắt · ') + 'Kỳ ' + T.gioDoc(L.batDauLuc) + ' · ' + ({ CHUA_MO: 'chưa mở sổ', DANG_KY: 'đang nhận ghi danh', PHONG_CHO: 'phòng chờ', DANG_DAU: 'đang đấu' }[L.giaiDoan] || L.giaiDoan) +
      (cur && cur.daGhiDanh ? ' · đã ghi danh, thắng ' + (cur.thangMayVong | 0) + ' vòng' : !b ? ' · chưa đủ tư cách kỳ này' : '') + (dhToday(P) ? ' · hôm nay đã vào đài' : '') + (st.dh ? ' · ' + st.dh.step : '');
  }
  var GC_NPC = 'tang_kinh_lao_nhan';
  // Tủ còn lượt rút miễn phí hôm nay (và còn quyển chưa có). Rút khi không còn miễn phí là bị trừ Linh Thạch.
  function gcPools(P) {
    var G = P.Gacha, Q = P.Quest;
    if (!G || !G.POOLS || !G.freeToday || !Q || !Q.flags || !Q.flags.bi_tich_hoan_thanh || !propMap(P, GC_NPC)) return [];
    if (!(P.Gateway && P.Gateway.connected)) return [];
    return Object.keys(G.POOLS).filter(function (id) {
      var pl = G.POOLS[id];
      return pl && pl.free && G.freeToday(P, id) && !(G.missing && !G.missing(P, id).length);
    });
  }
  function gcResult(P, res) {
    var ids = res.items || res.got || res.list || res.ketQua || (res.item ? [res.item] : []);
    if (!Array.isArray(ids)) return '';
    return ids.map(function (x) { var id = x && x.id || x; return P.ITEMS && P.ITEMS[id] ? P.ITEMS[id].name : String(id); }).join(', ');
  }
  function tickGacha(g) {
    var P = g.P, G = P.Gacha, pools = gcPools(P);
    if (!pools.length) { st.gc = null; return 'done'; }
    var a = st.gc || (st.gc = { touches: 0, touchAt: 0, routeAt: 0, travels: 0, at: now(), sentAt: 0 });
    if (now() - a.at > 3 * 60000) { st.gc = null; dailyLog('Tàng Kinh', 'Quá 3 phút chưa xong → để sau'); return 'fail'; }
    var w = atNpc(g, a, GC_NPC, function (m) { dailyLog('Tàng Kinh', m); });
    if (w === 'fail') { st.gc = null; return 'fail'; }
    if (w !== 'here' || (a.sentAt && now() - a.sentAt < 4000)) return 'busy';
    var pool = pools[0], label = G.POOLS[pool].label || pool;
    if (!G.freeToday(P, pool)) return 'busy'; // chắc chắn còn miễn phí mới rút
    a.sentAt = now();
    P.Gateway.cmd('bitich.gacha', { n: 1, poolId: pool }, function (res) {
      if (G.markFree) G.markFree(P, pool); // dù được hay không cũng không thử lại tủ này hôm nay
      if (!res || res.ok === false) { dailyLog('Tàng Kinh', 'Rút ' + label + ' không được: ' + (res && res.why || 'không rõ')); return; }
      var got = gcResult(P, res);
      dailyLog('Tàng Kinh', 'Rút miễn phí ' + label + (got ? ': ' + got : ' xong'));
      if (P.HUD && P.HUD.refreshBag) P.HUD.refreshBag();
    });
    return 'busy';
  }

  /* ================= Nhiệm vụ tông môn (Quản Sự, Bát Quái Thạch Phấn) ================= */
  // Mỗi ngày 3 việc trên sổ của Quản Sự (sect.nv.*). Người dùng tick các việc muốn làm; script lần lượt nhận …
  var SN_LIST = [
    ['chat_cay', 'Đốn Củi Linh Mộc', 'Chặt Cổ Thụ cho rụng 5 cành · tự làm', 'auto'],
    ['linh_chi', 'Hái Nấm Linh Chi', 'Nộp 10 · tự đi nhặt', 'gather'],
    ['phong_linh', 'Thu Phong Linh Thảo', 'Nộp 20 · tự đi nhặt', 'gather'],
    ['tinh_thach', 'Tinh Thạch Trấn Trận', 'Nộp 3 Hàn / Tử / Lục Tinh Thạch · tự đi nhặt', 'gather'],
    ['ca_linh_thu', 'Cá Nuôi Linh Thú', 'Nộp 10 Linh Ngư · tự câu (chậm, ~20 phút)', 'fish'],
    ['yeu_cot', 'Thu Gom Yêu Cốt', 'Nộp 100 Yêu Cốt / Độc Dịch · có dần khi farm', 'farm'],
    ['tru_yeu', 'Trừ Yêu Hộ Tông', 'Hạ 3000 yêu thú · có dần khi farm', 'farm'],
    ['huyen_thiet', 'Quặng Rèn Binh Khí', 'Nộp 500 Huyền Thiết · chỉ nhận khi túi đã đủ', 'have'],
    ['yeu_dan', 'Yêu Đan Luyện Khí', 'Nộp 3 Yêu Đan cấp 2 · chỉ nhận khi túi đã đủ', 'have'],
    ['pha_canh', 'Cống Phá Cảnh Đan', 'Nộp 5 Phá Cảnh Đan · chỉ nhận khi túi đã đủ', 'have'],
    ['to_doi_huyet_sac', 'Tổ Đội Thám Cấm Địa', 'Cần đội 4 người · không tự làm', 'no']
  ];
  var SN_HOW = {};
  SN_LIST.forEach(function (x) { SN_HOW[x[0]] = x[3]; });
  var SN_GATHER = { linh_chi: ['ling_chi_prop'], phong_linh: ['phong_linh_thao'], tinh_thach: ['mach_han_tinh', 'mach_tu_tinh', 'mach_luc_tinh'] };
  function snLog(m) { klog('[Tông môn] ' + m); say('Tông môn: ' + m); }
  function snDefs(P) { return P.Sect && P.Sect.NHIEM_VU || {}; }
  function snNv(P) { return P.QuanSuUI && P.QuanSuUI.nv || null; }
  function snFetch(P, force) {
    var G = P.Gateway;
    if (!P.QuanSuUI || !G || !G.connected || !G.cmd || (!force && now() - (st.snFetchAt || -1e9) < 15000)) return;
    st.snFetchAt = now();
    G.cmd('sect.nv.xem', {}, function (res) { if (res && res.ok && P.QuanSuUI.apDung) P.QuanSuUI.apDung(res.nv); });
  }
  function snHave(P, def) {
    var I = P.Inventory, n = 0;
    (def && def.vat || []).forEach(function (id) { n += I && I.count ? I.count(id) : 0; });
    return n;
  }
  function snCanDo(P, id) {
    var def = snDefs(P)[id], how = SN_HOW[id];
    if (!def || !how || how === 'no') return false;
    return how !== 'have' || snHave(P, def) >= def.can;
  }
  // Việc được chọn còn trên sổ, chưa làm; việc chờ farm để cuối.
  function snPicks(P, nv) {
    var ds = nv && nv.ds || [];
    return SN_LIST.map(function (x) { return x[0]; }).filter(function (id) {
      if (!cfg['sn_' + id]) return false;
      var row = ds.filter(function (r) { return r.id === id; })[0];
      return row && !row.daLam && snCanDo(P, id);
    }).sort(function (a, b) { return (SN_HOW[a] === 'farm') - (SN_HOW[b] === 'farm'); });
  }
  function snDang(P, nv) {
    var d = nv && nv.dang;
    if (!d) return null;
    var def = snDefs(P)[d.id] || d, can = d.can || def.can || 1;
    var co = def.loai === 'nop' ? Math.min(can, snHave(P, def)) : d.co | 0;
    return { d: d, def: def, how: SN_HOW[d.id] || 'no', co: co, can: can, du: !!d.du || co >= can };
  }
  function snDoneToday(nv) { return (nv.soXong | 0) >= ((nv.toiDa | 0) || 3); }
  function snAvail(P) {
    if (!P.Sect || !P.QuanSuUI) return false;
    var nv = snNv(P);
    if (!nv) { snFetch(P); return P.Gateway && P.Gateway.connected ? 'wait' : false; } // đang hỏi sổ việc: chưa biết
    if (!nv.coTong) return false;
    var s = snDang(P, nv);
    if (s) return s.du || s.how === 'auto' || s.how === 'gather' || s.how === 'fish' || s.how === 'no' || s.how === 'have';
    return !snDoneToday(nv) && snPicks(P, nv).length > 0;
  }
  function snEndSub(g) {
    st.gaOverride = null;
    if (st.ga && !cfg.gatherRun) st.ga = null;
    if (g && st.sn && st.sn.fishing && (g.sw.fishing || g.sw.fishingAuto) && g.sw.stopFishing) g.sw.stopFishing();
    if (st.sn) st.sn.fishing = false;
  }
  function snAfter(P, res, what) {
    if (res && res.nv && P.QuanSuUI && P.QuanSuUI.apDung) P.QuanSuUI.apDung(res.nv); else snFetch(P, true);
    snLog(res && res.ok === false ? what + ' không được: ' + (res.why || 'không rõ') : what);
    if (st.sn) { st.sn.sentAt = now() - 3000; st.sn.touches = 0; st.sn.touchAt = 0; }
  }
  function snAtQuanSu(g, a, what, send) {
    a.step = what;
    snEndSub(g);
    if (a.sentAt && now() - a.sentAt < 5000) return 'busy';
    var w = atNpc(g, a, g.P.Sect.NPC, snLog);
    if (w === 'fail') { st.sn = null; return 'fail'; }
    if (w === 'here') { a.sentAt = now(); send(); }
    return 'busy';
  }
  function snChop(g, a, s) {
    a.step = s.def.ten + ' ' + s.co + '/' + s.can;
    var mapId = propMap(g.P, 'co_thu_linh_moc');
    if (!mapId) { snLog('Không tìm thấy Cổ Thụ trong dữ liệu bản đồ'); st.sn = null; return 'fail'; }
    if (g.mapId !== mapId) return jobGo(g, a, mapId, 'Tông môn: đi chặt Cổ Thụ ở ' + mapName(mapId), snLog) ? 'busy' : (st.sn = null, 'fail');
    if (st.travel) stopTravel();
    setAuto(g, false);
    if (g.sw.chopping || (g.P.HUD && g.P.HUD.dialogOpen)) return 'busy';
    if (a.lastCo !== s.co) { a.lastCo = s.co; a.touches = 0; }
    var tree = findHere(g, 'co_thu_linh_moc');
    if (!tree) { snLog('Không thấy Cổ Thụ trong map'); st.sn = null; return 'fail'; }
    var r = touchProp(g, a, tree);
    // Chặt được khi sổ việc đã tải về máy (QuanSuUI.nv); không thì game mở lời tả cây → đóng, xem lại sổ.
    if (r === 'sent' && (!dcDlg || dcDlg.at !== a.touchAt)) dcDlg = { want: 'close', until: now() + 3000, at: a.touchAt };
    if (r === 'fail') { a.touches = 0; a.touchAt = 0; snFetch(g.P, true); }
    return 'busy';
  }
  function snFish(g, a, s) {
    a.step = s.def.ten + ' ' + s.co + '/' + s.can;
    var r = fishAt(g, a, 'Tông môn: đi câu Linh Ngư', snLog);
    if (r === 'fail') st.sn = null;
    return r;
  }
  // Tới chỗ câu (Hồ Bích Thủy / Suối Dược Cốc), chạm mặt nước, chọn "Tự động câu" như bấm tay. 'busy' | 'fail'.
  function fishAt(g, a, why, logf) {
    var sw = g.sw, T = g.P.Targeting;
    setAuto(g, false);
    if (sw.fishing || sw.fishingAuto) { a.fishing = true; return 'busy'; }
    var id = cfg.fishSpot && propMap(g.P, cfg.fishSpot) ? cfg.fishSpot : DC_WATERS.filter(function (w) { return propMap(g.P, w); })[0];
    var mapId = id && propMap(g.P, id);
    if (!mapId) { logf('Không tìm thấy chỗ câu cá'); return 'fail'; }
    if (g.mapId !== mapId) return jobGo(g, a, mapId, why + ' ở ' + mapName(mapId), logf) ? 'busy' : 'fail';
    if (st.travel) stopTravel();
    var w = findHere(g, id);
    if (!w || (g.P.HUD && g.P.HUD.dialogOpen)) return 'busy';
    if (!inPropReach(g, w)) {
      if (!(g.me.path && g.me.path.length && now() - a.routeAt < 3000)) { var r = harvestRoute(g, w); if (r) { g.me.setPath(r.path); a.routeAt = now(); } }
      return 'busy';
    }
    if (a.touchAt && now() - a.touchAt < DC_REPLY_MS) return 'busy';
    var key = 'scn:' + w.id;
    if (T && T.list && T.list.some(function (e) { return e.key === key; })) { T.key = key; T.manual = true; }
    if (!T || T.key !== key) return 'busy';
    if (g.me.path && g.me.path.length) g.me.path.length = 0;
    a.touchAt = now();
    dcDlg = { want: 'fish', until: now() + DC_DLG_MS, at: a.touchAt };
    g.P.Input.pressInteract();
    return 'busy';
  }

  /* ================= Câu cá săn Linh Ngư ================= */
  // Theo hệ thống câu cá của game (PNTT.Fishing): mỗi lần thả chờ 3–6 giây, 80% dính cá, trong đó 5% là Linh Ngư (còn …
  var FISH_ITEM = 'linh_ngu', FISH_COMMON = 'ca_song';
  function fishLog(m) { klog('[Câu cá] ' + m); say('Câu cá: ' + m); }
  function fishCount(P) { return P.Inventory && P.Inventory.count ? P.Inventory.count(FISH_ITEM) : 0; }
  // Ước lượng thời gian câu thêm k Linh Ngư: ~5s một lần thả, 80% dính × 5% Linh Ngư ≈ 25 lần / con.
  var FISH_CAST_S = 5;
  function fishEta(k) {
    var F = window.PNTT && window.PNTT.Fishing, per = F && F.CATCH_RATE && F.SPIRIT_FISH_RATE ? 1 / (F.CATCH_RATE * F.SPIRIT_FISH_RATE) : 25;
    var sec = Math.max(0, k) * per * FISH_CAST_S;
    return sec >= 3600 ? (sec / 3600).toFixed(1).replace('.0', '') + ' giờ' : Math.max(1, Math.round(sec / 60)) + ' phút';
  }
  function fishWant(P) { return !(cfg.fishGoal > 0) || fishCount(P) < cfg.fishGoal; }
  function fishOff() { if (cfg.fishRun) { cfg.fishRun = false; save(); if (ui.root) syncInputs(); } }
  function fishStop(g, msg) {
    var a = st.fish;
    st.fish = null;
    if (g && (g.sw.fishing || g.sw.fishingAuto) && g.sw.stopFishing) g.sw.stopFishing();
    if (msg) fishLog(msg);
    if (a && a.back && g && (g.mapId !== a.back.map || dist(g.me.x, g.me.y, a.back.x, a.back.y) > BACK_NEAR || (a.back.khu && gaKhu(g.P) !== a.back.khu))) goBack(a.back.map, a.back.x, a.back.y, 'Câu cá xong → về chỗ farm', 'fish', a.back.khu);
  }
  function tickFish(g) {
    var on = cfg.planRun ? planIs('fish') : cfg.fishRun, P = g.P;
    if (!on) { if (st.fish) fishStop(g); return false; }
    // Việc khác chen ngang (chăm vườn, Dược Công, nhặt NL, săn hồn; boss / Thương Đội / biến dị / xổng chuồng / hoạt động
    // thì vòng chính đã cho chúng chạy trước): thôi câu, giữ việc câu lại — làm xong việc kia, về chỗ câu thì câu tiếp.
    if (st.dc || st.ga || st.fa || st.hon || st.bh || st.bd || st.xc || st.td || st.ll || st.ht || st.tl || st.vn) {
      if ((g.sw.fishing || g.sw.fishingAuto) && g.sw.stopFishing) g.sw.stopFishing();
      if (st.fish) st.fish.step = 'tạm dừng để ' + (st.fa ? 'chăm vườn' : st.dc ? 'làm Dược Công' : st.ga ? 'nhặt nguyên liệu' : st.hon ? 'săn hồn' :
        st.bh ? 'đánh boss' : st.td ? 'săn Thương Đội' : st.bd ? 'đánh biến dị' : st.xc ? 'săn xổng chuồng' : 'đi hoạt động') + ', xong câu tiếp';
      return false;
    }
    if (st.fish && st.fish.paused) { fishLog('Xong việc chen ngang → quay lại câu tiếp'); st.fish.paused = false; st.fish.touches = 0; st.fish.touchAt = 0; st.fish.travels = 0; }
    if (!P.Fishing || !P.Inventory) { fishLog('Bản game này không có câu cá'); fishOff(); return false; }
    var a = st.fish;
    if (!fishWant(P)) { fishStop(g, 'Đã đủ ' + cfg.fishGoal + ' Linh Ngư' + (a ? ' (+' + (fishCount(P) - a.start) + ' con lượt này)' : '') + ' → thôi câu'); fishOff(); return false; }
    if (P.Inventory.canFit && !P.Inventory.canFit(FISH_COMMON) && !P.Inventory.canFit(FISH_ITEM)) { fishStop(g, 'Túi đầy → thôi câu (dọn túi rồi bật lại)'); fishOff(); return false; }
    if (!a) {
      a = st.fish = { touches: 0, touchAt: 0, routeAt: 0, travels: 0, at: now(), back: takeBack(g), start: fishCount(P), fishStart: P.Inventory.count(FISH_COMMON), step: '' };
      fishLog('Đi câu Linh Ngư · đang có ' + a.start + (cfg.fishGoal > 0 ? '/' + cfg.fishGoal : ''));
    }
    // Có con đang đánh CHÍNH MÌNH: dừng câu, đánh đúng con đó, hạ xong câu tiếp (quái đi ngang / đuổi người khác thì kệ).
    var foe = engagedBy(g);
    // Một lần câu ~5s (chờ 3–6s rồi máy chủ báo dính cá): sắp cuốn câu mà máu còn khá thì cuốn xong đã rồi mới quay ra đánh.
    var fs0 = g.sw.fishing;
    if (foe && fs0 && fs0.duration - fs0.t < 1.2 && g.me.hpMax && g.me.hp / g.me.hpMax > 0.5) { a.step = 'sắp cuốn câu · cuốn xong rồi đánh'; return true; }
    if (foe) {
      if ((g.sw.fishing || g.sw.fishingAuto) && g.sw.stopFishing) { g.sw.stopFishing(); fishLog('Bị ' + (foe.def ? mobLabel(foe) : 'người chơi') + ' đánh → dừng câu, hạ nó rồi câu tiếp'); }
      a.step = 'đánh ' + (foe.def ? mobLabel(foe) : 'người chơi') + ' đang đánh mình rồi câu tiếp';
      if (foe.def) evPin(g, foe);
      setAuto(g, true);
      return false;
    }
    var r = fishAt(g, a, 'Câu cá: đi câu Linh Ngư', fishLog);
    if (r === 'fail') { fishStop(g, 'Không câu được → thôi'); fishOff(); return false; }
    var n = fishCount(P);
    a.step = (g.sw.fishing || g.sw.fishingAuto ? 'đang tự động câu' : 'tới chỗ câu') + ' · Linh Ngư ' + n + (cfg.fishGoal > 0 ? '/' + cfg.fishGoal + ' (còn ~' + fishEta(cfg.fishGoal - n) + ')' : '') +
      ' · lượt này +' + (n - a.start) + ' Linh Ngư, +' + Math.max(0, P.Inventory.count(FISH_COMMON) - a.fishStart) + ' Cá Sông';
    return true;
  }
  // 'busy' · 'run' (để phần nhặt nguyên liệu chạy) · 'done' (xong / chờ farm) · 'fail'
  function tickSect(g) {
    var P = g.P, Sx = P.Sect, nv = snNv(P);
    if (!Sx || !P.QuanSuUI || !P.Gateway || !P.Gateway.connected) return 'done';
    var a = st.sn || (st.sn = { touches: 0, touchAt: 0, routeAt: 0, travels: 0, at: now(), sentAt: 0, step: '' });
    if (!nv) { snFetch(P); a.step = 'xem sổ việc'; if (now() - a.at > 15000) { st.sn = null; return 'fail'; } return 'busy'; }
    if (!nv.coTong) { snLog('Chưa vào tông môn nào → bỏ qua'); st.sn = null; return 'done'; }
    var s = snDang(P, nv);
    if (s) {
      if (s.du) return snAtQuanSu(g, a, 'nộp ' + s.def.ten, function () {
        if (g.sw.stopFishing && (g.sw.fishing || g.sw.fishingAuto)) g.sw.stopFishing();
        P.Gateway.cmd('sect.nv.nop', { requestId: 'tt' + Date.now().toString(36) }, function (res) { snAfter(P, res, 'Nộp ' + s.def.ten); });
      });
      if (s.how === 'auto') return snChop(g, a, s);
      if (s.how === 'gather') {
        a.step = s.def.ten + ' ' + s.co + '/' + s.can;
        st.gaOverride = { types: SN_GATHER[s.d.id] || [], items: s.def.vat || [], until: s.can, why: 'Tông môn' };
        return 'run';
      }
      if (s.how === 'fish') return snFish(g, a, s);
      if (s.how === 'farm') { a.step = s.def.ten + ' ' + s.co + '/' + s.can + ' · có dần khi farm'; snEndSub(g); return 'done'; }
      return snAtQuanSu(g, a, 'bỏ ' + s.def.ten, function () {
        P.Gateway.cmd('sect.nv.bo', {}, function (res) { snAfter(P, res, 'Bỏ việc ' + s.def.ten + ' (không tự làm được, chưa mất lượt)'); });
      });
    }
    if (snDoneToday(nv)) { if (!a.doneLogged) snLog('Hôm nay đã xong ' + nv.soXong + '/' + nv.toiDa + ' việc'); st.sn = null; return 'done'; }
    var pick = snPicks(P, nv)[0];
    if (!pick) { st.sn = null; return 'done'; }
    var def = snDefs(P)[pick];
    return snAtQuanSu(g, a, 'nhận ' + def.ten, function () {
      P.Gateway.cmd('sect.nv.nhan', { id: pick }, function (res) { snAfter(P, res, 'Nhận việc ' + def.ten); });
    });
  }

  /* ================= Vận Tiêu (áp tải xe, từ Trúc Cơ) ================= */
  // Huấn Sư Huynh ở Thanh Trúc Lâm → "Nhận Tiêu" (400 Linh Thạch, 3 chuyến/ngày). Kéo xe đi bộ theo đúng …
  var VT_STONE_PAD = 50, VT_KEEP = 150, VT_FAR = 210, VT_PORTAL_KEEP = 80, VT_GIVE_KEEP = 90, VT_LAND_R = 220;
  function vtThreats(g, cart) {
    if (!cart || !cart.m) return [];
    var me = g.me, cm = cart.m;
    var hostiles = hostilePlayers(g).filter(function (r) {
      return dist(r.x, r.y, cm.x, cm.y) <= 260 || dist(r.x, r.y, me.x, me.y) <= 260;
    });
    if (hostiles.length > 0) return hostiles;
    return mobsAlive(g).filter(function (m) {
      if (!m || m.dead || !m.def || m.def.tieuXa) return false;
      var dToCart = dist(m.x, m.y, cm.x, cm.y);
      var dToMe = dist(m.x, m.y, me.x, me.y);
      var aggroCart = dToCart <= (m.def.hitRadius || 30) + 80 && (m.state === 'attack' || m.state === 'chase' || m.attackState === 'telegraph');
      var aggroMe = dToMe <= (m.def.hitRadius || 30) + 40 && (m.state === 'attack' || m.attackState === 'telegraph');
      return aggroCart || aggroMe;
    }).sort(function (a, b) {
      return dist(cm.x, cm.y, a.x, a.y) - dist(cm.x, cm.y, b.x, b.y);
    });
  }
  function vtCanFly(g) {
    var me = g.me, PL = g.P.Player;
    if (me.flying || me.downed || me.state === 'sit' || st.healing || busyUI(g.P) || !g.P.Input.pressFlyToggle) return false;
    if (PL.canFly && !PL.canFly(me)) return false;
    if (PL.inNoFlyZone && PL.inNoFlyZone(me, g.sw.map)) return false;
    return now() - st.lastFlyPress >= FLY_RETRY_MS;
  }
  function vtLog(m) { klog('[Vận Tiêu] ' + m); say('Vận Tiêu: ' + m); }
  function vtChuyen(P) { return P && P.VanTieuUI && P.VanTieuUI.chuyen || null; }
  function vtActive(g) { return !!(g && vtChuyen(g.P)); }
  // Boss / hoạt động có bị Vận Tiêu giữ chân không: đang đi nhận tiêu thì không; đang kéo xe thì tuỳ prioVt.
  function vtBusy(g) { return !cfg.prioVt && vtActive(g); }
  function vtVnHour(P) {
    var V = P && P.VanTieu;
    return (V && V.gioVN) ? V.gioVN(Date.now()) : new Date(Date.now() + 252e5).getUTCHours();
  }
  function vtVnDay(P) {
    var V = P && P.VanTieu;
    return (V && V.day) ? V.day(Date.now()) : new Date(Date.now() + 252e5).toISOString().slice(0, 10);
  }
  function vtWhyNot(P) {
    var V = P.VanTieu;
    if (!V || !V.conLuotVan) return 'game chưa có Vận Tiêu';
    if (!(P.Gateway && P.Gateway.connected)) return 'chưa nối máy chủ';
    if (!V.daTrucCo(P)) return 'chưa tới Trúc Cơ';
    if (V.dangMo && !vtChuyen(P) && !V.dangMo(Date.now())) return 'ngoài giờ nhận tiêu (' + (V.GIO_MO || 11) + 'h–' + (V.GIO_DONG || 22) + 'h)';
    if (V.conLuotVan(P.Quest && P.Quest.flags || {}, Date.now()) <= 0) return 'hết lượt hôm nay';
    if ((P.Progress && P.Progress.stones | 0) < V.PHI + VT_STONE_PAD) return 'thiếu Linh Thạch (phí ' + V.PHI + ')';
    if (P.Gateway.coDenBuoc) return 'đang bị cắm cờ đen (Sát Nghiệp nặng)';
    return '';
  }
  function vtAvail(P) { return !!vtChuyen(P) || !vtWhyNot(P); }
  function vtCart(g) {
    var me = g.me, best = null;
    (g.sw.enemies || []).forEach(function (m) {
      if (!m || m.dead || !m.def || !m.def.tieuXa) return;
      var d = dist(me.x, me.y, m.x, m.y);
      if (!best || d < best.d) best = { m: m, d: d };
    });
    return best;
  }
  function vtLeft(P) {
    var V = P.VanTieu, I = P.Quest && P.Quest.flags || {};
    return V && V.conLuotVan ? V.conLuotVan(I, Date.now()) : 0;
  }
  function vtQuietKhu(g) {
    var P = g.P, n = gaSoKhu(P);
    if (n <= 1) return 1;
    if (khuList && khuList.mapId === g.mapId && Array.isArray(khuList.dem) && khuList.dem.length) {
      var minCount = 999999, bestKhu = n;
      for (var i = n - 1; i >= 0; i--) {
        var count = khuList.dem[i] | 0;
        if (count < minCount) { minCount = count; bestKhu = i + 1; }
      }
      return bestKhu;
    }
    return n;
  }
  function tickVanTieu(g) {
    var P = g.P, V = P.VanTieu, me = g.me, ch = vtChuyen(P);
    if (!V || !V.TUYEN) return 'done';
    var a = st.vt || (st.vt = { touches: 0, touchAt: 0, routeAt: 0, travels: 0, at: now(), step: '', had: false, trips: 0 });
    if (!ch) {
      if (a.had) { a.had = false; a.trips++; a.at = now(); a.travels = 0; a.touches = 0; a.touchAt = 0; }
      var why = vtWhyNot(P);
      if (why) { vtLog(a.trips ? 'Xong ' + a.trips + ' chuyến · ' + why : 'Không áp tiêu: ' + why); st.vt = null; return 'done'; }
      if (now() - a.at > 4 * 60000) { vtLog('Quá 4 phút chưa nhận được xe → để sau'); st.vt = null; return 'fail'; }
      setAuto(g, false);
      // Chỉ lúc kéo xe mới phải đi bộ: đi nhận xe (cả lúc vừa giao xong quay về) thì bay, tới gần Huấn Sư Huynh mới hạ cánh.
      var npcN = g.mapId === V.MAP_NHAN && findHere(g, V.NPC_NHAN), cN = npcN && propCenter(g, npcN), nearN = !!(cN && dist(me.x, me.y, cN.x, cN.y) <= VT_LAND_R);
      if (me.flying && nearN) { if (now() - st.lastFlyPress > 1500) { st.lastFlyPress = now(); P.Input.pressFlyToggle(); } a.step = 'hạ cánh để nhận xe'; return 'busy'; }
      if (!me.flying && !nearN && vtCanFly(g)) { st.lastFlyPress = now(); P.Input.pressFlyToggle(); }

      // 1. Tự chuyển sang khu vắng nhất trước khi nhận tiêu để tránh 100% bị người chơi khác cướp tiêu
      if (cfg.vtQuietKhu !== false && g.mapId === V.MAP_NHAN && gaSoKhu(P) > 1) {
        if (!khuList || khuList.mapId !== g.mapId || now() - khuListAt > 60000) {
          if (now() - (a.khuAskAt || 0) > 4000) {
            a.khuAskAt = now();
            if (P.Gateway && P.Gateway.send) P.Gateway.send({ op: 'khu', act: 'xem' });
          }
        }
        var quietKhu = vtQuietKhu(g);
        if (gaKhu(P) !== quietKhu) {
          if (!a.khuWant) {
            a.khuWant = quietKhu; a.khuAt = 0; a.touches = 0; a.touchAt = 0;
            vtLog('Đang ở khu ' + gaKhu(P) + '/' + gaSoKhu(P) + ' → đổi ngầm sang khu ' + quietKhu + ' vắng vẻ trước khi nhận tiêu để tránh cướp');
          }
          a.step = 'đổi ngầm sang khu vắng (' + quietKhu + '/' + gaSoKhu(P) + ') để tránh cướp';
          // Gửi lệnh ngầm qua Gateway trước (chuyển trong ~200ms không cần chạy tới Bảng Khu)
          if (P.Gateway && P.Gateway.connected && P.Gateway.send) {
            if (!a.directSendAt || now() - a.directSendAt > 2000) {
              a.directSendAt = now();
              P.Gateway.send({ op: 'khu', act: 'chon', khu: quietKhu });
            }
          }
          if (now() - (a.directSendAt || 0) < 1200) return 'busy';
          if (khuGo(g, a, '[Vận Tiêu]')) return 'busy';
        }
      }
      a.khuWant = 0;

      a.step = (me.flying ? 'bay về ' : 'về ') + 'nhận xe ở ' + mapName(V.MAP_NHAN) + ' (còn ' + vtLeft(P) + ' chuyến)';
      if (!npcTalk(g, a, V.NPC_NHAN, 'vtnhan', vtLog)) { st.vt = null; return 'fail'; }
      return 'busy';
    }
    if (!a.had) { a.had = true; a.travels = 0; a.touches = 0; a.touchAt = 0; vtLog('Nhận ' + (V.tenHang ? V.tenHang(ch.hang) : 'xe') + ' → kéo tới Bảnh Tiên Sinh (' + mapName(V.MAP_GIAO) + ')'); }
    setAuto(g, false);
    var cart = vtCart(g);

    // 2. Hộ tiêu: phát hiện quái/người cắn xe → ưu tiên tiêu diệt, bật giáp và chờ xe hồi máu an toàn
    if (cfg.vtGuardCart !== false && cart && cart.m) {
      var threats = vtThreats(g, cart);
      if (threats.length > 0) {
        var foe = threats[0];
        if (st.travel) stopTravel();
        a.step = 'hộ tiêu: diệt ' + (foe.ten || foe.name || (foe.def && foe.def.name) || 'mục tiêu cắn xe');
        if (cart.m.hp < cart.m.hpMax * 0.9) talUse(g, 'kim_giap', 'bảo vệ xe tiêu');
        evEngage(g, a, foe);
        return 'busy';
      }
      // Sau khi diệt xong hiểm hoạ: nếu xe mất máu thì đứng chờ an toàn để game tự hồi phục đầy máu (HOI_AN_TOAN_DPS)
      if (cart.m.hp < cart.m.hpMax * 0.92) {
        if (!a.healWaitAt) a.healWaitAt = now();
        if (now() - a.healWaitAt < 15000) {
          a.step = 'chờ xe hồi máu an toàn (' + Math.round(cart.m.hp / cart.m.hpMax * 100) + '%)';
          if (st.travel) stopTravel();
          if (me.path && me.path.length) me.path.length = 0;
          return 'busy';
        }
      } else {
        a.healWaitAt = 0;
      }
    }

    // 3. Giữ khoảng cách kéo xe (chống đứt dây kéo DAY_KEO = 320px)
    if (cart && cart.d > VT_KEEP) {
      a.step = 'chờ xe theo kịp (cách ' + Math.round(cart.d) + 'px)';
      if (st.travel) stopTravel();
      if (cart.d > VT_FAR) {
        if (!(me.path && me.path.length && now() - a.routeAt < 1500)) { var rb = spotCheck(g).route(cart.m.x, cart.m.y); if (rb) { me.setPath(rb.path); a.routeAt = now(); } }
      } else if (me.path && me.path.length) me.path.length = 0;
      return 'busy';
    }
    if (g.mapId === V.MAP_GIAO) {
      if (st.travel) stopTravel();
      if (cart && cart.d > VT_GIVE_KEEP && npcNear(g, V.NPC_GIAO)) { a.step = 'chờ xe sát bên để giao'; if (me.path && me.path.length) me.path.length = 0; return 'busy'; }
      a.step = 'giao hàng cho Bảnh Tiên Sinh';
      if (!npcTalk(g, a, V.NPC_GIAO, 'vtgiao', vtLog)) { a.touches = 0; a.touchAt = 0; }
      return 'busy';
    }
    var idx = V.TUYEN.indexOf(g.mapId), next = idx >= 0 ? V.TUYEN[idx + 1] : V.MAP_NHAN;
    a.step = 'kéo xe sang ' + mapName(next) + (cart ? ' · xe cách ' + Math.round(cart.d) + 'px' : '');
    // 4. Qua cổng an toàn: chờ xe sát cổng (<= 80px) mới bước qua cổng để không bị kẹt xe bên kia map
    var pt = portalTarget(g, next)[0];
    var portalKeep = cfg.vtSafePortal !== false ? VT_PORTAL_KEEP : 140;
    if (pt && pt.d < 100 && cart && cart.d > portalKeep) {
      a.step = 'chờ xe sát rồi mới qua cổng sang ' + mapName(next) + ' (xe cách ' + Math.round(cart.d) + 'px)';
      if (st.travel) stopTravel();
      if (me.path && me.path.length) me.path.length = 0;
      return 'busy';
    }
    if (!st.travel || st.travel.map !== next) startTravel(next, null, null, 'Vận Tiêu: kéo xe sang ' + mapName(next));
    tickTravel(g);
    return 'busy';
  }

  /* ================= Thương Đội (Thiên Đạo báo): săn Tiêu Sư / Thương Nhân lấy Oán Hồn ================= */
  // "Một Thương Đội vừa lên đường qua <map>, có Tiêu Sư hộ tống…": Oán Hồn chỉ có từ Thương Nhân và Tiêu Sư của …
  var TD_EVENT_MS = 12 * 60000, TD_MAX_MS = 12 * 60000;
  var tdEvents = [];
  // "… lên đường qua Thảo Dược Cốc – khu 1, có Tiêu Sư…" (từ 16/10 Thiên Đạo báo cả khu) hoặc kiểu cũ chỉ có map.
  // Từ bản cập nhật 20/10 Thiên Đạo báo trước 20 giây ("… sắp lên đường qua …") rồi đoàn mới hiện → nhận cả hai kiểu.
  var TD_NEWS_RE = /mot thuong doi (?:vua |sap |se |chuan bi )?(?:len duong|xuat phat|di) qua ([^,!.]+?(?:\s*[-–—,]\s*khu\s*\d+)?)(?=\s*[,!.]|\s+(?:sau|trong|nua)\b|$)/;
  var TD_SPAWN_DELAY_MS = 20000;
  function tdLog(m) { klog('[Thương Đội] ' + m); say('Thương Đội: ' + m); }
  // Ma Đạo (Hồn Phiên) săn Thương Nhân / Tiêu Sư lấy Oán Hồn; Chính Đạo (Kiếm Hạp) săn Kiếp Tặc chặn đoàn lấy Hiệp
  // Nghĩa Lệnh. Đánh Tiêu Sư trước (cận chiến, giữ Thương Nhân), rồi tới gần nhất.
  function tdTargets(g) {
    var P = g.P, k = tdKind(P), me = g.me;
    return (g.sw.enemies || []).filter(function (m) {
      if (!m || !m.def || !m.def.human || !honCanHit(P, m)) return false;
      return k === 'chinh' ? m.type === 'kiep_tac' : m.def.hon === 'oan_hon';
    }).sort(function (a, b) {
      var ta = a.type === 'tieu_su' ? 0 : 1, tb = b.type === 'tieu_su' ? 0 : 1;
      return ta - tb || dist(me.x, me.y, a.x, a.y) - dist(me.x, me.y, b.x, b.y);
    });
  }
  function tdWantMa(P) {
    var L = P.LuyenQuy, s = L && honState(P);
    if (!s || !s.phien) return false;
    var need = honNext(P, s), oan = need && need.filter(function (x) { return x.id === 'oan_hon'; })[0];
    var tgt = honSellTarget(s, need, 'oan_hon'); // săn thêm Oán Hồn để bán chợ
    if (!(oan && oan.co < oan.can) && !(tgt && (s.oan | 0) < tgt)) return false;
    var cap = (s.moc && s.moc.tenDo) || 20;
    return cfg.honAllowRed || (s.nghiep | 0) + HON_KILL_NGHIEP.oan_hon < cap;
  }
  function tdWantChinh(P) {
    var CD = P.ChinhDao;
    if (!CD || !CD.coHap || !CD.coHap(P) || !CD.congThucCon || !CD.conKeTiep) return false;
    var k = CD.conKeTiep(P, 0);
    if (CD.tran && k > CD.tran(P)) return false;
    var x = CD.congThucCon(k).filter(function (r) { return r.id === CD.HIEP_NGHIA; })[0];
    return !!x && (P.Inventory && P.Inventory.count ? P.Inventory.count(x.id) : 0) < x.can;
  }
  function tdKind(P) {
    var s = honState(P);
    if (s) {
      if (s.dao === 'chinh' || s.hap) return 'chinh';
      if (s.dao === 'ma' || s.phien) return 'ma';
      if (s.dao) return s.dao;
    }
    return tdWantMa(P) ? 'ma' : tdWantChinh(P) ? 'chinh' : '';
  }
  function tdWant(P) { return !!tdKind(P); }
  // Tin Thiên Đạo báo đoàn đã xong (bị hạ / bị cướp / tan / tới nơi): khỏi đi dò từng khu tìm nữa.
  var TD_DONE_RE = /da ha|bi ha|ha guc|tieu diet|bi cuop|cuop sach|cuop duoc|tan ra|tan tac|giai tan|danh tan|bi diet|den noi|toi noi|ket thuc/;
  function tdDoneText(t) { return /thuong doi|thuong nhan|tieu su/.test(t) && !/(?:vua|sap|se|chuan bi) len duong/.test(t) && TD_DONE_RE.test(t); }
  function tdSame(e, map, khu) { return (!map || e.map === map) && (!khu || !e.khu || e.khu === khu); }
  function tdMarkDone(P, t) {
    var map = mapByName(P, t), khu = newsKhu(t), hit = 0;
    tdEvents.forEach(function (e) { if (!e.done && tdSame(e, map, khu)) { e.done = true; hit++; } });
    klog('[Thương Đội] Thiên Đạo: đoàn ' + (map ? 'ở ' + mapName(map) + (khu ? ' khu ' + khu : '') + ' ' : '') + 'đã xong (bị hạ / cướp / tới nơi)' + (hit ? ' → thôi tìm' : ''));
  }
  // Lịch sử khung chat (các dòng đã hiện trên màn hình): sau tin "lên đường qua <map>" mà đã có tin đoàn xong thì
  // coi như đoàn đó không còn. Dòng chat không có giờ nên so theo thứ tự.
  function tdHistoryDone(P, ev) {
    var lines = [], start = -1, done = -1;
    try { lines = Array.prototype.slice.call(document.querySelectorAll('.chat-line')); } catch (e) { return false; }
    lines.forEach(function (el, i) {
      var who = el.querySelector && el.querySelector('.chat-who'), w = who ? plainVi(who.textContent) : '';
      if (w && w !== 'thien dao') return;
      var t = plainVi(el.textContent || ''), pl = tdParse(P, t);
      if (pl) { if (pl.map === ev.map && (!ev.khu || !pl.khu || pl.khu === ev.khu)) start = i; }
      else if (tdDoneText(t) && tdSame(ev, mapByName(P, t), newsKhu(t))) done = i;
    });
    return done > start && start >= 0;
  }
  function tdRoute(P, map) {
    var T = P.VanTieu && P.VanTieu.TUYEN || [], i = T.indexOf(map);
    return i >= 0 ? T.slice(i, i + 2) : [map];
  }
  // Map có chỗ sinh Thương Đội (thuongDoi trong dữ liệu bản đồ) và điểm giữa các chỗ đó: đoàn hiện ra ở đây.
  var tdMapsCache = null;
  function tdMaps(P) {
    if (tdMapsCache) return tdMapsCache;
    var out = {}, MD = P.MapData || {}, T = P.CONFIG.TILE || 32;
    Object.keys(MD).forEach(function (k) {
      var m = MD[k];
      if (!m || typeof m !== 'object' || typeof m.id !== 'string' || out[m.id] || !Array.isArray(m.enemies)) return;
      var pts = m.enemies.filter(function (e) { return e && e.thuongDoi && isFinite(e.tx) && isFinite(e.ty); });
      if (!pts.length) return;
      var x = 0, y = 0;
      pts.forEach(function (e) { x += (e.tx + 0.5) * T; y += (e.ty + 1) * T; });
      out[m.id] = { map: m.id, x: x / pts.length, y: y / pts.length };
    });
    if (Object.keys(out).length) tdMapsCache = out;
    return out;
  }

  // Đuổi theo mục tiêu đã nhắm: người phàm chạy ra khỏi tầm nhìn (máy chủ xoá khỏi danh sách) thì tới chỗ …
  var TD_CHASE_MS = 120000, TD_PORTAL_NEAR = 160, TD_LOOK_MS = 8000, TD_LEAD_S = 1.2;
  var TD_JUMP_PX = 250, TD_VMAX = 260;
  function tdNote(g, d, t) {
    var L = d.last && d.last.obj === t ? d.last : { first: now() };
    // Lúc qua cổng, toạ độ có thể nhảy sang toạ độ map bên kia trước khi bị xoá: giữ chỗ thấy cuối cùng bên này.
    if (L.obj === t && L.map === g.mapId && now() - L.at < 1000 && dist(L.x, L.y, t.x, t.y) > TD_JUMP_PX) return;
    var vx = t._vx || 0, vy = t._vy || 0, v = Math.sqrt(vx * vx + vy * vy);
    if (v > TD_VMAX) { vx *= TD_VMAX / v; vy *= TD_VMAX / v; }
    L.obj = t; L.name = mobLabel(t); L.x = t.x; L.y = t.y; L.vx = vx; L.vy = vy;
    L.map = g.mapId; L.at = now(); L.via = null; L.lookAt = 0; L.arriveAt = 0;
    if (!L.first) L.first = now();
    d.last = L;
  }
  // Cổng nó vừa chui qua: cổng gần chỗ thấy lần cuối, hoặc gần chỗ nó sắp tới theo hướng đang chạy.
  function tdPortalOf(g, L) {
    var T = g.P.CONFIG.TILE || 32, px = L.x + L.vx * TD_LEAD_S, py = L.y + L.vy * TD_LEAD_S, best = null;
    (g.sw.map.portals || []).forEach(function (p) {
      if (!p || !p.toMap) return;
      var x = (p.tx + 0.5) * T, y = (p.ty + 0.5) * T, d = Math.min(dist(L.x, L.y, x, y), dist(px, py, x, y));
      if (d <= TD_PORTAL_NEAR && (!best || d < best.d)) best = { toMap: p.toMap, x: x, y: y, d: d };
    });
    return best;
  }
  function tdChase(g, d) {
    var L = d.last, me = g.me, P = g.P;
    if (!L || now() - L.at > TD_CHASE_MS) return false;
    setAuto(g, false);
    if (L.via && g.mapId === L.via) {
      // Vừa qua cổng theo: tìm quanh cửa vào, không thấy thì tới chỗ sinh Thương Đội của map này.
      if (!L.arriveAt) {
        L.arriveAt = now();
        var cm = tdMaps(P)[g.mapId];
        L.map = g.mapId; L.x = cm ? cm.x : me.x; L.y = cm ? cm.y : me.y; L.vx = L.vy = 0; L.via = null; L.at = now(); L.lookAt = 0;
        tdLog('Sang ' + mapName(g.mapId) + ' → tìm ' + L.name);
      }
    }
    if (L.via || g.mapId !== L.map) {
      var to = L.via || L.map;
      d.step = 'đuổi ' + L.name + ' sang ' + mapName(to);
      if (!st.travel || st.travel.map !== to) { startTravel(to, null, null, 'Thương Đội: đuổi ' + L.name + ' sang ' + mapName(to)); st.travel.rush = true; }
      tickTravel(g);
      return true;
    }
    var pt = tdPortalOf(g, L);
    if (pt) {
      L.via = pt.toMap; L.arriveAt = 0;
      tdLog(L.name + ' chạy qua cổng sang ' + mapName(pt.toMap) + ' → đuổi theo');
      d.step = 'đuổi ' + L.name + ' sang ' + mapName(pt.toMap);
      startTravel(pt.toMap, null, null, 'Thương Đội: đuổi ' + L.name + ' sang ' + mapName(pt.toMap));
      st.travel.rush = true;
      tickTravel(g);
      return true;
    }
    if (st.travel) stopTravel();
    var gx = L.x + L.vx * TD_LEAD_S, gy = L.y + L.vy * TD_LEAD_S;
    if (dist(me.x, me.y, gx, gy) > 60) {
      d.step = 'đuổi ' + L.name + ' (ra khỏi tầm nhìn, cách ' + Math.round(dist(me.x, me.y, gx, gy)) + 'px)';
      if (!(me.path && me.path.length && now() - d.routeAt < 600)) {
        var sc = spotCheck(g), r = sc.route(gx, gy) || sc.route(L.x, L.y);
        if (r) { if (me.state === 'sit') P.Player.stand(me); me.setPath(r.path); d.routeAt = now(); }
        else { L.vx = L.vy = 0; if (!sc.route(L.x, L.y)) L.x = me.x, L.y = me.y; }
      }
      return true;
    }
    // Tới chỗ đoán mà chưa thấy: đứng nhìn một lúc rồi thôi.
    if (!L.lookAt) L.lookAt = now();
    d.step = 'tìm ' + L.name + ' quanh đây';
    return now() - L.lookAt < TD_LOOK_MS;
  }

  function tdFinish(g, msg) {
    var d = st.td;
    st.td = null;
    st.lastTdResult = msg;
    if (tgRec && tgRec.k === 'td') tgAdd(tgRec, 'Hoàn thành: ' + msg);
    tdLog(msg);
    if (st.farmTarget && st.farmTarget.def && st.farmTarget.def.human) releaseTarget(g);
    if (d && d.back && (g.mapId !== d.back.map || dist(g.me.x, g.me.y, d.back.x, d.back.y) > BACK_NEAR || (d.back.khu && gaKhu(g.P) !== d.back.khu))) goBack(d.back.map, d.back.x, d.back.y, 'Xong Thương Đội → về chỗ farm', 'td', d.back.khu);
    return false;
  }

  /* ================= Tự hủy trạng thái treo (stale state timeout) ================= */
  var STALE_CHECK_INTERVAL_MS = 2000; // kiểm tra trạng thái treo mỗi 2s
  var lastStaleCheckAt = 0;
  function checkStaleStates(g, force) {
    if (!g) return;
    var t = now();
    if (!force && t - lastStaleCheckAt < STALE_CHECK_INTERVAL_MS) return;
    lastStaleCheckAt = t;

    // 1. World Boss (st.bh)
    if (st.bh) {
      if (!st.bh.at) st.bh.at = t;
      else if (t - st.bh.at > BH_MAX_MS) {
        var b = st.bh.b;
        var bName = b ? bhName(g.P, b) : 'Boss';
        bhFinish(g, 'Quá hạn ' + Math.round(BH_MAX_MS / 60000) + ' phút (tự hủy trạng thái treo boss ' + bName + ')', BH_SKIP_MS);
      } else if (st.bh.phase === 'loot' && st.bh.killAt && (t - st.bh.killAt > BH_LOOT_MS + 10000)) {
        bhFinish(g, 'Quá hạn chờ bốc thăm quà boss → tự hủy trạng thái treo', BH_SKIP_MS);
      }
    }

    // 2. Quái Biến Dị (st.bd)
    if (st.bd) {
      if (!st.bd.at) st.bd.at = t;
      else if (t - st.bd.at > BD_MAX_MS) {
        var bdName = st.bd.type || 'biến dị';
        bdFinish(g, 'Quá hạn ' + Math.round(BD_MAX_MS / 60000) + ' phút (tự hủy trạng thái treo biến dị ' + bdName + ')');
      }
    }

    // 3. Yêu Thú Xổng Chuồng (st.xc)
    if (st.xc) {
      if (!st.xc.at) st.xc.at = t;
      else if (t - st.xc.at > XC_MAX_MS) {
        if (st.xc.ev) st.xc.ev.done = true;
        var xcName = (st.xc.ev && st.xc.ev.what) || (st.xc.ev && st.xc.ev.type) || 'xổng chuồng';
        xcFinish(g, 'Quá hạn ' + Math.round(XC_MAX_MS / 60000) + ' phút (tự hủy trạng thái treo xổng chuồng ' + xcName + ')');
      }
    }

    // 4. Thương Đội (st.td)
    if (st.td) {
      if (!st.td.at) st.td.at = t;
      else if (t - st.td.at > TD_MAX_MS) {
        if (st.td.ev) st.td.ev.done = true;
        tdFinish(g, 'Quá hạn ' + Math.round(TD_MAX_MS / 60000) + ' phút (tự hủy trạng thái treo Thương Đội)');
      }
    }
  }
  function tickThuongDoi(g) {
    var P = g.P, me = g.me;
    if (!cfg.tdHunt || me.downed || st.bh || st.bd || vtActive(g) || st.vt) { if (st.td && !cfg.tdHunt) st.td = null; return false; }
    if (!st.td) {
      if (!tdWant(P)) {
        tdEvents.forEach(function (e) {
          if (e.done || e.noted) return;
          e.noted = true;
          tdLog('Thiên Đạo báo đoàn ở ' + mapName(e.map) + (e.khu ? ' khu ' + e.khu : '') + ' nhưng không cần Oán Hồn / Hiệp Nghĩa Lệnh lúc này → không đi (muốn săn thêm thì bật "Săn thêm để bán chợ" ở Hồn Phiên)');
        });
        return false;
      }
      var ev = tdEvents.filter(function (e) {
        if (!e.done && now() - e.at < TD_EVENT_MS && tdHistoryDone(P, e)) { e.done = true; tdLog('Lịch sử chat: đoàn ở ' + mapName(e.map) + ' đã xong → không đi tìm'); }
        return !e.done && now() - e.at < TD_EVENT_MS;
      })[0], here = tdTargets(g)[0];
      if (!ev && !here) return false;
      var back = st.back ? takeBack(g) : st.travel ? { map: st.travel.map, x: st.travel.x, y: st.travel.y, khu: st.travel.khu || gaKhu(g.P) } : takeBack(g);
      st.td = {
        ev: here ? null : ev, maps: here ? [g.mapId] : tdRoute(P, ev.map), mi: 0, back: back, at: now(), khuSeen: {}, lookAt: 0,
        khu: here ? 0 : ev.khu || 0, pts: null, ptsMap: null,
        khuWant: 0, khuAt: 0, touches: 0, touchAt: 0, routeAt: 0, travels: 0, target: null, seen: false, step: ''
      };
      tdLog(here ? 'Thấy ' + mobLabel(here) + ' ngay đây → săn' : 'Đi ' + mapName(ev.map) + (ev.khu ? ' khu ' + ev.khu + ' (Thiên Đạo báo khu, khỏi dò)' : '') + ' săn Thương Đội');
    }
    var d = st.td;
    if (now() - d.at > TD_MAX_MS && !(d.last && now() - d.last.at < TD_CHASE_MS)) { if (d.ev) d.ev.done = true; return tdFinish(g, 'Quá ' + TD_MAX_MS / 60000 + ' phút → về'); }
    if (!tdWant(P) && !tdTargets(g).length && lootBeforeLeave(g)) { d.step = 'nhặt hồn rơi trước khi về'; return true; }
    if (!tdWant(P)) { if (d.ev) d.ev.done = true; return tdFinish(g, 'Đủ Oán Hồn / sắp chạm mốc Sát Nghiệp → về'); }
    if (d.ev && !d.seen && !d.ev.done && tdHistoryDone(P, d.ev)) d.ev.done = true;
    if (d.ev && d.ev.done && !d.seen && !tdTargets(g).length) return tdFinish(g, 'Thiên Đạo báo đoàn đã xong (bị hạ / cướp / tới nơi) → thôi dò khu, về');
    var list = tdTargets(g);
    if (d.target && (d.target.dead || d.target.hp <= 0)) {
      st.huntKillAt = now();
      if (tgRec && tgRec.k === 'td') tgAdd(tgRec, 'Hạ ' + mobLabel(d.target));
    }
    if (huntLoot(g, d.target)) { setAuto(g, false); d.step = 'nhặt đồ rơi'; return true; }
    if (list.length) {
      var t = d.target && list.indexOf(d.target) >= 0 ? d.target : list[0];
      if (d.target !== t) { d.target = t; d.step = 'săn ' + mobLabel(t) + ' · khu ' + gaKhu(P); }
      tdNote(g, d, t);
      d.seen = true; d.khuWant = 0;
      if (st.travel) stopTravel();
      honStrike(g, d, t, true);
      return true;
    }
    d.target = null;
    if (d.seen && lootBeforeLeave(g)) { d.step = 'nhặt hồn rơi'; return true; }
    if (d.seen) {
      var L = d.last, killed = !L || !L.obj || L.obj.dead || L.obj.hp <= 0;
      if (!killed && tdChase(g, d)) return true;
      if (d.ev) d.ev.done = true;
      return tdFinish(g, killed ? 'Đã hạ hết Tiêu Sư / Thương Nhân của đoàn → về' : 'Mất dấu ' + L.name + ' (đuổi ' + Math.round((now() - L.first) / 1000) + 's) → về');
    }
    var map = d.maps[d.mi];
    if (!map) { if (d.ev) d.ev.done = true; return tdFinish(g, 'Không tìm thấy Thương Đội → về'); }
    if (g.mapId !== map) {
      d.khuWant = 0; d.step = 'đi tới ' + mapName(map);
      if (!jobGo(g, d, map, 'Thương Đội: đi ' + mapName(map), tdLog)) { d.mi++; d.travels = 0; }
      return true;
    }
    if (st.travel && st.travel.map === map && !d.khuWant) stopTravel();
    if (d.khu) return tdSweep(g, d, map);
    if (d.khuWant) { if (khuGo(g, d, '[Thương Đội]')) return true; d.lookAt = now(); return true; }
    if (!d.lookAt) d.lookAt = now();
    var khu = gaKhu(P), so = gaSoKhu(P);
    if (now() - d.lookAt < BD_LOOK_MS) { d.step = 'tìm đoàn ở ' + mapName(map) + ' · xem khu ' + khu; return true; }
    d.khuSeen[khu] = true;
    var next = 0;
    for (var i = 1; i < so && !next; i++) { var k = ((khu - 1 + i) % so) + 1; if (!d.khuSeen[k]) next = k; }
    if (!next) { d.mi++; d.khuSeen = {}; d.lookAt = 0; d.travels = 0; tdLog(mapName(map) + ': dò hết khu không thấy đoàn' + (d.maps[d.mi] ? ' → sang ' + mapName(d.maps[d.mi]) : '')); return true; }
    d.khuSeen[next] = true;
    d.khuWant = next; d.khuAt = 0; d.touches = 0; d.touchAt = 0;
    d.step = 'tìm đoàn · sang khu ' + next;
    return khuGo(g, d, '[Thương Đội]') || true;
  }
  // Thiên Đạo đã báo khu: sang thẳng khu đó, tới chỗ sinh Thương Đội của map trước rồi tuần lưới khắp map (máy chủ
  // chỉ gửi thứ trong tầm nhìn). Tuần hết map không thấy thì sang map kế trên tuyến, vẫn khu đó.
  function tdSweep(g, d, map) {
    var P = g.P, me = g.me;
    if (gaKhu(P) !== d.khu && gaSoKhu(P) >= d.khu) {
      if (!d.khuWant) { d.khuWant = d.khu; d.khuAt = 0; d.touches = 0; d.touchAt = 0; }
      d.step = 'đổi sang khu ' + d.khu + ' (Thiên Đạo báo)';
      if (khuGo(g, d, '[Thương Đội]')) return true;
      if (gaKhu(P) !== d.khu) { if (d.ev) d.ev.done = true; return tdFinish(g, 'Không đổi sang được khu ' + d.khu + ' → về'); }
    }
    d.khuWant = 0;
    if (!d.pts || d.ptsMap !== map) {
      var cm = tdMaps(P)[map];
      d.ptsMap = map;
      d.pts = sweepPlan(g, cm ? [{ x: cm.x, y: cm.y }] : [], null, true);
    }
    // Tới sớm hơn lúc đoàn hiện (Thiên Đạo báo trước 20 giây): đứng chờ ngay chỗ đoàn hiện ra, chưa đi dò.
    var cm0 = tdMaps(P)[map];
    if (cm0 && d.ev && now() - d.ev.at < TD_SPAWN_DELAY_MS + 5000 && d.mi === 0) {
      d.step = 'chờ đoàn hiện ở ' + mapName(map) + ' khu ' + d.khu + ' (Thiên Đạo báo trước 20 giây)';
      setAuto(g, false);
      if (dist(me.x, me.y, cm0.x, cm0.y) > 60 && !(me.path && me.path.length && now() - d.routeAt < 1500)) { var rc = spotCheck(g).route(cm0.x, cm0.y); if (rc) { moveFighting(g, rc.path); d.routeAt = now(); } }
      return true;
    }
    if (!sweepStep(g, d, d.pts)) {
      d.mi++; d.pts = null; d.travels = 0;
      tdLog('Tuần hết ' + mapName(map) + ' khu ' + d.khu + ' không thấy đoàn' + (d.maps[d.mi] ? ' → sang ' + mapName(d.maps[d.mi]) + ' (khu ' + d.khu + ')' : ''));
      return true;
    }
    setAuto(g, false);
    d.step = 'dò khắp ' + mapName(map) + ' khu ' + d.khu + ' tìm đoàn (còn ' + d.pts.length + ' chỗ)';
    return true;
  }
  // Mục tiêu người phàm đang săn (Hồn Phiên / Thương Đội): ghim vào khoá ở mọi khung hình.
  function huntTarget() {
    if (st.bh || st.ll || st.ht) return null;
    var c = st.ct && !st.ct.haul && st.ct.cart;
    return (c && !c.dead && c.hp > 0 ? c : null) || (st.td && st.td.target) || (st.hon && st.hon.target) || null;
  }

  /* ================= Dồn sát thương boss thế giới tối đa ================= */
  // Đồ boss thế giới chia theo sát thương (và món kết liễu cho người hạ). Khi đang đánh boss: không lùi …
  var BOSS_GUARD_WAIT_MS = 5000, BOSS_NOHIT_MS = 6000;
  var BOSS_GUARD_FIRST = { nhen_bach_ngoc: 1, song_duc_ma_bao: 1 };
  var bossHitAt = new WeakMap(), bossEngage = new WeakMap();
  function bossGuardTarget(g, boss) {
    var hv = boss.def && boss.def.hoVe, me = g.me;
    if (!hv) return null;
    if (!bossEngage.get(boss) && dist(me.x, me.y, boss.x, boss.y) < 260) bossEngage.set(boss, now());
    var eng = bossEngage.get(boss);
    // Nhện Bạch Ngọc / Ma Báo: còn một hộ vệ là chủ ổ không ăn sát thương nào (hướng dẫn game) → hạ hộ vệ trước luôn.
    if (!BOSS_GUARD_FIRST[boss.type] && (!eng || now() - eng < BOSS_GUARD_WAIT_MS || now() - (bossHitAt.get(boss) || 0) < BOSS_NOHIT_MS)) return null;
    var guards = mobsAlive(g).filter(function (m) { return m.type === hv && dist(m.x, m.y, boss.x, boss.y) <= 600; });
    return guards.sort(function (a, b) { return dist(me.x, me.y, a.x, a.y) - dist(me.x, me.y, b.x, b.y); })[0] || null;
  }
  // Túi đầy thì món trúng thăm không bay vào túi được (nằm lại, 20 giây sau thành đồ chung) → nhắc một lần mỗi boss.
  var bagWarned = new WeakMap();
  function bagCheck(g, wb) {
    var I = g.P.Inventory;
    if (!I || !I.usedSlots || !I.capacity || bagWarned.get(wb)) return;
    var free = I.capacity() - I.usedSlots();
    if (free > 1) return;
    bagWarned.set(wb, true);
    klog('[Boss] Túi chỉ còn ' + Math.max(0, free) + ' ô trống → đồ trúng thăm của ' + mobLabel(wb) + ' có thể không vào túi!');
    say('Túi gần đầy — dọn túi để nhận đồ boss');
  }
  function bossTalismans(g) {
    var me = g.me, wb = worldBossNear(g) || (st.bh && st.bh.boss) || anyBossNear(g) || nearBoss(g);
    if (!wb) return;
    if (cfg.autoMpTal && me.mpMax > 0 && me.mp / me.mpMax < 0.4) talUse(g, 'thanh_tam', 'dồn sát thương boss, linh lực ' + Math.round(me.mp));
    bagCheck(g, wb);
    if (!cfg.bossMaxDmg && bossCapped(g, wb) && wb.hp > wb.hpMax * 0.1) return; // Nếu không bật dồn tối đa thì mới giữ bùa cho lúc kết liễu
    var d = dist(me.x, me.y, wb.x, wb.y), face = function () { me.dir = dirToward(wb.x - me.x, wb.y - me.y); };
    if (d <= 260 && talOk(g.P, me, 'kim_o')) { face(); talUse(g, 'kim_o', 'dồn sát thương ' + mobLabel(wb)); }
    else if (d <= 120 && talOk(g.P, me, 'hoa_phu')) { face(); talUse(g, 'hoa_phu', 'dồn sát thương ' + mobLabel(wb)); }
  }

  /* ================= Lịch treo máy: làm lần lượt các việc, xong hết thì về farm ================= */
  // Mỗi việc: avail(g) = lúc này có việc để làm; step(g, first) = 'busy' (script giữ quyền điều khiển) · …
  var PLAN_IDLE_MS = 60000;
  function planLog(m) { klog('[Lịch] ' + m); say('Lịch: ' + m); }
  function planIs(id) { return !!(cfg.planRun && enabled && st.plan && st.plan.job === id); }
  function dcAvail(g) {
    var Q = g.P.Quest;
    if (!Q || !Q.seedTaskInfo || !Q.startSeedQuest || (Q.canOpenSeedMenu && !Q.canOpenSeedMenu())) return false;
    var t = Q.seedTaskInfo();
    return t ? t.kind !== 'tournament' : !!dcNextTask(Q);
  }
  function honAvail(P) {
    var L = P.LuyenQuy, s = L && honState(P);
    if (!s || !s.phien) return false;
    var w = honWanted(P, s), cap = (s.moc && s.moc.tenDo) || 20;
    if (w.capped) return !!(cfg.honCung && (s.nghiep | 0) > 0 && P.Progress && (P.Progress.stones | 0) >= (L.GIA_CUNG || 500));
    if (st.honCapped && !cfg.honAllowRed && (s.nghiep | 0) > Math.max(0, cap - HON_RESUME)) return false;
    var maps = honMaps(P);
    return Object.keys(w.out).some(function (k) { return Object.keys(maps).some(function (id) { return maps[id][k] > 0; }); });
  }
  var PLAN_JOBS = [
    {
      id: 'diemdanh', ten: 'Điểm danh hằng ngày', maxMs: 3 * 60000,
      avail: function (g) { return ddAvail(g.P); }, step: function (g) { return tickDiemDanh(g); },
      info: function (P) { return ddText(P).replace(/^\S+ /, ''); }
    },
    {
      id: 'gacha', ten: 'Rút Tàng Kinh miễn phí', maxMs: 3 * 60000,
      avail: function (g) { return gcPools(g.P).length > 0; }, step: function (g) { return tickGacha(g); },
      info: function (P) { var n = gcPools(P).length; return n ? 'còn ' + n + ' lượt miễn phí hôm nay' : 'hết lượt miễn phí / chưa mở Tàng Kinh'; }
    },
    {
      id: 'sect', ten: 'Nhiệm vụ tông môn', maxMs: 45 * 60000, rest: 2 * 60000,
      avail: function (g) { return snAvail(g.P); }, step: function (g) { return tickSect(g); },
      info: function (P) { var nv = snNv(P); if (!nv) return 'chưa xem sổ việc'; if (!nv.coTong) return 'chưa vào tông môn'; var s = snDang(P, nv); return 'hôm nay ' + (nv.soXong | 0) + '/' + (nv.toiDa | 0) + (s ? ' · đang: ' + s.def.ten + ' ' + s.co + '/' + s.can : ''); }
    },
    {
      id: 'dc', ten: 'Dược Công', maxMs: 40 * 60000,
      avail: dcAvail,
      step: function (g, first) { if (first) { cfg.dcRun = true; cfg.dcReturn = null; st.dc = null; save(); if (ui.root) syncInputs(); return 'run'; } return cfg.dcRun ? 'run' : 'done'; },
      stop: function () { if (cfg.dcRun) { cfg.dcRun = false; st.dc = null; dcDlg = null; save(); if (ui.root) syncInputs(); } },
      info: function (P) { var Q = P.Quest; if (!Q || !Q.seedTaskRunsLeft) return '—'; var n = 0; DC_TASKS.forEach(function (t) { if (cfg['dc_' + t[0]] !== false) n += Q.seedTaskRunsLeft(t[0]); }); return n ? 'còn ' + n + ' lượt hôm nay' : 'hôm nay đã xong'; }
    },
    {
      id: 'vt', ten: 'Vận Tiêu', maxMs: 30 * 60000,
      avail: function (g) {
        if (cfg.vtAutoTrigger && !vtChuyen(g.P)) {
          var h = vtVnHour(g.P), targetH = cfg.vtScheduleHour != null ? Number(cfg.vtScheduleHour) : 13;
          if (h < targetH) return false;
        }
        return vtAvail(g.P);
      },
      step: function (g) { return tickVanTieu(g); },
      stop: function () { if (!vtChuyen(window.PNTT)) st.vt = null; },
      info: function (P) {
        if (vtChuyen(P)) return 'đang áp tải';
        var h = vtVnHour(P), targetH = cfg.vtScheduleHour != null ? Number(cfg.vtScheduleHour) : 13;
        if (cfg.vtAutoTrigger && h < targetH) return 'chờ mốc ' + targetH + 'h (hiện tại ' + h + 'h)';
        return vtWhyNot(P) || 'còn ' + vtLeft(P) + ' chuyến hôm nay';
      }
    },
    {
      id: 'hon', ten: 'Hồn Phiên (săn hồn)', maxMs: 60 * 60000,
      avail: function (g) { return honAvail(g.P); },
      step: function (g, first) { if (first) return 'run'; if (!st.hon && now() - st.plan.at > 4000) return 'done'; if (st.hon && /^không có map/.test(st.hon.step || '')) { honStop(g); return 'done'; } return 'run'; },
      stop: function (g) { if (st.hon) honStop(g); },
      info: function (P) { return !P.LuyenQuy ? '—' : honAvail(P) ? 'còn hồn cần săn' : 'không cần săn lúc này'; }
    },
    {
      id: 'farmcare', ten: 'Chăm vườn', maxMs: 6 * 60000,
      avail: function (g) { return !!(g.P.Farm && faWork(g.P)); },
      step: function (g, first) { if (first && !st.fa) faStart('lịch'); return st.fa ? 'run' : 'done'; },
      info: function (P) { var n = P.Farm ? faWork(P) : 0; return n ? n + ' luống cần làm' : 'chưa có việc'; }
    },
    {
      id: 'fish', ten: 'Câu Linh Ngư', maxMs: 40 * 60000,
      avail: function (g) { return !!g.P.Fishing && cfg.fishGoal > 0 && fishWant(g.P); },
      step: function (g, first) { if (first) return 'run'; return fishWant(g.P) ? 'run' : 'done'; },
      stop: function (g) { if (st.fish) fishStop(g); },
      info: function (P) { return 'Linh Ngư ' + fishCount(P) + (cfg.fishGoal > 0 ? '/' + cfg.fishGoal : '') + (cfg.fishGoal > 0 ? '' : ' · đặt số Linh Ngư cần thì lịch mới làm'); }
    },
    {
      id: 'hauky36', ten: 'Giai đoạn 36: Thạch Quy biến dị', maxMs: 90 * 60000, rest: 5 * 60000,
      avail: function (g) { return !!tqNeed(g.P); }, step: function (g) { return tickTq36(g); },
      stop: function () { st.tq = null; },
      info: function (P) { if (!P.HauKy || !P.Quest) return '—'; var nd = tqNeed(P); return nd ? tqText(P, nd) : P.Quest.stage === (P.Quest.LAP_CONG_STAGE || 36) ? 'đủ phần Thạch Quy · về nộp Tông Môn Quản Sự' : 'chỉ chạy khi đang ở Giai đoạn 36'; }
    },
    {
      id: 'hx', ten: 'Huyết Xích Cấm Địa', maxMs: 90 * 60000, rest: 5 * 60000,
      avail: function (g) { return HUYET_MAPS[g.mapId] || !hxWhyNot(g); },
      step: function (g, first) { if (first) return 'run'; return HUYET_MAPS[g.mapId] || st.hx || !hxWhyNot(g) ? 'run' : 'done'; },
      stop: function () { if (!cfg.hxRun) st.hx = null; },
      info: function (P) { var g0 = game(); var w = g0 && hxWhyNot(g0); return w || 'còn ' + hxLeft(P) + ' lượt hôm nay'; }
    },
    {
      id: 'yl', ten: 'Yên Lãng Sơn (cần tổ đội)', maxMs: 60 * 60000, rest: 5 * 60000,
      avail: function (g) { return (g.P.YenLang && g.mapId === g.P.YenLang.MAP) || !ylWhyNot(g); },
      step: function (g, first) { if (first) return 'run'; return (g.P.YenLang && g.mapId === g.P.YenLang.MAP) || st.yl || !ylWhyNot(g) ? 'run' : 'done'; },
      stop: function () { if (!cfg.ylRun) st.yl = null; },
      info: function (P) { var g0 = game(); var w = g0 && ylWhyNot(g0); return w || 'còn ' + ylLeft(P) + ' lượt hôm nay'; }
    },
    {
      id: 'gather', ten: 'Nhặt nguyên liệu', maxMs: 0,
      avail: function (g) { return Object.keys(gaWanted(g.P)).length > 0; },
      step: function (g, first) { if (first) { cfg.gatherRun = true; st.ga = null; save(); if (ui.root) syncInputs(); return 'run'; } return cfg.gatherRun ? 'run' : 'done'; },
      stop: function () { if (cfg.gatherRun) { cfg.gatherRun = false; st.ga = null; save(); if (ui.root) syncInputs(); } },
      info: function (P) { var n = Object.keys(gaWanted(P)).length; return n ? n + ' loại cần nhặt · tối đa ' + cfg.planGatherMin + ' phút/lượt' : 'không có loại nào cần nhặt'; }
    }
  ];
  function planJob(id) { return PLAN_JOBS.filter(function (j) { return j.id === id; })[0]; }
  // Việc theo thứ tự người chơi xếp (cfg.planOrder); việc chưa có trong danh sách xếp xuống cuối theo thứ tự mặc định.
  function planList() {
    var ord = Array.isArray(cfg.planOrder) ? cfg.planOrder : [];
    function k(j) { var i = ord.indexOf(j.id); return i >= 0 ? i : 100 + PLAN_JOBS.indexOf(j); }
    return PLAN_JOBS.slice().sort(function (a, b) { return k(a) - k(b); });
  }
  function planHome(g) { var f = cfg.farm; return f ? { map: f.map, x: f.x, y: f.y } : { map: g.mapId, x: g.me.x, y: g.me.y }; }
  function planEndJob(g, r) {
    var p = st.plan, J = planJob(p.job);
    if (J.stop) J.stop(g);
    if (J.id === 'sect') { snEndSub(g); st.sn = null; }
    p.rest[J.id] = now() + (r === 'fail' ? 10 * 60000 : J.rest || 60000);
    planLog((r === 'fail' ? 'Tạm dừng: ' : 'Xong: ') + J.ten);
    p.job = null;
    p.checkAt = 0;
  }
  function planStop(g) {
    var p = st.plan;
    if (p && p.job) { var J = planJob(p.job); if (J.stop) J.stop(g); if (J.id === 'sect') { snEndSub(g); st.sn = null; } }
    st.plan = null;
  }
  function planFarm(g) {
    var p = st.plan, b = p.back, me = g.me;
    if (!b) return false;
    // Đang săn hồn dư / sự kiện (chen ngang lúc lịch rảnh): để việc đó đi, không kéo về chỗ farm (trước đây hai bên
    // giành nhau → chạy ra vào map liên tục, săn hồn báo "không đi được tới …").
    if (jobBusy(g) || (st.travel && !st.travel.plan)) { p.home = false; return false; }
    var d = g.mapId === b.map ? dist(me.x, me.y, b.x, b.y) : Infinity;
    if (d <= 120 || (p.home && d <= Math.max(200, cfg.farmRadius))) {
      if (!p.home) { p.home = true; if (!p.homeLogged) planLog('Xong các việc trong lịch → farm ở ' + mapName(b.map)); p.homeLogged = true; setAuto(g, true); }
      if (st.travel && st.travel.plan) stopTravel();
      return false;
    }
    p.home = false;
    if (!st.travel || st.travel.map !== b.map) { startTravel(b.map, b.x, b.y, 'Lịch: về chỗ farm ' + mapName(b.map)); st.travel.plan = true; }
    tickTravel(g);
    return true;
  }
  function tickPlan(g) {
    if (!cfg.planRun) { if (st.plan) planStop(g); return false; }
    var p = st.plan || (st.plan = { job: null, at: 0, rest: {}, back: planHome(g), checkAt: 0, home: false, first: false });
    if (p.job) {
      var J = planJob(p.job), r, vtOn = J.id === 'vt' && vtActive(g);
      var maxMs = J.id === 'gather' ? cfg.planGatherMin * 60000 : J.maxMs;
      if (!cfg['plan_' + J.id] && !vtOn) r = 'done';
      else if (now() - p.at > maxMs && !vtOn) { planLog(J.ten + ': quá ' + Math.round(maxMs / 60000) + ' phút → làm việc khác'); r = J.id === 'gather' ? 'done' : 'fail'; }
      else { r = J.step(g, p.first); p.first = false; }
      if (r === 'busy') return true;
      if (r === 'run') return false;
      planEndJob(g, r);
    }
    if (now() < p.checkAt) return planFarm(g);
    p.checkAt = now() + 1500;
    var PJ = planList();
    p.wait = p.wait || {};
    for (var i = 0; i < PJ.length; i++) {
      var J2 = PJ[i], ok = false;
      if (!cfg['plan_' + J2.id] || p.rest[J2.id] > now()) continue;
      try { ok = J2.avail(g); } catch (e) { ok = false; }
      // Việc xếp trên còn đang chờ dữ liệu từ máy chủ (vd. sổ việc tông môn): đứng chờ tối đa 15 giây chứ không nhảy
      // sang việc xếp dưới, để đúng thứ tự người chơi đã xếp.
      if (ok === 'wait') {
        if (!p.wait[J2.id]) p.wait[J2.id] = now();
        if (now() - p.wait[J2.id] < 15000) { p.checkAt = now() + 800; return false; }
        continue;
      }
      delete p.wait[J2.id];
      if (!ok) continue;
      p.job = J2.id; p.at = now(); p.first = true; p.home = false; p.homeLogged = false;
      if (st.travel && st.travel.plan) stopTravel();
      planLog('Bắt đầu: ' + J2.ten);
      var r2 = J2.step(g, true);
      p.first = false;
      if (r2 === 'busy') return true;
      if (r2 === 'run') return false;
      planEndJob(g, r2);
      return false;
    }
    p.checkAt = now() + PLAN_IDLE_MS;
    return planFarm(g);
  }
  // Ngoài lịch: Vận Tiêu / nhiệm vụ tông môn bật riêng; bấm nút "làm ngay" điểm danh / Tàng Kinh.
  function tickStandalone(g) {
    if (st.oneShot) {
      var r0 = st.oneShot === 'dd' ? tickDiemDanh(g) : tickGacha(g);
      if (r0 === 'busy') return true;
      st.oneShot = null;
    }
    if (cfg.planRun) return false;
    if (cfg.vtAutoTrigger && !cfg.vtRun && !vtActive(g)) {
      var h = vtVnHour(g.P), today = vtVnDay(g.P);
      var targetH = cfg.vtScheduleHour != null ? Number(cfg.vtScheduleHour) : 13;
      if (h >= targetH && h < 22 && st.vtTriggeredDay !== today) {
        if (vtAvail(g.P) && vtLeft(g.P) > 0) {
          st.vtTriggeredDay = today;
          cfg.vtRun = true;
          save();
          if (ui.root) syncInputs();
          vtLog('Đạt mốc giờ hẹn (' + h + 'h >= ' + targetH + 'h) → tự động kích hoạt Vận Tiêu hôm nay (' + today + ')');
        }
      }
    }
    if (cfg.vtRun || vtActive(g)) {
      var r = tickVanTieu(g);
      if (r === 'busy') return true;
      if (cfg.vtRun && !vtActive(g)) { cfg.vtRun = false; save(); if (ui.root) syncInputs(); }
    }
    if (cfg.snRun && now() > (st.snRest || 0)) {
      var r2 = tickSect(g);
      if (r2 === 'busy') return true;
      if (r2 !== 'run') {
        snEndSub(g);
        st.snRest = now() + (r2 === 'fail' ? 10 * 60000 : 2 * 60000);
        var nv = snNv(g.P);
        if (nv && nv.coTong && snDoneToday(nv)) { cfg.snRun = false; save(); if (ui.root) syncInputs(); }
      }
    }
    return false;
  }

  /* ================= Tranh Đoạt Linh Thụ (tông đấu tông, Thứ Ba · Thứ Bảy 20:00 ghi danh, 20:16 vào sân) ================= */
  // Góp mặt đủ = đóng góp ≥ 30 (mỗi giây đứng trong vòng cây +1) → ưu tiên có góp mặt trước.
  function inDungeon2(g) { return vnIn(g) || !!HUYET_MAPS[g.mapId] || !!(g.P.YenLang && g.mapId === g.P.YenLang.MAP); }
  function ltIn(g) { var U = g && g.P && g.P.LinhThuUI; return !!(U && U.dangTrongTran && U.dangTrongTran()); }
  function ltInVung(L, x, y, v) { return !!(L && v && (L.trongVung ? L.trongVung(x, y, v) : Math.hypot(x - v.x, y - v.y) <= (v.r || 0))); }
  function ltLog(m) { klog('[Linh Thụ] ' + m); say('Linh Thụ: ' + m); }
  function ltRes(U) { var k = U && U.ket; if (!k) return ''; var b = k.tomTat && k.tomTat.ben || [{}, {}]; return ({ thang: 'THẮNG', thua: 'thua', hoa: 'hoà' }[k.ketQua] || '?') + ' ' + (b[0].diem | 0) + '–' + (b[1].diem | 0) + ' · đóng góp ' + (k.dg | 0) + ' · ' + ({ du: 'góp mặt đủ', it: 'góp mặt ít', afk: 'không đủ góp mặt' }[k.bac] || ''); }
  function tickLinhThu(g) {
    var P = g.P, L = P.LinhThu, U = P.LinhThuUI, G = P.Gateway, me = g.me, O = P.CONFIG.TILE || 32;
    if (!cfg.ltRun || !L || !U || !G) { st.lt = null; return false; }
    if (!ltIn(g)) {
      if (st.lt && st.lt.inMatch) {
        var bk = st.lt.back;
        st.lt = null;
        ltLog('Hết trận → về chỗ farm');
        if (bk && (g.mapId !== bk.map || dist(me.x, me.y, bk.x, bk.y) > BACK_NEAR || (bk.khu && gaKhu(g.P) !== bk.khu))) goBack(bk.map, bk.x, bk.y, 'Linh Thụ xong → về chỗ farm', 'lt', bk.khu);
        return false;
      }
      if (!G.connected || !G.cmd) return false;
      var l = L.lich(Date.now()), S = U.st, mine = S && S.lich && S.lich.id === l.id ? S : null;
      if (l.giaiDoan !== 'DANG_KY' && l.giaiDoan !== 'CHUAN_BI') { if (st.lt) st.lt = null; return false; }
      if (!mine && now() - (st.ltXem || -1e9) > 30000) { st.ltXem = now(); G.cmd('linhthu.xem', {}, function () { }); }
      if (l.giaiDoan === 'DANG_KY' && mine && !mine.daGhi && !mine.daKhoa && !mine.tuCach && !me.downed && now() - (st.ltReg || -1e9) > 20000) {
        st.ltReg = now();
        G.cmd('linhthu.ghiDanh', {}, function (r) { ltLog(r && r.ok ? 'Đã ghi danh kỳ ' + L.gioDoc(l.khoaLuc) : 'Chưa ghi danh được: ' + (r && r.why ? (L.LOI[r.why] || r.why) : 'không rõ')); });
      }
      if (mine && mine.tuCach && st.ltWhy !== l.id) { st.ltWhy = l.id; ltLog('Không ghi danh được: ' + L.viLoi(mine.tuCach)); }
      // Đã ghi danh: từ 90 giây trước giờ khoá sổ tới lúc vào sân thì đứng chờ (vắng / bận là mất suất)
      if (!(mine && mine.daGhi && mine.trangThai !== 'HUY' && Date.now() > l.khoaLuc - 90000 && Date.now() < l.khoiLuc + 30000) || inDungeon2(g)) return false;
      var w = st.lt || (st.lt = { back: takeBack(g), step: '' });
      w.step = 'đã ghi danh · chờ khoá sổ ' + L.gioDoc(l.khoaLuc) + ' để vào sân';
      if (st.travel) stopTravel();
      if (me.path && me.path.length) me.path.length = 0;
      setAuto(g, false);
      return true;
    }
    var a = st.lt || (st.lt = { back: null, step: '' }), tr = U.tran || {}, N = U.nhip || {}, d = typeof tr.doi === 'number' ? tr.doi : -1;
    if (!a.inMatch) { a.inMatch = true; ltLog('Vào sân'); }
    if (st.travel) stopTravel();
    a.pk = false;
    if (U.ket) { if (!a.resLog) { a.resLog = true; ltLog('Kết quả: ' + ltRes(U)); } a.step = 'xong trận · chờ về làng'; setAuto(g, false); return true; }
    if (me.downed) { a.step = 'gục · chờ hồi sinh'; return true; }
    if (d < 0 || (N.tt || tr.trangThai) !== 'DANG_DAU') { a.step = 'chờ khai trận'; setAuto(g, false); if (me.path && me.path.length) me.path.length = 0; return true; }
    var R = G.remotes || {}, foes = [], hp = me.hpMax ? me.hp / me.hpMax : 1, tx = me.x / O, ty = me.y / O, range = tlRange(g);
    Object.keys(R).forEach(function (id) { var r = R[id]; if (r && !r.downed && isFinite(r.x) && U.laDichNguoi(r)) foes.push(r); });
    var C = L.CAY, cx = C.x * O, cy = C.y * O, home = L.NHA[d], hx = home.x * O, hy = home.y * O, eh = L.NHA[1 - d], et = L.TRU[1 - d];
    var sc = N.diem || [0, 0], cay = N.cay || { chu: -1, n: [0, 0] }, txt = ' · điểm ta ' + (sc[d] | 0) + ' – địch ' + (sc[1 - d] | 0);
    function go(x, y, r0) {
      if (dist(me.x, me.y, x, y) <= (r0 || 30)) return false;
      if (!(me.path && me.path.length && now() - (a.routeAt || 0) < 900 && dist(x, y, a.gx, a.gy) < 48)) { var r = spotCheck(g).route(x, y); if (r) { moveFighting(g, r.path); a.routeAt = now(); a.gx = x; a.gy = y; } }
      return true;
    }
    function mode(m, t) { if (a.mode !== m) { a.mode = m; klog('[Linh Thụ] ' + t); } a.step = t + txt; }
    function still() { setAuto(g, false); if (me.path && me.path.length) me.path.length = 0; }
    function bad(x, y) { return dist(x, y, et.x * O, et.y * O) < (L.TRU_TAM + 1.5) * O || dist(x, y, eh.x * O, eh.y * O) < (eh.r + 1.5) * O; }
    var near = foes.filter(function (f) { return dist(f.x, f.y, me.x, me.y) < Math.max(range + 140, 320) && !bad(f.x, f.y); });
    // 1) Máu thấp: về vùng hồi máu nhà mình, hồi gần đầy mới ra.
    if (hp < 0.35) a.heal = true;
    if (a.heal) {
      if (hp >= 0.9) a.heal = false;
      else { mode('heal', 'máu ' + Math.round(hp * 100) + '% → về vùng hồi máu'); setAuto(g, false); if (!go(hx, hy, home.r * O * 0.5)) still(); return true; }
    }
    // 2) Thụ Tâm (2 phút cuối, một lần): quanh mình không có địch thì đứng yên sát gốc cây niệm.
    var tam = N.tam;
    if (tam && tam.co && !(tam.xong >= 0) && !near.length) {
      mode('tam', 'niệm Thụ Tâm · đứng yên sát gốc cây (+' + L.THU_TAM.DIEM + ')');
      if (!ltInVung(L, tx, ty, { x: C.x, y: C.y, r: L.THU_TAM.R * 0.7 })) { setAuto(g, false); go(cx, cy, 10); } else still();
      return true;
    }
    // 3) Rễ tông mình bị cắt: người (trong nhóm trợ thủ) gần rễ nhất về nối — đứng yên trong vòng rễ.
    var cn = N.can && N.can[d], cut = cn ? L.LINH_CAN[d].filter(function (c, i) { return cn[i] && !cn[i][0]; }) : [];
    if (cut.length && !near.length) {
      var rt = cut.sort(function (p1, p2) { return dist(me.x, me.y, p1.x * O, p1.y * O) - dist(me.x, me.y, p2.x * O, p2.y * O); })[0], rx = rt.x * O, ry = rt.y * O, md = dist(me.x, me.y, rx, ry);
      var mates = teamMates(g), mine2 = mates.length ? !mates.some(function (m) { return dist(m.r.x, m.r.y, rx, ry) < md - 20; }) : (cay.n[d] | 0) >= 4 || !ltInVung(L, tx, ty, C);
      if (mine2) {
        mode('can', 'nối Linh Căn ' + (L.TEN_TUYEN[rt.tuyen] || '') + ' (rễ tông mình bị cắt)');
        if (!ltInVung(L, tx, ty, { x: rt.x, y: rt.y, r: L.CAN.R * 0.6 })) { setAuto(g, false); go(rx, ry, 8); } else still();
        return true;
      }
    }
    // 4) Địch quanh mình (không ở sân nhà địch): dồn con máu thấp nhất.
    if (near.length) {
      var fo = near.sort(function (p1, p2) { return p1.hp - p2.hp || dist(me.x, me.y, p1.x, p1.y) - dist(me.x, me.y, p2.x, p2.y); })[0], Tg = P.Targeting;
      st.pin = { t: fo, at: now() };
      if (Tg) { Tg.key = 'dosat:' + fo.id; Tg.manual = true; Tg.khoaNguoi = fo.id; }
      setAuto(g, true); a.pk = true;
      mode('fight', 'đánh ' + (fo.name || 'địch') + ' (' + Math.round((fo.hp || 0) * 100) + '%)');
      if (dist(me.x, me.y, fo.x, fo.y) > range - 10) go(fo.x, fo.y, Math.max(20, range - 25));
      return true;
    }
    // 5) Giữ cây: đứng trong vòng cây (lệch nửa vòng về phía nhà mình), không tự đánh để khỏi bị kéo ra ngoài.
    var k0 = C.r * 0.45 * O / Math.max(1, dist(cx, cy, hx, hy)), spot = { x: cx + (hx - cx) * k0, y: cy + (hy - cy) * k0 };
    mode('cay', 'giữ Linh Thụ (' + (cay.tranh ? 'tranh chấp ' + cay.n[0] + '–' + cay.n[1] : cay.chu === d ? 'tông ta giữ · ' + (cay.n[d] | 0) + ' người' : cay.chu >= 0 ? 'địch giữ' : 'cây trống') + ')');
    if (!ltInVung(L, tx, ty, { x: C.x, y: C.y, r: C.r - 0.8 })) { setAuto(g, false); go(spot.x, spot.y, 24); return true; }
    still();
    return true;
  }

  /* ================= Tam Lộ Tranh Phong (5 chọi 5 ba đường, tối Thứ Tư 21h) ================= */
  // Tam Lộ: tự ghi danh / chấp nhận trận; trong trận đứng sau lính ta xa nhất, máu thấp về hồi; hết trận về chỗ farm.
  var TL_REG_GAP_MS = 20000, TL_ACC_GAP_MS = 2500, TL_FULL_HP = 90, TL_FRONT_GAP = 0.025, TL_LANE_R = 8;
  var TL_TOWER_PAD = 30, TL_COVER_N = 2, TL_SAFE_R = 300, TL_RECALL_MS = 7000;
  function tlIn(g) { var U = g.P.TamLoUI; return !!(U && U.dangTrongTran && U.dangTrongTran()); }
  function tlLog(m) { klog('[Tam Lộ] ' + m); say('Tam Lộ: ' + m); }
  function tlNow(P) { var U = P.TamLoUI; return U && U.now ? U.now() : Date.now(); }
  // Tiến độ dọc đường (0 = căn cứ mình, 1 = căn cứ địch); null nếu đứng xa đường.
  function tlProg(TL, doi, lane, x, y) {
    var c = TL.cachDuong(lane, x / TL.O, y / TL.O);
    return c.d > TL_LANE_R ? null : doi === 0 ? c.f : 1 - c.f;
  }
  function tlPoint(TL, doi, lane, prog) {
    var q = TL.diemDuong(lane, doi === 0 ? prog : 1 - prog);
    return { x: q.x * TL.O, y: q.y * TL.O };
  }
  function tickTamLo(g) {
    var P = g.P, TL = P.TamLo, U = P.TamLoUI, G = P.Gateway, me = g.me;
    if (!cfg.tlRun || !TL || !U || !G) { st.tl = null; return false; }
    if (!tlIn(g)) {
      if (st.tl && st.tl.inMatch) {
        var bk = st.tl.back;
        st.tl = null;
        tlLog('Hết trận → về chỗ farm');
        if (bk && (g.mapId !== bk.map || dist(me.x, me.y, bk.x, bk.y) > BACK_NEAR || (bk.khu && gaKhu(g.P) !== bk.khu))) goBack(bk.map, bk.x, bk.y, 'Tam Lộ xong → về chỗ farm', 'tl', bk.khu);
        return false;
      }
      if (!G.tamLo || !G.connected) return false; // máy chủ chưa mở chế độ này
      var bang = me.realmId && TL.bangCua ? TL.bangCua(me.realmId) : null;
      if (!bang || !bang.bang) return false;
      var l = TL.lich(tlNow(P)), S = U.st, mine = S && S.lich && S.lich.id === l.id ? S : null;
      if (mine && mine.trangThai === 'CHO_CHAP_NHAN' && mine.chapNhan && !mine.chapNhan.toi && now() - (st.tlAccAt || -1e9) > TL_ACC_GAP_MS) {
        st.tlAccAt = now();
        if (P.TamLoCho && P.TamLoCho.chapNhan) P.TamLoCho.chapNhan(); else G.tamLo('chapNhan', {});
        tlLog('Chấp nhận trận đấu');
      }
      if (l.giaiDoan === 'DANG_KY' && !(mine && mine.daGhi) && !me.downed && now() - (st.tlRegAt || -1e9) > TL_REG_GAP_MS) {
        st.tlRegAt = now();
        G.tamLo('ghiDanh', {}, function (res) {
          tlLog(res && res.ok === false ? 'Chưa ghi danh được: ' + (TL.viLoi ? TL.viLoi(res.why) : res.why || '') : 'Đã ghi danh kỳ ' + TL.gioDoc(l.batDauLuc) + ' (' + bang.bang + ')');
        });
      }
      var waiting = mine && mine.daGhi && mine.trangThai !== 'HUY' && mine.trangThai !== 'XONG' &&
        (l.giaiDoan === 'CHAP_NHAN' || l.giaiDoan === 'MAN_CHO' || l.giaiDoan === 'CHUAN_BI' || mine.trangThai === 'CHO_CHAP_NHAN' || mine.trangThai === 'CHUAN_BI');
      if (!waiting) { if (st.tl && !st.tl.inMatch) st.tl = null; return false; }
      var w0 = st.tl || (st.tl = { back: takeBack(g), at: now(), step: '' });
      if (!w0.logged) { w0.logged = true; tlLog('Đã ghi danh, sắp ghép trận → đứng chờ (không đi việc khác)'); }
      w0.step = 'chờ vào trận';
      if (st.travel) stopTravel();
      if (me.path && me.path.length) me.path.length = 0;
      setAuto(g, false);
      return true;
    }
    var a = st.tl || (st.tl = { back: null, at: now(), step: '' });
    if (!a.inMatch) { a.inMatch = true; tlLog('Vào trận' + (cfg.tlJungle ? ' · đi rừng' : TL.DUONG[+cfg.tlLane] ? ' · đường ' + TL.DUONG[+cfg.tlLane].ten : ' · tự chọn đường')); }
    if (st.travel) stopTravel();
    var T = U.trangThai ? U.trangThai() : {}, doi = U.doi ? U.doi() : -1;
    if (me.downed) { a.step = 'gục · chờ hồi sinh ở căn cứ'; a.retreat = false; return true; }
    if (doi < 0 || !T.khoi) { a.step = 'chờ trận khởi'; setAuto(g, false); return true; }
    a.pk = false;
    var O = TL.O, hp = me.hpMax ? me.hp / me.hpMax : 1, pct = hp * 100, nh = T.nhip, tNow = tlNow(P), dt0 = nh ? tNow - (nh.serverNow || tNow) : 0;
    var mins = nh && !nh.cd ? (nh.t + dt0) / 60000 : 0, home = TL.NHA[doi], hx = home.x * O, hy = home.y * O;
    var all = (g.sw.enemies || []).filter(function (m) { return m && !m.dead && m.def && m.def.tamLo; }), vis = all.filter(function (m) { return !m.xa; });
    var R = G.remotes || {}, allies = [], foes = [], range = tlRange(g);
    Object.keys(R).forEach(function (id) { var r = R[id]; if (r && !r.downed && isFinite(r.x)) { if (U.laBanNguoi(r)) allies.push(r); else if (U.laDichNguoi(r)) foes.push(r); } });
    var isB = function (m) { return m.def.tamLo.ve === 'tru' || m.def.tamLo.ve === 'nha'; }, isL = function (m) { return m.def.tamLo.ve === 'linh'; };
    var myU = vis.filter(function (m) { return m.tm === doi; }), foeU = vis.filter(function (m) { return m.tm === 1 - doi; });
    var near = function (r) { return foeU.concat(foes).some(function (m) { return !isB(m) && dist(me.x, me.y, m.x, m.y) < r; }); };
    function within(L, x, y, r) { return L.filter(function (o) { return dist(o.x, o.y, x, y) <= r; }); }
    // Sức hai phe quanh (x, y): mỗi người 0,3 + 0,7 × % máu, trụ còn đánh được đứng gần +1,2.
    function power(x, y, r) {
      var us = dist(me.x, me.y, x, y) <= r + 200 ? 0.3 + 0.7 * hp : 0, them = 0;
      within(allies, x, y, r).forEach(function (o) { us += 0.3 + 0.7 * o.hp; });
      within(foes, x, y, r).forEach(function (o) { them += 0.3 + 0.7 * o.hp; });
      within(vis.filter(isB), x, y, 380).forEach(function (m) { if (m.tm === doi) us += 1.2; else if (!m.kh) them += 1.2; });
      return { us: us, them: them };
    }
    // Trụ địch (không khiên) chỉ đứng vào khi có ≥ TL_COVER_N lính ta trong tầm đỡ đạn.
    var towerR = (TL.LOAI && TL.LOAI.tru && TL.LOAI.tru.tam || 330) + TL_TOWER_PAD;
    function exposed(x, y) { return foeU.filter(isB).some(function (tw) { return dist(x, y, tw.x, tw.y) <= towerR && within(myU.filter(isL), tw.x, tw.y, towerR - TL_TOWER_PAD).length < TL_COVER_N; }); }
    function go(x, y, nearR) {
      if (dist(me.x, me.y, x, y) <= (nearR || 40)) return false;
      if (!(me.path && me.path.length && now() - (a.routeAt || 0) < 900 && dist(x, y, a.gx, a.gy) < 64)) { var r = spotCheck(g).route(x, y); if (r) { moveFighting(g, r.path); a.routeAt = now(); a.gx = x; a.gy = y; } }
      return true;
    }
    function lock(t, isP) { var Tg = P.Targeting; st.pin = { t: t, at: now() }; if (!isP) st.farmTarget = t; if (Tg) { Tg.key = (isP ? 'dosat:' : 'foe:') + t.id; Tg.manual = true; if (isP) Tg.khoaNguoi = t.id; } }
    function mode(m, txt) { if (a.mode !== m) { a.mode = m; a.modeAt = now(); if (m !== 'lane') klog('[Tam Lộ] ' + txt); } a.step = txt; }
    // Bụi cỏ gần (x, y) trong 3 ô: đứng chờ trong bụi (địch không thấy), không có thì đứng đúng chỗ.
    function bush(x, y) {
      var N = TL.NHIN; if (!N || !N.buiO) return { x: x, y: y };
      var tx = Math.floor(x / O), ty = Math.floor(y / O), b = null;
      for (var dy = -3; dy <= 3; dy++) for (var dx = -3; dx <= 3; dx++) if (N.buiO(tx + dx, ty + dy) && !N.chanO(tx + dx, ty + dy) && (!b || dx * dx + dy * dy < b.d)) b = { x: (tx + dx + 0.5) * O, y: (ty + dy + 0.5) * O, d: dx * dx + dy * dy };
      return b || { x: x, y: y };
    }
    // 1) Máu thấp: về thành (đứng yên ~6s, không ai gần) hoặc chạy về suối hồi đầy.
    if (pct < cfg.tlBackHp) a.retreat = true;
    if (a.retreat) {
      var sp = TL.SUOI[doi], sx = sp.x * O, sy = sp.y * O, dS = dist(me.x, me.y, sx, sy);
      if (pct >= TL_FULL_HP) { a.retreat = false; a.recallAt = 0; tlLog('Hồi đầy → ra lại'); }
      else if (dS <= TL.SUOI_R * O) { mode('back', 'hồi máu ở suối ' + Math.round(pct) + '%'); setAuto(g, false); if (me.path && me.path.length) me.path.length = 0; return true; }
      else {
        if (!near(TL_SAFE_R) && !T.hoiThanh && !a.recallAt && U.hoiThanh) { a.recallAt = now(); if (me.path && me.path.length) me.path.length = 0; U.hoiThanh(); tlLog('Máu ' + Math.round(pct) + '% → về thành'); }
        if (a.recallAt && now() - a.recallAt < TL_RECALL_MS && !near(TL_SAFE_R)) { mode('back', 'đang về thành'); setAuto(g, false); return true; }
        a.recallAt = 0;
        mode('back', 'máu ' + Math.round(pct) + '% · chạy về suối');
        setAuto(g, true);
        go(sx, sy, 20);
        return true;
      }
    }
    // 2) Bị áp đảo (địch đông / khoẻ hơn quanh mình): lùi về trụ ta gần nhất phía sau, không đánh đổi mạng.
    var pw = power(me.x, me.y, 450);
    if (foes.length && (pw.them > pw.us + 0.5 && hp < 0.8 || a.mode === 'lui' && now() - a.modeAt < 3000 && within(foes, me.x, me.y, 700).length)) { // đã lùi thì giữ ≥ 3 giây
      var safe = myU.filter(function (m) { return isB(m) && dist(m.x, m.y, hx, hy) < dist(me.x, me.y, hx, hy) - 60; }).sort(function (p1, p2) { return dist(me.x, me.y, p1.x, p1.y) - dist(me.x, me.y, p2.x, p2.y); })[0];
      mode('lui', 'địch đông hơn (' + pw.them.toFixed(1) + ' / ' + pw.us.toFixed(1) + ') · lùi về ' + (safe ? 'trụ ta' : 'căn cứ'));
      setAuto(g, true);
      go(safe ? (safe.x * 2 + hx) / 3 : hx, safe ? (safe.y * 2 + hy) / 3 : hy, 60);
      return true;
    }
    // 3) Giao tranh: địch quanh mình hoặc đang đánh đồng đội gần (≤ 750px), phe ta không yếu hơn → vào, dồn con máu thấp
    // nhất (khoá như bấm chọn), không đuổi vào trụ địch trừ khi nó sắp gục. Đánh xa thì giữ mép tầm (thả diều).
    var cand = foes.filter(function (o) {
      return dist(me.x, me.y, o.x, o.y) <= Math.max(range + 140, 320) || allies.some(function (al) { return dist(al.x, al.y, o.x, o.y) < 420 && dist(me.x, me.y, al.x, al.y) < 750; });
    });
    if (cand.length) {
      var best = null;
      cand.forEach(function (o) { var sc = o.hp + dist(me.x, me.y, o.x, o.y) / 700 + (exposed(o.x, o.y) && o.hp > 0.25 ? 2 : 0); if (!best || sc < best.s) best = { o: o, s: sc }; });
      var fo = best.o, pf = power(fo.x, fo.y, 500);
      if ((pf.us >= pf.them * 0.9 || fo.hp < 0.25 && hp > 0.5) && (!exposed(fo.x, fo.y) || fo.hp < 0.25 && pf.us > pf.them + 1)) {
        lock(fo, true); setAuto(g, true); a.pk = true;
        var df = dist(me.x, me.y, fo.x, fo.y);
        mode('fight', 'giao tranh · dồn ' + (fo.name || T.ten && T.ten[fo.id] || 'địch') + ' (' + Math.round(fo.hp * 100) + '%) · ta ' + pf.us.toFixed(1) + ' / địch ' + pf.them.toFixed(1));
        var K2 = +cfg.keepDist || 0;
        if (K2 > 0) { if (Math.abs(df - K2) > 15) { var k2 = (K2 - df) / Math.max(1, df); go(me.x + (me.x - fo.x) * k2, me.y + (me.y - fo.y) * k2, 10); } }
        else if (df > range - 10) go(fo.x, fo.y, Math.max(20, range - 25));
        else if (range > 90 && df < range * 0.55) { var k = (range * 0.85 - df) / Math.max(1, df); go(me.x + (me.x - fo.x) * k, me.y + (me.y - fo.y) * k, 10); } // giữ mép tầm
        return true;
      }
    }
    // 4) Giữ nhà: trụ / nhà chính ta có lính địch (≥ 2) hoặc người địch trong tầm, mình ở gần (≤ 1800px) → về giữ.
    var hurt = myU.filter(function (m) { return isB(m) && dist(me.x, me.y, m.x, m.y) < 1800 && (within(foeU.filter(isL), m.x, m.y, 340).length >= 2 || within(foes, m.x, m.y, 380).length); })
      .sort(function (p1, p2) { return dist(p1.x, p1.y, hx, hy) - dist(p2.x, p2.y, hx, hy); })[0];
    if (hurt) {
      var inv = within(foeU.filter(isL), hurt.x, hurt.y, 360).sort(function (p1, p2) { return p1.hp - p2.hp; })[0];
      mode('def', 'giữ ' + mobLabel(hurt) + ' đang bị đánh');
      setAuto(g, true);
      if (inv && dist(me.x, me.y, inv.x, inv.y) < 420) { lock(inv); return false; }
      go(hurt.x + (hx - hurt.x) * 0.15, hurt.y + (hy - hurt.y) * 0.15, 90);
      return true;
    }
    // 5) Mục tiêu lớn: Cổ Long (cần ≥ 1 đồng đội gần, hoặc khoẻ và không thấy địch) · Baron (≥ 2 đồng đội, từ phút 8). Sắp hồi
    // (≤ 25 giây) thì tới trước, núp bụi cạnh hố chờ.
    var pits = [];
    if (nh && nh.rong && nh.rong.so < nh.rong.tran) pits.push({ k: 'rong', ten: 'Cổ Long', p: TL.HO_RONG, x: nh.rong });
    if (nh && nh.baron) pits.push({ k: 'baron', ten: 'Baron', p: TL.HO_BARON, x: nh.baron });
    for (var i = 0; i < pits.length; i++) {
      var pt0 = pits[i], px = pt0.p.x * O, py = pt0.p.y * O, al = within(allies, px, py, 1000).length, fn = within(foes, px, py, 1000).length;
      var ok = pt0.k === 'rong' ? hp > 0.55 && (al >= 1 || !fn && hp > 0.8 && !foes.length) && al + 1 >= fn : hp > 0.6 && al >= 2 && al + 1 > fn;
      if (!ok || dist(me.x, me.y, px, py) > 2600) continue;
      var boss = vis.filter(function (m) { return m.def.tamLo.loai === pt0.k; })[0], left = (pt0.x.luc || 0) - dt0;
      if (pt0.x.song) {
        mode('obj', 'đánh ' + pt0.ten + ' cùng ' + al + ' đồng đội');
        setAuto(g, true);
        if (boss) { lock(boss); if (!go(boss.x, boss.y, Math.max(30, range - 20))) return false; return true; }
        go(px, py, 120); return true;
      }
      if (left > 0 && left < 25000 && al >= 1) { var bz = bush(px + (hx - px) * 0.25, py + (hy - py) * 0.25); mode('obj', 'chờ ' + pt0.ten + ' hồi (' + Math.ceil(left / 1000) + 's) · núp gần hố'); setAuto(g, true); go(bz.x, bz.y, 24); return true; }
    }
    // 6) Chọn đường (8 giây xét lại): đường có lính địch áp sát phía ta nhất, ít đồng đội nhất; người chọn sẵn đường thì giữ.
    // Từ phút 14 đồng đội đã đi chung (≥ 2 người gần nhau) thì đi theo đội thay vì đứng một mình một đường.
    var lane = TL.DUONG[+cfg.tlLane] ? +cfg.tlLane : a.lane != null ? a.lane : 1;
    if (!TL.DUONG[+cfg.tlLane] && now() - (a.laneAt || -1e9) > 8000) {
      a.laneAt = now();
      var ls = [0, 1, 2].map(function (ln) {
        var on = allies.filter(function (o) { return TL.cachDuong(ln, o.x / O, o.y / O).d < TL_LANE_R; }).length;
        var press = foeU.filter(function (m) { if (!isL(m)) return false; var pr = tlProg(TL, doi, ln, m.x, m.y); return pr != null && pr < 0.5; }).length;
        return { ln: ln, s: press * 1.5 - on * 1.4 + (ln === 1 ? 0.3 : 0) + (ln === a.lane ? 1 : 0) };
      }).sort(function (p1, p2) { return p2.s - p1.s; });
      if (a.lane !== ls[0].ln) { if (a.lane != null) tlLog('Đổi sang đường ' + TL.DUONG[ls[0].ln].ten); a.lane = ls[0].ln; }
      lane = a.lane;
    }
    if (mins >= 14 && !cfg.tlJungle) {
      var grp = allies.filter(function (o) { return within(allies, o.x, o.y, 600).length >= 2; });
      if (grp.length >= 2) {
        var cx = 0, cy = 0; grp.forEach(function (o) { cx += o.x; cy += o.y; }); cx /= grp.length; cy /= grp.length;
        if (dist(me.x, me.y, cx, cy) > 260 && !exposed(cx, cy)) { mode('group', 'cuối trận · đi theo đội (' + grp.length + ' người)'); setAuto(g, true); go(cx + (hx - cx) * 0.08, cy + (hy - cy) * 0.08, 120); return true; }
      }
    }
    // Lính ta xa nhất trên đường → chỗ đứng sau nó (đánh xa đứng lùi hơn); trụ địch thiếu lính đỡ thì lùi khỏi tầm.
    var front = -1, myTower = -1;
    myU.forEach(function (m) { var pr = tlProg(TL, doi, lane, m.x, m.y); if (pr == null) return; if (isL(m) && pr > front) front = pr; if (isB(m) && pr > myTower) myTower = pr; });
    // 7) Rừng: đi rừng, hoặc đường đang vắng (không lính ta / lính địch gần) trước phút 14 → dọn bãi phe ta còn quái (bùa trước
    // khi đang thiếu bùa), quay lại đường khi đợt lính mới tới. Bãi tới nơi mà trống thì nhớ, chờ hết thời gian hồi.
    var lanePt = tlPoint(TL, doi, lane, Math.max(0.04, front >= 0 ? front : myTower - 0.02));
    var quiet = !within(myU.filter(isL), lanePt.x, lanePt.y, 500).length && !within(foeU.filter(isL), lanePt.x, lanePt.y, 900).length;
    if (cfg.tlJungle || (quiet && mins < 14)) {
      a.camps = a.camps || {};
      var buffs = (T.buff || []).map(function (b) { return b.k; }), camp = null;
      TL.BAI.forEach(function (c) {
        if (c.doi !== doi || (a.camps[c.id] || 0) > now()) return;
        var cx2 = c.vi.x * O, cy2 = c.vi.y * O, mobs = all.filter(function (m) { return m.tm !== doi && !isB(m) && !isL(m) && dist(m.x, m.y, cx2, cy2) < 6 * O; });
        if (!mobs.length && a.camps[c.id] !== -1) { if (dist(me.x, me.y, cx2, cy2) < 4 * O) a.camps[c.id] = now() + c.hoiSinh * 1000; else if (mins * 60 < TL.BAI_RA_SAU / 1000) return; }
        var sc = dist(me.x, me.y, cx2, cy2) - (c.buff && buffs.indexOf(c.buff) < 0 ? 900 : 0);
        if ((cfg.tlJungle || sc < 1500) && (!camp || sc < camp.s)) camp = { c: c, s: sc, x: cx2, y: cy2, mobs: mobs };
      });
      if (camp) {
        var big = camp.mobs.filter(function (m) { return !m.xa; }).sort(function (p1, p2) { return (p2.hpMax || 0) - (p1.hpMax || 0); })[0];
        mode('jungle', 'dọn rừng · ' + camp.c.ten + (cfg.tlJungle ? '' : ' (đường đang vắng)'));
        setAuto(g, true);
        if (big) { lock(big); if (!go(big.x, big.y, Math.max(30, range - 20))) return false; return true; }
        go(camp.x, camp.y, 60); return true;
      }
    }
    // 8) Đi đường.
    var want = front >= 0 ? front - (range > 90 ? 0.035 : TL_FRONT_GAP) : Math.max(0.04, myTower - 0.02);
    var pt = tlPoint(TL, doi, lane, Math.max(0, Math.min(1, want)));
    for (var kk = 0; kk < 40 && exposed(pt.x, pt.y) && want > 0; kk++) { want -= 0.01; pt = tlPoint(TL, doi, lane, Math.max(0, want)); }
    var inBad = exposed(me.x, me.y);
    setAuto(g, true);
    if (front < 0 && !near(400)) pt = bush(pt.x, pt.y); // chờ đợt lính: núp bụi gần chỗ đứng
    mode('lane', TL.DUONG[lane].ten + ' · ' + (front >= 0 ? 'theo lính ta ' + Math.round(front * 100) + '%' : 'chờ lính') + (inBad ? ' · trong tầm trụ địch, lùi ra' : ''));
    if (!inBad && near(190)) return false; // địch trong tầm: để auto đánh tại chỗ (ăn lính / trụ)
    go(pt.x, pt.y, 40);
    return true;
  }
  // Tầm đánh: chiêu tự động xa nhất (không tính chiêu hồi máu), ít nhất tầm vũ khí, tối đa 260px.
  function tlRange(g) {
    var S = g.P.Skills, r = g.P.Player.reach ? g.P.Player.reach() : 26;
    (S && S.autoRotation ? S.autoRotation() : []).forEach(function (d) { if (d && !d.heal && d.range > 0) r = Math.max(r, skillRange(g, d) || 0); });
    return Math.min(260, r);
  }

  /* ================= Sự kiện tông môn: Bí Cảnh Lãm Làng · Sỹ Sách Điện ================= */
  // Lãm Làng (phá lồng, Tà Mạch Trụ, diệt Quỷ Phiên rồi dồn Tà Soái) và Sỹ Sách Điện (Ải 1 Thủ Vệ → Ải 2 Trụ Băng / Hoả →
  // Ải 3 Sỹ Sách Đỉnh). Trong lúc đó việc khác tạm nghỉ; né chiêu / thiền / nhặt đồ vẫn chạy. Ra ngoài thì về chỗ farm.
  var EV_LOOK_MS = 60000, EV_VAO_GAP_MS = 4000, EV_PIN_MS = 800;
  function evLog(tag, m) { klog('[' + tag + '] ' + m); say(tag + ': ' + m); }
  function evIn(g) {
    var P = g.P;
    return !!(tlIn(g) || (P.LamLang && g.mapId === P.LamLang.MAP) || (P.HuThien && P.HuThien.laMap && P.HuThien.laMap(g.mapId)) || (P.VetNut && P.VetNut.laMap && P.VetNut.laMap(g.mapId)));
  }
  // Khoá mục tiêu cho tickTarget giữ nguyên (không để chọn mục tiêu tự động đổi sang con khác).
  function evPin(g, t) {
    var T = g.P.Targeting, key = 'foe:' + t.id;
    st.pin = { t: t, at: now() };
    st.farmTarget = t;
    if (T && T.list && T.list.some(function (e) { return e.key === key; })) { T.key = key; T.manual = true; }
  }
  // Đánh t: khoá, bật auto, xa thì tự đi tới. true = đang đi tới, false = trong tầm (để auto / né / lùi lo).
  function evEngage(g, a, t) {
    var P = g.P, me = g.me;
    evPin(g, t);
    setAuto(g, true);
    var hpPct = t.hpMax > 0 ? (t.hp / t.hpMax) : 1;
    var d = dist(me.x, me.y, t.x, t.y);
    var reach = (P.Player.reach ? P.Player.reach() : 26) + (t.def && t.def.bodyRadius || 0);

    // Khi săn yêu thú xổng chuồng (st.xc) hoặc quái tranh Last Hit (isLastHitOnly):
    // Chủ động áp sát chạm tâm rơi d <= 2px NGAY TỪ ĐẦU (từ 100% HP) bám dính như hình với bóng,
    // đảm bảo khi quái gục thì nhân vật đã đứng đúng tâm toạ độ và nhặt sạch item Frame-0 trước mọi người chơi khác.
    var isDying = hpPct <= (isLastHitOnly(t) ? 0.28 : 0.20) || (t.hp != null && t.hp <= (isLastHitOnly(t) ? 15000 : 10000));
    var hugClose = !!(st.xc || isLastHitOnly(t));
    if (hugClose || isDying) {
      if (isDying) huntBurst(g, t, d, reach);
      if (d > 2 && !(me.path && me.path.length && now() - a.routeAt < 350)) {
        var rClose = spotCheck(g).route(t.x, t.y);
        if (rClose) { moveFighting(g, rClose.path); a.routeAt = now(); }
      }
      return true;
    }
    // Áp sát mục tiêu vào tầm đánh thực tế của vũ khí/chiêu thức (không đứng xa ngoài tầm)
    if (d > reach) {
      if (!(me.path && me.path.length && now() - a.routeAt < 600)) {
        var r = spotCheck(g).route(t.x, t.y);
        if (r) { moveFighting(g, r.path); a.routeAt = now(); }
      }
      return true;
    }
    if (!g.sw.approach) g.sw.approach = { key: 'foe:' + t.id, until: P.Game.time + 2 };
    return false;
  }
  // Đi tới ô (tx, ty) của map đang đứng. true = đang đi, false = đã tới.
  function evWalk(g, a, tx, ty, near) {
    var T = g.P.CONFIG.TILE || 32, x = (tx + 0.5) * T, y = (ty + 0.5) * T, me = g.me;
    if (dist(me.x, me.y, x, y) <= (near || 60)) return false;
    if (!(me.path && me.path.length && now() - a.routeAt < 1500)) {
      var r = spotCheck(g).route(x, y);
      if (r) { moveFighting(g, r.path); a.routeAt = now(); }
    }
    return true;
  }
  function evNearest(g, list) {
    var me = g.me;
    return list.sort(function (p, q) { return dist(me.x, me.y, p.x, p.y) - dist(me.x, me.y, q.x, q.y); })[0] || null;
  }
  function evPct(m) { return Math.round(m.hp / Math.max(1, m.hpMax) * 100) + '%'; }
  function evNew() { return { at: now(), routeAt: 0, touches: 0, touchAt: 0, travels: 0, sentAt: 0, tries: 0, inside: false, back: null, step: '', pi: 0 }; }
  // Nhận quyền điều khiển: dừng các việc đang chạy, nhớ chỗ về (chỗ về của việc bị dừng nếu có).
  function evTakeOver(g, a) {
    a.back = st.bh ? st.bh.back : st.bd ? st.bd.back : st.xc ? st.xc.back : st.td ? st.td.back : st.hon ? st.hon.back : takeBack(g);
    st.bh = null; st.bd = null; st.xc = null; st.td = null; st.hon = null; st.fk = null;
    if (st.travel) stopTravel();
  }
  function evEnd(g, key, msg, tag) {
    var a = st[key];
    st[key] = null;
    st.pin = null;
    if (msg) evLog(tag, msg);
    if (a && a.back && (g.mapId !== a.back.map || dist(g.me.x, g.me.y, a.back.x, a.back.y) > BACK_NEAR || (a.back.khu && gaKhu(g.P) !== a.back.khu))) goBack(a.back.map, a.back.x, a.back.y, tag + ' xong → về chỗ farm', key, a.back.khu);
    return false;
  }

  /* --- Lãm Làng --- */
  var LL_TE_DAN = { tx: 28, ty: 25 }, LL_GIENG = { tx: 12, ty: 24 }, LL_DAI_DA = { tx: 28, ty: 7 };
  var LL_GUARD_R = 300;         // px quanh lồng: Tà Tu canh phải hạ hết mới phá được
  var LL_TOWER_GUARD_R = 320;   // px quanh trụ: Vệ Binh hạ trước rồi mới đánh trụ
  var LL_INVITE_MS = 7 * 60000; // lời mời còn hạn tới lúc Tà Soái hiện (muộn nhất 7 phút)
  function hookLamLang(P) {
    var U = P.LamLangUI;
    if (!U || U._ttHooked || !U.onGoi) return;
    U._ttHooked = true;
    var on = U.onGoi;
    U.onGoi = function (o) { if (o && o.k === 'mo') st.llInviteAt = now(); return on.apply(this, arguments); };
  }
  function llWantIn(P) {
    var n = P.LamLangUI && P.LamLangUI.ngoai, r = n && n.run;
    if (r && r.laThanhVien) return true;
    if (st.llDone === dcToday()) return false; // hôm nay đã dự xong một lượt
    if (r) return !!(r.conNhan && !n.daDuHomNay);
    return !(n && n.daDuHomNay) && now() - (st.llInviteAt || -1e9) < LL_INVITE_MS;
  }
  function llCage(g, a, row, mobs) {
    var prop = findHere(g, row.id);
    if (!prop) { a.step = 'không thấy ' + row.id; return false; }
    var c = propCenter(g, prop), name = prop.name || row.id;
    var guards = mobs.filter(function (m) { return m.def.contactDmg > 0 && dist(m.x, m.y, c.x, c.y) <= LL_GUARD_R; });
    if (guards.length) { a.step = name + ' · hạ ' + guards.length + ' Tà Tu canh lồng'; return evEngage(g, a, evNearest(g, guards)); }
    a.step = 'phá ' + name;
    if (a.lao !== row.id) { a.lao = row.id; a.touches = 0; a.touchAt = 0; }
    // Chạm lồng như bấm chuột: game gửi lệnh phá phong ấn (LamLangUI.interact).
    if (touchProp(g, a, prop) === 'fail') { a.touches = 0; a.touchAt = 0; }
    return true;
  }
  function llTower(g, a, mobs) {
    var tw = evNearest(g, mobs.filter(isTower));
    if (!tw) { a.step = 'tới Đài Đá tìm Tà Mạch Trụ'; return evWalk(g, a, LL_DAI_DA.tx, LL_DAI_DA.ty, 120); }
    var guards = mobs.filter(function (m) { return m.def.contactDmg > 0 && dist(m.x, m.y, tw.x, tw.y) <= LL_TOWER_GUARD_R; });
    a.step = guards.length ? 'hạ ' + guards.length + ' Vệ Binh quanh ' + mobLabel(tw) : 'đánh ' + mobLabel(tw) + ' ' + evPct(tw);
    return evEngage(g, a, guards.length ? evNearest(g, guards) : tw);
  }
  // Hợp lực Tà Soái (BossHopLuc._st): Xích đứng gần nhau, Huyết Ấn chạy vào chia đòn, Trận Nhãn giữ ấn, Phá Thế dồn bùa.
  var LL_HOLD_MS = 600;
  function llPlayer(g, id) {
    var G = g.P.Gateway;
    if (id == null) return null;
    if (G && id === G.selfId) return g.me;
    var r = G && G.remotes && G.remotes[id];
    return r && !r.downed && isFinite(r.x) ? r : null;
  }
  function llInEll(p, x, y, r) { var dx = (p.x - x) / r, dy = (p.y - y) / (r / 2); return dx * dx + dy * dy <= 1; }
  function llGo(g, a, x, y) {
    var me = g.me;
    if (me.path && me.path.length && now() - a.routeAt < 400 && a.goTo && dist(a.goTo.x, a.goTo.y, x, y) < 24) return true;
    var r = spotCheck(g).route(x, y);
    if (!r) return false;
    if (me.state === 'sit') g.P.Player.stand(me);
    moveFighting(g, r.path);
    a.routeAt = now(); a.goTo = { x: x, y: y };
    return true;
  }
  // Người đang ở trong bí cảnh (mình + đồng môn thấy được), xếp theo id: mọi trợ thủ cùng tông tính ra cùng một thứ tự
  // → tự chia việc với nhau (tuyến, ấn Trận Nhãn) mà không cần nói chuyện.
  function llPeople(g) {
    var G = g.P.Gateway, out = [{ id: String(G && G.selfId), p: g.me }];
    var R = G && G.remotes || {};
    Object.keys(R).forEach(function (id) { var r = R[id]; if (r && !r.downed && isFinite(r.x)) out.push({ id: String(id), p: r }); });
    return out.sort(function (x, y) { return x.id < y.id ? -1 : x.id > y.id ? 1 : 0; });
  }
  // Chia ấn Trận Nhãn: lần lượt từng ấn lấy người (theo thứ tự id) gần nó nhất chưa có việc. -1 = mình không phải giữ ấn.
  function llSealOf(g, tn) {
    var ppl = llPeople(g), used = {}, self = String(g.P.Gateway && g.P.Gateway.selfId), mine = -1;
    tn.pts.forEach(function (q, k) {
      var best = null;
      ppl.forEach(function (x) { if (!used[x.id] && (!best || dist(x.p.x, x.p.y, q.x, q.y) < dist(best.p.x, best.p.y, q.x, q.y))) best = x; });
      if (best) { used[best.id] = 1; if (best.id === self) mine = k; }
    });
    return mine;
  }
  // Cơ chế hợp lực đang cần mình làm gì. undefined = không có gì, cứ đánh; true/false = giá trị trả về cho tickLamLang.
  function llCoop(g, a, mobs) {
    var H = g.P.BossHopLuc, s = H && H._st ? H._st() : null, me = g.me, G = g.P.Gateway, t = Date.now(), self = G && G.selfId;
    if (!s) return;
    var i, c, o;
    // Xích: hai người bị nối phải lại gần nhau tới hết 7 giây.
    for (i = 0; i < (s.xich || []).length; i++) {
      c = s.xich[i];
      if (t - c.bat > c.w || (c.a !== self && c.b !== self)) continue;
      o = llPlayer(g, c.a === self ? c.b : c.a);
      if (!o) continue;
      var dx = o.x - me.x, dy = o.y - me.y, dd = Math.sqrt(dx * dx + 4 * dy * dy);
      a.hold = now() + LL_HOLD_MS;
      if (dd <= c.xa * 0.55) continue;
      a.step = 'bị Xích với đồng môn → lại gần (' + Math.round(dd) + '/' + c.xa + ')';
      if (llGo(g, a, o.x, o.y)) return true;
    }
    // Huyết Ấn: vòng bám theo người bị ấn; đủ người đứng trong thì chia đòn.
    for (i = 0; i < (s.an || []).length; i++) {
      c = s.an[i];
      if (t - c.bat > c.w) continue;
      o = llPlayer(g, c.t);
      var cx = o ? o.x : c.x, cy = o ? o.y : c.y;
      a.hold = now() + LL_HOLD_MS;
      if (o === me) { a.step = 'mình bị Huyết Ấn → đứng yên cho đồng môn dồn vào chia đòn'; setAuto(g, false); if (me.path && me.path.length) me.path.length = 0; return true; }
      if (llInEll(me, cx, cy, c.r * 0.55)) { a.step = 'đứng trong Huyết Ấn chia đòn'; setAuto(g, false); if (me.path && me.path.length) me.path.length = 0; return true; }
      a.step = 'chạy vào Huyết Ấn chia đòn';
      setAuto(g, false);
      if (llGo(g, a, cx, cy)) return true;
    }
    // Trận Nhãn: Tà Soái bất hoại, cần giữ mọi ấn cùng lúc. Người được chia ấn tới giữ; người không giữ ấn chặn Tà
    // Binh lao vào các ấn.
    var tn = s.tn;
    if (tn && !tn.ket && t - tn.bat < tn.w && tn.pts && tn.pts.length) {
      a.hold = now() + LL_HOLD_MS;
      var on = -1;
      tn.pts.forEach(function (q, k) { if (llInEll(me, q.x, q.y, tn.r * 0.75)) on = k; });
      if (on >= 0) { a.step = 'giữ Trận Nhãn ' + (on + 1) + '/' + tn.pts.length + ' (' + Math.round((tn.p && tn.p[on]) || 0) + '%)'; setAuto(g, false); if (me.path && me.path.length) me.path.length = 0; return true; }
      var mine = llSealOf(g, tn);
      // Ấn được chia mà đã có người khác đứng → lấy ấn còn trống gần nhất.
      if (mine >= 0 && tn.c && tn.c[mine] === 1) {
        var free = -1;
        tn.pts.forEach(function (q, k) { if (tn.c[k] !== 1 && (free < 0 || dist(me.x, me.y, q.x, q.y) < dist(me.x, me.y, tn.pts[free].x, tn.pts[free].y))) free = k; });
        mine = free;
      }
      if (mine >= 0) {
        var q0 = tn.pts[mine];
        a.step = 'tới giữ Trận Nhãn ' + (mine + 1) + '/' + tn.pts.length;
        setAuto(g, false);
        if (llGo(g, a, q0.x, q0.y)) return true;
      }
      var BINH = g.P.LamLang && g.P.LamLang.TRAN_NHAN && g.P.LamLang.TRAN_NHAN.BINH || 'lam_lang_ta_tu';
      var binh = evNearest(g, (mobs || []).filter(function (m) {
        return m.type === BINH && tn.pts.some(function (q) { return dist(m.x, m.y, q.x, q.y) < 320; });
      }));
      if (binh) { a.step = 'chặn Tà Binh lao vào Trận Nhãn'; evEngage(g, a, binh); return true; }
      a.step = 'Trận Nhãn: các ấn đã có người giữ · đứng chờ';
      setAuto(g, false);
      return true;
    }
  }
  // Chia tuyến tự động (nhiều nhân vật cùng bật trợ thủ): theo thứ tự id người trong bí cảnh, lẻ → Đài Đá, chẵn → Cổng
  // Đông. Chốt lúc tập hợp (mọi người còn đứng chung ở giếng nên ai cũng thấy đủ người).
  function llLaneAuto(g) {
    var ppl = llPeople(g), self = String(g.P.Gateway && g.P.Gateway.selfId), k = 0;
    ppl.forEach(function (x, i) { if (x.id === self) k = i; });
    return ppl.length < 2 ? 'lao' : k % 2 ? 'tru' : 'lao';
  }
  function llBurst(g, S, boss) {
    var H = g.P.BossHopLuc, s = H && H._st ? H._st() : null, me = g.me;
    var pt = s && s.pt && !s.pt.ket && Date.now() - s.pt.bat < s.pt.w;
    var yeu = S.boss && S.boss.suyYeuDen > Date.now();
    if (!pt && !yeu) return '';
    var d = dist(me.x, me.y, boss.x, boss.y), face = function () { me.dir = dirToward(boss.x - me.x, boss.y - me.y); };
    if (cfg.autoMpTal && me.mpMax > 0 && me.mp / me.mpMax < 0.4) talUse(g, 'thanh_tam', 'dồn sát thương Tà Soái');
    if (d <= 260 && talOk(g.P, me, 'kim_o')) { face(); talUse(g, 'kim_o', pt ? 'Phá Thế' : 'Tà Soái suy yếu'); }
    else if (d <= 120 && talOk(g.P, me, 'hoa_phu')) { face(); talUse(g, 'hoa_phu', pt ? 'Phá Thế' : 'Tà Soái suy yếu'); }
    return pt ? ' · PHÁ THẾ: dồn sát thương' : ' · SUY YẾU +50%: dồn sát thương';
  }
  function tickLamLang(g) {
    var P = g.P, LL = P.LamLang, U = P.LamLangUI, G = P.Gateway, me = g.me;
    if (!LL || !U || !G || !G.connected || !G.cmd) return false;
    if (!cfg.llRun && !st.llOpen) { st.ll = null; return false; }
    if (g.mapId !== LL.MAP) {
      if (st.ll && st.ll.inside) { st.llDone = dcToday(); st.llInviteAt = 0; return evEnd(g, 'll', 'Bí cảnh đóng → ra ngoài', 'Lãm Làng'); }
      if (now() - (st.llLookAt || -1e9) > EV_LOOK_MS && U.xemTruoc) { st.llLookAt = now(); U.xemTruoc(); }
      // Tông Chủ / Trưởng Lão bấm nút mở: tới Quản Sự, mở lượt hôm nay (mở xong game cho vào luôn).
      if (st.llOpen) {
        var o = st.llOpen;
        if (now() - o.at > 3 * 60000) { st.llOpen = null; evLog('Lãm Làng', 'Quá 3 phút chưa mở được bí cảnh'); return false; }
        var w0 = atNpc(g, o, LL.NPC, function (m) { evLog('Lãm Làng', m); });
        if (w0 === 'fail') { st.llOpen = null; return false; }
        if (w0 === 'here' && !o.sent) {
          o.sent = true;
          G.cmd('lamlang.mo', {}, function (res) {
            st.llOpen = null;
            evLog('Lãm Làng', res && res.ok ? 'Đã mở bí cảnh cho tông' : 'Chưa mở được: ' + (res && res.why || 'không rõ'));
            if (res && res.ok) st.llInviteAt = now();
          });
        }
        return true;
      }
      if (!cfg.llRun || !llWantIn(P) || me.downed || vtBusy(g) || now() < (st.llRestUntil || 0)) { if (st.ll && !st.ll.inside) st.ll = null; return false; }
      var a0 = st.ll || (st.ll = evNew());
      if (!a0.back) { evTakeOver(g, a0); evLog('Lãm Làng', 'Tông môn đang mở bí cảnh → vào'); }
      if (now() - a0.sentAt < EV_VAO_GAP_MS) return true;
      if (++a0.tries > 5) {
        st.llRestUntil = now() + 3 * 60000; st.llInviteAt = 0;
        return evEnd(g, 'll', 'Vào bí cảnh 5 lần không được → thôi', 'Lãm Làng');
      }
      a0.sentAt = now();
      a0.step = 'vào bí cảnh';
      setAuto(g, false);
      G.cmd('lamlang.vao', {}, function (res) {
        if (res && res.ok) evLog('Lãm Làng', 'Đã vào bí cảnh');
        else evLog('Lãm Làng', 'Chưa vào được: ' + (res && res.why || 'không rõ'));
      });
      return true;
    }
    if (!cfg.llRun) return false; // tự vào bằng tay: để người chơi tự đánh
    var a = st.ll || (st.ll = evNew());
    a.inside = true;
    var S = U.st;
    if (!S || me.downed) { a.step = 'chờ trạng thái bí cảnh'; return false; }
    if (S.gd === 'xong') { a.step = 'kết thúc · chờ bí cảnh đưa ra'; return false; }
    // Thệ Nguyện: chốt trước khi Tà Soái hiện; game tự mở bảng chọn → chọn xong thì đóng bảng.
    if (S.the && a.theSent && !a.theClosed) { a.theClosed = true; var H = P.HUD; if (H && H.dialogOpen && H.closeDialog) H.closeDialog(); }
    if (!S.the && (S.gd === 'tap_hop' || S.gd === 'song_tuyen') && now() - (a.theAt || 0) > 5000) {
      a.theAt = now(); a.theSent = true;
      var theId = LL.THE[cfg.llThe] ? cfg.llThe : LL.THE_MAC_DINH;
      G.cmd('lamlang.the', { id: theId }, function (res) { if (res && res.ok) evLog('Lãm Làng', 'Thệ Nguyện: ' + LL.THE[theId].ten); });
    }
    var teDan = g.sw.map.data && g.sw.map.data.lamLangTeDan || LL_TE_DAN;
    if (S.gd === 'tap_hop') {
      a.lane = llLaneAuto(g);
      a.step = 'tập hợp · chờ Song Tuyến' + (cfg.llTuyen === 'auto' ? ' · được chia ' + (a.lane === 'tru' ? 'Đài Đá (trụ)' : 'Cổng Đông (lồng)') : '');
      setAuto(g, false); evWalk(g, a, LL_GIENG.tx, LL_GIENG.ty, 90); return true;
    }
    var mobs = mobsAlive(g);
    var bossPhase = S.gd === 'quyet_chien' || !!(S.boss && !S.boss.dead);
    a.boss = bossPhase;
    var cp = bossPhase ? llCoop(g, a, mobs) : undefined;
    if (cp !== undefined) return cp;
    // Bóng Tàn Tà Hồn (đồng môn vừa gục): hạ trong 15s thì +5% Tông Mệnh, để sống thì Tà Soái hồi máu, thêm kháng.
    // Đang có Tà Soái thì KHÔNG bỏ boss đi đánh Bóng Tàn (đồng môn khác lo); chỉ diệt Bóng Tàn khi chưa / không thấy Tà Soái.
    var bossHere = bossPhase && mobs.some(function (m) { return m.type === LL.BOSS; });
    var bt = bossHere ? null : evNearest(g, mobs.filter(function (m) { return m.type === 'bong_tan_ta_hon' && dist(me.x, me.y, m.x, m.y) < 600; }));
    if (bt) { a.step = 'diệt Bóng Tàn Tà Hồn (15s, không thì Tà Soái hồi máu)'; evEngage(g, a, bt); return true; }
    if (bossPhase) {
      // Có Tà Soái thì dồn Tà Soái. Chỉ đánh Quỷ Phiên đang cắn sát mình khi Tà Soái không ở cạnh (không đuổi đám âm hồn).
      var boss = mobs.filter(function (m) { return m.type === LL.BOSS; })[0];
      var qp = evNearest(g, mobs.filter(function (m) { return m.type === LL.QUY_PHIEN.TYPE && dist(me.x, me.y, m.x, m.y) < 90; }));
      if (qp && (!boss || dist(me.x, me.y, boss.x, boss.y) > 120)) { a.step = 'diệt Quỷ Phiên đang cắn (hút máu cho Tà Soái)'; evEngage(g, a, qp); return true; }
      if (boss) {
        var bs = llBurst(g, S, boss);
        a.step = 'dồn Tà Soái ' + evPct(boss) + (S.giap ? ' · giáp ' + Math.round(S.giap * 100) + '%' : '') + bs;
        // Đang bị Xích (đã đứng gần bạn xích): không bỏ bạn xích chạy theo Tà Soái ở xa.
        if (a.hold > now() && dist(me.x, me.y, boss.x, boss.y) > 200) { evPin(g, boss); setAuto(g, false); return true; }
        evEngage(g, a, boss);
        return true; // giữ quyền điều khiển: không để chọn mục tiêu / nhặt đồ / farm kéo đi chỗ khác
      }
      a.step = 'tới Tế Đàn đánh Tà Soái';
      return evWalk(g, a, teDan.tx, teDan.ty, 120);
    }
    // Song Tuyến: lồng sắp bị huyết tế làm trước.
    var lao = (S.lao || []).filter(function (x) { return x.tt === 'giam'; }).sort(function (p, q) { return (p.het || 9e15) - (q.het || 9e15); });
    var tru = (S.tru || []).filter(function (x) { return !x.vo; });
    var first = cfg.llTuyen === 'auto' ? (a.lane || llLaneAuto(g)) : cfg.llTuyen;
    var order = first === 'tru' ? ['tru', 'lao'] : ['lao', 'tru'];
    for (var i = 0; i < order.length; i++) {
      if (order[i] === 'lao' && lao.length) return llCage(g, a, lao[0], mobs);
      if (order[i] === 'tru' && tru.length) return llTower(g, a, mobs);
    }
    a.step = 'hai tuyến xong · chờ Tà Soái ở Tế Đàn';
    return evWalk(g, a, teDan.tx, teDan.ty, 120);
  }




  /* --- Giai đoạn 36 (Lập Công Hậu Kỳ): Thạch Quy biến dị --- */
  // Hậu Kỳ giai đoạn 36: hạ Thạch Quy ở Miếu Ông Trường Con (100 con biến dị + Mảnh Bia + Xích Diễm Quy Đan), biến dị đánh trước.
  var TQ_MAP = 'dong_mach_ngam', TQ_EVENT_MS = 5 * 60000;
  function tqLog(m) { klog('[GĐ 36] ' + m); say('GĐ 36: ' + m); }
  function tqNeed(P) {
    var H = P.HauKy, Q = P.Quest, I = P.Inventory;
    if (!H || !Q || !Q.soThachQuyBienDi || Q.stage !== (Q.LAP_CONG_STAGE || (H.GD && H.GD.LAP_CONG))) return null;
    var n = Q.soThachQuyBienDi(), items = (H.TQ_NOP || []).map(function (x) { return { id: x[0], can: x[1], co: I && I.count ? I.count(x[0]) : 0 }; });
    return n < H.TQ_BIEN_DI_CAN || items.some(function (x) { return x.co < x.can; }) ? { n: n, can: H.TQ_BIEN_DI_CAN, items: items } : null;
  }
  function tqText(P, nd) {
    var I = P.ITEMS || {};
    return 'biến dị ' + nd.n + '/' + nd.can + nd.items.map(function (x) { return ' · ' + (I[x.id] ? I[x.id].name : x.id) + ' ' + Math.min(x.co, x.can) + '/' + x.can; }).join('');
  }
  function tqSpawns(P) {
    var MD = P.MapData || {}, m = MD.get ? MD.get(TQ_MAP) : null, T = P.CONFIG.TILE || 32, L = P.HauKy && P.HauKy.TQ_LOAI || 'thach_quy';
    if (!m || m.id !== TQ_MAP) Object.keys(MD).some(function (k) { var x = MD[k]; if (x && typeof x === 'object' && x.id === TQ_MAP) { m = x; return true; } return false; });
    return (m && m.enemies || []).filter(function (e) { return e && e.type === L && isFinite(e.tx); }).map(function (e) { return { x: (e.tx + 0.5) * T, y: (e.ty + 1) * T }; });
  }
  function tqTargets(g) {
    var me = g.me, L = g.P.HauKy && g.P.HauKy.TQ_LOAI || 'thach_quy';
    return (g.sw.enemies || []).filter(function (m) { return m && !m.dead && m.hp > 0 && m.type === L; })
      .sort(function (a, b) { return ((b.bienDi ? 1 : 0) - (a.bienDi ? 1 : 0)) || dist(me.x, me.y, a.x, a.y) - dist(me.x, me.y, b.x, b.y); });
  }
  function tickTq36(g) {
    var P = g.P, me = g.me, nd = tqNeed(P);
    if (!nd) { if (st.tq) tqLog('Đủ phần Thạch Quy của Giai đoạn 36 → về nộp ở Tông Môn Quản Sự'); st.tq = null; return 'done'; }
    var a = st.tq || (st.tq = { travels: 0, routeAt: 0, khuWant: 0, khuAt: 0, touches: 0, touchAt: 0, pts: null, last: -1, target: null, step: '' });
    if (nd.n !== a.last) { if (a.last >= 0) tqLog('Hạ được Thạch Quy biến dị · ' + tqText(P, nd)); a.last = nd.n; }
    if (g.mapId !== TQ_MAP) {
      a.step = 'đi ' + mapName(TQ_MAP);
      if (!jobGo(g, a, TQ_MAP, 'GĐ 36: đi ' + mapName(TQ_MAP) + ' hạ Thạch Quy', tqLog)) return 'fail';
      return 'busy';
    }
    if (st.travel && st.travel.map === TQ_MAP && !a.khuWant) stopTravel();
    // Thiên Đạo báo Thạch Quy biến dị ở đây kèm khu: sang thẳng khu đó.
    var L = P.HauKy && P.HauKy.TQ_LOAI || 'thach_quy';
    var ev = bdEvents.filter(function (e) { return !e.done && e.type === L && e.map === TQ_MAP && e.khu && now() - e.at < TQ_EVENT_MS; }).slice(-1)[0];
    if (ev && gaKhu(P) !== ev.khu && !a.target) {
      if (a.khuWant !== ev.khu) {
        a.khuWant = ev.khu; a.khuAt = 0; a.touches = 0; a.touchAt = 0;
        var rRem = ev.spawnAt && ev.spawnAt > now() ? (' (còn ' + Math.ceil((ev.spawnAt - now()) / 1000) + 's)') : '';
        tqLog('Thiên Đạo báo Thạch Quy biến dị ở khu ' + ev.khu + rRem + ' → sang');
      }
      a.step = 'sang khu ' + ev.khu + ' (Thiên Đạo báo biến dị)';
      if (khuGo(g, a, '[GĐ 36]')) return 'busy';
      ev.done = true;
    }
    a.khuWant = 0;
    var list = tqTargets(g), t = a.target && list.indexOf(a.target) >= 0 && (a.target.bienDi || !list[0].bienDi) ? a.target : list[0];
    if (t) {
      if (t !== a.target && t.bienDi) tqLog('Thấy Thạch Quy biến dị ở khu ' + gaKhu(P) + ' → đánh');
      a.target = t;
      a.step = (t.bienDi ? 'đánh Thạch Quy BIẾN DỊ ' : 'hạ Thạch Quy ') + num(t.hp) + '/' + num(t.hpMax) + ' · ' + tqText(P, nd);
      if (st.travel) stopTravel();
      var T = P.Targeting, key = 'foe:' + t.id;
      if (T && T.list && T.list.some(function (e) { return e.key === key; })) { T.key = key; T.manual = true; }
      st.farmTarget = t;
      setAuto(g, true);
      var reach = (P.Player.reach ? P.Player.reach() : 26) + (t.def && t.def.bodyRadius || 0) - 2;
      if (dist(me.x, me.y, t.x, t.y) > Math.max(reach, 140) && !(me.path && me.path.length && now() - a.routeAt < 600)) {
        var r = spotCheck(g).route(t.x, t.y);
        if (r) { moveFighting(g, r.path); a.routeAt = now(); }
      } else if (!g.sw.approach) g.sw.approach = { key: key, until: P.Game.time + 2 };
      return 'busy';
    }
    // Nếu có thông báo báo trước 20s và chưa xuất hiện: đứng sẵn ở điểm spawn chờ
    if (ev && ev.spawnAt && now() < ev.spawnAt && !a.target) {
      var remainSec = Math.ceil((ev.spawnAt - now()) / 1000);
      a.step = 'chờ Thạch Quy biến dị xuất hiện (' + remainSec + 's) · khu ' + gaKhu(P);
      if (!a.pts || !a.pts.length) a.pts = tqSpawns(P).map(function (q) { return { x: q.x, y: q.y, prio: true, dwell: 1500 }; });
      if (a.pts && a.pts[0] && dist(me.x, me.y, a.pts[0].x, a.pts[0].y) > 20) {
        var rSp = spotCheck(g).route(a.pts[0].x, a.pts[0].y);
        if (rSp) moveFighting(g, rSp.path);
      }
      return 'busy';
    }
    a.target = null;
    if (tickLoot(g)) { a.step = 'nhặt đồ rơi'; return 'busy'; }
    // Không thấy con nào: đi vòng qua các chỗ sinh Thạch Quy (máy chủ chỉ gửi quái ở gần).
    if (!a.pts || !a.pts.length) a.pts = tqSpawns(P).map(function (q) { return { x: q.x, y: q.y, prio: true, dwell: 1500 }; });
    if (!a.pts.length) { tqLog('Không thấy chỗ sinh Thạch Quy trong dữ liệu bản đồ'); return 'fail'; }
    setAuto(g, false);
    a.step = 'đi vòng chỗ sinh Thạch Quy · ' + tqText(P, nd);
    if (!sweepStep(g, a, a.pts)) a.pts = null;
    return 'busy';
  }

  /* --- Vạn Hoang Chiến Trường: Sinh tồn Battle Royale đỉnh cao --- */
  // Tự ghi danh, né bão độc, loot rương/Huyết Lan theo thứ tự ưu tiên, ẩn thân bụi rậm & tự vệ PK
  var HL_MARGIN = 50, HL_REACH = 40;
  function hlState(P) { var U = P.ChienTruongUI; return U && U.trangThai ? U.trangThai() : null; }
  function hlZone(P, c) {
    var CT = P.ChienTruong, G = P.Gateway;
    if (!CT || !CT.boTai || !c || !c.bo || !c.bo.tam) return null;
    try { var t = (G && G.gioMayChu && G.gioMayChu()) || Date.now(); return CT.boTai({ r0: c.bo.r0, tam0: c.bo.tam, gd: c.bo.ds || [] }, t - c.bo.t0); } catch (e) { return null; }
  }
  function hlSafe(z, x, y) {
    if (!z) return true;
    if (dist(x, y, z.x, z.y) > z.r - HL_MARGIN) return false;
    return !(z.dich && z.toiHet != null && z.toiHet < 25000 && dist(x, y, z.dich.x, z.dich.y) > z.dich.r - HL_MARGIN);
  }
  function tickChienTruong(g) {
    var P = g.P, CT = P.ChienTruong, G = P.Gateway, me = g.me;
    if (!cfg.hlRun || !CT || !P.ChienTruongUI || !G || !G.chienTruong) { st.hl = null; return false; }

    var U = P.ChienTruongUI, tNow = (G.gioMayChu && G.gioMayChu()) || Date.now();
    var lich = CT.lich ? CT.lich(tNow) : null;

    // 1. Ngoài Chiến Trường: tự động ghi danh khi tới giai đoạn DANG_KY
    if (g.mapId !== CT.MAP && g.mapId !== CT.MAP_CHO) {
      if (lich && lich.giaiDoan === 'DANG_KY' && !me.downed) {
        var bang = me.realmId && CT.bangCua ? CT.bangCua(me.realmId) : null;
        var s = U.st;
        var daGhi = s && s.lich && s.lich.id === lich.id && s.daGhi;
        if (bang && bang.bang && !daGhi && now() - (st.ctRegAt || -1e9) > 20000) {
          st.ctRegAt = now();
          G.chienTruong('ghiDanh', {}, function (res) {
            klog('[Chiến Trường] Ghi danh Vạn Hoang Chiến Trường: ' + (res && res.ok ? 'thành công' : (res && res.why || 'chờ')));
          });
        }
      }
      return false;
    }

    // 2. Trong Phòng Chờ (MAP_CHO)
    if (g.mapId === CT.MAP_CHO) {
      st.hl = null;
      var stCho = U.st;
      if (stCho && (stCho.trangThai === 'LOAI' || stCho.trangThai === 'XONG')) {
        if (now() - (st.ctLeaveAt || -1e9) > 4000) {
          st.ctLeaveAt = now();
          G.chienTruong('roi');
          klog('[Chiến Trường] Đã xong / bị loại → rời phòng chờ về làng');
        }
      }
      return true;
    }

    // 3. Đang trên đảo Chiến Trường (CT.MAP)
    if (g.mapId !== CT.MAP || me.downed) { st.hl = null; return false; }
    var c = hlState(P);
    if (!c) return false;

    // 3.1. Nếu đã thành bóng ma (bị loại / quan sát)
    if (c.bong) {
      if (now() - (st.ctBongAt || -1e9) > 4000) {
        st.ctBongAt = now();
        G.chienTruong('roi');
        klog('[Chiến Trường] Bị loại thành hồn ma → về phòng chờ');
      }
      return true;
    }

    var a = st.hl || (st.hl = { routeAt: 0, sentAt: 0, id: null, tries: 0, fails: {}, got: 0, step: '', bushAt: 0 });

    // 3.2. Đang trong tiến trình mở rương / hái lan (đứng yên 2s)
    if (c.mo) {
      if (me.path && me.path.length) me.path.length = 0;
      setAuto(g, false);
      a.step = 'đang mở (đứng yên)';
      return true;
    }

    var z = hlZone(P, c);

    // 3.3. Bão độc & vòng bo: nếu đang ở ngoài bo hoặc bo đang thu mà vị trí hiện tại không an toàn
    var isOutside = (c.nhip && c.nhip.ngoai) || !hlSafe(z, me.x, me.y);
    if (isOutside && z) {
      setAuto(g, false);
      var safeCenter = z.dich || z;
      var dSafe = dist(me.x, me.y, safeCenter.x, safeCenter.y);
      a.step = 'BÃO ĐỘC! Chạy vào bo an toàn (' + Math.round(dSafe) + 'px)';
      if (!(me.path && me.path.length && now() - a.routeAt < 600)) {
        var rSafe = spotCheck(g).route(safeCenter.x, safeCenter.y);
        if (rSafe) { moveFighting(g, rSafe.path); }
        else { moveFighting(g, [{ x: safeCenter.x, y: safeCenter.y }]); }
        a.routeAt = now();
      }
      return true;
    }

    // 3.4. Chiến đấu PK & tự vệ sinh tồn
    var foes = [];
    if (G.remotes) {
      Object.keys(G.remotes).forEach(function (id) {
        var r = G.remotes[id];
        if (r && !r.downed && !r.dead && isFinite(r.x)) foes.push(r);
      });
    }
    var closeFoes = foes.filter(function (r) { return dist(me.x, me.y, r.x, r.y) <= 150; });
    var hpPct = me.hpMax ? (me.hp / me.hpMax) : 1;

    // Tình huống máu thấp (< 28%) khi có địch cận kề: ưu tiên né bụi cỏ gần nhất trong bo để ẩn thân
    if (hpPct < 0.28 && closeFoes.length && c.bui) {
      var safeBushes = Object.keys(c.bui).map(function (k) { return c.bui[k]; })
        .filter(function (b) { return b && hlSafe(z, b.x, b.y); })
        .sort(function (b1, b2) { return dist(me.x, me.y, b1.x, b1.y) - dist(me.x, me.y, b2.x, b2.y); });
      if (safeBushes.length) {
        var bush = safeBushes[0], bDist = dist(me.x, me.y, bush.x, bush.y);
        if (bDist > 20) {
          a.step = 'máu thấp (' + Math.round(hpPct * 100) + '%) → chạy vào bụi ẩn thân (' + Math.round(bDist) + 'px)';
          var rBush = spotCheck(g).route(bush.x, bush.y);
          if (rBush) moveFighting(g, rBush.path);
          else moveFighting(g, [{ x: bush.x, y: bush.y }]);
          return true;
        } else if (c.an) {
          if (me.path && me.path.length) me.path.length = 0;
          a.step = 'đang ẩn thân trong bụi cỏ (vô hình)';
          return true;
        }
      }
    }

    // Nếu có địch trong cự ly 140px: đánh thường tự vệ hoặc dứt điểm kẻ địch thấp máu
    if (closeFoes.length) {
      closeFoes.sort(function (e1, e2) { return (e1.hp || 1) - (e2.hp || 1); });
      var targetFoe = closeFoes[0], fDist = dist(me.x, me.y, targetFoe.x, targetFoe.y);
      setAuto(g, false);
      a.step = 'tự vệ chiến đấu đối thủ (' + Math.round(fDist) + 'px)';
      if (P.Targeting && P.Targeting.khoaVao) {
        try { P.Targeting.khoaVao(targetFoe); } catch (e) { }
      }
      if (P.Player && P.Player.attack) P.Player.attack(me, targetFoe);
      if (fDist > 38 && !(me.path && me.path.length && now() - a.routeAt < 600)) {
        var rAtk = spotCheck(g).route(targetFoe.x, targetFoe.y);
        if (rAtk) { moveFighting(g, rAtk.path); }
        else { moveFighting(g, [{ x: targetFoe.x, y: targetFoe.y }]); }
        a.routeAt = now();
      }
      return true;
    }

    // 3.5. Loot rương & hái Vạn Hoang Huyết Lan (ưu tiên: Huyết Lan > Rương Vàng > Rương thường)
    var lay = c.lay || {};
    var chests = Object.keys(c.ruong || {}).map(function (k) { return c.ruong[k]; })
      .filter(function (r) { return r && !lay[r.id] && !(a.fails[r.id] > now()) && hlSafe(z, r.x, r.y); });

    if (a.id && !(c.ruong || {})[a.id]) {
      a.got++;
      klog('[Chiến Trường] Đã mở thành công (' + a.got + ' rương/khóm kỳ này)');
      a.id = null;
      a.tries = 0;
    }

    if (chests.length) {
      chests.sort(function (x, y) {
        var pX = x.thao ? 3000 : x.vang ? 1500 : 500;
        var pY = y.thao ? 3000 : y.vang ? 1500 : 500;
        return (pY - pX) || (dist(me.x, me.y, x.x, x.y) - dist(me.x, me.y, y.x, y.y));
      });
      var h = chests[0], d = dist(me.x, me.y, h.x, h.y);
      var chestName = h.thao ? 'khóm Huyết Lan' : h.vang ? 'Rương Vàng' : 'Rương Buff';
      setAuto(g, false);
      if (d > HL_REACH) {
        a.step = 'tới ' + chestName + ' (' + Math.round(d) + 'px)';
        if (!(me.path && me.path.length && now() - a.routeAt < 700)) {
          var rCh = spotCheck(g).route(h.x, h.y);
          if (rCh) { moveFighting(g, rCh.path); a.routeAt = now(); }
          else a.fails[h.id] = now() + 20000;
        }
        return true;
      }
      if (me.path && me.path.length) me.path.length = 0;
      if (a.id !== h.id) { a.id = h.id; a.tries = 0; }
      if (now() - a.sentAt > 2600) {
        if (++a.tries > 3) {
          a.fails[h.id] = now() + 20000;
          a.id = null;
          klog('[Chiến Trường] Mở mãi không được ' + chestName + ' → bỏ qua 20 giây');
          return false;
        }
        a.sentAt = now();
        G.chienTruong('moRuong', { id: h.id });
        klog('[Chiến Trường] Bắt đầu mở ' + chestName);
      }
      a.step = 'mở ' + chestName;
      return true;
    }

    // 3.6. Cơ chế ẩn nấp bụi rậm (Bush Stealth Survival) khi rảnh rỗi
    if (c.an) {
      if (me.path && me.path.length) me.path.length = 0;
      a.step = 'đang ẩn thân trong bụi cỏ (vô hình)';
      return true;
    }

    if (c.bui) {
      var bushes = Object.keys(c.bui).map(function (k) { return c.bui[k]; })
        .filter(function (b) { return b && hlSafe(z, b.x, b.y); })
        .sort(function (b1, b2) { return dist(me.x, me.y, b1.x, b1.y) - dist(me.x, me.y, b2.x, b2.y); });
      if (bushes.length) {
        var nb = bushes[0], nd = dist(me.x, me.y, nb.x, nb.y);
        if (nd > 20) {
          a.step = 'vào bụi cỏ ẩn thân (' + Math.round(nd) + 'px)';
          if (!(me.path && me.path.length && now() - a.routeAt < 800)) {
            var rB = spotCheck(g).route(nb.x, nb.y);
            if (rB) { moveFighting(g, rB.path); a.routeAt = now(); }
          }
          return true;
        } else {
          if (me.path && me.path.length) me.path.length = 0;
          a.step = 'đứng yên trong bụi chờ kích hoạt ẩn thân';
          return true;
        }
      }
    }

    // 3.7. Nếu không có bụi, di chuyển chậm rãi vào tâm vùng an toàn
    if (z) {
      var center = z.dich || z;
      if (dist(me.x, me.y, center.x, center.y) > 60) {
        a.step = 'di chuyển vào tâm bo an toàn';
        if (!(me.path && me.path.length && now() - a.routeAt < 1000)) {
          var rC = spotCheck(g).route(center.x, center.y);
          if (rC) { moveFighting(g, rC.path); }
          else { moveFighting(g, [{ x: center.x, y: center.y }]); }
          a.routeAt = now();
        }
        return true;
      }
    }

    return false;
  }

  function tickHuyetLan(g) {
    return tickChienTruong(g);
  }


  /* --- Thống kê cướp tiêu --- */
  // Đếm theo thông báo của game (VanTieuUI.nhan): "bat" kèm cuop = cướp được xe; "het" của xe cướp được: ly "giao" = dắt về
  // giao thành công (+ Linh Thạch thưởng), lý do khác = mất xe giữa đường (bị cướp lại, tụt dây kéo, hết giờ…). Lưu theo ngày.
  var CT_STAT_KEY = 'ttbot.cuoptieu.v1';
  var ctStats = (function () { try { var o = JSON.parse(localStorage.getItem(CT_STAT_KEY) || 'null'); if (o && o.all) return o; } catch (e) { } return { ngay: '', rob: 0, giao: 0, mat: 0, lt: 0, all: { rob: 0, giao: 0, mat: 0, lt: 0 } }; })();
  function ctStatDay() { var P = window.PNTT, V = P && P.VanTieu; try { return V && V.day ? V.day(Date.now()) : new Date(Date.now() + 252e5).toISOString().slice(0, 10); } catch (e) { return ''; } }
  function ctStatRoll() { var d = ctStatDay(); if (ctStats.ngay !== d) { ctStats.ngay = d; ctStats.rob = ctStats.giao = ctStats.mat = ctStats.lt = 0; } }
  function ctStatAdd(k, n) { ctStatRoll(); ctStats[k] += n; ctStats.all[k] += n; try { localStorage.setItem(CT_STAT_KEY, JSON.stringify(ctStats)); } catch (e) { } }
  function ctStatToday() { ctStatRoll(); return { rob: ctStats.rob, giao: ctStats.giao, mat: ctStats.mat, lt: ctStats.lt }; }
  function hookVanTieu(P) {
    var U = P.VanTieuUI;
    if (!U || !U.nhan || U._ttStat) return;
    U._ttStat = true;
    var orig = U.nhan;
    U.nhan = function (a) {
      var had = !!U.chuyen, r = orig.apply(this, arguments);
      try {
        var V = P.VanTieu;
        if (a && a.act === 'bat' && a.cuop && !had) {
          st.vtRobbed = true; ctStatAdd('rob', 1);
          klog('[Cướp tiêu] Cướp thành công ' + (V && V.tenHang ? V.tenHang(a.hang) : 'xe') + ' (hôm nay ' + ctStats.rob + ')');
        } else if (a && a.act === 'het' && had) {
          if (st.vtRobbed) {
            st.vtRobbed = false;
            if (a.ly === 'giao') { ctStatAdd('giao', 1); if (a.thuong > 0) ctStatAdd('lt', a.thuong | 0); klog('[Cướp tiêu] Dắt về giao thành công' + (a.thuong ? ' +' + a.thuong + ' Linh Thạch' : '') + ' (hôm nay ' + ctStats.giao + ')'); }
            else { ctStatAdd('mat', 1); klog('[Cướp tiêu] Mất xe giữa đường' + (a.ly ? ' (' + a.ly + ')' : '')); }
          } else {
            st.lastVtResult = a.ly === 'giao' ? ('Giao hàng xong' + (a.thuong ? ' · +' + a.thuong + ' Linh Thạch' : '')) : ('Mất xe giữa đường' + (a.ly ? ' (' + a.ly + ')' : ''));
            klog('[Vận Tiêu] ' + st.lastVtResult);
            if (tgRec && tgRec.k === 'vt') tgAdd(tgRec, st.lastVtResult);
          }
        }
      } catch (e) { }
      return r;
    };
  }

  /* --- Tổ đội cướp tiêu (camp Thung Lũng) --- */
  // Theo VanTieu / VanTieuUI: xe là quái def.tieuXa; mỗi người góp tối đa KEP_DPS/giây, xe không bị đánh 6 giây thì tự hồi; ai đánh …
  var CT_CAMP_IN = 150, CT_DRIFT = 260, CT_GUARD_R = 340, CT_FLAG_MS = 6000, CT_FOLLOW = 90;
  function ctLog(m) { klog('[Cướp tiêu] ' + m); say('Cướp tiêu: ' + m); }
  function ctMap(P) { var V = P.VanTieu, T = V && V.TUYEN; return T ? T[T.length - 2] : 'thach_phong_thung_lung'; }
  function ctStones(P) { var L = P.Loot; return L && L.stoneToday ? L.stoneToday(P) : null; }
  function ctCapped(P) { var s = ctStones(P); return !!(s && s.tran > 0 && s.da >= s.tran); }
  function ctTurns(P) { var V = P.VanTieu; return V && V.conLuotCuop ? V.conLuotCuop(P.Quest && P.Quest.flags, Date.now()) : 0; }
  function ctWhyNot(g) {
    var P = g.P, V = P.VanTieu;
    if (!cfg.ctRun) return 'đang tắt';
    if (!V || !V.TUYEN) return 'bản game không có Vận Tiêu';
    if (V.daTrucCo && !V.daTrucCo(P)) return 'chưa tới Trúc Cơ';
    if (V.dangMo && !V.dangMo(Date.now())) return 'ngoài giờ Vận Tiêu (' + V.GIO_MO + 'h–' + V.GIO_DONG + 'h)';
    if (cfg.ctCap && !ctCapped(P)) { var s = ctStones(P); return 'chưa đủ trần Linh Thạch ngày' + (s ? ' (' + num(s.da) + '/' + num(s.tran) + ')' : ''); }
    return '';
  }
  // Đồng đội đang kéo xe: cờ đỏ (game ép khi áp tải) hoặc báo qua kênh chung.
  var ctHaulMem = {};
  function ctGate(g, x, y) { var T = g.P.CONFIG.TILE || 32, b = null, bd = 260; (g.sw.map.data.portals || []).forEach(function (p) { var d = dist(x, y, (p.tx + 0.5) * T, (p.ty + 0.5) * T); if (d < bd) { bd = d; b = p.toMap; } }); return b; }
  function ctHaulers(g) {
    var P = g.P, G = P.Gateway, pt = teamParty(P), self = G && G.selfId, out = [], RK = ((P.VanTieu && P.VanTieu.DAY_KEO) || 320) + 40;
    if (!pt) return out;
    var carts = (g.sw.enemies || []).filter(function (c) { return c && !c.dead && c.def && c.def.tieuXa; });
    pt.members.forEach(function (m) {
      if (!m || m.id === self || !teamHas(m.name)) return;
      var r = G.remotes && G.remotes[m.id], here = !!(r && isFinite(r.x)), b = teamSeen[m.id] && now() - teamSeen[m.id].at < TEAM_FRESH_MS ? teamSeen[m.id] : null;
      // Có tin kênh chung thì tin theo đó. Không có (mỗi người một máy): cờ đỏ + có xe tiêu sát bên (trong dây kéo). Người hộ
      // tống cũng cắm cờ đỏ nên chỉ cờ đỏ thì không đủ; giao xong xe biến mất → cờ đỏ hộ tống không bị nhận nhầm là người kéo.
      var mm = ctHaulMem[m.id];
      if (b && b.ct ? b.ct.haul : here && r.coChien === 'do' && carts.some(function (c) { return dist(c.x, c.y, r.x, r.y) <= RK; })) { if (here) ctHaulMem[m.id] = { at: now(), map: g.mapId, x: r.x, y: r.y }; }
      else if (!here && !(b && b.ct) && mm && now() - mm.at < 90000) {
        // Người kéo vừa khuất (qua cổng sang map khác / ra ngoài tầm nhìn): vẫn đi theo. Map lấy theo danh sách nhóm, chưa
        // cập nhật thì đoán theo cổng gần chỗ thấy cuối; tới nơi thấy lại người kéo là bám tiếp, thấy mà hết xe là thôi.
        var mp = m.mapId && m.mapId !== mm.map ? m.mapId : (mm.map === g.mapId && ctGate(g, mm.x, mm.y)) || mm.map;
        out.push({ id: m.id, name: m.name, map: mp, x: mp === mm.map ? mm.x : NaN, y: mp === mm.map ? mm.y : NaN, lost: true });
        return;
      } else { if (here || (b && b.ct)) delete ctHaulMem[m.id]; return; }
      out.push({ id: m.id, name: m.name, map: here ? g.mapId : (b && b.map) || m.mapId, x: here ? r.x : b && b.x, y: here ? r.y : b && b.y });
    });
    return out;
  }
  function ctOurs(g, cart, haulers) {
    var V = g.P.VanTieu, R = (V && V.DAY_KEO) || 320;
    return haulers.some(function (h) { return h.map === g.mapId && isFinite(h.x) && dist(h.x, h.y, cart.x, cart.y) <= R + 40; });
  }
  function ctHang(P, id) { var H = P.VanTieu && P.VanTieu.HANG || []; for (var i = 0; i < H.length; i++) if (H[i].id === id) return i; return -1; }
  // Loại xe người chơi chọn cướp (hạng lạ / chưa biết thì vẫn cướp).
  function ctHangOn(id) { return cfg['ctH_' + id] !== false; }
  function ctCarts(g, haulers) {
    var me = g.me, P = g.P;
    return (g.sw.enemies || []).filter(function (m) { return m && !m.dead && m.hp > 0 && m.def && m.def.tieuXa && ctHangOn(m.def.tieuXaHang) && !ctOurs(g, m, haulers); })
      .sort(function (a, b) { return (ctHang(P, b.def.tieuXaHang) - ctHang(P, a.def.tieuXaHang)) || dist(me.x, me.y, a.x, a.y) - dist(me.x, me.y, b.x, b.y); });
  }
  // Chỗ camp: trong Thung Lũng, cách cổng từ Mỏ Linh Thạch sang một đoạn về phía giữa map (xe vừa qua cổng là thấy).
  function ctCamp(g) {
    var V = g.P.VanTieu, i = V.TUYEN.indexOf(g.mapId), prev = V.TUYEN[i - 1], pt = prev ? portalTarget(g, prev)[0] : null;
    if (!pt) return { x: g.sw.map.pxWidth / 2, y: g.sw.map.pxHeight / 2 };
    var cx = g.sw.map.pxWidth / 2, cy = g.sw.map.pxHeight / 2, d = dist(pt.x, pt.y, cx, cy) || 1;
    return { x: pt.x + (cx - pt.x) / d * CT_CAMP_IN, y: pt.y + (cy - pt.y) / d * CT_CAMP_IN };
  }
  function ctBack(g) { var f = cfg.farm; return f ? { map: f.map, x: f.x, y: f.y } : takeBack(g); }
  // Màu cờ: nhóm trưởng (tên đầu danh sách Tổ đội trợ thủ, không có danh sách thì trưởng tổ đội) dùng màu đã chọn sẵn trong …
  var CT_COLORS = { vang: 'vàng', lam: 'lam', luc: 'lục', den: 'đen (Chiến Đấu)' }, CT_ESCORT_FLAG = 'do';
  function ctOwnFlag() { return CT_COLORS[cfg.ctFlag] ? cfg.ctFlag : 'vang'; }
  function ctLeader(g) {
    var P = g.P, G = P.Gateway, pt = teamParty(P), self = G && G.selfId, L = teamList(), lid = null, lname = '';
    if (pt) {
      var m = L.length ? pt.members.filter(function (x) { return x && plainVi(x.name || '').trim() === L[0]; })[0] : null;
      if (!m) m = pt.members.filter(function (x) { return x && x.id === pt.leaderId; })[0];
      if (m) { lid = m.id; lname = m.name; }
    }
    if (!lid && L.length && L[0] === plainVi(myName(g)).trim()) lid = self;
    return { id: lid, name: lname || myName(g), self: !lid || lid === self };
  }
  function ctWantFlag(g) {
    var ld = ctLeader(g);
    if (ld.self) return { flag: ctOwnFlag(), from: 'mình là nhóm trưởng' };
    var G = g.P.Gateway, r = G.remotes && G.remotes[ld.id], b = teamSeen[ld.id] && now() - teamSeen[ld.id].at < TEAM_FRESH_MS ? teamSeen[ld.id] : null;
    if (r && CT_COLORS[r.coChien]) return { flag: r.coChien, from: 'theo cờ trên người ' + ld.name };
    if (b && b.ct && CT_COLORS[b.ct.flag]) return { flag: b.ct.flag, from: 'theo ' + ld.name + ' (kênh chung)' };
    if (st.ctLeaderFlag && CT_COLORS[st.ctLeaderFlag]) return { flag: st.ctLeaderFlag, from: 'màu ' + ld.name + ' lần trước' };
    return { flag: ctOwnFlag(), from: 'chưa thấy ' + ld.name + ' → màu chọn sẵn' };
  }
  // Đường xe thật: mỗi map cướp được trên tuyến tìm đường đi bộ từ cổng vào tới cổng ra (dữ liệu bản đồ). Thung Lũng chỉ ~28 …
  var ctRoad = {};
  function ctPath(P, id) {
    if (id in ctRoad) return ctRoad[id];
    var T = P.VanTieu.TUYEN, i = T.indexOf(id), m = xcMapDef(P, id), TL = P.CONFIG.TILE || 32;
    if (!m || !m.ground || !m.legend || i < 1 || i >= T.length - 1) return (ctRoad[id] = null);
    var W = m.width, H = m.height, pi = (m.portals || []).filter(function (q) { return q.toMap === T[i - 1]; })[0], po = (m.portals || []).filter(function (q) { return q.toMap === T[i + 1]; })[0];
    if (!pi || !po) return (ctRoad[id] = null);
    function free(x, y) { if (x < 0 || y < 0 || x >= W || y >= H) return false; var lg = m.legend[m.ground[y].charAt(x)]; return !(lg && lg.block); }
    function snap(q) { for (var r = 0; r < 5; r++) for (var dy = -r; dy <= r; dy++) for (var dx = -r; dx <= r; dx++) if (free(q.tx + dx, q.ty + dy)) return (q.ty + dy) * W + q.tx + dx; return -1; }
    var s0 = snap(pi), gi = snap(po);
    if (s0 < 0 || gi < 0) return (ctRoad[id] = null);
    var prev = new Int32Array(W * H).fill(-1), q = [s0], DX = [1, -1, 0, 0, 1, 1, -1, -1], DY = [0, 0, 1, -1, 1, -1, 1, -1];
    prev[s0] = s0;
    for (var h = 0; h < q.length && prev[gi] < 0; h++) {
      var c = q[h], cx = c % W, cy = (c - cx) / W;
      for (var k = 0; k < 8; k++) {
        var nx = cx + DX[k], ny = cy + DY[k];
        if (!free(nx, ny) || (k >= 4 && (!free(nx, cy) || !free(cx, ny)))) continue;
        var ni = ny * W + nx;
        if (prev[ni] < 0) { prev[ni] = c; q.push(ni); }
      }
    }
    if (prev[gi] < 0) return (ctRoad[id] = null);
    var cells = [];
    for (var at = gi; ; at = prev[at]) { cells.push(at); if (at === prev[at]) break; }
    var pts = [], len = 0;
    cells.reverse().forEach(function (ci, j) { var x = (ci % W + 0.5) * TL, y = (Math.floor(ci / W) + 0.5) * TL; if (j) len += dist(x, y, pts[j - 1].x, pts[j - 1].y); pts.push({ x: x, y: y, d: len }); });
    return (ctRoad[id] = { map: id, pts: pts, len: len });
  }
  // Các map trên tuyến cướp được (theo thứ tự xe đi) có đường xe.
  function ctLane(P) { var V = P.VanTieu; return V.TUYEN.filter(function (id) { return !(V.camCuop && V.camCuop(id)) && ctPath(P, id); }); }
  // Điểm trên đường xe cách cổng vào Thăng Long một quãng `back` px (ngược chiều xe đi).
  function ctAt(P, back) {
    var L = ctLane(P);
    for (var i = L.length - 1; i >= 0; i--) {
      var r = ctRoad[L[i]];
      if (back <= r.len || !i) { var d = Math.min(r.len, Math.max(128, r.len - back)), p = r.pts.filter(function (q) { return q.d >= d; })[0] || r.pts[0]; return { map: r.map, x: p.x, y: p.y, f: d / r.len }; }
      back -= r.len;
    }
    return null;
  }
  // Quãng xe còn phải đi tới Thăng Long từ chỗ (x, y) ở map `map`.
  function ctRemain(P, map, x, y) {
    var L = ctLane(P), i = L.indexOf(map);
    if (i < 0) return 0;
    var r = ctRoad[map], b = r.pts[0];
    r.pts.forEach(function (q) { if (dist(q.x, q.y, x, y) < dist(b.x, b.y, x, y)) b = q; });
    for (var s1 = r.len - b.d, j = i + 1; j < L.length; j++) s1 += ctRoad[L[j]].len;
    return s1;
  }
  // Đồng đội đang có mặt cùng map để cùng đánh xe (1–6 người, đếm theo thực tế từng lúc; ai báo hết lượt cướp thì không tính).
  function ctCrew(g) { return teamMates(g).filter(function (m) { return !(m.bus && m.bus.ct && m.bus.ct.turns === 0); }); }
  // Đối thủ cắm cờ (khác màu, không phải người kéo) đang có trong map → đứng sớm hơn (ai đánh trước nhiều hơn thì nhận xe).
  function ctRivalsHere(g) { return hostilePlayers(g).filter(function (r) { return r.coChien && r.coChien !== 'do' && isFinite(r.x); }).length; }
  // Hạng xe nặng nhất đang chọn cướp (lập chỗ đứng cho xe khó nhất).
  function ctHangMax(P) { var h = 'trang'; (P.VanTieu.HANG || []).forEach(function (x) { if (ctHangOn(x.id)) h = x.id; }); return h; }
  function ctCampPt(g, n) {
    var P = g.P, V = P.VanTieu, h = ctHangMax(P), v = 68 * (V.heSoToc ? V.heSoToc(h) || 0.8 : 0.8);
    if (ctRivalsHere(g) > 0) st.ctRivalAt = now();
    var need = (V.hpXe ? V.hpXe(h) : 2016) / (Math.max(1, n) * (V.KEP_DPS || 20)) * 1.35 + (now() - (st.ctRivalAt || -1e9) < 90000 ? 16 : 8);
    var p = ctAt(P, need * v), m = cfg.ctCampMap, r = m && ctLane(P).indexOf(m) >= 0 && ctRoad[m];
    if (r) { // chỗ chờ người dùng chọn
      var d = Math.max(128, Math.min(r.len - 64, r.len * ({ dau: 0, giua: 0.5, cuoi: 0.85 }[cfg.ctCampPos] || 0))), q = r.pts.filter(function (o) { return o.d >= d; })[0] || r.pts[0];
      p = { map: m, x: q.x, y: q.y, f: d / r.len, fixed: true };
      p.have = ctRemain(P, m, q.x, q.y) / v;
    }
    if (p) { p.need = need; p.hang = h; p.n = n; }
    return p;
  }
  function ctStation(g, a) {
    var ld = ctLeader(g), G = g.P.Gateway, hs = ctHaulers(g);
    // Có người đang kéo xe: nhóm trưởng có thể đang kéo / hộ tống → những người ở lại cướp tiếp chọn trưởng tạm là người có id
    // nhỏ nhất trong nhóm ở lại (cùng thứ tự với phần chia hộ tống), đi tuần chung với nhau.
    if (hs.length) {
      var oth = teamMates(g).filter(function (m) { return !hs.some(function (h) { return h.id === m.id; }); });
      var ids = [String(G.selfId)].concat(oth.map(function (m) { return String(m.id); })).sort(), stay = oth.length >= 2 ? ids.slice(2) : ids;
      var lid = stay[0], lm = oth.filter(function (m) { return String(m.id) === lid; })[0];
      ld = lid === String(G.selfId) || !lm ? { id: G.selfId, name: myName(g), self: true } : { id: lm.id, name: lm.name, self: false };
    }
    var lr = !ld.self && G.remotes && G.remotes[ld.id];
    if (lr && isFinite(lr.x) && teamMates(g).length) { a.follow = ld.name; return { x: lr.x + 24, y: lr.y + 18 }; } // bám theo nhóm trưởng (hoặc trưởng tạm)
    a.follow = '';
    var cp = ctCampPt(g, (ctTurns(g.P) > 0 ? 1 : 0) + ctCrew(g).length);
    a.camp = cp;
    return cp || ctCamp(g);
  }
  // Đồng đội báo thấy xe (kênh chung): xe trong map này, mới báo → tới đón.
  function ctMateSighting(g) {
    var best = null;
    Object.keys(teamSeen).forEach(function (id) {
      var b = teamSeen[id], c = b && b.ct && b.ct.cart;
      if (!c || b.map !== g.mapId || now() - b.at > 3000) return;
      if (!best || c.t > best.t) best = c;
    });
    return best;
  }
  function ctFlag(g, want) {
    var G = g.P.Gateway, a = st.ct;
    if (!G || !G.cmd || G.coDenBuoc || (G.coChien || '') === want || vtChuyen(g.P)) return;
    if (a && now() - (a.flagAt || 0) < CT_FLAG_MS) return;
    if (a) a.flagAt = now();
    G.cmd('coChien', { mau: want }, function (res) {
      if (res && res.ok) { G.coChien = res.co || want; ctLog(want === CT_ESCORT_FLAG ? 'Cắm cờ đỏ như đồng đội đang kéo xe (hộ tống)' : want ? 'Cắm cờ ' + (CT_COLORS[want] || want) + ' (cùng màu là đồng minh)' : 'Tháo cờ chiến'); }
      else ctLog('Không đổi được cờ: ' + (res && res.why || 'máy chủ không nhận'));
    });
  }
  function ctMoveTo(g, a, x, y, near) {
    var me = g.me;
    if (dist(me.x, me.y, x, y) <= near) { if (me.path && me.path.length && !a.chase) me.path.length = 0; return false; }
    if (me.path && me.path.length && now() - (a.routeAt || 0) < 700) return true;
    var r = spotCheck(g).route(x, y);
    if (r) { if (me.state === 'sit') g.P.Player.stand(me); moveFighting(g, r.path); a.routeAt = now(); }
    return true;
  }
  // Người chơi đáng đánh: thù địch theo game (khác màu cờ / cờ đen), trừ người cờ đỏ (đang áp tiêu, không cướp được xe) —
  // trừ khi chính người đó đang đánh mình (vừa mất máu mà họ đứng sát).
  function ctHurt(g) { var hit = 0; hpLog.forEach(function (e) { hit += e.d; }); return hit >= Math.max(1, (g.me.hpMax || 100) * 0.005); }
  function ctThreats(g, cx, cy, R) {
    var me = g.me, hurt = ctHurt(g);
    return hostilePlayers(g).filter(function (r) {
      if (!isFinite(r.x)) return false;
      var near = dist(r.x, r.y, cx, cy) <= R, onMe = dist(r.x, r.y, me.x, me.y) <= 200;
      if (r.coChien === 'do') return hurt && dist(r.x, r.y, me.x, me.y) <= 120;
      return near || (onMe && hurt);
    }).sort(function (x, y) { return dist(x.x, x.y, cx, cy) - dist(y.x, y.y, cx, cy); });
  }

  // Đánh xe đang chạy: xe chạy liên tục (theo người kéo), đuổi sau đuôi thì chém xong xe đã đi → mất nửa thời gian đuổi.
  var CT_HIT_S = 0.4, CT_AHEAD_S = 0.9;
  // Xả chiêu vào xe liên tục: chiêu nào hồi xong, đủ linh lực mà lúc chiêu bắn ra xe còn trong tầm (đoán theo vận tốc xe — …
  function ctBurst(g, c) {
    var P = g.P, me = g.me, S = P.Skills, PL = P.Player;
    if (cfg.autoMpTal && me.mpMax > 0 && me.mp / me.mpMax < 0.35) talUse(g, 'thanh_tam', 'xả chiêu vào xe tiêu, linh lực ' + Math.round(me.mp));
    if (me.state === 'attack' || me.state === 'pose' || st.contest) return false;
    var d = dist(me.x, me.y, c.x, c.y);
    if (d <= 260 && talOk(P, me, 'kim_o')) { me.dir = dirToward(c.x - me.x, c.y - me.y); talUse(g, 'kim_o', 'xả vào xe tiêu'); }
    else if (d <= 120 && talOk(P, me, 'hoa_phu')) { me.dir = dirToward(c.x - me.x, c.y - me.y); talUse(g, 'hoa_phu', 'xả vào xe tiêu'); }
    if (!S || !S.dmgOf || !PL.castSpell) return false;
    var vx = c._vx || 0, vy = c._vy || 0, best = null;
    burstSkills(g).forEach(function (def) {
      var cast = def.thunder ? ((P.CONFIG.THUNDER && P.CONFIG.THUNDER.CAST) || 0.34) : (def.cast || 0.5), tf = 0.6 * cast + 0.15;
      var dp = dist(me.x, me.y, c.x + vx * tf, c.y + vy * tf), r = evalSkill(g, def, c, Math.max(d, dp) + 6, [c]);
      if (r.ok && r.eff > 0 && (!best || r.eff > best.eff)) best = r;
    });
    if (!best) return false;
    honPin(P, c, me);
    me.dir = dirToward(c.x - me.x, c.y - me.y);
    me.castTarget = c;
    var ok = best.def.thunder ? PL.castThunder(me) : PL.castSpell(me, best.def);
    if (ok !== true) { me.castTarget = null; return false; }
    if (st.ct) st.ct.casts = (st.ct.casts || 0) + 1;
    klog('[Cướp tiêu] Tung ' + (best.def.short || best.def.name) + ' vào xe (' + num(c.hp) + '/' + num(c.hpMax) + ')');
    return true;
  }
  function tickCtBurst(g) {
    var a = st.ct;
    if (cfg.ctRun && a && a.started && !a.haul && !a.cart && !vtChuyen(g.P) && !ctCanRob(g, ctTurns(g.P))) {
      var nc = ctCarts(g, ctHaulers(g))[0];
      if (nc) { a.cart = nc; a.lastCart = { x: nc.x, y: nc.y, vx: nc._vx || 0, vy: nc._vy || 0, at: now(), map: g.mapId, name: nc.def.name || 'xe' }; ctStrikeCart(g, a, nc); return true; }
    }
    var c = a && !a.haul && a.cart;
    if (!cfg.ctRun || !c || c.dead || c.hp <= 0 || (g.sw.enemies || []).indexOf(c) < 0 || g.me.downed) return false;
    if (ctOurs(g, c, ctHaulers(g)) || ctCanRob(g, ctTurns(g.P))) { a.cart = null; return false; } // đồng đội vừa cướp được / hết lượt: thôi
    return ctBurst(g, c);
  }
  function ctStrikeCart(g, a, c) {
    var P = g.P, me = g.me, PL = P.Player;
    setAuto(g, false);
    honPin(P, c, me);
    st.farmTarget = c;
    if (me.state === 'sit') PL.stand(me);
    var vx = c._vx || 0, vy = c._vy || 0, sp = Math.sqrt(vx * vx + vy * vy);
    if (sp > 160) { vx *= 160 / sp; vy *= 160 / sp; sp = 160; }
    var reach = (PL.reach ? PL.reach() : 26) + (c.def.bodyRadius || 16) - 2;
    var hx = c.x + vx * CT_HIT_S, hy = c.y + vy * CT_HIT_S, dHit = dist(me.x, me.y, hx, hy), d = dist(me.x, me.y, c.x, c.y);
    // Khi máu thấp (< 35%) và có người chơi thù địch quanh xe (< 380px): không lao vào cận chiến nạp mạng
    var hpRatio = me.hp / (me.hpMax || 1);
    var nearPks = hostilePlayers(g).filter(function (p) { return dist(me.x, me.y, p.x, p.y) < 380 || dist(c.x, c.y, p.x, p.y) < 320; });
    if (hpRatio < 0.35 && nearPks.length) {
      if (cfg.autoShield) { if (!talUse(g, 'kim_long', 'thấp máu trong PK cướp tiêu')) talUse(g, 'kim_giap', 'thấp máu trong PK cướp tiêu'); }
      if (cfg.autoMpTal && me.mpMax > 0 && me.mp / me.mpMax < 0.35) talUse(g, 'thanh_tam', 'thấp máu cướp tiêu');
      if (me.path && me.path.length) me.path.length = 0;
      g.sw.tuChiDuong = false;
      var pNear = nearPks[0], dP = dist(me.x, me.y, pNear.x, pNear.y);
      if (dP < 220) {
        var awayX = me.x + (me.x - pNear.x) / (dP || 1) * 80, awayY = me.y + (me.y - pNear.y) / (dP || 1) * 80;
        var rSafe = spotCheck(g).route(awayX, awayY);
        if (rSafe) { moveFighting(g, rSafe.path); return; }
      }
      return;
    }
    if (ctBurst(g, c)) return;
    if (me.state === 'attack' || me.state === 'pose') return;
    // Chiêu sắp hồi xong trong lúc nhát chém (khoá người ATTACK_TIME) chưa xong thì không chém: giữ nhịp xả chiêu liên tục.
    var AT = ((P.CONFIG.PLAYER && P.CONFIG.PLAYER.ATTACK_TIME) || 0.8) / (me.hasteMult || 1), soon = Infinity;
    if (P.Skills && P.Skills.coolLeft) burstSkills(g).forEach(function (def) { if ((me.mp || 0) >= skillCost(g, def).mp) soon = Math.min(soon, P.Skills.coolLeft(me, def)); });
    var holdSwing = soon < AT * 0.85;
    if (dHit <= reach && d <= reach + 12 && !holdSwing) {
      if (me.path && me.path.length) me.path.length = 0;
      g.sw.tuChiDuong = false;
      me.dir = dirToward(c.x - me.x, c.y - me.y);
      if (PL.attack && PL.attack(me, c) !== false) a.swings = (a.swings || 0) + 1;
      return;
    }
    // Chạy kèm bên hông xe: tới đúng chỗ xe sẽ ở lúc đòn kế tiếp trúng (đoán theo vận tốc), lệch ngang nửa tầm cho khỏi bị
    // xe đẩy. Mình chạy nhanh hơn xe nên chém xong bước bù vài chục px là chém tiếp được → gần như mỗi nhịp một nhát.
    var tx = hx, ty = hy;
    if (sp > 12) {
      var ux = vx / sp, uy = vy / sp, sd = (-(me.x - c.x) * uy + (me.y - c.y) * ux) >= 0 ? 1 : -1;
      tx = hx + ux * sp * 0.2 - uy * reach * 0.55 * sd; ty = hy + uy * sp * 0.2 + ux * reach * 0.55 * sd;
    }
    if (me.path && me.path.length && now() - (a.routeAt || 0) < 150) return;
    var r = spotCheck(g).route(tx, ty) || spotCheck(g).route(c.x, c.y);
    if (r) { moveFighting(g, r.path); a.routeAt = now(); }
  }
  // Xe vừa ra khỏi tầm nhìn (máy chủ chỉ gửi thứ ở gần): đuổi theo chỗ đoán xe đang tới, tối đa CT_CHASE_MS.
  var CT_CHASE_MS = 15000;
  function ctChase(g, a) {
    var L = a.lastCart, me = g.me, V = g.P.VanTieu;
    if (!L || now() - L.at > CT_CHASE_MS) { a.lastCart = null; return false; }
    if (L.map !== g.mapId) {
      if (g.mapId !== L.next) { if (!L.next) { a.lastCart = null; return false; } a.step = 'đuổi ' + L.name + ' sang ' + mapName(L.next); jobGo(g, a, L.next, 'Cướp tiêu: đuổi xe sang ' + mapName(L.next), ctLog); return true; }
      L.map = g.mapId; L.next = null; L.x = me.x; L.y = me.y; L.at = now(); // vừa qua cổng: xe ở quanh cổng vào
      if (st.travel) stopTravel();
    }
    var dt = Math.min(6, (now() - L.at) / 1000), px = L.x + L.vx * dt, py = L.y + L.vy * dt;
    var nx = V.TUYEN[V.TUYEN.indexOf(g.mapId) + 1], pp = nx ? portalTarget(g, nx)[0] : null;
    if (pp && (dist(L.x, L.y, pp.x, pp.y) < 220 || dist(px, py, pp.x, pp.y) < 140)) {
      if (V.camCuop && V.camCuop(nx)) { a.lastCart = null; return false; } // xe đã vào Thăng Long: an toàn, thôi
      L.next = nx; a.step = L.name + ' qua cổng sang ' + mapName(nx) + ' → đuổi theo';
      if (!st.travel || st.travel.map !== nx) { startTravel(nx, null, null, 'Cướp tiêu: đuổi xe sang ' + mapName(nx)); st.travel.rush = true; }
      tickTravel(g);
      return true;
    }
    if (dist(me.x, me.y, px, py) < 40 && dt > 3) { a.lastCart = null; return false; }
    a.step = 'đuổi theo ' + L.name + ' (ra khỏi tầm nhìn ' + dt.toFixed(1) + 's)';
    setAuto(g, false);
    if (!(me.path && me.path.length && now() - (a.routeAt || 0) < 400)) { var r = spotCheck(g).route(px, py); if (r) { moveFighting(g, r.path); a.routeAt = now(); } }
    return true;
  }
  // Lý do game không cho cướp lúc này ('' = cướp được), theo VanTieu.checkCuop / camCuop.
  function ctCanRob(g, turns) {
    var P = g.P, V = P.VanTieu, G = P.Gateway;
    if (turns <= 0) return 'hết lượt cướp hôm nay';
    if (vtChuyen(P)) return 'đang kéo xe';
    if (V.camCuop && V.camCuop(g.mapId)) return 'map này không cướp được';
    if (V.checkCuop) { var r = V.checkCuop({ R: P, flags: P.Quest && P.Quest.flags, coChien: G.coChien || '', chinhChu: false, cungToi: false, now: Date.now() }); if (!r.ok) return r.why || 'game không cho cướp'; }
    return '';
  }
  // Xe đồng đội đang kéo: thấy tận mắt (xe trong dây kéo quanh người kéo) hoặc theo kênh chung.
  // Người kéo xe này nếu là người tổ khác: cờ đỏ, đứng trong dây kéo quanh xe, thù địch với mình.
  function ctCartOwner(g, c, haulers) {
    var V = g.P.VanTieu, R = ((V && V.DAY_KEO) || 320) + 40;
    if (ctOurs(g, c, haulers)) return null;
    return hostilePlayers(g).filter(function (r) { return r.coChien === 'do' && isFinite(r.x) && dist(r.x, r.y, c.x, c.y) <= R; })
      .sort(function (x, y) { return dist(x.x, x.y, c.x, c.y) - dist(y.x, y.y, c.x, c.y); })[0] || null;
  }
  // Khoá đúng người chơi cần đánh (game khoá người qua Targeting.khoaNguoi → "dosat:<id>"), auto của game đánh người đó.
  function ctPinPlayer(P, r) { var T = P.Targeting; if (T && r && r.id != null) { T.khoaNguoi = r.id; } }
  function ctHaulCart(g, hl) {
    var V = g.P.VanTieu, R = (V && V.DAY_KEO) || 320, best = null;
    (g.sw.enemies || []).forEach(function (m) { if (m && !m.dead && m.def && m.def.tieuXa && isFinite(hl.x) && dist(m.x, m.y, hl.x, hl.y) <= R + 40 && (!best || dist(m.x, m.y, hl.x, hl.y) < dist(best.x, best.y, hl.x, hl.y))) best = m; });
    if (best) return { x: best.x, y: best.y, hp: best.hp, hm: best.hpMax };
    var b = teamSeen[hl.id];
    return b && b.ct && b.ct.haul && b.ct.hm && now() - b.at < TEAM_FRESH_MS ? { x: b.ct.cx, y: b.ct.cy, hp: b.ct.hp, hm: b.ct.hm } : null;
  }
  function ctCartHurt(g, hl) { var c = ctHaulCart(g, hl); return !!(c && c.hm > 0 && c.hp / c.hm < 0.8); }
  // Tháo cờ mình đã cắm (màu nhóm hoặc cờ đỏ hộ tống); đang kéo xe thì game giữ cờ đỏ, không động vào.
  function ctUnflag(g, a) {
    var G = g.P.Gateway, co = G && G.coChien || '';
    if (!a || !a.flagged || !co || vtChuyen(g.P) || G.coDenBuoc) return;
    if (co !== a.flagColor && !(a.escort && co === CT_ESCORT_FLAG)) return;
    G.cmd('coChien', { mau: '' }, function (res) { if (res && res.ok) { G.coChien = res.co || ''; ctLog('Tháo cờ chiến'); } else ctUnflagRetry = { at: now() + CT_FLAG_MS, a: a }; });
  }
  var ctUnflagRetry = null;
  // Sang đi boss / sự kiện khác: thôi cướp tiêu, tháo cờ ngay (không kéo về chỗ farm — việc mới tự lo đường đi).
  function ctEventName(g, inEv) {
    if (st.bh) return 'đi boss';
    if (st.dh) return 'Đại Hội';
    if (st.tl && st.tl.inMatch) return 'Tam Lộ';
    if (st.ll) return 'Lãm Làng';
    if (st.ht) return 'Sỹ Sách Điện';
    if (st.vn && cfg.vnRun) return 'Vết Nứt';
    if (st.hx && st.hx.inside) return 'Huyết Xích';
    if (st.yl && st.yl.inside) return 'Yên Lãng Sơn';
    if (st.contest) return 'tranh đồ boss';
    if (st.bd || (cfg.bdHunt && bdPending().length)) return 'săn biến dị';
    if (st.xc || (cfg.xcHunt && xcPending().length)) return 'săn xổng chuồng';
    if (st.td) return 'săn Thương Đội';
    return inEv ? 'sự kiện' : '';
  }
  function ctYield(g, what) {
    if (!st.ct || vtChuyen(g.P)) return;
    ctStop(g, 'Chuyển sang ' + what + ' → tháo cờ, tạm thôi cướp tiêu', true);
  }
  // Lệnh tháo cờ bị từ chối (vừa giao chiến / vừa đổi cờ): thử lại tới khi được.
  function tickCtUnflag(g) {
    var r = ctUnflagRetry;
    if (!r || now() < r.at || st.ct) { if (r && st.ct) ctUnflagRetry = null; return; }
    ctUnflagRetry = null;
    ctUnflag(g, r.a);
  }
  function ctStop(g, why, noBack) {
    var a = st.ct;
    st.ct = null;
    if (why) ctLog(why);
    ctUnflag(g, a);
    if (!noBack && a && a.back && (g.mapId !== a.back.map || dist(g.me.x, g.me.y, a.back.x, a.back.y) > BACK_NEAR || (a.back.khu && gaKhu(g.P) !== a.back.khu))) goBack(a.back.map, a.back.x, a.back.y, 'Thôi cướp tiêu → về chỗ farm', 'ct', a.back.khu);
    return false;
  }
  function tickCuopTieu(g) {
    var P = g.P, V = P.VanTieu, me = g.me, G = P.Gateway;
    // Đang kéo xe (tự áp hay cướp được): tập trung kéo về Bảnh Tiên Sinh, báo cho đồng đội đi kèm.
    if (cfg.ctRun && vtChuyen(P)) {
      var a0 = st.ct || (st.ct = { at: now(), back: ctBack(g), step: '' });
      if (!a0.haul) { a0.haul = true; ctLog('Đang kéo ' + (V.tenHang ? V.tenHang(vtChuyen(P).hang) : 'xe') + ' → về Bảnh Tiên Sinh, đồng đội hộ tống'); }
      a0.pk = false;
      var myCart = vtCart(g);
      teamPost(g, { ct: { haul: true, flag: ctLeader(g).self ? ctOwnFlag() : st.ctLeaderFlag || '', hp: myCart ? myCart.m.hp : 0, hm: myCart ? myCart.m.hpMax : 0, cx: myCart ? myCart.m.x : 0, cy: myCart ? myCart.m.y : 0, stat: ctStatToday() } });
      a0.step = 'kéo xe về Thăng Long';
      if (tickVanTieu(g) === 'busy') return true;
      return true;
    }
    if (vtActive(g) || st.vt || (cfg.vtRun && !st.ct)) return false;
    if (st.ct && st.ct.haul) { st.ct.haul = false; ctLog('Xong chuyến kéo xe → quay lại Thung Lũng'); }
    if (ctEventName(g, false)) return false; // việc khác (boss / sự kiện) đang giữ quyền: chờ xong mới cắm cờ đi cướp lại
    var why = ctWhyNot(g);
    if (why) { if (st.ct) ctStop(g, 'Thôi: ' + why); st.ctWhy = why; return false; }
    var a = st.ct || (st.ct = { at: now(), back: ctBack(g), step: '', flagged: false });
    var wf = ctWantFlag(g);
    if (!a.started) { a.started = true; ctLog('Đủ điều kiện → cắm cờ ' + CT_COLORS[wf.flag] + ' (' + wf.from + '), ra Thung Lũng camp cướp tiêu' + (cfg.ctCap ? ' (đã đủ trần Linh Thạch ngày)' : '')); }
    if (!ctLeader(g).self && wf.flag) st.ctLeaderFlag = /^theo/.test(wf.from) ? wf.flag : st.ctLeaderFlag;
    st.ctWhy = '';
    var turns = ctTurns(P), haulers = ctHaulers(g);
    teamPost(g, { ct: { haul: false, flag: wf.flag, turns: turns, stat: ctStatToday() } });
    if (a.flagColor && a.flagColor !== wf.flag) ctLog('Nhóm trưởng đổi màu cờ → đổi sang ' + CT_COLORS[wf.flag]);
    a.flagColor = wf.flag; a.wfFrom = wf.from;
    a.pk = false;
    // Đồng đội đang kéo xe: đi kèm, đánh người chơi thù địch tới gần xe / người kéo.
    var hl = haulers[0];
    // Đội đông (≥ 4): chỉ 2 người hộ tống người kéo (thứ tự cố định theo id), những người khác ở lại cướp tiếp.
    if (hl) {
      var others = teamMates(g).filter(function (m) { return !haulers.some(function (h) { return h.id === m.id; }); });
      if (others.length >= 2) {
        var ids = [String(G.selfId)].concat(others.map(function (m) { return String(m.id); })).sort();
        if (ids.indexOf(String(G.selfId)) >= 2 && !ctCartHurt(g, hl)) { a.guardSkip = hl.name; hl = null; }
      }
    }
    // Hộ tống: đổi sang cờ đỏ giống người kéo (game ép cờ đỏ cho người kéo xe); hết hộ tống thì về lại màu nhóm.
    ctFlag(g, hl ? CT_ESCORT_FLAG : wf.flag); a.flagged = true; a.escort = !!hl;
    if (hl) {
      if (hl.map && hl.map !== g.mapId) { a.step = 'đi kèm ' + hl.name + ' sang ' + mapName(hl.map); if (!jobGo(g, a, hl.map, 'Cướp tiêu: hộ tống ' + hl.name, ctLog)) a.travels = 0; return true; }
      if (st.travel) stopTravel();
      if (!isFinite(hl.x)) { a.step = 'tìm ' + hl.name + ' (đang kéo xe) ở ' + mapName(g.mapId); setAuto(g, true); return true; }
      if (hl.lost && dist(me.x, me.y, hl.x, hl.y) < 60) ctHaulMem[hl.id].at = 0; // tới chỗ thấy cuối mà không thấy ai: thôi
      var hc = ctHaulCart(g, hl), gx = hc ? hc.x : hl.x, gy = hc ? hc.y : hl.y;
      var foes = ctThreats(g, gx, gy, CT_GUARD_R + 80).filter(function (r) { return r.coChien !== 'do'; });
      if (foes.length) {
        a.pk = true; a.step = 'bảo vệ ' + hl.name + ': đánh ' + (foes[0].name || 'kẻ địch');
        setAuto(g, true);
        ctMoveTo(g, a, foes[0].x, foes[0].y, 70);
        return true;
      }
      a.step = 'hộ tống ' + hl.name + ' kéo xe';
      if (ctHurt(g) && engagedBy(g)) { setAuto(g, true); return true; }
      setAuto(g, false);
      ctMoveTo(g, a, hl.x, hl.y, CT_FOLLOW);
      return true;
    }
    // Ra Thung Lũng, đúng khu camp.
    var cp0 = ctCampPt(g, (turns > 0 ? 1 : 0) + ctCrew(g).length), map = cp0 ? cp0.map : ctMap(P);
    var hunting = ctRoad[g.mapId] && (ctCarts(g, haulers).length || (a.lastCart && now() - a.lastCart.at < CT_CHASE_MS));
    if (g.mapId !== map && !hunting) { a.step = 'ra ' + mapName(map) + ' camp'; if (!jobGo(g, a, map, 'Cướp tiêu: ra ' + mapName(map), ctLog)) a.travels = 0; return true; }
    if (st.travel && st.travel.map === map && !a.khuWant) stopTravel();
    var so = gaSoKhu(P);
    if (cfg.ctKhu > 0 && cfg.ctKhu <= so && gaKhu(P) !== cfg.ctKhu && !a.khuDone) {
      if (!a.khuWant) { a.khuWant = cfg.ctKhu; a.khuAt = 0; a.touches = 0; a.touchAt = 0; }
      a.step = 'sang khu ' + cfg.ctKhu + ' camp';
      if (khuGo(g, a, '[Cướp tiêu]')) return true;
      a.khuDone = true;
    }
    a.khuWant = 0;
    // Tự vệ trước (người chơi / quái đang đánh mình).
    var lowHp = me.hp < (me.hpMax || 1) * 0.35, cartNow = ctCarts(g, haulers).length > 0 && !ctCanRob(g, turns);
    var foe0 = ctHurt(g) && (!cartNow || lowHp) ? ctThreats(g, me.x, me.y, 160).filter(function (r) { return r.coChien !== 'do'; })[0] : null;
    if (foe0) { a.pk = true; a.step = 'tự vệ: ' + (foe0.name || 'kẻ địch'); setAuto(g, true); return true; }
    var why2 = ctCanRob(g, turns), carts = why2 ? [] : ctCarts(g, haulers);
    if (why2 && why2 !== a.robWhy) { a.robWhy = why2; if (ctCarts(g, haulers).length) ctLog('Thấy xe nhưng chưa cướp được: ' + why2); }
    if (!why2) a.robWhy = '';
    if (carts.length) {
      var c = carts[0], hn = V.tenHang ? V.tenHang(c.def.tieuXaHang) : 'xe';
      if (a.cart !== c) { a.cart = c; ctLog('Thấy ' + hn + ' (' + num(c.hp) + '/' + num(c.hpMax) + ') → cướp'); }
      a.step = 'cướp ' + hn + ' · ' + num(c.hp) + '/' + num(c.hpMax) + ' · còn ' + turns + ' lượt cướp';
      a.lastCart = { x: c.x, y: c.y, vx: c._vx || 0, vy: c._vy || 0, at: now(), map: g.mapId, name: hn };
      teamPost(g, { ct: { haul: false, flag: a.flagColor, cart: { x: c.x, y: c.y, vx: c._vx || 0, vy: c._vy || 0, t: Date.now(), hp: c.hp } } });
      // Đội ≥ 3: hai người (thứ tự id) luôn đánh xe liên tục để chắc có người đứng đầu 30 giây cuối; người còn lại, khi có địch
      // đang đánh xe (cờ khác, không phải người kéo), đi hạ địch đó: bị hạ là mất quyền nhận xe và thôi góp sát thương.
      var crewIds = [String(G.selfId)].concat(ctCrew(g).map(function (m) { return String(m.id); })).sort(), myRank = crewIds.indexOf(String(G.selfId));
      // Xe vừa đổi chủ sang tổ đội khác (máu xe bật lên đầy lúc đang bị đánh): 10 giây bảo hộ không đánh được xe → cả đội dồn hạ
      // người kéo bên đó (cờ đỏ, đứng trong dây kéo cạnh xe): người kéo gục thì xe đứng yên, đội mình có thêm thời gian cướp.
      if (a.cart === c && a.lastHp != null && c.hp > a.lastHp + c.hpMax * 0.3) { a.protUntil = now() + ((V.BAO_HO_MS || 10000) + 500); ctLog('Xe vừa bị tổ khác cướp → hạ người kéo trong lúc xe được bảo hộ'); }
      a.lastHp = c.hp;
      var owner = ctCartOwner(g, c, haulers), protect = now() < (a.protUntil || 0), late = false;
      // Không kịp đánh vỡ xe trước khi nó tới Thăng Long (máu còn ÷ sức cả đội so với quãng còn lại ÷ tốc độ xe): hạ người kéo trước.
      if (owner && !owner.downed) {
        var rm = ctRemain(P, g.mapId, c.x, c.y), vv = Math.max(20, Math.sqrt((c._vx || 0) * (c._vx || 0) + (c._vy || 0) * (c._vy || 0)));
        if (rm) late = c.hp / (crewIds.length * (V.KEP_DPS || 20)) > rm / vv - 3;
      }
      if (owner && !owner.downed && (protect || (late && myRank >= 1))) { // không kịp: người đầu vẫn đánh xe (xe không tự hồi), người khác hạ người kéo
        a.pk = true; a.role = 'hạ người kéo';
        a.step = (protect ? 'xe đang bảo hộ → ' : late ? 'không kịp đánh vỡ xe trước Thăng Long → ' : '') + 'hạ người kéo ' + (owner.name || '') + ' cho xe đứng yên · ' + num(c.hp) + '/' + num(c.hpMax);
        ctPinPlayer(P, owner); setAuto(g, true);
        var hpRatio = me.hp / (me.hpMax || 1);
        if (hpRatio < 0.35) {
          if (cfg.autoShield) { if (!talUse(g, 'kim_long', 'hạ người kéo máu thấp')) talUse(g, 'kim_giap', 'hạ người kéo máu thấp'); }
          var dO = dist(me.x, me.y, owner.x, owner.y);
          if (dO < 160) {
            var awayX = me.x + (me.x - owner.x) / (dO || 1) * 60, awayY = me.y + (me.y - owner.y) / (dO || 1) * 60;
            var rSafe = spotCheck(g).route(awayX, awayY);
            if (rSafe) ctMoveTo(g, a, awayX, awayY, 40);
          }
        } else {
          ctMoveTo(g, a, owner.x, owner.y, 50);
        }
        return true;
      }
      if (crewIds.length >= 3 && myRank >= 2) {
        var rivals = ctThreats(g, c.x, c.y, 160).filter(function (r) { return r.coChien !== 'do'; })
          .sort(function (x, y) { return (x.hp / (x.hpMax || x.hp || 1)) - (y.hp / (y.hpMax || y.hp || 1)); });
        if (rivals.length) {
          a.pk = true; a.role = 'hạ địch'; ctPinPlayer(P, rivals[0]);
          a.step = 'hạ ' + (rivals[0].name || 'kẻ địch') + ' đang đánh xe (' + rivals.length + ' địch quanh xe) · ' + num(c.hp) + '/' + num(c.hpMax);
          setAuto(g, true);
          var hpRatio = me.hp / (me.hpMax || 1);
          if (hpRatio < 0.35) {
            if (cfg.autoShield) { if (!talUse(g, 'kim_long', 'hạ địch máu thấp')) talUse(g, 'kim_giap', 'hạ địch máu thấp'); }
            var dR = dist(me.x, me.y, rivals[0].x, rivals[0].y);
            if (dR < 160) {
              var awayX = me.x + (me.x - rivals[0].x) / (dR || 1) * 60, awayY = me.y + (me.y - rivals[0].y) / (dR || 1) * 60;
              var rSafe = spotCheck(g).route(awayX, awayY);
              if (rSafe) ctMoveTo(g, a, awayX, awayY, 40);
            }
          } else {
            ctMoveTo(g, a, rivals[0].x, rivals[0].y, 60);
          }
          return true;
        }
      }
      a.role = 'đánh xe';
      ctStrikeCart(g, a, c);
      return true;
    }
    a.cart = null;
    if (a.role === 'hạ người kéo' || a.role === 'đánh xe') { a.role = null; a.pk = false; }
    if (turns > 0 && ctChase(g, a)) return true;
    // Đồng đội thấy xe ở chỗ khác trong map: tới đón đầu.
    var ms = turns > 0 && !why2 ? ctMateSighting(g) : null;
    if (ms) {
      var dt0 = Math.min(5, (Date.now() - ms.t) / 1000) + 1.5, mx = ms.x + ms.vx * dt0, my = ms.y + ms.vy * dt0;
      a.step = 'đồng đội thấy xe → tới đón (' + Math.round(dist(me.x, me.y, mx, my)) + 'px)';
      setAuto(g, false);
      ctMoveTo(g, a, mx, my, 40);
      return true;
    }
    if (ctHurt(g) && engagedBy(g)) { setAuto(g, true); a.step = 'đánh quái đang cắn mình'; return true; }
    setAuto(g, false);
    var cp = ctStation(g, a);
    if (cp && cp.map && cp.map !== g.mapId) {
      a.step = 'ra ' + mapName(cp.map) + ' camp cướp tiêu';
      if (!st.travel || st.travel.map !== cp.map) {
        startTravel(cp.map, cp.x, cp.y, 'Cướp tiêu: sang ' + mapName(cp.map) + ' camp');
      }
      tickTravel(g);
      return true;
    }
    var nCrew = (turns > 0 ? 1 : 0) + ctCrew(g).length;
    a.step = turns > 0 ? (a.follow ? 'bám theo nhóm trưởng ' + a.follow + ' tuần đường xe' : (a.camp && a.camp.fixed ? 'đứng chờ ' + Math.round(a.camp.f * 100) + '% đường xe ở ' + mapName(a.camp.map) + ' (chỗ đã chọn · còn ~' + Math.round(a.camp.have) + 's đường xe, ' + a.camp.n + ' người cần ~' + Math.round(a.camp.need) + 's' + (a.camp.have < a.camp.need ? ' → có thể không kịp' : '') + ')' : a.camp ? 'đứng chờ ' + Math.round(a.camp.f * 100) + '% đường xe ở ' + mapName(a.camp.map) + ' (đủ ~' + Math.round(a.camp.need) + 's cho ' + a.camp.n + ' người đánh vỡ ' + (V.tenHang ? V.tenHang(a.camp.hang) : 'xe') + ', xe qua thì bám theo đánh)' : 'đứng sát cổng vào')) + ' · ' + nCrew + ' người cùng đánh' + (a.guardSkip ? ' · ' + a.guardSkip + ' đã có 2 người hộ tống' : '') + ' · ' + mapName(map) + ' khu ' + gaKhu(P) + ' · còn ' + turns + ' lượt cướp' + (a.robWhy ? ' · ' + a.robWhy : '') : 'hết lượt cướp hôm nay · đứng canh / hộ tống đồng đội';
    ctMoveTo(g, a, cp.x, cp.y, 40);
    return true;
  }

  /* --- Bộ bí tịch --- */
  // Bí tịch: đọc Skills.DEFS / PASSIVES, chấm điểm từng tình huống bằng mô phỏng chuỗi chiêu theo luật game, dựng bộ
  // tối đa 8 chiêu (Combo "TT·…") + 5 bị động (setPassiveEquipped).
  var BT_MODES = [
    ['boss', '👑 Săn boss', 'Một mục tiêu máu trâu: sát thương lớn nhất trong thời gian ngắn nhất'],
    ['farm', '🌾 Farm quái', 'Quái đứng cụm: chiêu diện rộng, ít tốn linh lực, hồi máu / linh lực khi hạ quái'],
    ['pk', '⚔ PK', 'Đánh người: dồn sát thương 6 giây đầu, khống chế (choáng, trói, đóng băng, hoảng sợ), chống khống chế, khiên'],
    ['team', '🤝 Tổ đội · sự kiện', 'Vết Nứt, Lãm Làng có tổ đội: dồn sát thương như săn boss + bị động hồi cho cả đội']
  ];
  // Thứ tự ưu tiên bị động mỗi bộ (chỉ lấy cuốn đang có; Hỏa Mạch chỉ khi thanh có ≥ 2 chiêu Hỏa; hồi cho đội chỉ khi có tổ đội).
  var BT_PASSIVE = {
    boss: ['kiem_y', 'hoa_mach', 'tu_linh', 'kim_quang_chao', 'moc_xuan', 'tho_thuan', 'ho_tam', 'ma_khi', 'phong_hanh', 'bang_tam', 'moc_sinh'],
    farm: ['moc_sinh', 'tu_linh', 'kiem_y', 'hoa_mach', 'phong_hanh', 'moc_xuan', 'kim_quang_chao', 'tinh_tam', 'tho_thuan', 'ho_tam'],
    pk: ['kim_quang_chao', 'bang_tam', 'ma_khi', 'ho_tam', 'moc_xuan', 'phong_hanh', 'kiem_y', 'hoa_mach', 'tho_thuan', 'tu_linh'],
    team: ['thao_duoc', 'cat_tuong', 'kiem_y', 'hoa_mach', 'tu_linh', 'kim_quang_chao', 'moc_xuan', 'tho_thuan', 'ho_tam', 'ma_khi']
  };
  var BT_CC = { stun: 1, freeze: 1, fear: 1, root: 0.8, slow: 0.35 };
  var BT_SWITCH_MS = 20000, BT_HOLD_MS = 3000;
  var btCache = null, btWant = null;
  function btEffects(def) { return [].concat(def.effect || []).filter(Boolean); }
  // Vũ khí đang cầm (id) và tình trạng pháp khí cộng hưởng của chiêu: game tính đủ sát thương khi có boostWeapon trong
  // hành trang (Skills.hasBoostWeapon), thiếu thì còn WEAPON_NO_BOOST_MULT (50%). Tứ Ảnh Phược Tiên cần roi (kieuRoi).
  function btWeapon(g) { var me = g.me, I = g.P.Inventory, e = I && I.equipped ? I.equipped('vu_khi') : null; return (e && e.id) || (me.cfg && me.cfg.weapon) || ''; }
  function btBoost(g, def) {
    var S = g.P.Skills, I = g.P.ITEMS || {}, need = def.boostWeapon || null, roi = def.canVuKhi || def.kieuRoi || null;
    if (need) { var ok = S.hasBoostWeapon ? S.hasBoostWeapon(def) : false, wp = btWeapon(g); return { id: need, name: I[need] ? I[need].name : need, ok: ok, held: wp === need, mult: ok ? S.WEAPON_BOOST_MULT || 1 : S.WEAPON_NO_BOOST_MULT || 0.5 }; }
    if (roi) { var ok2 = S.vuKhiHopLe ? !!S.vuKhiHopLe(def) : false; return { id: roi[0], name: roi.map(function (x) { return I[x] ? I[x].name : x; }).join(' / '), ok: ok2, held: roi.indexOf(btWeapon(g)) >= 0, mult: ok2 ? 1 : 0, need: true }; }
    return null;
  }
  function btCcSec(def) {
    var t = 0;
    btEffects(def).forEach(function (e) { if (BT_CC[e.kind]) t += BT_CC[e.kind] * (e.time || 0) * (e.chance || 1); });
    return t;
  }
  // Số mục tiêu một chiêu trúng khi có n kẻ đứng cụm quanh mục tiêu.
  function btTargets(g, def, n) {
    if (n <= 1) return 1;
    var R = def.thunder ? (g.P.CONFIG.THUNDER && g.P.CONFIG.THUNDER.RADIUS) || 0 : def.blastR || 0;
    var cap = def.maxTargets || n;
    if (def.shape === 'aura' || R >= 40) return Math.min(n, cap);
    if (R > 0) return Math.min(cap, 1 + (n - 1) * R / 60);
    return 1;
  }
  function btInfo(g, def, n) {
    var one = skillDmg(g, def) + dotOf(g, def); // nhiều viên: game chia sát thương cho các viên (shotShare), không nhân
    return { def: def, id: def.id, th: !!def.thunder, cd: fullCd(g, def), pose: poseLen(g, def), v: one * btTargets(g, def, n), one: one, mp: skillCost(g, def).mp };
  }
  // Mô phỏng chuỗi chiêu T giây: mỗi lượt tung chiêu có sát thương / thời gian chiếm (chờ + nhịp) cao nhất.
  function btSim(g, info, T) {
    var G = spellGap(g), t = 0, gap = 0, cds = info.map(function () { return 0; }), out = { dmg: 0, mp: 0, n: 0 };
    var PL = g.P.Player, mel = PL.meleeDamage ? PL.meleeDamage() || 0 : 0, AT = (g.P.CONFIG.PLAYER && g.P.CONFIG.PLAYER.ATTACK_TIME) || 0.8;
    // Chờ chiêu hồi thì chém thường (mỗi ATTACK_TIME một nhát): bộ toàn chiêu hồi lâu sẽ để hở nhiều nhịp → điểm thấp hơn.
    function fill(a, b) { if (b - a >= AT) { var n = Math.floor((b - a) / AT); out.dmg += n * mel; } }
    for (var k = 0; k < 400; k++) {
      var bi = -1, bs = 0, bsc = -1;
      for (var i = 0; i < info.length; i++) {
        var x = info[i], s0 = Math.max(t, cds[i], x.th ? 0 : gap);
        if (s0 >= T) continue;
        var sc = x.v / (s0 - t + (x.th ? x.pose : Math.max(x.pose, G)));
        if (sc > bsc) { bsc = sc; bi = i; bs = s0; }
      }
      if (bi < 0) { fill(t, T); break; }
      var y = info[bi];
      fill(t, bs);
      out.dmg += y.v; out.mp += y.mp; out.n++;
      cds[bi] = bs + y.cd; if (!y.th) gap = bs + G; t = bs + y.pose;
    }
    return out;
  }
  function btScore(g, mode, set) {
    if (!set.length) return 0;
    var me = g.me;
    if (mode === 'farm') {
      var f = btSim(g, set.map(function (d) { return btInfo(g, d, 4); }), 15);
      var farmBonus = 0;
      set.forEach(function (d) {
        if (d.lifesteal) farmBonus += 0.15; // Hút máu hồi phục khi farm quái
        if ((d.blastR || 0) >= 25 || d.shape === 'aura') farmBonus += 0.1; // Sát thương diện rộng bao quát
      });
      return (f.dmg / (1 + f.mp / Math.max(60, (me.mpMax || 100) * 0.6))) * (1 + farmBonus);
    }
    if (mode === 'pk') {
      var cc = 0, wound = 0, fast = 0;
      set.forEach(function (d) {
        cc += btCcSec(d);
        btEffects(d).forEach(function (e) { if (e.kind === 'wound') wound += (e.time || 2); });
        if ((d.speed || 0) >= 300) fast += 1;
      });
      var base = btSim(g, set.map(function (d) { return btInfo(g, d, 1); }), 6).dmg;
      var mult = 1 + 0.12 * Math.min(cc, 6) + 0.03 * Math.min(wound, 5) + 0.03 * Math.min(fast, 3);
      return base * mult;
    }
    var one = set.map(function (d) { return btInfo(g, d, 1); });
    var dotBonus = 0;
    set.forEach(function (d) {
      if (dotOf(g, d) > 0) dotBonus += 0.05; // DoT hữu dụng duy trì sát thương lên boss
    });
    return (btSim(g, one, 12).dmg + 0.5 * btSim(g, one, 30).dmg) * (1 + Math.min(dotBonus, 0.15));
  }
  // Mọi chiêu chủ động nhân vật dùng được (đã có sách, đủ cảnh giới, đúng đạo / vũ khí). PK lấy cả chiêu chỉ đánh người.
  function btOwned(g, mode) {
    var S = g.P.Skills, out = [];
    (S.learnedSlots ? S.learnedSlots() : []).forEach(function (k) {
      var d = S.slotDef(k);
      if (!d || (d.playerTargetOnly && mode !== 'pk')) return;
      if (d.bienHinh || skillDmg(g, d) > 1 || dotOf(g, d) > 0 || btCcSec(d) > 0) out.push(d);
    });
    return out;
  }
  function btPlan(g, mode) {
    var S = g.P.Skills, MAX = S.HOTBAR_MAX || 8, pool = btOwned(g, mode), set = [], auto = [], cur = 0;
    // Ưu tiên slot bí tịch biến hình (Hóa Thân) nếu đã học cho PK, Boss, Team
    var form = pool.filter(function (d) { return d && d.bienHinh; })[0];
    if (form && (mode === 'pk' || mode === 'boss' || mode === 'team')) {
      pool.splice(pool.indexOf(form), 1);
      set.push(form);
      auto.push(form.id); // tick Auto để game và bot chủ động dùng
    }
    while (set.length < MAX && pool.length) {
      var best = null, bv = -1;
      pool.forEach(function (d) { var v = btScore(g, mode, set.concat([d])); if (v > bv) { bv = v; best = d; } });
      pool.splice(pool.indexOf(best), 1);
      set.push(best);
      if (bv > cur + 0.5) auto.push(best.id); // chiêu chẳng thêm được gì (bị chiêu khác lấn nhịp) thì vẫn để trên thanh nhưng không tick
      cur = Math.max(cur, bv);
    }
    // Tối ưu hóa thứ tự các vị trí trên thanh Hotbar (Slot 1 -> Slot MAX):
    // Luôn giữ Hóa Thân (nếu có) ở Slot 0 đầu tiên
    var formSlot = set.filter(function (d) { return d && d.bienHinh; })[0];
    var normalSkills = set.filter(function (d) { return !d || !d.bienHinh; });
    if (mode === 'pk') {
      // PK: Slot 1 Hóa Thân -> Slot 2 Khống Chế Cứng (Stun / Freeze / Root - ưu tiên CC dài hơn) -> Slot 3.. Burst & Rỉ Máu (Wound)
      normalSkills.sort(function (a, b) {
        var ccA = btCcSec(a), ccB = btCcSec(b);
        if (ccA >= 0.8 && ccB < 0.8) return -1;
        if (ccB >= 0.8 && ccA < 0.8) return 1;
        if (ccA >= 0.8 && ccB >= 0.8) {
          if (Math.abs(ccB - ccA) > 0.05) return ccB - ccA; // CC dài hơn ra trước
        }
        var dpsA = btInfo(g, a, 1).v / Math.max(1, btInfo(g, a, 1).pose);
        var dpsB = btInfo(g, b, 1).v / Math.max(1, btInfo(g, b, 1).pose);
        return dpsB - dpsA;
      });
    } else if (mode === 'boss' || mode === 'team') {
      // Boss: Slot 1 Hóa Thân -> Slot 2 DoT/Debuff (Wound/Burn) -> Slot 3.. Đơn mục tiêu DPS cao nhất
      normalSkills.sort(function (a, b) {
        var dotA = dotOf(g, a) > 0 ? 1 : 0, dotB = dotOf(g, b) > 0 ? 1 : 0;
        if (dotA !== dotB) return dotB - dotA;
        var dpsA = btInfo(g, a, 1).v / Math.max(1, btInfo(g, a, 1).pose);
        var dpsB = btInfo(g, b, 1).v / Math.max(1, btInfo(g, b, 1).pose);
        return dpsB - dpsA;
      });
    } else if (mode === 'farm') {
      // Farm: Chiêu diện rộng AoE nhiều mục tiêu lên đầu -> Chiêu tiết kiệm linh lực
      normalSkills.sort(function (a, b) {
        var aoeA = ((a.blastR || 0) >= 20 || a.shape === 'aura' || (a.maxTargets || 1) >= 3) ? 1 : 0;
        var aoeB = ((b.blastR || 0) >= 20 || b.shape === 'aura' || (b.maxTargets || 1) >= 3) ? 1 : 0;
        if (aoeA !== aoeB) return aoeB - aoeA;
        return (skillCost(g, a).mp || 0) - (skillCost(g, b).mp || 0);
      });
    }
    set = formSlot ? [formSlot].concat(normalSkills) : normalSkills;
    var hoa = set.filter(function (d) { return d.element === 'Hỏa'; }).length, party = teamParty(g.P), sword = /kiem/.test(btWeapon(g));
    var pas = [], PMAX = S.PASSIVE_MAX || 5;
    (BT_PASSIVE[mode] || []).forEach(function (id) {
      if (pas.length >= PMAX || !S.knownPassive || !S.knownPassive(id)) return;
      if (id === 'hoa_mach' && hoa < 2) return;
      if (id === 'kiem_y' && !sword) return; // Kiếm Ý chỉ cộng khi vũ khí đang cầm là kiếm (Skills.kiemYTruoc: /kiem/)
      var P0 = S.PASSIVES && S.PASSIVES[id];
      if (P0 && P0.hoTro && !(party && party.members.length >= 2)) return;
      pas.push(id);
    });
    var one = set.map(function (d) { return btInfo(g, d, mode === 'farm' ? 4 : 1); });
    return {
      mode: mode, bar: set.map(function (d) { return d.id; }), auto: auto, passives: pas, score: cur,
      d6: btSim(g, one, 6).dmg, d12: btSim(g, one, 12).dmg, d30: btSim(g, one, 30).dmg
    };
  }
  function btPlans(g) {
    if (btCache && now() - btCache.at < 5000) return btCache.plans;
    var plans = {};
    BT_MODES.forEach(function (m) { plans[m[0]] = btPlan(g, m[0]); });
    btCache = { at: now(), plans: plans };
    return plans;
  }
  // Chiêu hợp với từng việc (☑ trong bảng): xét trên MỌI bí tịch của game, kể cả cuốn chưa có. Săn boss / tổ đội: sát thương …
  function btFit(g) {
    var S = g.P.Skills, ids = ['loi_chuong'].concat(Object.keys(S.DEFS)), out = { boss: {}, farm: {}, pk: {}, team: {} };
    var defs = ids.map(function (id) { return id === 'loi_chuong' ? S.THUNDER_DEF : S.DEFS[id]; }).filter(function (d) { return d; });
    function rate(d, n) { if (d.bienHinh) return 1000; var x = btInfo(g, d, n); return x.v / Math.max(x.cd, spellGap(g)); }
    function topHalf(n, filt) {
      var list = defs.filter(filt || function () { return true; }).map(function (d) { return { id: d.id, v: rate(d, n) }; }).sort(function (a, b) { return b.v - a.v; });
      var o = {}; list.slice(0, Math.ceil(list.length / 2)).forEach(function (x) { o[x.id] = 1; }); return o;
    }
    var b1 = topHalf(1, function (d) { return !d.playerTargetOnly && !d.bienHinh; }), f4 = topHalf(4, function (d) { return !d.playerTargetOnly && !d.bienHinh; });
    defs.forEach(function (d) {
      var id = d.id;
      if (d.bienHinh) {
        out.boss[id] = out.pk[id] = out.team[id] = 1;
        return;
      }
      if (b1[id]) out.boss[id] = out.team[id] = 1;
      if (!d.playerTargetOnly && (f4[id] || (d.maxTargets || 1) >= 3 || d.shape === 'aura')) out.farm[id] = 1;
      if (btCcSec(d) >= 0.7 || b1[id] || d.playerTargetOnly) out.pk[id] = 1;
    });
    return out;
  }
  function btModeName(mode) { var m = BT_MODES.filter(function (x) { return x[0] === mode; })[0]; return m ? m[1] : mode; }
  function btSkillName(g, id) {
    var S = g.P.Skills, d = id === 'loi_chuong' ? S.THUNDER_DEF : S.DEFS[id];
    return d ? d.short || d.name : id;
  }
  // Áp một bộ: chiêu chủ động vào Combo "TT·…" của game (đủ 6 Combo thì sửa Combo đang dùng), bị động thay bằng bộ mới.
  function btApply(g, mode, why) {
    var S = g.P.Skills, plan = btPlans(g)[mode];
    if (!plan || !S.setHotbarSkillVisible || !S.setAutoUses) return false;
    var name = 'TT·' + btModeName(mode).replace(/^\S+\s/, ''), note = '';
    if (S.comboDanhSach && S.comboThem && S.comboChuyen) {
      var idx = S.comboDanhSach().indexOf(name);
      if (idx < 0) idx = S.comboDay && S.comboDay() ? -1 : S.comboThem(name);
      if (idx >= 0) { if (S.comboDung() !== idx) S.comboChuyen(idx); } else note = ' (đủ 6 Combo → sửa Combo đang dùng)';
    }
    S.learnedSlots().forEach(function (k) { var id = S.SLOTS[k]; if (id && plan.bar.indexOf(id) < 0 && S.onBar(id)) S.setHotbarSkillVisible(id, false); });
    plan.bar.forEach(function (id) { if (!S.onBar(id)) S.setHotbarSkillVisible(id, true); });
    plan.bar.forEach(function (id) { var on = plan.auto.indexOf(id) >= 0; if (S.autoPreferred(id) !== on) S.setAutoUses(id, on); });
    if (S.setPassiveEquipped && S.passiveList) {
      S.passiveList().slice().forEach(function (id) { if (plan.passives.indexOf(id) < 0) S.setPassiveEquipped(id, false); });
      plan.passives.forEach(function (id) { S.setPassiveEquipped(id, true); });
    }
    st.btMode = mode; st.btAt = now();
    klog('[Bí tịch] Dùng bộ ' + btModeName(mode) + (why ? ' · ' + why : '') + note + ': ' + plan.bar.map(function (id) { return btSkillName(g, id) + (plan.auto.indexOf(id) >= 0 ? '' : '(không tick)'); }).join(', ') +
      ' · bị động ' + (plan.passives.map(function (id) { return S.PASSIVES[id] ? S.PASSIVES[id].short : id; }).join(', ') || '—'));
    return true;
  }
  // Việc đang làm → bộ hợp: Tam Lộ đối đầu / người thù địch ở gần = PK; Tam Lộ phá trụ / boss = boss; Vết Nứt / Lãm Làng có tổ đội = tổ đội; đánh boss / sự kiện = boss; còn lại farm.
  function btWantMode(g) {
    var me = g.me;
    // 1. Tam Lộ Tranh Phong meta Bí Tịch
    if (tlIn(g)) {
      var U = g.P.TamLoUI, G = g.P.Gateway;
      var R = (G && G.remotes) || {};
      var hasFoeNearby = Object.keys(R).some(function (id) {
        var r = R[id];
        return r && !r.downed && isFinite(r.x) && U && U.laDichNguoi && U.laDichNguoi(r) && dist(me.x, me.y, r.x, r.y) <= 360;
      });
      if (hasFoeNearby) return 'pk';
      var ft = st.farmTarget;
      if (ft && !ft.dead && ft.def && ft.def.tamLo) {
        var ve = ft.def.tamLo.ve;
        if (ve === 'tru' || ve === 'nha' || ft.def.tamLo.jungle === 'rong' || ft.def.tamLo.jungle === 'baron') return 'boss';
      }
      return 'farm';
    }
    // 1b. Tranh Đoạt Linh Thụ meta Bí Tịch
    if (ltIn(g)) {
      var U = g.P.LinhThuUI, G = g.P.Gateway;
      var R = (G && G.remotes) || {};
      var hasFoeNearby = Object.keys(R).some(function (id) {
        var r = R[id];
        return r && !r.downed && isFinite(r.x) && U && U.laDichNguoi && U.laDichNguoi(r) && dist(me.x, me.y, r.x, r.y) <= 360;
      });
      return hasFoeNearby ? 'pk' : 'farm';
    }
    // 2. Cảm biến quét người chơi thù địch trong vòng 320px (ngang tầm THREAT_SCAN)
    if (hostilePlayers(g).some(function (r) { return isFinite(r.x) && dist(me.x, me.y, r.x, r.y) <= 320; })) return 'pk';
    var pt = teamParty(g.P);
    if (pt && pt.members.length >= 2 && (st.vn || st.ll || evIn(g))) return 'team';
    var t = st.farmTarget;
    if ((t && !t.dead && isBoss(t)) || evIn(g) || (cfg.bossMaxDmg && worldBossNear(g)) || (st.bh && st.bh.boss) || (st.bd && st.bd.target)) return 'boss';
    return 'farm';
  }
  function tickBiTich(g) {
    if (!cfg.btAuto || g.me.downed || busyUI(g.P)) return;
    var want = btWantMode(g);
    // Tình huống PK khẩn cấp: có địch cận kề <= 200px hoặc đang trong tỉ thí duel
    var pkEmergency = want === 'pk' && (
      (g.P.Gateway && g.P.Gateway.duel) ||
      hostilePlayers(g).some(function (r) { return isFinite(r.x) && dist(g.me.x, g.me.y, r.x, r.y) <= 200; })
    );
    if (!btWant || btWant.mode !== want) {
      btWant = { mode: want, at: now() };
      if (!pkEmergency) return;
    }
    var holdMs = pkEmergency ? 0 : (want === 'pk' ? 800 : BT_HOLD_MS);
    if (want === st.btMode || now() - btWant.at < holdMs) return;
    var switchGap = want === 'pk' ? 3000 : BT_SWITCH_MS;
    if (st.btAt && now() - st.btAt < switchGap) return;
    btApply(g, want, pkEmergency ? 'PK khẩn cấp' : 'tự đổi theo việc đang làm');
  }

  /* --- Tổ đội trợ thủ --- */
  // Các nhân vật cùng chạy trợ thủ (teamNames) tự lập tổ đội: người đầu danh sách làm đội trưởng.
  var TEAM_TICK_MS = 1000, TEAM_INVITE_GAP_MS = 30000, TEAM_FRESH_MS = 5000;
  var teamBus = null, teamSeen = {}, teamInvAt = {}, teamTickAt = 0;
  function teamList() { return String(cfg.teamNames || '').split(/[,;\n]/).map(function (x) { return plainVi(x).trim(); }).filter(Boolean); }
  function myName(g) { return String(g.me && g.me.cfg && g.me.cfg.name || ''); }
  function teamHas(name) { var L = teamList(); return !L.length || L.indexOf(plainVi(name).trim()) >= 0; }
  function teamIsDesignatedLeader(g) { var L = teamList(); return L.length > 0 && L[0] === plainVi(myName(g)).trim(); }
  function teamParty(P) { var G = P.Gateway; return G && G.party && G.party.members && G.party.members.length ? G.party : null; }
  // Đồng đội đang ở cùng bản đồ (không tính mình): [{id, name, r (vị trí), bus}]
  function teamMates(g) {
    if (!cfg.teamOn) return [];
    var P = g.P, G = P.Gateway, pt = teamParty(P), self = G && G.selfId, out = [];
    if (!pt) return out;
    pt.members.forEach(function (m) {
      if (!m || m.id === self || !teamHas(m.name)) return;
      var r = G.remotes && G.remotes[m.id];
      if (!r || r.downed || !isFinite(r.x)) return;
      out.push({ id: m.id, name: m.name, r: r, bus: teamSeen[m.id] && now() - teamSeen[m.id].at < TEAM_FRESH_MS ? teamSeen[m.id] : null });
    });
    return out;
  }
  function teamLeaderId(g) { var pt = teamParty(g.P); return pt ? pt.leaderId : null; }
  function teamIsLeader(g) { var G = g.P.Gateway; return !teamParty(g.P) || teamLeaderId(g) === (G && G.selfId); }
  // Thứ tự cố định trong đội (theo id) → chia việc không trùng nhau mà không cần hỏi nhau.
  function teamRank(g, mates) { var self = String(g.P.Gateway && g.P.Gateway.selfId), ids = [self].concat(mates.map(function (m) { return String(m.id); })).sort(); return { rank: ids.indexOf(self), n: ids.length }; }
  function teamPost(g, extra) {
    if (!teamBus) return;
    var G = g.P.Gateway;
    try { teamBus.postMessage(Object.assign({ from: G && G.selfId, name: myName(g), map: g.mapId, x: g.me.x, y: g.me.y, t: Date.now() }, extra || {})); } catch (e) { }
  }
  function tickTeam(g) {
    if (!cfg.teamOn || now() - teamTickAt < TEAM_TICK_MS) return;
    teamTickAt = now();
    var P = g.P, G = P.Gateway;
    if (!teamBus && typeof BroadcastChannel !== 'undefined') {
      try { teamBus = new BroadcastChannel('ttbot-team'); teamBus.onmessage = function (ev) { var d = ev && ev.data; if (d && d.from != null && d.from !== (G && G.selfId)) { d.at = now(); teamSeen[d.from] = d; } }; } catch (e) { teamBus = null; }
    }
    teamPost(g, { vn: st.vn ? { lane: st.vn.lane, step: st.vn.step, inside: !!st.vn.inside } : null });
    if (!G || !G.connected || vnIn(g)) return; // trong Vết Nứt không được lập tổ đội mới
    // Nhận lời mời của người trong danh sách.
    (G.partyInviteOrder || []).slice().forEach(function (id) {
      var inv = G.partyPending && G.partyPending[id];
      if (inv && teamList().length && teamHas(inv.name) && G.partyAnswer) { G.partyAnswer(true, inv.inviteId); klog('[Tổ đội] Nhận lời mời của ' + inv.name); }
    });
    // Đội trưởng (người đầu danh sách): mời đồng đội đang thấy ở gần mà chưa vào đội.
    if (teamIsDesignatedLeader(g) && G.partyInvite) {
      var pt = teamParty(P), inParty = {}, R = G.remotes || {};
      if (pt && pt.leaderId !== G.selfId) return; // đang ở đội người khác làm trưởng: để nguyên
      (pt ? pt.members : []).forEach(function (m) { inParty[m.id] = 1; });
      if (pt && pt.members.length >= (pt.maxMembers || 6)) return;
      Object.keys(R).forEach(function (id) {
        var r = R[id];
        if (!r || inParty[id] || !r.name || !teamList().length || !teamHas(r.name) || plainVi(r.name).trim() === plainVi(myName(g)).trim()) return;
        if (now() - (teamInvAt[id] || -1e9) < TEAM_INVITE_GAP_MS) return;
        teamInvAt[id] = now();
        G.partyInvite(id);
        klog('[Tổ đội] Mời ' + r.name + ' vào tổ đội');
      });
    }
  }

  /* --- Vết Nứt Không Gian --- */
  // Vết Nứt (VetNut / VetNutUI): mê cung 128×128, game cập nhật TileMap.blocked theo cửa → tìm đường thẳng trên cả bản đồ.
  // Hạ Hộ Môn → đi lối thông (bỏ lối cụt) → boss canh lối → trụ ấn → đánh Hòm → nhặt đồ quý, giữ đủ 20 giây trong Phòng Hòm.
  var VN_REPATH_MS = 1200, VN_NEAR = 40, VN_BODY = 7, VN_RETARGET = 32;
  // Món Hòm được xướng tên cả máy chủ (nhặt trước), Vạn Xích Nhất Tuyến cực hiếm đứng đầu; còn lại theo phẩm cấp thật.
  var VN_BIG = ['van_xich_nhat_tuyen', 'phong_song_duc', 'yeu_huyet_cap_4', 'thu_tuong_giap', 'xich_long_huyet', 'luc_phi_kiem', 'ngua_hac_tho',
    'pha_canh_dan', 'truc_co_dan', 'yeu_dan_cap_2'];
  function vnLog(m) { klog('[Vết Nứt] ' + m); say('Vết Nứt: ' + m); }
  function vnIn(g) { var V = g.P.VetNut; return !!(V && V.laMap && V.laMap(g.mapId)); }
  function vnSt(P) { var U = P.VetNutUI; return U && U.trangThai ? U.trangThai() : null; }
  function vnNow(P) { return Date.now(); }
  function vnTickets(P) { var V = P.VetNut, I = P.Inventory; return V && I && I.count ? I.count(V.VE) : 0; }
  // Tìm đường trên toàn mê cung (BFS 8 hướng trên TileMap.blocked, tránh khe hút và ô tường sắp mọc). Trả về các điểm px.
  function vnAvoid(g, md) {
    var P = g.P, V = P.VetNut, L = vnSt(P) || {}, W = md.width, bad = {};
    (md.vn && md.vn.khe || []).forEach(function (i) { bad[i] = 1; });
    Object.keys(L.khe || {}).forEach(function (i) { bad[i] = 1; });
    if (L.bienCanh && L.bienCanh.ids && V.oCuaBien) L.bienCanh.ids.forEach(function (id) { V.oCuaBien(md, id).forEach(function (i) { bad[i] = 1; }); });
    return bad;
  }
  function vnBlocked(g) {
    var TM = g.P.TileMap;
    if (TM && TM.blocked && TM.width) return { b: TM.blocked, W: TM.width, H: TM.height };
    var m = g.sw.map;
    return m && m.vnGrid ? m.vnGrid : null;
  }
  function vnPath(g, tx, ty) {
    var md = g.sw.map.data, B = vnBlocked(g), T = g.P.CONFIG.TILE || 32;
    if (!B || !md) return null;
    var W = B.W, H = B.H, bad = vnAvoid(g, md), me = g.me;
    var sx = Math.floor(me.x / T), sy = Math.floor(me.y / T), gx = Math.floor(tx / T), gy = Math.floor(ty / T);
    function free(x, y) { if (x < 0 || y < 0 || x >= W || y >= H) return false; var i = y * W + x; return B.b[i] !== 1 && !bad[i]; }
    if (!free(gx, gy)) { // đích nằm trên ô chặn: lấy ô đi được gần nhất
      var best = null;
      for (var r = 1; r <= 4 && !best; r++) for (var dy = -r; dy <= r; dy++) for (var dx = -r; dx <= r; dx++) if (!best && free(gx + dx, gy + dy)) best = [gx + dx, gy + dy];
      if (!best) return null;
      gx = best[0]; gy = best[1];
    }
    var prev = new Int32Array(W * H).fill(-1), q = new Int32Array(W * H), qh = 0, qt = 0, start = sy * W + sx, goal = gy * W + gx;
    prev[start] = start; q[qt++] = start;
    var D8 = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
    while (qh < qt) {
      var c = q[qh++];
      if (c === goal) break;
      var cx = c % W, cy = (c - cx) / W;
      for (var k = 0; k < 8; k++) {
        var nx = cx + D8[k][0], ny = cy + D8[k][1];
        if (!free(nx, ny)) continue;
        if (k >= 4 && (!free(cx + D8[k][0], cy) || !free(cx, cy + D8[k][1]))) continue;
        var ni = ny * W + nx;
        if (prev[ni] !== -1) continue;
        prev[ni] = c; q[qt++] = ni;
      }
    }
    if (prev[goal] === -1) return null;
    var cells = [];
    for (var at = goal; at !== start; at = prev[at]) cells.push(at);
    cells.reverse();
    // Đường đi mượt: đường ô lưới 8 hướng là răng cưa (chéo – thẳng – chéo), mỗi lần tính lại còn quay về tâm ô kế bên → nhân …
    var cpt = cells.map(function (ci) { var cx2 = ci % W; return { x: (cx2 + 0.5) * T, y: ((ci - cx2) / W + 0.5) * T }; });
    var endPt = free(Math.floor(tx / T), Math.floor(ty / T)) ? { x: tx, y: ty } : { x: (gx + 0.5) * T, y: (gy + 0.5) * T };
    if (cpt.length) cpt[cpt.length - 1] = endPt; else cpt.push({ x: tx, y: ty }); // cùng ô với đích: vẫn bước nốt tới đúng điểm
    var HW = VN_BODY;
    function clear(x0, y0, x1, y1) {
      var d = dist(x0, y0, x1, y1), n = Math.max(1, Math.ceil(d / 6));
      for (var i2 = 0; i2 <= n; i2++) {
        var xs = x0 + (x1 - x0) * i2 / n, ys = y0 + (y1 - y0) * i2 / n;
        if (!free(Math.floor((xs - HW) / T), Math.floor((ys - HW) / T)) || !free(Math.floor((xs + HW) / T), Math.floor((ys - HW) / T)) ||
          !free(Math.floor((xs - HW) / T), Math.floor((ys + HW) / T)) || !free(Math.floor((xs + HW) / T), Math.floor((ys + HW) / T))) return false;
      }
      return true;
    }
    var pts = [], cur = { x: me.x, y: me.y }, i3 = 0;
    while (i3 < cpt.length) {
      var j3 = i3;
      while (j3 + 1 < cpt.length && clear(cur.x, cur.y, cpt[j3 + 1].x, cpt[j3 + 1].y)) j3++;
      if (j3 === i3 && !clear(cur.x, cur.y, cpt[i3].x, cpt[i3].y) && pts.length === 0) { /* đang sát tường: vẫn đi theo ô */ }
      pts.push(cpt[j3]); cur = cpt[j3]; i3 = j3 + 1;
    }
    return { pts: pts, len: cells.length };
  }
  function vnGo(g, a, x, y, near) {
    var me = g.me;
    if (dist(me.x, me.y, x, y) <= (near || VN_NEAR)) { if (me.path && me.path.length && a.goKey === Math.round(x) + ',' + Math.round(y)) me.path.length = 0; return false; }
    var key = Math.round(x) + ',' + Math.round(y), L = vnSt(g.P) || {};
    var cua = L.cua || { sanh: [], an: [], lo: [] };
    var anOpen = (cua.an || []).indexOf(1);
    var loThong = (cua.lo || []).indexOf(1);
    var doorFound = anOpen >= 0 || loThong >= 0 || !!(a && a.doorFound && now() - (a.doorFoundAt || 0) < 180000);
    if (doorFound) {
      setAuto(g, false);
      if (!a || !a.target || a.target.type !== 'vn_hom') {
        st.farmTarget = null;
      }
    }
    if (me.path && me.path.length && a.apVer === L.apVer && now() - a.routeAt < VN_REPATH_MS && (a.goKey === key || (a.goX != null && dist(a.goX, a.goY, x, y) < VN_RETARGET))) return true;
    var r = vnPath(g, x, y);
    a.goKey = key; a.goX = x; a.goY = y; a.routeAt = now(); a.apVer = L.apVer;
    if (!r) { a.noPath = (a.noPath || 0) + 1; return false; }
    a.noPath = 0;
    if (me.state === 'sit') {
      if (g.P.Player && g.P.Player.stand) g.P.Player.stand(me);
      else if (g.P.Input && g.P.Input.pressMeditate) g.P.Input.pressMeditate();
    }
    moveFighting(g, r.pts);
    return true;
  }
  function vnPathLen(g, x, y) { var r = vnPath(g, x, y); return r ? r.len : Infinity; }
  function vnMobsNear(g, x, y, R) { return mobsAlive(g).filter(function (m) { return m.def && m.def.contactDmg > 0 && dist(m.x, m.y, x, y) <= R; }); }
  // Tính điểm đứng ở viền đón đồ Hòm Hư Không (R ~ 48-52px phía Dưới/Tây Nam/Đông Nam nơi bảo vật văng ra)
  function vnHomStance(g, hom) {
    var md = g.sw.map.data, V = g.P.VetNut, me = g.me;
    var x0 = hom.x, y0 = hom.y;
    // Hòm Hư Không tựa lưng vào vách đá phía trên (y < y0); đồ văng theo nan quạt phía Nam (y > y0).
    // Bán kính đón đầu tối ưu: 49px (vừa trong tầm đánh melee reach = 50px, vừa đúng tâm vùng đồ văng 50-80px).
    var cands = [
      { x: x0, y: y0 + 49 },          // Chính Nam
      { x: x0 - 35, y: y0 + 35 },     // Tây Nam (Dưới-Trái)
      { x: x0 + 35, y: y0 + 35 },     // Đông Nam (Dưới-Phải)
      { x: x0 - 48, y: y0 + 16 },     // Tây (Trái)
      { x: x0 + 48, y: y0 + 16 }      // Đông (Phải)
    ];
    var valid = cands.filter(function (c) {
      if (!V || !V.trongHom) return true;
      return V.trongHom(md, c.x, c.y);
    });
    if (!valid.length) valid = [{ x: x0, y: y0 + 48 }];
    var RR = g.P.Gateway.remotes || {}, Uv = g.P.VetNutUI;
    var rivals = Object.keys(RR).map(function (id) { return RR[id]; }).filter(function (r) {
      return r && !r.downed && isFinite(r.x) && !(Uv && Uv.khongDich && Uv.khongDich(r.id, r)) && !(g.P.Gateway.partyMember && r.id != null && g.P.Gateway.partyMember(r.id));
    });
    var mates = teamMates(g);
    var best = null;
    valid.forEach(function (c) {
      var dMe = dist(me.x, me.y, c.x, c.y);
      var rivalNear = rivals.filter(function (r) { return dist(c.x, c.y, r.x, r.y) < 70; }).length;
      var mateBonus = mates.some(function (m) { return dist(c.x, c.y, m.r.x, m.r.y) < 100; }) ? 40 : 0;
      // Ưu tiên vị trí ít địch, gần đồng đội, và nếu mình đang đứng gần đó thì giữ nguyên không đổi qua lại
      var score = -rivalNear * 150 + mateBonus - dMe * 0.4;
      if (dMe <= 14) score += 80; // Trọng số ổn định vị trí đang đứng
      if (!best || score > best.s) best = { pos: c, s: score };
    });
    return best ? best.pos : valid[0];
  }

  // Đánh mục tiêu t: tự khoá, tự chém, tung chiêu sát thương cao nhất (không phụ thuộc auto của game tự đổi mục tiêu).
  function vnFight(g, a, t) {
    if (!t) return false;
    var me = g.me;
    var P = g.P, L = vnSt(P) || {}, cua = L.cua || { sanh: [], an: [], lo: [] };
    var anOpen = (cua.an || []).indexOf(1);
    var loThong = (cua.lo || []).indexOf(1);
    var doorFound = anOpen >= 0 || loThong >= 0 || !!(a && a.doorFound && now() - (a.doorFoundAt || 0) < 180000);
    // Khi đã tìm được cửa: BỎ QUA TOÀN BỘ QUÁI TRÊN ĐƯỜNG, chỉ đánh Hòm Hư Không (vn_hom)
    if (doorFound && t.type !== 'vn_hom') {
      a.target = null;
      st.farmTarget = null;
      if (me.attackTarget === t) me.attackTarget = null;
      setAuto(g, false);
      return false;
    }
    a.target = t;
    // Đối với Hòm Hư Không: không áp sát tâm (0-20px) mà chuyển sang Thế Đứng Viền Đón Đầu (R ~ 49px)
    if (t.type === 'vn_hom') {
      var stPos = vnHomStance(g, t);
      var dSt = dist(me.x, me.y, stPos.x, stPos.y);
      var dHom = dist(me.x, me.y, t.x, t.y);
      setAuto(g, false);
      honPin(g.P, t, me);
      st.farmTarget = t;
      var hpPct = t.hpMax > 0 ? (t.hp / t.hpMax) : 1;
      var isDying = hpPct <= 0.12 || (t.hp != null && t.hp <= 12000);
      if (dSt > 14) {
        var D0 = g.P.Player.reach ? g.P.Player.reach() : 26;
        huntBurst(g, t, dHom, D0);
        vnGo(g, a, stPos.x, stPos.y, 6);
        a.step = (isDying ? 'chực sẵn viền đón đầu Hòm vỡ ' : 'đánh Hòm Hư Không ') + evPct(t) + ' (di chuyển ra viền ' + Math.round(dHom) + 'px)';
        return true;
      }
      // Đã tới viền đón đầu: đứng yên giữ thế, liên tục tung chiêu / chém thường
      if (me.path && me.path.length) me.path.length = 0;
      honStrike(g, a, t, true);
      a.step = (isDying ? 'chực sẵn viền đón đầu Hòm vỡ ' : 'đánh Hòm Hư Không ') + evPct(t) + ' ở viền đón đồ (' + Math.round(dHom) + 'px)';
      return true;
    }
    var reach = (g.P.Player.reach ? g.P.Player.reach() : 26) + (t.def && t.def.bodyRadius || 0);
    // Còn xa (vách mê cung chắn): đi theo đường tìm trên toàn mê cung; tới gần thì tự chém + tung chiêu.
    if (dist(me.x, me.y, t.x, t.y) > reach + 40) {
      setAuto(g, false);
      honPin(g.P, t, me);
      st.farmTarget = t;
      var D = g.P.Player.reach ? g.P.Player.reach() : 26;
      if (huntBurst(g, t, dist(me.x, me.y, t.x, t.y), D)) return true; // chiêu tầm xa thì tung luôn trên đường tới
      vnGo(g, a, t.x, t.y, reach - 6);
      return true;
    }
    honStrike(g, a, t, true);
    return true;
  }
  // Vết nứt ở ngoài: đi tới đúng chỗ, bước vào.
  function vnOutside(g) {
    var P = g.P, V = P.VetNut, U = P.VetNutUI, me = g.me, S = U && U.st, nut = S && S.nut;
    var a = st.vn;
    // Vừa bấm vào: đứng yên chờ được hút vào mê cung (đổi map), không bỏ đi.
    if (a && !a.inside && S && S.daVao && now() - a.sentAt < 20000) { a.step = 'đang được hút vào vết nứt'; setAuto(g, false); if (me.path && me.path.length) me.path.length = 0; return true; }
    if (!nut || !(vnNow(P) < nut.den) || S.daVao) { if (a && !a.inside) { st.vn = null; if (a.back) goBack(a.back.map, a.back.x, a.back.y, 'Vết Nứt: đã khép / đã vào → về chỗ farm', 'vn', a.back.khu); } return false; }
    if (me.downed || vtBusy(g)) return false;
    if (V.duTuCach && !V.duTuCach(P.Progress && P.Progress.realmId)) { if (!st.vnWhy) { st.vnWhy = 1; vnLog('Chưa đủ cảnh giới (cần Luyện Khí tầng 13)'); } return false; }
    if (!vnTickets(P)) return false; // không có vé: phần mua vé lo
    if (!a) { a = st.vn = evNew(); evTakeOver(g, a); vnLog('Vết nứt đang mở ở ' + (nut.ten || mapName(nut.map)) + ' (khép sau ' + V.dem(nut.den - vnNow(P)) + ') → tới vào'); }
    if (g.mapId !== nut.map) { a.step = 'đi tới ' + (nut.ten || mapName(nut.map)); return jobGo(g, a, nut.map, 'Vết Nứt: tới ' + mapName(nut.map), vnLog) || true; }
    if (st.travel) stopTravel();
    if (nut.x == null) { a.step = 'chờ thấy chỗ vết nứt trong map'; setAuto(g, false); return true; }
    setAuto(g, false);
    if (dist(me.x, me.y, nut.x, nut.y) > (V.TAM_VAO || 72) - 8) {
      a.step = 'tới vết nứt (' + Math.round(dist(me.x, me.y, nut.x, nut.y)) + 'px)';
      if (!(me.path && me.path.length && now() - a.routeAt < 1500)) { var r = spotCheck(g).route(nut.x, nut.y); if (r) { moveFighting(g, r.path); a.routeAt = now(); } }
      return true;
    }
    if (me.path && me.path.length) me.path.length = 0;
    if (now() - a.sentAt < 3000) { a.step = 'đang bước vào'; return true; }
    a.sentAt = now();
    a.step = 'bước vào vết nứt';
    if (U.tuongTac && U.tuongTac(me, true)) vnLog('Bước vào vết nứt');
    else if (P.Gateway.vetNut) P.Gateway.vetNut('vao', {}, function (res) { if (res && res.ok === false) vnLog('Chưa vào được: ' + (res.why ? V.viLoi(res.why) : 'không rõ')); });
    return true;
  }
  // Mua vé khi hết (Hồng Tỷ, Chân Núi Tản Viên).
  function vnBuyTicket(g) {
    var P = g.P, V = P.VetNut;
    if (!cfg.vnBuy || !V || !V.muaVe || vnTickets(P) >= Math.max(1, cfg.vnTicketKeep | 0)) { st.vnBuy = null; return false; }
    var S0 = P.VetNutUI && P.VetNutUI.st, nut0 = S0 && S0.nut;
    if (vnIn(g) || (nut0 && Date.now() < nut0.den && S0.daVao)) { st.vnBuy = null; return false; } // vừa vào / đang trong lượt: mua sau
    if ((P.Progress && P.Progress.stones | 0) < V.GIA_VE * 1 + 50) return false;
    if (now() < (st.vnBuyRest || 0)) return false;
    var a = st.vnBuy || (st.vnBuy = evNew());
    if (!a.back) a.back = takeBack(g);
    var w = atNpc(g, a, V.NPC_VE, vnLog);
    if (w === 'fail') { st.vnBuyRest = now() + 10 * 60000; st.vnBuy = null; return false; }
    if (w !== 'here') { a.step = 'đi mua Hư Không Lệnh ở Hồng Tỷ'; return true; }
    var need = Math.max(1, (cfg.vnTicketKeep | 0) - vnTickets(P)), n = need >= 5 && (P.Progress.stones | 0) >= V.GIA_VE * 5 ? 5 : 1;
    var res = V.muaVe(n, P);
    vnLog(res && res.ok ? 'Đã mua ' + n + ' Hư Không Lệnh (-' + res.cost + ' Linh Thạch)' : 'Chưa mua được vé: ' + (res && res.why || 'không rõ'));
    if (!res || !res.ok) st.vnBuyRest = now() + 10 * 60000;
    var b = a.back;
    st.vnBuy = null;
    if (b) goBack(b.map, b.x, b.y, 'Mua vé xong → về chỗ farm', 'vnBuy', b.khu);
    return true;
  }
  function vnInside(g) {
    var P = g.P, V = P.VetNut, me = g.me, md = g.sw.map.data, vn = md && md.vn, L = vnSt(P) || {};
    var a = st.vn || (st.vn = evNew());
    a.inside = true;
    if (st.healing || me.state === 'sit') {
      st.healing = false;
      st.healMoving = false;
      if (me.state === 'sit') {
        if (P.Player && P.Player.stand) P.Player.stand(me);
        else if (P.Input && P.Input.pressMeditate) P.Input.pressMeditate();
      }
    }
    if (!vn) { a.step = 'chờ dữ liệu mê cung'; return false; }
    if (me.downed || L.guc) { a.step = 'gục · chờ hồi sinh ở Sảnh (còn ' + (L.mang | 0) + ' mạng)'; return false; }
    var cua = L.cua || { sanh: [], an: [], lo: [] }, self = P.Gateway && P.Gateway.selfId;
    var lo = cua.lo || [], loThong = lo.indexOf(1);
    var anOpen = (cua.an || []).indexOf(1);
    var doorFound = anOpen >= 0 || loThong >= 0 || !!(a.doorFound && now() - (a.doorFoundAt || 0) < 180000);
    if (a.lane != null && lo[a.lane] === 2) a.lane = null; // lối đang nhắm vừa bị báo cụt: bỏ ngay, nhịp sau chọn lối khác
    var mine = L.cam && self != null && L.cam[self] && L.cam[self].length;
    var inHom = V.trongHom(md, me.x, me.y), inSanh = V.trongSanh(md, me.x, me.y);
    // Đồ Hòm còn nằm đất nhặt được (trong Phòng Hòm, chưa bị khoá / bỏ qua).
    var homDrops = L.tt === 'HOM' || L.homMo ? (g.sw.drops || []).filter(function (r) {
      if (!r || r.state !== 'ground' || r.granted || !r.ht || !isFinite(r.x) || (r.htBo && Date.now() < r.htBo)) return false;
      if (r.lootId != null && lootSkip[r.lootId] > now()) return false;
      return V.trongHom(md, r.x, r.y);
    }) : [];
    // 1) Đang cầm đồ Hòm: đủ 20 giây mới thành của mình, gục là văng. Vẫn nhặt tiếp khi quanh không có người lạ (đồ nằm đất chỉ …
    var holdFoeNear = false;
    if (mine && cfg.vnHomHold && homDrops.length) {
      var R0 = P.Gateway.remotes || {}, U0 = P.VetNutUI, G0 = P.Gateway, fleeing = a.holdFleeTo > now();
      var foes0 = Object.keys(R0).map(function (id) { return R0[id]; }).filter(function (r) { return r && !r.downed && isFinite(r.x) && V.trongHom(md, r.x, r.y) && !(U0 && U0.khongDich && U0.khongDich(r.id, r)) && !(G0.partyMember && r.id != null && G0.partyMember(r.id)); }); // mọi người lạ trong Phòng Hòm (không cắt theo bán kính → không chập chờn ở mép)
      if (foes0.length) {
        var nearF = foes0.some(function (f) { return dist(f.x, f.y, me.x, me.y) < (fleeing ? 300 : 220); });
        // món mình tới trước mọi người lạ quanh đó ít nhất 80px, và không ai đang sát người (< 110px)
        var safe0 = fleeing && nearF ? [] : homDrops.filter(function (r) { var dm = dist(me.x, me.y, r.x, r.y); return foes0.every(function (f) { return dist(f.x, f.y, r.x, r.y) > dm + 80 && dist(f.x, f.y, me.x, me.y) > 110; }); });
        if (safe0.length) homDrops = safe0;
        else { holdFoeNear = true; if (nearF && !fleeing) a.holdFleeTo = now() + 2500; }
      }
    }
    // Tổ đội: đang cầm rồi mà trong Phòng Hòm còn đồng đội chưa cầm món nào → nhường đồ còn lại cho họ.
    var mateEmpty = mine && teamMates(g).some(function (m) { return V.trongHom(md, m.r.x, m.r.y) && !(L.cam && L.cam[m.id] && L.cam[m.id].length); });
    if (mine && cfg.vnHomHold && (!homDrops.length || holdFoeNear || mateEmpty)) {
      a.step = 'đang cầm ' + mine + ' món · giữ đủ 20 giây trong Phòng Hòm';
      var R = P.Gateway.remotes || {}, U2 = P.VetNutUI, G2 = P.Gateway, foes = Object.keys(R).map(function (id) { return R[id]; }).filter(function (r) {
        // cùng tổ đội / cùng tông không PK được nhau → không phải người lạ
        return r && !r.downed && isFinite(r.x) && V.trongHom(md, r.x, r.y) && !(U2 && U2.khongDich && U2.khongDich(r.id, r)) && !(G2.partyMember && r.id != null && G2.partyMember(r.id));
      });
      var matesC = teamMates(g);
      var nearFoe = foes.reduce(function (m0, r) { var d1 = dist(me.x, me.y, r.x, r.y); return !m0 || d1 < m0.d ? { r: r, d: d1 } : m0; }, null);
      var fl = a.flee;
      // Đích đang chạy tới còn ổn (người lạ chưa chặn ở đó, chưa tới nơi) thì giữ, khỏi đổi hướng liên tục.
      if (fl && (now() - fl.at > 6000 || dist(me.x, me.y, fl.x, fl.y) < 30 || foes.some(function (r) { return dist(r.x, r.y, fl.x, fl.y) < 120; }))) fl = a.flee = null;
      if (nearFoe && nearFoe.d < 220 && !fl) {
        // chỗ trong Phòng Hòm xa người lạ nhất, ưu tiên phía ngược hướng người lạ gần nhất (chạy ra xa, không băng qua họ)
        var hb = vn.hom, T = P.CONFIG.TILE || 32, best = null, ax = me.x - nearFoe.r.x, ay = me.y - nearFoe.r.y;
        for (var ty = hb.y0; ty <= hb.y1; ty++) for (var tx = hb.x0; tx <= hb.x1; tx += 2) {
          var x = (tx + 0.5) * T, y = (ty + 0.5) * T;
          if (!V.trongHom(md, x, y)) continue;
          var dmin = foes.reduce(function (m0, r) { return Math.min(m0, dist(x, y, r.x, r.y)); }, 1e9);
          var away = (x - me.x) * ax + (y - me.y) * ay >= 0 ? 0 : -400;
          var near0 = matesC.length ? matesC.reduce(function (m0, m) { return Math.min(m0, dist(x, y, m.r.x, m.r.y)); }, 1e9) : 0;
          var sc0 = dmin + away - 0.15 * dist(me.x, me.y, x, y) - 0.25 * Math.max(0, near0 - 120); // ở gần đồng đội
          if (!best || sc0 > best.s) best = { x: x, y: y, s: sc0 };
        }
        if (best) fl = a.flee = { x: best.x, y: best.y, at: now() };
      }
      if (fl) { a.step += ' · tránh người lạ (cách ' + Math.round(nearFoe ? nearFoe.d : 0) + 'px)'; vnGo(g, a, fl.x, fl.y, 20); }
      else if (me.path && me.path.length && (!nearFoe || nearFoe.d > 260)) me.path.length = 0;
      return true;
    }
    // 2) Hòm đã vỡ: nhặt đồ trong Phòng Hòm (món lớn trước); đang vận đống Linh Thạch thì đứng yên.
    if (L.tt === 'HOM' || L.homMo) {
      if (L.van) { a.step = 'đang vận ' + (L.van.ten || 'bảo vật'); if (me.path && me.path.length) me.path.length = 0; return true; }
      var drops = homDrops;
      if (drops.length) {
        var PR = (P.Loot && P.Loot.PICK_R) || 40;
        // Zero-Walk Instant Sweep (Frame 0): Nhặt tức thì TẤT CẢ các món đồ văng vào chân / bán kính PICK_R trong frame đầu tiên
        drops.forEach(function (dr) {
          if (!(dr.vanMs > 0) && dist(me.x, me.y, dr.x, dr.y) <= PR && P.Gateway.vetNut && now() - (dr._ttVn || 0) > 250) {
            dr._ttVn = now();
            P.Gateway.vetNut('nhat', { id: dr.lootId }, function () { });
          }
        });
        // Giá trị: món lớn (VN_BIG, cực hiếm, Toái Không Linh Chi mỗi ngày 5–10 cây) bỏ xa đồ thường (theo phẩm), đống Linh Thạch
        // phải vận 8 giây xếp cuối. Chọn món có (giá trị × khả năng tới trước người lạ) − quãng đi lớn nhất: món xịn trước, nhưng
        // món người lạ chắc chắn tới trước thì thôi tranh, lấy món quý nhất mình tới trước được. Đồng đội gần hơn thì nhường.
        var CB = V.HOM_CONG_BO || {}, val = function (r) {
          var i = VN_BIG.indexOf(r.itemId);
          if ((CB.cucHiem || []).indexOf(r.itemId) >= 0) return 60000; // cực hiếm: còn cơ hội là tranh
          if (i >= 0) return 20000 - i * 400;
          if ((CB.moiNgay || []).indexOf(r.itemId) >= 0) return 19800;
          return r.vanMs > 0 ? 40 : 200 + Math.min(5000, gradeScore(P, r.itemId)) / 5 + ((CB.coThe || []).indexOf(r.itemId) >= 0 ? 60 : 0);
        };
        var matesH = teamMates(g).filter(function (m) { return V.trongHom(md, m.r.x, m.r.y); }), RR = P.Gateway.remotes || {}, Uv = P.VetNutUI;
        var rivals = Object.keys(RR).map(function (id) { return RR[id]; }).filter(function (r) { return r && !r.downed && isFinite(r.x) && V.trongHom(md, r.x, r.y) && !(Uv && Uv.khongDich && Uv.khongDich(r.id, r)) && !(P.Gateway.partyMember && r.id != null && P.Gateway.partyMember(r.id)); });
        var best0 = null;
        drops.forEach(function (r) {
          var dm = dist(me.x, me.y, r.x, r.y);
          if (matesH.some(function (m) { return dist(m.r.x, m.r.y, r.x, r.y) + 20 < dm; })) return;
          var df = rivals.reduce(function (m0, f) { return Math.min(m0, dist(f.x, f.y, r.x, r.y)); }, 1e9);
          var sc = val(r) * (df > dm + 30 ? 1 : df > dm - 40 ? 0.6 : df > dm - 120 ? 0.25 : 0.05) - dm * 0.6;
          if (!best0 || sc > best0.s) best0 = { r: r, s: sc };
        });
        var d0 = best0 ? best0.r : drops[0];
        a.step = 'nhặt ' + dropName(g, d0) + ' (' + drops.length + ' món quanh Hòm' + (mine ? ' · đang cầm ' + mine : '') + ')';
        setAuto(g, false);
        a.homSweep = null;
        // Món không phải vận: vào trong tầm nhặt là tự gửi lệnh nhặt (lặp mỗi 0,25 giây), khỏi phải đứng hẳn lên món đồ.
        var dd0 = dist(me.x, me.y, d0.x, d0.y);
        if (!(d0.vanMs > 0) && dd0 <= PR - 5 && P.Gateway.vetNut && now() - (d0._ttVn || 0) > 250) { d0._ttVn = now(); P.Gateway.vetNut('nhat', { id: d0.lootId }, function () { }); }
        // Quét nhặt dạo dọc đường đi (Arc Sweep): bất kỳ món nào đi ngang qua trong bán kính PICK_R đều được hốt ngay
        drops.forEach(function (dr) {
          if (dr.lootId !== d0.lootId && !(dr.vanMs > 0) && dist(me.x, me.y, dr.x, dr.y) <= PR - 4 && P.Gateway.vetNut && now() - (dr._ttVn || 0) > 250) {
            dr._ttVn = now();
            P.Gateway.vetNut('nhat', { id: dr.lootId }, function () { });
          }
        });
        if (dd0 <= 12) {
          if (me.path && me.path.length) me.path.length = 0; // đứng lên món đồ: game tự gửi lệnh nhặt
          if (!a.pickAt || a.pickId !== d0.lootId) { a.pickAt = now(); a.pickId = d0.lootId; }
          else if (now() - a.pickAt > (d0.vanMs > 0 ? 6000 : 3000)) { lootSkip[d0.lootId] = now() + 20000; a.pickAt = 0; }
          return true;
        }
        if (!vnGo(g, a, d0.x, d0.y, 6) && a.noPath) lootSkip[d0.lootId] = now() + 20000; // không có đường tới: bỏ qua món này
        return true;
      }
      // Không thấy món nào: tầm nhìn trong Phòng Hòm chỉ ~288px → đi một vòng Phòng Hòm tìm đồ văng xa (máy chủ chỉ gửi thứ ở gần).
      if (L.tt === 'HOM' && vn.hom) {
        var Tt = P.CONFIG.TILE || 32, hb2 = vn.hom;
        if (!a.homSweep) {
          var pts2 = [];
          for (var yy = hb2.y0 + 3; yy <= hb2.y1; yy += 7) for (var xx = hb2.x0 + 3; xx <= hb2.x1; xx += 7) { var px2 = (xx + 0.5) * Tt, py2 = (yy + 0.5) * Tt; if (V.trongHom(md, px2, py2)) pts2.push({ x: px2, y: py2, prio: true, dwell: 600 }); }
          a.homSweep = { pts: pts2, at: now(), n: pts2.length };
        }
        if (a.homSweep.pts.length && now() - a.homSweep.at < 60000) {
          a.step = 'Hòm đã vỡ · đi vòng Phòng Hòm tìm đồ văng xa (còn ' + a.homSweep.pts.length + '/' + a.homSweep.n + ' chỗ)';
          setAuto(g, false);
          // đi bằng đường tìm trong mê cung (vnGo), tới gần chỗ nào thì gạch chỗ đó
          var hsP = a.homSweep.pts;
          for (var hi = hsP.length - 1; hi >= 0; hi--) if (dist(me.x, me.y, hsP[hi].x, hsP[hi].y) < 90) hsP.splice(hi, 1);
          if (hsP.length) {
            var nx0 = hsP.reduce(function (m0, q) { return !m0 || dist(me.x, me.y, q.x, q.y) < dist(me.x, me.y, m0.x, m0.y) ? q : m0; }, null);
            if (!vnGo(g, a, nx0.x, nx0.y, 60) && a.noPath) hsP.splice(hsP.indexOf(nx0), 1);
            return true;
          }
        }
      }
      a.step = 'Hòm đã vỡ · hết đồ nhặt được quanh đây';
      return false;
    }
    // 3) Đã có Cửa Ấn thật mở (hoặc đang ở Phòng Hòm): tới đánh Hòm ở viền đón đầu.
    var hom = mobsAlive(g).filter(function (m) { return m.type === 'vn_hom'; })[0] || (g.sw.enemies || []).filter(function (m) { return m && m.type === 'vn_hom' && !m.dead; })[0];
    if (anOpen >= 0 || inHom) {
      if (hom && dist(me.x, me.y, hom.x, hom.y) < 420) { return vnFight(g, a, hom); }
      a.step = (doorFound ? 'tìm được cửa → bỏ quái tới ' : '') + 'cửa ' + V.tenCong(anOpen >= 0 ? anOpen : (a.doorLane != null ? a.doorLane : 0)) + ' đã mở → tới viền Phòng Hòm';
      setAuto(g, false);
      st.farmTarget = null;
      if (vnGo(g, a, vn.ruong.x, vn.ruong.y + 49, 40)) return true;
      return false;
    }
    // Có con đang đánh mình trên đường: nếu chưa tìm được cửa thì hạ nó (lấy góp sức, khỏi bị cắn đuổi). Khi đã tìm được cửa: BỎ QUA TOÀN BỘ QUÁI!
    if (!doorFound) {
      var foe = engagedBy(g);
      if (foe && foe.def && !inSanh) { a.step = 'đánh ' + mobLabel(foe) + ' đang đuổi mình'; return vnFight(g, a, foe); }
    }
    // 4) Cửa đá chưa mở: hạ Hộ Môn gần nhất.
    var sanh = cua.sanh || [], anyGate = sanh.some(function (x) { return x === 1 || x === true; });
    if (!anyGate || L.tt === 'MO' || L.tt === 'DEM') {
      if (L.tt === 'MO' || L.tt === 'DEM') { a.step = L.tt === 'DEM' ? 'cửa vừa khép · chờ Hộ Môn hiện' : 'chờ vết nứt khép cửa (đủ người / hết 10 phút)'; setAuto(g, false); return true; }
      var targetK = doorFound && a.doorLane != null ? a.doorLane : -1;
      var hm = null;
      for (var k0 = 0; k0 < 5; k0++) {
        if (targetK >= 0 && k0 !== targetK) continue;
        var pos = V.hoMonTai(md, k0);
        if (!pos) continue;
        var mob = vnMobsNear(g, pos.x, pos.y, 220).filter(function (m) { return isBoss(m); })[0];
        var dd = dist(me.x, me.y, pos.x, pos.y);
        if (!hm || dd < hm.d) hm = { k: k0, pos: pos, mob: mob, d: dd };
      }
      if (hm) {
        if (hm.mob) { a.step = 'hạ Hộ Môn ' + V.tenCong(hm.k) + ' ' + evPct(hm.mob); return vnFight(g, a, hm.mob); }
        a.step = 'tới Hộ Môn ' + V.tenCong(hm.k);
        return vnGo(g, a, hm.pos.x, hm.pos.y + 60, 70) || true;
      }
    }
    // 5) Chọn lối: "thông" thì đi thẳng; không thì lối gần nhất chưa bị báo cụt, cửa đá đã mở.
    var k = loThong, why = '';
    var mates = teamMates(g), lid = teamLeaderId(g), lead = mates.filter(function (m) { return m.id === lid; })[0];
    var leadLane = lead ? (lead.bus && lead.bus.vn && lead.bus.vn.lane != null ? lead.bus.vn.lane : V.loTai(md, lead.r.x, lead.r.y)) : -1;
    if (k >= 0) why = 'lối ' + V.tenCong(k) + ' đã báo THÔNG';
    else if (doorFound && a.doorLane != null && lo[a.doorLane] !== 2) {
      k = a.doorLane;
      why = 'tìm được cửa lối ' + V.tenCong(k) + ' → bỏ quái chạy thẳng tới';
    }
    else if (lead && leadLane >= 0 && lo[leadLane] !== 2 && (sanh[leadLane] === 1 || sanh[leadLane] === true)) { k = leadLane; why = 'theo đội trưởng ' + lead.name + ' dò lối ' + V.tenCong(k); }
    else {
      if (a.lane != null && lo[a.lane] !== 2 && (sanh[a.lane] === 1 || sanh[a.lane] === true || V.loTai(md, me.x, me.y) === a.lane)) k = a.lane;
      else {
        var bestK = null;
        for (var k1 = 0; k1 < 5; k1++) {
          if (lo[k1] === 2 || !(sanh[k1] === 1 || sanh[k1] === true)) continue;
          var Lk = vn.lo[k1], len = vnPathLen(g, Lk.boss.x, Lk.boss.y);
          if (!bestK || len < bestK.len) bestK = { k: k1, len: len };
        }
        if (bestK && bestK.len < Infinity) k = bestK.k;
      }
      why = k >= 0 ? 'chưa rõ lối nào thông → dò lối ' + V.tenCong(k) + ' (gần nhất chưa bị báo cụt)' : '';
    }
    if (k < 0) { a.step = 'chưa có lối nào đi được · chờ cửa đá mở'; setAuto(g, false); return true; }
    if (a.lane !== k) { a.lane = k; vnLog(why[0].toUpperCase() + why.slice(1)); }
    var LK = vn.lo[k];
    // Boss canh lối còn sống: tới gian giữa hạ boss (cả bản biết thông / cụt, ba người sát thương cao nhất có quà).
    // KHI ĐÃ TÌM ĐƯỢC CỬA / LỐI ĐÃ THÔNG: BỎ QUA TOÀN BỘ BOSS VÀ QUÁI, CHẠY THẲNG TỚI TRỤ ẤN / PHÒNG HÒM!
    if (!lo[k] && !doorFound) {
      var boss = vnMobsNear(g, LK.boss.x, LK.boss.y, 400).filter(function (m) { return isBoss(m) && m.type !== 'vn_hom'; })[0];
      if (boss) { a.step = 'đánh boss canh lối ' + V.tenCong(k) + ' · ' + mobLabel(boss) + ' ' + evPct(boss); return vnFight(g, a, boss); }
      if (dist(me.x, me.y, LK.boss.x, LK.boss.y) > 120) { a.step = 'tới gian boss lối ' + V.tenCong(k); return vnGo(g, a, LK.boss.x, LK.boss.y, 100) || true; }
      a.step = 'gian boss lối ' + V.tenCong(k) + ' · chờ boss / kết quả lối';
      return false;
    }
    // Lối thông / đã tìm được cửa: tới ba trụ ấn, đứng trụ còn trống.
    setAuto(g, false);
    st.farmTarget = null;
    var R2 = P.Gateway.remotes || {}, others = Object.keys(R2).map(function (id) { return R2[id]; }).filter(function (r) { return r && !r.downed && isFinite(r.x); });
    // Chỉ coi là đang giữ trụ khi trụ đó chưa có ai khác đứng (đường đi có thể băng ngang trụ người khác đã giữ).
    var AR = (V.AN && V.AN.r) || 24, onPillar = LK.tru.filter(function (q) { return dist(me.x, me.y, q.x, q.y) <= AR - 4 && !others.some(function (r) { return dist(r.x, r.y, q.x, q.y) <= AR; }); })[0];
    // Tổ đội ≥ 3 người: mỗi người một trụ theo thứ tự cố định (tự mở ấn, không chờ người lạ). Trụ của mình có người lạ
    // đứng rồi thì lấy trụ trống. Đi ngang trụ của đồng đội thì không dừng lại giữ nhầm.
    var tr0 = teamRank(g, mates), mineQ = null;
    if (mates.length >= 2 && tr0.rank < LK.tru.length) {
      var q1 = LK.tru[tr0.rank], stranger = others.some(function (r) { return dist(r.x, r.y, q1.x, q1.y) <= AR && !mates.some(function (m) { return m.r === r; }); });
      if (!stranger) mineQ = q1;
    }
    if (mineQ && onPillar !== mineQ) onPillar = null;
    if (onPillar) { a.step = 'giữ trụ ấn lối ' + V.tenCong(k) + ' (' + ((L.an && L.an[k] && L.an[k].so) | 0) + '/3 người)'; if (me.path && me.path.length) me.path.length = 0; setAuto(g, false); return true; }
    var free = LK.tru.filter(function (q) { return !others.some(function (r) { return dist(r.x, r.y, q.x, q.y) <= AR; }); });
    var pick = evNearest(g, (free.length ? free : LK.tru).slice());
    if (mineQ) { pick = mineQ; free = [mineQ]; }
    a.step = (doorFound ? 'tìm được cửa → bỏ quái tới ' : '') + (free.length ? 'trụ ấn còn trống' : 'các trụ đã có người · đứng chờ cạnh') + ' · lối ' + V.tenCong(k);
    vnGo(g, a, pick.x, pick.y, free.length ? 4 : 50);
    return true;
  }
  function tickVetNut(g) {
    var P = g.P, V = P.VetNut;
    if (!V || !P.VetNutUI) return false;
    if (vnIn(g)) {
      if (!cfg.vnRun) return false; // tự vào bằng tay: để người chơi tự đi
      return vnInside(g);
    }
    if (st.vn && st.vn.inside) { var a = st.vn; st.vn = null; vnLog('Ra khỏi Vết Nứt'); if (a.back) goBack(a.back.map, a.back.x, a.back.y, 'Vết Nứt xong → về chỗ farm', 'vn', a.back.khu); return false; }
    if (!cfg.vnRun) { if (st.vn) st.vn = null; return false; }
    if (vnOutside(g)) return true;
    return false;
  }


  /* ================= Bí cảnh: Huyết Xích Cấm Địa · Yên Lãng Sơn ================= */
  // Bí cảnh ở nữ tu Miếu Hoang. Huyết Xích: 3 tầng, quét hết quái mới hái, tầng 3 hạ Cự Mãng. Yên Lãng: Tĩnh thì đứng yên,
  // Đảo Âm thì đi lại; Tuần Vệ → bụi linh thảo → 3 Trấn Sơn Bia → Hộ Vệ → Tộc Trưởng, thắng thì nhặt đồ trước khi núi sụp.
  var BC_NPC = 'nu_tu_mieu_hoang', HX_ORDER = ['rung_mang_xa', 'mach_dat_dong', 'dam_lay_boss'], HX_FEE = 100;
  var BC_ENTER_GAP_MS = 6000, BC_SEEN_R = 150, BC_FIGHT_R = 420, BC_MEMBER_WAIT_MS = 3 * 60000;
  function hxLog(m) { klog('[Huyết Xích] ' + m); say('Huyết Xích: ' + m); }
  function ylLog(m) { klog('[Yên Lãng] ' + m); say('Yên Lãng: ' + m); }
  function bcRealm(P) { return (P.Progress && P.Progress.realmId) || (P.SceneWorld && P.SceneWorld.player && P.SceneWorld.player.realmId) || ''; }
  function bcStones(P) { return P.Progress ? P.Progress.stones | 0 : 0; }
  function bcParty(P) { var pt = P.Gateway && P.Gateway.party; return { n: pt && pt.members ? pt.members.length : 1, run: pt && pt.activeRunId ? String(pt.activeRunId) : '', leader: !pt || !P.Gateway.partyIsLeader || P.Gateway.partyIsLeader() }; }
  function hxUsed(P) {
    var H = P.HuyetSac, f = (P.Quest && P.Quest.flags) || {}, d = H && H.day ? H.day(Date.now()) : '';
    var u = f.huyetSacDay === d ? f.huyetSacCount | 0 : 0, i = st.hxInfo;
    if (i && H && H.day && H.day(i.at) === d) u = Math.max(u, i.used | 0);
    return u;
  }
  function hxLeft(P) { var H = P.HuyetSac; return H && H.luotNgay ? Math.max(0, H.luotNgay(bcRealm(P)) - hxUsed(P)) : 0; }
  function hxTimeLeft() { var i = st.hxInfo; return i && i.endAt ? i.endAt - Date.now() : null; }
  function hxWhyNot(g) {
    var P = g.P, pt = bcParty(P);
    if (!P.HuyetSac || !P.Gateway || !P.Gateway.partyEnterDungeon) return 'bản game này chưa có Huyết Xích';
    if (P.realmReached && !P.realmReached(bcRealm(P), 'luyen_khi_7')) return 'cần Luyện Khí tầng 7';
    if (!hxLeft(P)) return 'hôm nay đã hết lượt';
    if (bcStones(P) < HX_FEE + (cfg.hxKeep | 0)) return 'thiếu Linh Thạch (phí ' + HX_FEE + (cfg.hxKeep > 0 ? ', giữ lại ' + cfg.hxKeep : '') + ')';
    if (pt.n > 1 && !pt.leader) return 'đang trong tổ đội — chỉ đội trưởng mở được (đội trưởng mở thì cả đội ở Miếu Hoang vào cùng)';
    return '';
  }
  function ylLeft(P) { var Y = P.YenLang; return Y && Y.conLuot ? Y.conLuot((P.Quest && P.Quest.flags) || {}, Date.now(), bcRealm(P)) : 0; }
  function ylWhyNot(g) {
    var P = g.P, Y = P.YenLang, pt = bcParty(P), again = /^yl-/.test(pt.run);
    if (!Y || !P.Gateway || !P.Gateway.partyEnterDungeon) return 'bản game này chưa có Yên Lãng Sơn';
    if (Y.canhGioiHopLe && !Y.canhGioiHopLe(bcRealm(P))) return 'chỉ Luyện Khí 7 – Trúc Cơ';
    if (again) return '';
    if (!ylLeft(P)) return 'hôm nay đã hết lượt';
    if (pt.n < (Y.TOI_THIEU || 2)) return 'luật game: cần tổ đội ' + (Y.TOI_THIEU || 2) + '–' + (Y.TOI_DA || 6) + ' người, không vào một mình được';
    if (pt.n > (Y.TOI_DA || 6)) return 'tổ đội quá ' + (Y.TOI_DA || 6) + ' người';
    return '';
  }
  // Máy chủ báo trạng thái lượt Huyết Xích / chiêu Yên Lãng; chặn ra đòn khi núi ra lệnh Tĩnh / Đảo Âm.
  function hookBiCanh(P) {
    var H = P.HuyetSacUI;
    if (H && H.state && !H.state._tt) {
      var hs = H.state;
      H.state = function (n) {
        try { var sn = Number(n && n.serverNow) || Date.now(), ex = Number(n && n.expiresAt) || 0; st.hxInfo = { used: n && n.used | 0, at: Date.now(), endAt: ex ? Date.now() + Math.max(0, ex - sn) : 0 }; } catch (e) { }
        return hs.apply(this, arguments);
      };
      H.state._tt = true;
    }
    var U = P.YenLangUI, Y = P.YenLang;
    if (U && U.onGoi && !U.onGoi._tt && Y) {
      var og = U.onGoi;
      U.onGoi = function (r) {
        try {
          if (r && r.act === 'yl_ma') { var c = Y.MA && Y.MA.CHIEU[r.k]; fxNote(r.pts, (+r.w || (c && c.bao) || 1500) / 1000, +r.r || (c && c.r) || 60, (c && c.ten) || 'Ma chiêu Tộc Trưởng', true); }
          else if (r && r.act === 'yl_chieu') { var c2 = Y.CHIEU_QUAI && Y.CHIEU_QUAI[r.k]; fxNote([{ x: +r.x, y: +r.y }], (+r.w || (c2 && c2.bao) || 1400) / 1000, +r.r || (c2 && c2.r) || 50, (c2 && c2.ten) || 'Chiêu quái', true); }
        } catch (e) { }
        return og.apply(this, arguments);
      };
      U.onGoi._tt = true;
    }
    var PL = P.Player;
    if (PL && !PL._ttYl) {
      PL._ttYl = true;
      ['attack', 'castSpell', 'castThunder'].forEach(function (k) {
        var f = PL[k];
        if (typeof f !== 'function') return;
        PL[k] = function () { if (enabled && (cfg.ylRun || planIs('yl')) && ylPhase(P)) return false; return f.apply(this, arguments); };
      });
    }
  }
  // Lệnh núi đang hiệu lực: 'tinh' (đứng yên, không đánh) · 'dao' (không được đứng yên) · '' (tự do).
  // Tính từ 0,4 giây trước lúc mở cửa sổ tới hết cửa sổ (giờ máy chủ, theo YenLangUI.fxTrangThai).
  function ylPhase(P) {
    var U = P.YenLangUI, Y = P.YenLang, m = P.SceneWorld && P.SceneWorld.map;
    if (!U || !U.fxTrangThai || !Y || !m || !m.data || m.data.id !== Y.MAP) return '';
    var f = U.fxTrangThai(), l = f && f.lenh;
    if (!l || l.gd === 'xong') return '';
    var t = +f.now, on = l.gd === 'mo' || (l.gd === 'bao' && +l.moLuc - t < 400);
    if (!on || t > +l.dongLuc + 250) return '';
    return l.kieu === 'dao' ? 'dao' : 'tinh';
  }
  // Giữ đúng lệnh núi (gọi trước né chiêu: né = di chuyển = Thạch Hóa). true = đang giữ lệnh.
  function ylHold(g) {
    if (!(cfg.ylRun || planIs('yl'))) return false;
    var ph = ylPhase(g.P), me = g.me;
    if (!ph || me.downed) return false;
    g.sw.approach = null; g.sw.tuChiDuong = false;
    if (g.sw.autoOn) setAuto(g, false);
    if (ph === 'tinh') {
      if (me.path && me.path.length) me.path.length = 0;
      if (st.yl) st.yl.step = '⏸ lệnh Tĩnh: đứng yên, không đánh';
      return true;
    }
    // Đảo Âm: đi qua lại liên tục quanh chỗ đang đứng (không ra đòn — vung đòn là đứng lại).
    var a = st.yl || {};
    if (!(me.path && me.path.length)) {
      a.jig = -(a.jig || 1);
      var sc = spotCheck(g), r = null;
      for (var k = 0; k < 6 && !r; k++) { var ang = k * Math.PI / 3 + (a.jig > 0 ? 0 : Math.PI); r = sc.route(me.x + Math.cos(ang) * 70, me.y + Math.sin(ang) * 70); }
      if (r) me.setPath(r.path);
    }
    if (st.yl) st.yl.step = '🏃 lệnh Đảo Âm: chạy, không đứng yên';
    return true;
  }
  // Đánh: tự khoá, tự chém, tung chiêu sát thương cao nhất, giữ cự ly tầm đánh hợp lý
  function bcFight(g, a, t) {
    a.target = t;
    var me = g.me, P = g.P, hz = cfg.dodge ? hazards(g) : [];
    var reach = (P.Player.reach ? P.Player.reach() : 26) + (t.def && t.def.bodyRadius || 20);
    if (hz.length) {
      if (dist(me.x, me.y, t.x, t.y) > reach && inHazard(hz, t.x, t.y)) {
        if (me.path && me.path.length && !st.dodging) me.path.length = 0;
        setAuto(g, false);
        a.step += ' · chờ vòng chiêu nổ';
        return true;
      }
    }
    setAuto(g, true);
    honPin(P, t, me);
    st.farmTarget = t;
    if (me.state === 'sit') P.Player.stand(me);
    var d = dist(me.x, me.y, t.x, t.y);
    huntBurst(g, t, d, reach);
    var isLow = (t.hpMax > 0 && t.hp / t.hpMax <= 0.04) || (t.hp != null && t.hp <= 30000);
    var targetDist = isLow ? 2 : Math.max(16, reach - 6);
    if (d > targetDist) {
      if (!(me.path && me.path.length && now() - a.routeAt < 400)) {
        var sc = spotCheck(g), r = sc.route(t.x, t.y);
        if (r) { me.setPath(r.path); a.routeAt = now(); }
      }
    } else {
      if (me.path && me.path.length && !st.dodging && !st.kiting) me.path.length = 0;
    }
    return true;
  }
  function bcWalk(g, a, x, y, near) {
    var me = g.me;
    if (dist(me.x, me.y, x, y) <= (near || 60)) return false;
    if (!(me.path && me.path.length && now() - a.routeAt < 1500)) {
      var r = spotCheck(g).route(x, y);
      if (r) { setAuto(g, false); moveFighting(g, r.path); a.routeAt = now(); }
      else if (++a.noRoute > 20) { a.noRoute = 0; return false; }
    }
    return true;
  }
  function bcNearestMob(g, R, filter) {
    var me = g.me, best = null;
    mobsAlive(g).forEach(function (m) {
      if (filter && !filter(m)) return;
      var d = dist(me.x, me.y, m.x, m.y);
      if (d <= R && (!best || d < best.d)) best = { m: m, d: d };
    });
    return best && best.m;
  }
  function bcLooting(g) { return !!(st.looting || dropsLeft(g).length || huntDrops(g).length); }
  function bcHarvestLeft(g) { return st.harvest ? 1 : harvestSpots(g).length; }

  /* --- Huyết Xích --- */
  function tickHuyetXich(g) {
    var P = g.P, G = P.Gateway, me = g.me, want = cfg.hxRun || planIs('hx');
    if (HUYET_MAPS[g.mapId]) { if (!want) { st.hx = null; return false; } return hxInside(g); }
    var a = st.hx;
    if (a && a.inside) { // vừa ra khỏi bí cảnh (xong / rời / hết giờ / sụp / gục)
      st.hxRuns = (st.hxRuns || 0) + 1;
      hxLog('Ra khỏi bí cảnh sau ' + Math.round((now() - a.inAt) / 60000) + ' phút · hôm nay còn ' + hxLeft(P) + ' lượt');
      var bk = a.back;
      a = st.hx = null;
      st.hxRest = now() + 4000;
      if (!want || hxWhyNot(g)) { if (bk && (g.mapId !== bk.map || dist(me.x, me.y, bk.x, bk.y) > BACK_NEAR || (bk.khu && gaKhu(g.P) !== bk.khu))) goBack(bk.map, bk.x, bk.y, 'Huyết Xích xong → về chỗ farm', 'hx', bk.khu); return false; }
      st.hx = a = evNew(); a.back = bk;
    }
    if (!want || !G || !G.connected) { if (a) st.hx = null; return false; }
    if (now() < (st.hxRest || 0) || me.downed || vtBusy(g)) return a ? true : false;
    var why = hxWhyNot(g);
    if (why) {
      if (a) return evEnd(g, 'hx', 'Thôi vào: ' + why, 'Huyết Xích');
      if (st.hxWhy !== why) { st.hxWhy = why; hxLog('Chưa vào: ' + why); }
      return false;
    }
    st.hxWhy = '';
    if (!a) { a = st.hx = evNew(); evTakeOver(g, a); hxLog('Còn ' + hxLeft(P) + ' lượt hôm nay → tới nữ tu Miếu Hoang đăng ký (phí ' + HX_FEE + ' Linh Thạch)'); }
    if (!a.back) evTakeOver(g, a);
    var w = atNpc(g, a, BC_NPC, hxLog);
    if (w === 'fail') { st.hxRest = now() + 10 * 60000; return evEnd(g, 'hx', 'Không tới được nữ tu Miếu Hoang → nghỉ 10 phút', 'Huyết Xích'); }
    if (w !== 'here') { a.step = 'đi tới nữ tu Miếu Hoang'; return true; }
    setAuto(g, false);
    if (P.HUD && P.HUD.dialogOpen && P.HUD.closeDialog) P.HUD.closeDialog();
    if (now() - a.sentAt < BC_ENTER_GAP_MS) { a.step = 'chờ vào Huyết Xích'; return true; }
    if (++a.tries > 4) { st.hxRest = now() + 10 * 60000; return evEnd(g, 'hx', 'Mở Huyết Xích 4 lần không được → nghỉ 10 phút', 'Huyết Xích'); }
    a.sentAt = now();
    a.step = 'mở Huyết Xích (lần ' + a.tries + ')';
    if (G.partySend) G.partySend('huyet_status');
    G.partyEnterDungeon(HX_ORDER[0]);
    hxLog('Mở Huyết Xích Cấm Địa' + (bcParty(P).n > 1 ? ' cho cả đội' : ' (một mình)'));
    return true;
  }
  function hxInside(g) {
    var P = g.P, G = P.Gateway, me = g.me, md = g.sw.map.data, mid = g.mapId, T = P.CONFIG.TILE || 32;
    var a = st.hx || (st.hx = evNew());
    if (!a.inside) { a.inside = true; a.inAt = now(); a.seen = {}; a.boss = {}; hxLog('Vào ' + mapName(mid)); }
    if (a.lastMap !== mid) { a.lastMap = mid; a.mapAt = now(); if (st.travel && st.travel.map === mid) stopTravel(); }
    if (me.downed) { a.step = 'gục · chờ hồi sinh'; return false; }
    var tl = hxTimeLeft(), tTxt = tl != null ? ' · còn ' + fmtSec(Math.max(0, tl / 1000)) : '';
    // 1) Quái trong tầm: đánh. Nếu quanh người có quái con áp sát dồn sát thương: ưu tiên dọn quái con trước
    var adds = mobsAlive(g).filter(function (m) {
      return !m.dead && !isBoss(m) && m.def && m.def.contactDmg > 0 && dist(me.x, me.y, m.x, m.y) <= 260;
    });
    var t = (adds.length ? bcNearestMob(g, 260, function (m) { return !isBoss(m); }) : null) || bcNearestMob(g, BC_FIGHT_R);
    if (t) {
      if (isBoss(t)) a.boss[mid] = 'seen';
      a.step = 'đánh ' + mobLabel(t) + ' ' + evPct(t) + tTxt;
      return bcFight(g, a, t);
    }
    // 2) Đồ rơi (boss văng đồ ra đất): để phần nhặt đồ lo.
    if (bcLooting(g)) { a.step = 'nhặt đồ rơi' + tTxt; return false; }
    // 3) Dò hết các điểm quái của tầng này (máy chủ chỉ gửi quái ở gần).
    var seen = a.seen[mid] || (a.seen[mid] = {});
    var pts = (md.enemies || []).map(function (e) { return { id: e.id, x: (e.tx + 0.5) * T, y: (e.ty + 0.5) * T }; });
    pts.forEach(function (q) { if (dist(me.x, me.y, q.x, q.y) <= BC_SEEN_R) seen[q.id] = 1; });
    var rest = pts.filter(function (q) { return !seen[q.id]; });
    var lowTime = tl != null && tl < 60000;
    if (rest.length && !lowTime) {
      var q0 = evNearest(g, rest);
      a.step = 'dò quái ' + mapName(mid) + ' (' + (pts.length - rest.length) + '/' + pts.length + ')' + tTxt;
      if (!bcWalk(g, a, q0.x, q0.y, BC_SEEN_R - 30)) seen[q0.id] = 1;
      return true;
    }
    if (mid === HX_ORDER[2] && !a.boss.done) { a.boss.done = true; hxLog('Đầm Lầy sạch quái → hái Trúc Cơ Thảo'); }
    // 4) Tài nguyên: để tickHarvest hái (đứng yên 3 giây mỗi chỗ).
    var hl = bcHarvestLeft(g);
    if (hl) { a.step = 'hái tài nguyên ' + mapName(mid) + ' (còn ' + hl + ' chỗ)' + tTxt; return false; }
    // 5) Sang tầng kế.
    var i = HX_ORDER.indexOf(mid);
    if (i >= 0 && i < HX_ORDER.length - 1 && !lowTime) {
      var nx = HX_ORDER[i + 1];
      if (a.nextLog !== nx) { a.nextLog = nx; hxLog(mapName(mid) + ' xong → sang ' + mapName(nx)); }
      a.step = 'sang ' + mapName(nx) + tTxt;
      return jobGo(g, a, nx, 'Huyết Xích: sang ' + mapName(nx), hxLog) || true;
    }
    // 6) Xong 3 tầng: rời để đi lượt kế.
    if (cfg.hxLeave && G.partySend && now() - (a.leftAt || 0) > 8000) { a.leftAt = now(); hxLog('Xong 3 tầng → rời bí cảnh'); G.partySend('leave_dungeon'); }
    a.step = 'xong lượt' + (cfg.hxLeave ? ' · đang rời' : ' · chờ hết giờ') + tTxt;
    setAuto(g, false);
    return true;
  }

  /* --- Yên Lãng Sơn --- */
  function tickYenLang(g) {
    var P = g.P, G = P.Gateway, Y = P.YenLang, me = g.me, want = cfg.ylRun || planIs('yl');
    if (Y && g.mapId === Y.MAP) { if (!want) { st.yl = null; return false; } return ylInside(g); }
    var a = st.yl;
    if (a && a.inside) {
      ylLog('Ra khỏi núi · hôm nay còn ' + ylLeft(P) + ' lượt');
      var bk = a.back;
      a = st.yl = null;
      st.ylRest = now() + 4000;
      if (!want || ylWhyNot(g)) { if (bk && (g.mapId !== bk.map || dist(me.x, me.y, bk.x, bk.y) > BACK_NEAR || (bk.khu && gaKhu(g.P) !== bk.khu))) goBack(bk.map, bk.x, bk.y, 'Yên Lãng xong → về chỗ farm', 'yl', bk.khu); return false; }
      st.yl = a = evNew(); a.back = bk;
    }
    if (!want || !Y || !G || !G.connected) { if (a) st.yl = null; return false; }
    if (now() < (st.ylRest || 0) || me.downed || vtBusy(g)) return a ? true : false;
    var why = ylWhyNot(g);
    if (why) {
      if (a) return evEnd(g, 'yl', 'Thôi vào: ' + why, 'Yên Lãng');
      if (st.ylWhy !== why) { st.ylWhy = why; ylLog('Chưa vào: ' + why); }
      return false;
    }
    st.ylWhy = '';
    var pt = bcParty(P), again = /^yl-/.test(pt.run);
    if (!a) { a = st.yl = evNew(); evTakeOver(g, a); ylLog(again ? 'Lượt của đội đang mở → vào lại' : pt.leader ? 'Còn ' + ylLeft(P) + ' lượt → tới nữ tu Miếu Hoang đăng ký cho cả đội' : 'Tới Miếu Hoang chờ đội trưởng đăng ký'); }
    if (!a.back) evTakeOver(g, a);
    var w = atNpc(g, a, BC_NPC, ylLog);
    if (w === 'fail') { st.ylRest = now() + 10 * 60000; return evEnd(g, 'yl', 'Không tới được nữ tu Miếu Hoang → nghỉ 10 phút', 'Yên Lãng'); }
    if (w !== 'here') { a.step = 'đi tới nữ tu Miếu Hoang'; return true; }
    setAuto(g, false);
    if (P.HUD && P.HUD.dialogOpen && P.HUD.closeDialog) P.HUD.closeDialog();
    // Thành viên: đội trưởng đăng ký thì ai đang ở Miếu Hoang được đưa vào cùng → đứng chờ (có hạn).
    if (!again && !pt.leader) {
      if (!a.waitAt) a.waitAt = now();
      if (now() - a.waitAt > BC_MEMBER_WAIT_MS) { st.ylRest = now() + 10 * 60000; return evEnd(g, 'yl', 'Chờ đội trưởng ' + Math.round(BC_MEMBER_WAIT_MS / 60000) + ' phút chưa thấy mở → nghỉ 10 phút', 'Yên Lãng'); }
      a.step = 'đứng cạnh nữ tu chờ đội trưởng mở Yên Lãng (' + fmtSec((BC_MEMBER_WAIT_MS - (now() - a.waitAt)) / 1000) + ')';
      return true;
    }
    if (now() - a.sentAt < BC_ENTER_GAP_MS) { a.step = 'chờ vào Yên Lãng Sơn'; return true; }
    if (++a.tries > 4) { st.ylRest = now() + 10 * 60000; return evEnd(g, 'yl', 'Mở Yên Lãng 4 lần không được → nghỉ 10 phút', 'Yên Lãng'); }
    a.sentAt = now();
    a.step = (again ? 'vào lại' : 'mở') + ' Yên Lãng Sơn (lần ' + a.tries + ')';
    G.partyEnterDungeon(Y.MAP);
    ylLog(again ? 'Vào lại Yên Lãng Sơn' : 'Mở Yên Lãng Sơn cho cả đội (' + pt.n + ' người)');
    return true;
  }
  function ylInside(g) {
    var P = g.P, G = P.Gateway, Y = P.YenLang, U = P.YenLangUI, me = g.me, md = g.sw.map.data, T = P.CONFIG.TILE || 32;
    var Q = (md && md.yenLangQuai) || {}, S = U && U.st, QT = Y.QUAI || {};
    var a = st.yl || (st.yl = evNew());
    if (!a.inside) { a.inside = true; a.inAt = now(); a.seen = {}; ylLog('Vào Yên Lãng Sơn'); }
    if (st.travel) stopTravel();
    if (me.downed) { a.step = 'gục · chờ hồi sinh'; return false; }
    if (ylHold(g)) return true;
    if (!S) { a.step = 'chờ dữ liệu bí cảnh'; setAuto(g, false); return true; }
    var px = function (q) { return { id: q.id, type: q.type, x: (q.tx + 0.5) * T, y: (q.ty + 0.5) * T }; };
    var tl = (S.supLuc || S.hetLuc || 0) - (U.fxTrangThai ? U.fxTrangThai().now : Date.now()), tTxt = tl > 0 ? ' · còn ' + fmtSec(tl / 1000) : '';
    if (S.ketQua === 'thua') { a.step = 'núi đã khép · chờ ra'; setAuto(g, false); return true; }
    if (S.ketQua === 'thang') {
      if (!a.winAt) { a.winAt = now(); ylLog('Tộc Trưởng đã gục → nhặt đồ quanh xác trước khi núi sụp'); }
      if (bcLooting(g)) { a.step = 'nhặt đồ quanh xác Tộc Trưởng' + tTxt; return false; }
      if (now() - a.winAt > 8000 && G.partySend && !a.leftAt) { a.leftAt = now(); ylLog('Nhặt xong → rời núi'); G.partySend('leave_dungeon'); }
      a.step = 'thắng · ' + (a.leftAt ? 'đang rời' : 'chờ đồ rơi') + tTxt;
      return true;
    }
    if (S.gd === 'tap_hop') { a.step = 'tập hợp ở chân núi' + tTxt; setAuto(g, false); if (me.path && me.path.length) me.path.length = 0; return true; }
    var biaLeft = (S.bia || []).filter(function (b) { return !b.vo; }).length;
    var isT = function (ty) { return function (m) { return m.type === ty; }; };
    var t = null, why = '';
    // 1) Quái đang áp sát (tộc binh, thi khối…) — trừ khi đó là bia (bia đứng yên, chỉ đánh khi tới lượt).
    t = bcNearestMob(g, 200, function (m) { return m.type !== QT.BIA && m.type !== QT.TOC_TRUONG && !(m.def && m.def.truBan); });
    if (t) why = 'dọn đường';
    // 2) Chưa mở linh thảo: hạ 2 Tuần Vệ.
    if (!t && !S.linhThaoMo) { t = bcNearestMob(g, BC_FIGHT_R + 200, isT(QT.TUAN_VE)); if (t) why = 'Tuần Vệ (mở phong ấn linh thảo)'; }
    // 3) Linh thảo đã mở: hái (mỗi người mỗi bụi một lần).
    if (!t && S.linhThaoMo && bcHarvestLeft(g)) { a.step = 'hái linh thảo' + tTxt; return false; }
    // 4) Trấn Sơn Bia còn đứng: đổ hết (Tộc Trưởng mất hộ thể).
    if (!t && S.linhThaoMo && biaLeft) { t = bcNearestMob(g, BC_FIGHT_R + 200, isT(QT.BIA)); if (t) why = 'Trấn Sơn Bia (còn ' + biaLeft + ')'; }
    // 5) Tộc Trưởng đã tỉnh: Hộ Vệ trước rồi Tộc Trưởng (bia còn thì bia trước — hắn đang được hộ thể).
    if (!t && S.boss && !biaLeft) {
      t = bcNearestMob(g, 600, isT(QT.HO_VE)) || bcNearestMob(g, 700, isT(QT.TOC_TRUONG));
      if (t) why = t.type === QT.HO_VE ? 'Hộ Vệ' : 'Tộc Trưởng ' + evPct(t);
    }
    if (t) { a.step = 'đánh ' + mobLabel(t) + ' · ' + why + tTxt; return bcFight(g, a, t); }
    if (bcLooting(g)) { a.step = 'nhặt đồ' + tTxt; return false; }
    // Không thấy mục tiêu: đi tới chỗ của việc kế tiếp.
    var goal = null, seen = a.seen;
    if (!S.linhThaoMo) {
      var tv = (Q.son_dao || []).filter(function (q) { return q.type === QT.TUAN_VE && !seen[q.id]; }).map(px);
      goal = evNearest(g, tv); why = 'tìm Tuần Vệ';
      if (!goal) { seen = a.seen = {}; why = 'dò lại Sơn Đạo'; goal = evNearest(g, (Q.son_dao || []).map(px)); }
    } else if (biaLeft) {
      goal = evNearest(g, (Q.bia || []).filter(function (q) { return !seen[q.id]; }).map(px)); why = 'tới Trấn Sơn Bia';
      if (!goal) { a.seen = {}; goal = evNearest(g, (Q.bia || []).map(px)); }
    } else {
      // Bia đổ hết: tới trước Tế Đàn (ngoài tầm Hộ Vệ) chờ Tộc Trưởng tỉnh.
      var tt = (Q.toc_truong || [])[0];
      goal = tt ? { id: 'te', x: (tt.tx + 0.5) * T, y: (tt.ty + 5.5) * T } : null;
      why = S.boss ? 'tới Tế Đàn đánh Tộc Trưởng' : 'chờ Tộc Trưởng tỉnh ở Tế Đàn';
    }
    if (!goal) { a.step = 'chờ' + tTxt; setAuto(g, false); return true; }
    a.step = why + tTxt;
    if (!bcWalk(g, a, goal.x, goal.y, goal.id === 'te' ? 40 : BC_SEEN_R - 30)) { if (goal.id !== 'te') a.seen[goal.id] = 1; else if (me.path && me.path.length) me.path.length = 0; }
    return true;
  }

  /* --- Sỹ Sách Điện (Hư Thiên) --- */
  function htNow(P) { var U = P.HuThienUI; return U && U.gio ? U.gio() : Date.now(); }
  function htGo(g, a, mapId) {
    if (!st.travel || st.travel.map !== mapId) startTravel(mapId, null, null, 'Sỹ Sách Điện: sang ' + mapName(mapId));
    tickTravel(g);
    return true;
  }
  // Không thấy quái cần đánh: đi lần lượt các điểm (chỗ Thủ Vệ / trụ đứng).
  function htPatrol(g, a, pts) {
    if (!pts.length) return false;
    var p = pts[a.pi % pts.length];
    if (!evWalk(g, a, p.tx, p.ty, 80)) a.pi++;
    return true;
  }
  // Hành lang sau hàng rào Ải 2 luôn đốt máu, bay qua được.
  function htFly(g) {
    var P = g.P, HT = P.HuThien, me = g.me, PL = P.Player;
    if (me.flying || !HT.trongHanhLang || !HT.trongHanhLang(g.sw.map.data, me.x, me.y)) return;
    if ((PL.canFly && !PL.canFly(me)) || now() - st.lastFlyPress < FLY_RETRY_MS) return;
    st.lastFlyPress = now();
    P.Input.pressFlyToggle();
  }
  // Tự động dựng trận bàn sát thương / khống chế tạo vùng bảo vệ trong Sỹ Sách Điện
  function htDropTran(g) {
    if (!cfg.autoTran) return false;
    var P = g.P, F = P.Formations, me = g.me;
    if (!F || !F.DEFS) return false;
    for (var i = 0; i < TRAN_DMG.length; i++) {
      var def = F.DEFS[TRAN_DMG[i]];
      if (def && tranOwned(P, def) && tranBegin(g, def, { x: me.x, y: me.y })) {
        klog('[Sỹ Sách Điện] Dựng ' + (def.name || def.id) + ' tạo vùng khống chế / bảo vệ');
        return true;
      }
    }
    return false;
  }
  // Danh sách người chơi thù địch từ tông môn khác ở các ải PK (Ải 3, Ải 4)
  function htFoes(g, data) {
    var G = g.P.Gateway, U = g.P.HuThienUI, HT = g.P.HuThien;
    if (!G || !G.remotes) return [];
    return Object.keys(G.remotes).map(function (id) { return G.remotes[id]; }).filter(function (r) {
      return r && !r.downed && isFinite(r.x) && !(U && U.khongDich && U.khongDich(r.id, r)) && !(G.partyMember && r.id != null && G.partyMember(r.id)) && (!data || !HT.trongSanh(data, r.x, r.y));
    });
  }
  function tickHuThien(g) {
    var P = g.P, HT = P.HuThien, U = P.HuThienUI, G = P.Gateway, me = g.me;
    if (!cfg.htRun || !HT || !HT.kyTai || !U || !G || !G.connected || !G.cmd) { st.ht = null; return false; }
    var t0 = htNow(P), ky = HT.kyTai(t0), gd = HT.giaiDoan(t0, ky), open = gd === 'MO' && HT.conNhanDoi(t0, ky);
    if (!HT.laMap(g.mapId)) {
      // Đã ra khỏi điện (hết giờ, Ải 1 đóng, Đỉnh ngã rồi bị đưa ra…): xong kỳ này, không vào lại.
      if (st.ht && st.ht.inside) { st.htSkip = ky.id; return evEnd(g, 'ht', 'Đã ra khỏi Sỹ Sách Điện', 'Sỹ Sách Điện'); }
      if (!(gd === 'BAO' || open) || st.htSkip === ky.id || me.downed || vtBusy(g)) {
        if (st.ht && !st.ht.inside) return evEnd(g, 'ht', gd === 'MO' || gd === 'XONG' ? 'Đã qua giờ vào điện' : '', 'Sỹ Sách Điện');
        return false;
      }
      var a0 = st.ht || (st.ht = evNew());
      if (!a0.back) { evTakeOver(g, a0); evLog('Sỹ Sách Điện', (gd === 'BAO' ? 'Sắp mở (' + HT.gioDoc(ky.batDauLuc) + ')' : 'Đang mở') + ' → tới Thủ Điện ở ' + mapName(HT.NPC_MAP)); }
      var w = atNpc(g, a0, HT.NPC, function (m) { evLog('Sỹ Sách Điện', m); });
      if (w === 'fail') { st.htSkip = ky.id; return evEnd(g, 'ht', 'Không tới được Thủ Điện → bỏ kỳ này', 'Sỹ Sách Điện'); }
      if (w !== 'here') { a0.step = 'đi tới Thủ Điện Sỹ Sách (' + mapName(HT.NPC_MAP) + ')'; return true; }
      setAuto(g, false);
      if (gd === 'BAO') { a0.step = 'chờ mở cửa lúc ' + HT.gioDoc(ky.batDauLuc); return true; }
      if (now() - a0.sentAt < EV_VAO_GAP_MS) return true;
      if (++a0.tries > 6) { st.htSkip = ky.id; return evEnd(g, 'ht', 'Vào điện 6 lần không được → bỏ kỳ này', 'Sỹ Sách Điện'); }
      a0.sentAt = now();
      a0.step = 'vào điện';
      G.cmd('huthien.vao', {}, function (res) {
        if (res && res.ht) U.ngoai = res.ht;
        if (res && res.ok) { evLog('Sỹ Sách Điện', 'Đã vào điện'); return; }
        var why = res && res.why || 'không rõ';
        evLog('Sỹ Sách Điện', 'Chưa vào được: ' + why);
        // Không đủ tư cách (chưa có tông, tông không có tên trong bảng, thiếu cảnh giới…) thì bỏ cả kỳ.
        if (/tông|tư cách|cảnh giới|tên trong bảng|đủ 20|đã đóng|qua giờ|chưa có/i.test(why)) st.htSkip = ky.id;
      });
      return true;
    }
    var a = st.ht || (st.ht = evNew());
    a.inside = true;
    if (me.downed) { a.step = 'gục · chờ hồi sinh ở Cổng Ngoại Điện'; return false; }
    var S = U.st || {}, ai = HT.ai(g.mapId), doi = S.doi || {}, toi = S.toi || {}, data = g.sw.map.data || {}, mobs = mobsAlive(g);

    // 1. Chống lặp vòng chết (Anti-Death Loop): Vừa hồi sinh ở Sảnh an toàn thì thiền hồi phục đầy máu/LL
    var inSafe = HT.trongSanh(data, me.x, me.y);
    var hpPct = me.hpMax ? me.hp / me.hpMax : 1;
    var mpPct = me.mpMax ? (me.mp || 0) / me.mpMax : 1;
    if (inSafe || me.state === 'sit' || st.healing) {
      if (hpPct < 0.88 || mpPct < 0.65) {
        a.step = 'vùng an toàn · thiền hồi phục (' + Math.round(hpPct * 100) + '% HP)';
        if (st.travel) stopTravel();
        if (me.path && me.path.length) me.path.length = 0;
        setAuto(g, false);
        if (me.state !== 'sit' && P.Player && P.Player.sit) P.Player.sit(true);
        if (now() - (st.htHealEatAt || 0) > 3000) { st.htHealEatAt = now(); tickEat(g); }
        return true;
      }
      if (me.state === 'sit' && P.Player && P.Player.stand) P.Player.stand();
    }

    // 2. Ải 1 · Dược Viên (PvE: Thu thập Ngọc Phù mở cửa)
    if (ai === 1) {
      if (doi.moAi1) { a.step = 'cửa Ải 1 đã mở → sang Ải 2'; return htGo(g, a, HT.MAP_2); }
      var myPhu = toi.ngocPhu | 0, canPhu = doi.can || HT.CAN_NGOC_PHU, tongPhu = doi.ngocPhu | 0;
      a.step = 'Ngọc Phù tông ' + tongPhu + '/' + canPhu + ' · bạn mang ' + myPhu + '/' + (HT.NGOC_PHU_TOI_DA || 3);
      // Ưu tiên nhặt Ngọc Phù rơi trên đất nếu cá nhân chưa đủ 3 viên
      if (myPhu < (HT.NGOC_PHU_TOI_DA || 3)) {
        var phuDrops = (g.sw.drops || []).filter(function (r) {
          return r && r.state === 'ground' && r.itemId === HT.NGOC_PHU && !(r.htBo > Date.now());
        });
        if (phuDrops.length) {
          var nearestPhu = evNearest(g, phuDrops), dPhu = dist(me.x, me.y, nearestPhu.x, nearestPhu.y);
          if (dPhu > 30) {
            a.step = 'lao tới nhặt Sỹ Sách Ngọc Phù (' + Math.round(dPhu) + 'px)';
            var pPhu = spotCheck(g).route(nearestPhu.x, nearestPhu.y);
            if (pPhu) moveFighting(g, pPhu.path);
            else moveFighting(g, [{ x: nearestPhu.x, y: nearestPhu.y }]);
            return true;
          }
          spamPick(g, nearestPhu);
          return true;
        }
      }
      var foes = mobs.filter(function (m) { return (m.type === 'htd_thu_ve' || m.type === 'htd_tieu_ve') && !HT.trongSanh(data, m.x, m.y); });
      var t1 = evNearest(g, foes);
      if (t1) { a.step += ' · hạ ' + mobLabel(t1); return evEngage(g, a, t1); }
      return htPatrol(g, a, data.htThuVe || []);
    }

    // 3. Ải 2 · Băng Hỏa Trận (PvE: Phá Trụ Băng / Hoả, mở rào)
    if (ai === 2) {
      var ai2 = S.ai2 || {};
      if (cfg.htMatThat && ai2.xoay && ai2.xoay.den > t0) { a.step = 'vào vòng xoáy tím → Mật Thất'; evWalk(g, a, ai2.xoay.tx, ai2.xoay.ty, 10); return true; }
      if (ai2.rao) { a.step = 'hàng rào đã mở → bay qua hành lang sang Ải 3'; htFly(g); return htGo(g, a, HT.MAP_3); }
      var towers = mobs.filter(isTower);
      if (towers.length) {
        // Focus fire: Ưu tiên trụ nào máu thấp hơn để sập nhanh từng trụ
        towers.sort(function (t1, t2) { return (t1.hp || 0) - (t2.hp || 0); });
        var targetTower = towers[0];
        var guards = mobs.filter(function (m) { return m.def && m.def.contactDmg > 0 && dist(m.x, m.y, targetTower.x, targetTower.y) <= LL_TOWER_GUARD_R; });
        if (guards.length) {
          a.step = 'hạ ' + guards.length + ' Trận Nhãn Vệ quanh ' + mobLabel(targetTower);
          return evEngage(g, a, evNearest(g, guards));
        }
        a.step = 'dồn sát thương ' + mobLabel(targetTower) + ' ' + evPct(targetTower);
        if (cfg.autoShield && me.hpMax && (me.hp / me.hpMax < 0.70)) {
          if (!talUse(g, 'kim_long', 'Ải 2 Hư Thiên: khiên chống đòn trụ Băng/Hỏa')) talUse(g, 'kim_giap', 'Ải 2 Hư Thiên: khiên chống đòn trụ Băng/Hỏa');
        }
        return evEngage(g, a, targetTower);
      }
      a.step = 'tìm Trụ Băng / Trụ Hoả';
      return htPatrol(g, a, data.htTranNhan || []);
    }

    // 4. Ải 3 · Nội Điện & Ải 4 · Mật Thất (PK Tông Môn tự do & Sỹ Sách Đỉnh / Lôi Thú)
    if (ai === 3 || ai === 4) {
      var type = ai === 3 ? HT.LOAI_DINH : 'htd_loi_thu', boss = mobs.filter(function (m) { return m.type === type; })[0];
      var spot = ai === 3 ? data.htDinh : data.htLoiThu, dinh = S.dinh || {};
      var dinhDead = (ai === 3 && (dinh.da || (boss && boss.dead)));

      // 4.1. Khi Sỹ Sách Đỉnh đã ngã: Quét, bảo kê và tranh cướp bảo vật đỉnh
      if (dinhDead) {
        a.step = 'Sỹ Sách Đỉnh đã ngã · quét & tranh bảo vật đỉnh';
        var drops = (g.sw.drops || []).filter(function (r) {
          return r && r.state === 'ground' && !r.granted && !(r.htBo > Date.now()) && !(lootSkip[r.lootId] > now());
        });
        if (drops.length) {
          drops.sort(function (d1, d2) {
            var s1 = (d1.kind === 'item') ? gradeScore(g.P, d1.itemId) : 100;
            var s2 = (d2.kind === 'item') ? gradeScore(g.P, d2.itemId) : 100;
            return (s2 - s1) || (dist(me.x, me.y, d1.x, d1.y) - dist(me.x, me.y, d2.x, d2.y));
          });
          var topDrop = drops[0], d = dist(me.x, me.y, topDrop.x, topDrop.y);
          if (d > 60 && cfg.autoHaste) {
            talUse(g, 'toc_hanh', 'tranh bảo vật Sỹ Sách Đỉnh');
          }
          if (d > 35) {
            a.step = 'lao tới nhặt ' + dropName(g, topDrop) + ' (' + Math.round(d) + 'px)';
            var p = spotCheck(g).route(topDrop.x, topDrop.y);
            if (p) moveFighting(g, p.path);
            else moveFighting(g, [{ x: topDrop.x, y: topDrop.y }]);
            return true;
          }
          // Bảo kê an toàn tuyệt đối khi đứng vận bảo vật cực hiếm: Bật khiên + Dựng trận bàn
          if (channelDrop(topDrop)) {
            if (me.path && me.path.length) me.path.length = 0;
            if (!talUse(g, 'kim_long', 'bảo vệ vận bảo vật Sỹ Sách Đỉnh')) talUse(g, 'kim_giap', 'bảo vệ vận bảo vật Sỹ Sách Đỉnh');
            htDropTran(g);
            a.step = 'đứng yên vận ' + dropName(g, topDrop);
            return true;
          }
          spamPick(g, topDrop);
          return true;
        }
        return false;
      }

      // 4.2. PK Tông Môn tự vệ ở Ải 3/4 (Chiến trường PK tự do)
      var rivals = htFoes(g, data);
      var underAttack = ctHurt(g);
      var closeRivals = rivals.filter(function (r) { return dist(me.x, me.y, r.x, r.y) <= 240; });
      if (rivals.length && (closeRivals.length > 0 || underAttack)) {
        if (cfg.autoShield && me.hpMax && (me.hp / me.hpMax < 0.85)) {
          if (!talUse(g, 'kim_long', 'PK Sỹ Sách Điện: khiên tự vệ')) talUse(g, 'kim_giap', 'PK Sỹ Sách Điện: khiên tự vệ');
        }
        htDropTran(g);
        // Ưu tiên dồn sát thương kẻ địch yếu máu nhất hoặc kẻ địch sát bên
        var pkTarget = (closeRivals.length ? closeRivals : rivals).sort(function (p, q) {
          var hpP = p.hp != null ? p.hp : 1, hpQ = q.hp != null ? q.hp : 1;
          return hpP - hpQ || dist(me.x, me.y, p.x, p.y) - dist(me.x, me.y, q.x, q.y);
        })[0];
        if (pkTarget) {
          a.step = 'PK tông môn: diệt ' + (pkTarget.name || 'kẻ địch') + (pkTarget.hp != null && pkTarget.hp <= 1 ? ' (' + Math.round(pkTarget.hp * 100) + '%)' : '');
          setAuto(g, true);
          ctPinPlayer(P, pkTarget);
          evPin(g, pkTarget);
          var dFoe = dist(me.x, me.y, pkTarget.x, pkTarget.y);
          if (dFoe <= 260) huntBurst(g, pkTarget, dFoe, 60);
          ctMoveTo(g, a, pkTarget.x, pkTarget.y, 60);
          return true;
        }
      }

      // 4.3. Tấn công Boss Sỹ Sách Đỉnh / Lôi Thú
      if (boss) {
        var bHpPct = boss.hpMax > 0 ? (boss.hp / boss.hpMax) : 1;
        var dToBoss = dist(me.x, me.y, boss.x, boss.y);
        // Né đòn Phun Lửa xanh tím (fireNova) khi Đỉnh < 22% máu
        if (ai === 3 && bHpPct <= 0.22 && dToBoss < 185) {
          if (me.hpMax && (me.hp / me.hpMax < 0.70)) {
            if (!talUse(g, 'kim_long', 'Sỹ Sách Đỉnh phun lửa Nova')) talUse(g, 'kim_giap', 'Sỹ Sách Đỉnh phun lửa Nova');
          }
        }
        a.step = 'đánh ' + mobLabel(boss) + ' ' + evPct(boss);
        return evEngage(g, a, boss);
      }

      a.step = ai === 3 ? 'tới tế đàn chờ Sỹ Sách Đỉnh' : 'tìm Lôi Thú';
      return spot ? evWalk(g, a, spot.tx, spot.ty, 150) : false;
    }
    return false;
  }

  /* ================= Ăn ================= */
  function tickEat(g) {
    if (!cfg.autoEat || now() - st.lastEat < 3000) return;
    var P = g.P, F = P.Food, inv = P.Inventory;
    if (!F || !inv || !inv.bag) return;
    if (F.list(P).length) return; // đang no
    st.lastEat = now();
    var best = null, bestPow = -1;
    for (var id in inv.bag) {
      if (!(inv.bag[id] > 0)) continue;
      var def = F.defOf(id, P);
      if (!def) continue;
      var pow = F.power(def);
      if (pow > bestPow) { best = id; bestPow = pow; }
    }
    if (!best) return;
    var r = F.eat(best, P);
    say(r && r.ok ? 'Đã ăn ' + (P.ITEMS[best] && P.ITEMS[best].name || best) : 'Không ăn được: ' + (r && r.why));
  }

  /* ================= Dev (Hoạt động cả khi online) ================= */
  function tickDev() {
    var g = game();
    if (!g) return;
    var p = g.me;
    if (!p) return;
    if (dev.baseSpeed === null) dev.baseSpeed = p.speed || (g.P.CONFIG && g.P.CONFIG.PLAYER && g.P.CONFIG.PLAYER.SPEED) || 68;
    var mult = (cfg && cfg.speed125 === false) ? 1.0 : (dev.mult || 1.25);
    var want = dev.baseSpeed * mult;
    if (Math.abs(p.speed - want) > 0.01) p.speed = want;
  }

  function devSpeed(m) {
    dev.mult = m;
    say('Tốc độ x' + m);
  }

  /* ================= Ưu tiên boss / hoạt động ================= */
  // Tới giờ boss (đang đi / đánh boss thế giới) hoặc đang tham gia hoạt động (Lãm Làng, Sỹ Sách Điện, Tam Lộ): gác …
  var PRIO_SET = {
    boss: {
      bossFocus: true, bossMaxDmg: true, bossNoSit: true, bossBurst: true, autoTran: true, lastHitBoss: true, lastHitDouble: true, lastHitScan: true, autoHpMargin: true, dodge: true,
      autoRevive: true, reviveMode: 'spot', autoEat: true, autoLoot: true, keepAuto: true, alwaysRun: true, autoMpTal: true,
      autoDash: true, autoShield: true, autoKhoiLoi: true, kite: false, healSit: false, farmKhu: false, stayFarm: false
    },
    ev: {
      bossBurst: true, dodge: true, autoEat: true, autoLoot: true, keepAuto: true, alwaysRun: true, autoMpTal: true, autoDash: true, autoShield: true,
      autoKhoiLoi: true, lastHitScan: true, farmKhu: false, stayFarm: false
    },
    // Cướp / kéo xe: phải còn sống và đánh liên tục cả 30 giây cuối mới nhận được xe → né, ăn thuốc, khiên, gượng dậy tại chỗ;
    // tắt đánh-lùi / ngồi thiền / đi nhặt đồ (đều làm ngắt nhịp đánh xe, rời khỏi vùng 400px nhận xe).
    ct: {
      dodge: true, autoEat: true, autoShield: true, autoMpTal: true, autoDash: true, autoKhoiLoi: true, autoRevive: true, reviveMode: 'spot', alwaysRun: true,
      kite: false, healSit: false, autoLoot: false, farmKhu: false, stayFarm: false
    }
  };
  var PRIO_NAME = { boss: 'Boss thế giới', ev: 'Hoạt động', ct: 'Cướp tiêu' };
  function prioRestore() {
    if (!prioSaved) return;
    Object.keys(prioSaved).forEach(function (k) { cfg[k] = prioSaved[k]; });
    klog('[Ưu tiên] Xong ' + PRIO_NAME[prioMode] + ' → trả lại cài đặt như cũ');
    prioSaved = null; prioMode = '';
    if (ui.root) syncInputs();
  }
  function prioApply(mode) {
    if (!cfg.prioOpt && !prioSaved) mode = '';
    if (prioMode === mode) return;
    prioRestore();
    if (!mode || !cfg.prioOpt) return;
    var set = PRIO_SET[mode], on = [];
    prioSaved = {}; prioMode = mode;
    Object.keys(set).forEach(function (k) { prioSaved[k] = cfg[k]; if (cfg[k] !== set[k]) { cfg[k] = set[k]; on.push(k); } });
    klog('[Ưu tiên] ' + PRIO_NAME[mode] + ': gác việc khác' + (on.length ? ', tạm bật cài đặt tối ưu (' + on.join(', ') + ')' : ''));
    if (ui.root) syncInputs();
  }
  function prioNow(g, inEv) {
    if (inEv || st.ll || st.ht || st.tl || st.lt || st.vn || tlIn(g) || ltIn(g)) return 'ev';
    if (cfg.ctRun && st.ct && (st.ct.started || st.ct.haul)) return 'ct';
    if (st.bh || worldBossNear(g)) return 'boss';
    return '';
  }

  // Auto của game chỉ giữ mục tiêu mình khoá tới lúc vừa vào tầm đánh, sau đó tự chọn lại theo "Ưu tiên mục tiêu" của game …
  var hotSaved = null;
  function tickPriority(g) {
    var Hb = g.P.Hotbar;
    if (!Hb || !Hb.uuTien || !Hb.setUuTien) return;
    var ctPk = !!(st.ct && st.ct.pk) || !!(st.dh && st.dh.pk) || !!(st.tl && st.tl.pk) || !!(st.lt && st.lt.pk);
    var bossNow = !!((st.ll && st.ll.boss) || ((cfg.bossFocus || st.bh) && (st.bh || worldBossNear(g)))) || ctPk;
    if (bossNow && hotSaved === null) hotSaved = Hb.uuTien();
    if (!bossNow && hotSaved !== null) {
      if (!cfg.priority && Hb.uuTien() !== hotSaved) Hb.setUuTien(hotSaved);
      hotSaved = null;
    }
    var want = ctPk ? 'nguoi' : bossNow ? 'boss' : cfg.priority;
    if (want && Hb.uuTien() !== want) Hb.setUuTien(want);
  }


  /* ================= Khoá / mở FPS & giảm lag ================= */
  // Móc vào Quality của game: gỡ ép 30 FPS khi treo máy (idle) / đông người (crowd), ép 10 FPS khi tiết kiệm pin, chống …
  var fpsTracker = { lastT: 0, frames: 0, fps: 0 }, lastSelfAtk = 0;
  var WEATHER_ARTS = ['BaiDaArt', 'RungTrucArt', 'DuocCocArt', 'MieuHoangArt', 'MoLinhThachArt', 'LongUyenArt', 'ThungLungArt', 'PhongChoArt',
    'HuThienArt', 'YenLangArt', 'SanDauArt', 'VeTay', 'LamLangArt', 'TanVienFxArt'];
  function hookFps(P) {
    if (!P) return;
    var Q = P.Quality;
    if (Q && !Q._ttFps) {
      Q._ttFps = true;
      var o = { idle: Q.idle, setCrowd: Q.setCrowd, lowPower: Q.lowPower, quanSat: Q.quanSat, fpsCap: Q.fpsCap, anChieuBoss: Q.anChieuBoss, remoteSpell: Q.remoteSpell, anNguoi: Q.anNguoi };
      if (o.idle) Q.idle = function () { return cfg.fpsUnlock ? false : o.idle.apply(this, arguments); };
      if (o.setCrowd) Q.setCrowd = function () { if (cfg.fpsUnlock) { Q.crowd = false; return; } return o.setCrowd.apply(this, arguments); };
      if (o.lowPower) Q.lowPower = function () { return cfg.fpsUnlock ? false : o.lowPower.apply(this, arguments); };
      if (o.quanSat) Q.quanSat = function () { if (cfg.fpsUnlock || cfg.antiAutoDowngrade) return; return o.quanSat.apply(this, arguments); };
      if (o.fpsCap) Q.fpsCap = function () { return cfg.fpsUnlock ? Number(cfg.fpsTarget) || 0 : o.fpsCap.apply(this, arguments); };
      if (o.anChieuBoss) Q.anChieuBoss = function () { return cfg.fpsUnlock || cfg.hideRemoteSkills ? false : o.anChieuBoss.apply(this, arguments); }; // luôn hiện chiêu boss để né
      if (o.remoteSpell) Q.remoteSpell = function (n, t, r) {
        if (cfg.hideRemoteSkills) { var me = P.SceneWorld && P.SceneWorld.player; return me && r && r.target === me ? 'cham' : 'skip'; }
        return o.remoteSpell.apply(this, arguments);
      };
      if (o.anNguoi) Q.anNguoi = function (n) {
        var T = P.Targeting, G = P.Gateway;
        if (cfg.playerVis === 'none') return !(T && T.thuDich && T.thuDich(n));
        if (cfg.playerVis === 'party') return !(T && T.thuDich && T.thuDich(n) || G && G.partyMember && G.partyMember(n.id));
        if (cfg.playerVis === 'all') return false;
        return o.anNguoi.apply(this, arguments);
      };
    }
    var V = P.VFX;
    if (V && V.spawnDamage && !V._ttFps) {
      V._ttFps = true;
      var sd = V.spawnDamage, lastDmg = 0;
      V.spawnDamage = function (x, y, n, kind) {
        if (kind === 'take') return sd.apply(this, arguments); // mình bị đánh: luôn hiện
        if (cfg.hideDamage === 'all') return;
        if (cfg.hideDamage === 'remote' && now() - lastSelfAtk >= 200) return;
        if (cfg.hideDamage === 'throttle') { if (now() - lastDmg < 160) return; lastDmg = now(); }
        return sd.apply(this, arguments);
      };
    }
    var SW = P.SceneWorld;
    if (SW && !SW._ttFps) {
      SW._ttFps = true;
      if (SW.onPlayerSlash) { var ops = SW.onPlayerSlash; SW.onPlayerSlash = function () { lastSelfAtk = now(); return ops.apply(this, arguments); }; }
      if (SW.showHitFx) {
        var shf = SW.showHitFx, lastHitSnd = 0;
        SW.showHitFx = function (m, dmg, by) {
          var self = by === SW.player || now() - lastSelfAtk < 200;
          if (cfg.hideImpactFx && !self) {
            if (P.Enemy && P.Enemy.flinch) P.Enemy.flinch(m, P.Game.time, by && by.x, by && by.y);
            if (P.VFX && P.VFX.spawnDamage) P.VFX.spawnDamage(m.x, m.y - 20, dmg, 'deal', !!(m.def && m.def.isBoss));
            if (now() - lastHitSnd > 160 && P.Audio && P.Audio.play) { lastHitSnd = now(); P.Audio.play(m.def && m.def.isBoss ? 'boss_hit' : dmg >= 25 ? 'hit_big' : 'hit', { rate: 0.9 + 0.2 * Math.random() }); }
            return;
          }
          return shf.apply(this, arguments);
        };
      }
    }
    var Rd = P.Renderer;
    if (Rd && Rd.present && !Rd._ttFps) {
      Rd._ttFps = true;
      var pr = Rd.present;
      Rd.present = function () {
        var res = pr.apply(this, arguments), t = performance.now();
        if (!fpsTracker.lastT) fpsTracker.lastT = t;
        fpsTracker.frames++;
        if (t - fpsTracker.lastT >= 500) { fpsTracker.fps = Math.round(fpsTracker.frames * 1000 / (t - fpsTracker.lastT)); fpsTracker.frames = 0; fpsTracker.lastT = t; }
        return res;
      };
    }
    WEATHER_ARTS.forEach(function (name) {
      var art = P[name];
      if (art && art.drawFx && !art._ttFps) { art._ttFps = true; var df = art.drawFx; art.drawFx = function () { if (cfg.hideWeatherFx) return; return df.apply(this, arguments); }; }
    });
    if (P.Weather && P.Weather.draw && !P.Weather._ttFps) { P.Weather._ttFps = true; var wd = P.Weather.draw; P.Weather.draw = function () { if (cfg.hideWeatherFx) return; return wd.apply(this, arguments); }; }
  }

  /* ================= Báo cáo Telegram ================= */
  // Ghi diễn biến từng lượt sự kiện: bước trợ thủ quyết định, nhật ký, trạng thái 10s/lần, gục, tin máy chủ.
  var TG_EV = [
    ['tl', 'Tam Lộ Tranh Phong', function (g) { return tlIn(g); }, 'tl'],
    ['lt', 'Tranh Đoạt Linh Thụ', function (g) { return ltIn(g); }, 'lt'],
    ['vn', 'Vết Nứt Không Gian', function (g) { return vnIn(g); }, 'vn'],
    ['dh', 'Đại Hội Tu Tiên', function (g) { return !!(DH_MAPS && DH_MAPS[g.mapId]); }, 'dh'],
    ['bc', 'Bí cảnh (Huyết Xích / Yên Lãng)', function (g) { return !!HUYET_MAPS[g.mapId] || !!(g.P.YenLang && g.mapId === g.P.YenLang.MAP); }, 'hx'],
    ['ll', 'Lãm Làng / Sỹ Sách Điện', function () { return !!(st.ll || st.ht); }, 'll'],
    ['vt', 'Vận Tiêu', function (g) { return !!st.vt || vtActive(g); }, 'vt'],
    ['ct', 'Cướp tiêu', function () { return !!(st.ct && (st.ct.started || st.ct.haul)); }, 'ct'],
    ['td', 'Thương Đội (săn & tin Thiên Đạo)', function () { return !!st.td; }, 'td'],
    ['xc', 'Yêu thú xổng chuồng', function () { return !!st.xc; }, 'xc'],
    ['bh', 'Boss', function (g) { return !!st.bh || !!tgBoss(g); }, 'bh']
  ];
  // Boss thật đang đánh ở gần: cờ boss của game / boss hồi ≥ 10 phút / có trong BOSS_TABLE.
  function tgBoss(g) {
    var me = g.me;
    return mobsAlive(g).filter(function (m) {
      return isBoss(m) && (m.def.isBoss || (m.def.respawnSec || 0) >= 600 || BOSS_TABLE.some(function (b) { return b.type === m.type; })) && m.hp < m.hpMax && dist(me.x, me.y, m.x, m.y) < 500;
    })[0] || null;
  }
  function tgBossName(m) { return String(m && m.def && m.def.name || 'Boss').split('|')[0].trim(); }
  var TG_SKIP_ACT = { nhip: 1, st: 1, xem: 1, bang: 1, ht: 1, vanNguoi: 1, an: 1 };
  var tgRec = null, tgLast = null, tgQ = [], tgBusy = false;
  function tgT(r) { var x = Math.round((Date.now() - r.t0) / 1000); return (x / 60 | 0) + ':' + ('0' + x % 60).slice(-2); }
  function tgAdd(r, m) { if (r.lines.length < 8000) r.lines.push('[' + tgT(r) + '] ' + m); }
  function tgReady() { return !!(cfg.tgOn && String(cfg.tgToken).trim() && String(cfg.tgChat).trim()); }
  // Gửi lên Bot API: qua GM_xmlhttpRequest nếu có; không có (chạy @grant none) thì dùng fetch trực tiếp (Telegram hỗ trợ CORS).
  function tgReq(method, body, type, cb) {
    var url = 'https://api.telegram.org/bot' + String(cfg.tgToken).trim() + '/' + method;
    function done(t, code) { var j = null; try { j = JSON.parse(t); } catch (e) { } cb(j || { ok: false, description: 'HTTP ' + code }); }
    if (typeof GM_xmlhttpRequest === 'function') {
      GM_xmlhttpRequest({
        method: 'POST', url: url, data: body, headers: { 'Content-Type': type }, timeout: 30000,
        onload: function (x) { done(x.responseText, x.status); }, onerror: function () { cb({ ok: false, description: 'không kết nối được Telegram' }); },
        ontimeout: function () { cb({ ok: false, description: 'Telegram không trả lời' }); }
      });
    } else if (window.fetch) {
      window.fetch(url, { method: 'POST', body: body, headers: { 'Content-Type': type } }).then(function (r) { return r.text().then(function (t) { done(t, r.status); }); },
        function () { cb({ ok: false, description: 'trình duyệt chặn kết nối (cài script qua Tampermonkey và cho phép api.telegram.org)' }); });
    } else {
      cb({ ok: false, description: 'môi trường không hỗ trợ kết nối mạng' });
    }
  }
  function tgSend(text, cb) { tgQ.push({ m: 'sendMessage', b: JSON.stringify({ chat_id: String(cfg.tgChat).trim(), text: String(text).slice(0, 4000), disable_web_page_preview: true }), t: 'application/json', cb: cb }); tgPump(); }
  function tgFile(name, text, cap) {
    var bd = '----ttbot' + Date.now().toString(36), body = '';
    [['chat_id', String(cfg.tgChat).trim()], ['caption', String(cap || '').slice(0, 1000)]].forEach(function (f) { body += '--' + bd + '\r\nContent-Disposition: form-data; name="' + f[0] + '"\r\n\r\n' + f[1] + '\r\n'; });
    body += '--' + bd + '\r\nContent-Disposition: form-data; name="document"; filename="' + name + '"\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n' + text + '\r\n--' + bd + '--\r\n';
    tgQ.push({ m: 'sendDocument', b: body, t: 'multipart/form-data; boundary=' + bd }); tgPump();
  }
  function tgPump() {
    if (tgBusy || !tgQ.length || now() < (st.tgWait || 0)) return;
    var it = tgQ[0]; tgBusy = true;
    tgReq(it.m, it.b, it.t, function (res) {
      tgBusy = false;
      var ra = res && res.parameters && res.parameters.retry_after;
      if (res && res.ok) tgQ.shift();
      else if (ra) st.tgWait = now() + ra * 1000 + 500;
      else if (++it.tries >= 3 || !it.tries) { tgQ.shift(); st.tgErr = res && res.description || 'lỗi'; }
      else st.tgWait = now() + 5000;
      if (it.cb) it.cb(res);
      if (tgQ.length) setTimeout(tgPump, 1200);
    });
    it.tries = it.tries || 0;
  }
  // Tin máy chủ gửi về bảng Vết Nứt / Tam Lộ / Linh Thụ / Vận Tiêu: ghi thô (bỏ các nhịp định kỳ).
  function tgHook(P) {
    [['VetNutUI', 'vn'], ['TamLoUI', 'tl'], ['LinhThuUI', 'lt'], ['VanTieuUI', 'vt']].forEach(function (h) {
      var U = P[h[0]];
      if (!U || !U.nhan || U.nhan._tg) return;
      var f = U.nhan;
      U.nhan = function (e) {
        try {
          if (tgRec && tgRec.k === h[1] && e && !TG_SKIP_ACT[e.act]) tgAdd(tgRec, '≡ ' + e.act + ' ' + JSON.stringify(e).slice(0, 300));
          if (h[1] === 'vn' && e) {
            var isDoorEv = (e.act === 'lo' && e.kq === 'thong') ||
              (e.act === 'cua' && e.an && e.an.indexOf(1) >= 0) ||
              (e.act === 'hom' && e.mo) ||
              (e.act === 'nhip' && ((e.lo && e.lo.indexOf(1) >= 0) || (e.an && e.an.indexOf(1) >= 0)));
            if (isDoorEv && st.vn) {
              st.vn.doorFound = true;
              st.vn.doorFoundAt = now();
              var dL = (e.act === 'lo' && e.k != null) ? e.k :
                (e.lo ? e.lo.indexOf(1) : (e.an ? e.an.indexOf(1) : -1));
              if (dL >= 0) {
                st.vn.doorLane = dL;
                st.vn.lane = dL;
              }
            }
          }
        } catch (x) { }
        return f.apply(this, arguments);
      };
      U.nhan._tg = 1;
    });
  }
  function tgSnap(g, r) {
    var P = g.P, me = g.me, G = P.Gateway || {}, a = st[r.st];
    var x = 'máu ' + (me.hpMax ? Math.round(me.hp / me.hpMax * 100) : 0) + '% · LL ' + (me.mpMax ? Math.round((me.mp || 0) / me.mpMax * 100) : 0) + '% · ' + mapName(g.mapId) + ' (' + Math.round(me.x) + ',' + Math.round(me.y) + ')';
    x += ' · quái <400px ' + mobsAlive(g).filter(function (m) { return dist(me.x, me.y, m.x, m.y) < 400; }).length + ' · người thù ' + hostilePlayers(g).length + ' · Tự Động ' + (g.sw.autoOn ? 'bật' : 'tắt');
    var t = me.attackTarget || me.castTarget;
    if (t && !t.dead && t.def && (g.sw.enemies || []).indexOf(t) >= 0 && dist(me.x, me.y, t.x, t.y) < 600) x += ' · đánh ' + mobLabel(t) + ' ' + evPct(t);
    if (a && a.step) x += ' · việc: ' + a.step;
    if (r.k === 'tl' && P.TamLoUI) {
      var T = P.TamLoUI.trangThai() || {}, n = T.nhip;
      if (n) x += ' · hạ ' + (n.ha || []).join('-') + ' · trụ ' + (n.tru || []).join('-') + (n.rong ? ' · rồng ' + (n.rong.song ? 'sống' : 'chưa') + ' ' + (n.rong.dd || [0, 0]).join('-') : '') + (n.baron ? ' · baron ' + (n.baron.song ? 'sống' : 'chưa') : '');
      if (st.tl) x += ' · chế độ ' + (st.tl.mode || '-') + ' · đường ' + (st.tl.lane != null ? st.tl.lane : cfg.tlLane);
    }
    if (r.k === 'vn') { var L = (typeof vnSt === 'function' ? vnSt(P) : null) || {}; x += ' · giai đoạn ' + (L.tt || '-') + ' · mạng ' + (L.mang | 0) + ' · cầm ' + ((L.cam && L.cam[G.selfId]) || []).length; }
    if (r.k === 'td' && st.td) {
      var td = st.td;
      x += ' · việc: ' + (td.step || (td.target ? 'đánh ' + mobLabel(td.target) : (td.seen ? 'trong đoàn' : 'tìm đoàn')));
      if (td.target && !td.target.dead) x += ' · mục tiêu ' + mobLabel(td.target) + ' ' + evPct(td.target);
    }
    if (r.k === 'xc' && st.xc) {
      var xc = st.xc;
      x += ' · việc: ' + (xc.step || (xc.target ? 'đánh ' + mobLabel(xc.target) : 'săn xổng chuồng'));
      if (xc.target && !xc.target.dead) x += ' · mục tiêu ' + mobLabel(xc.target) + ' ' + evPct(xc.target);
    }
    if (r.k === 'vt') {
      var cart = vtCart(g), ch = vtChuyen(P);
      if (ch) x += ' · xe ' + (P.VanTieu && P.VanTieu.tenHang ? P.VanTieu.tenHang(ch.hang) : 'hàng') + (cart ? ' cách ' + Math.round(cart.d) + 'px (máu ' + Math.round((cart.m.hp || 0) / (cart.m.hpMax || 1) * 100) + '%)' : ' chưa thấy xe');
    }
    var bz = r.k === 'bh' && tgBoss(g);
    if (bz) { var cbz = bossShare(bz); x += ' · boss ' + tgBossName(bz) + ' ' + evPct(bz) + (cbz ? ' · ' + bossShareText(cbz) : ' · chưa có số liệu công'); if (cbz) r.cong = bossShareText(cbz); }
    if (r.k === 'dh' && G.duel && typeof dhDmg === 'function') x += ' · sát thương ' + dhDmg(P, G);
    tgAdd(r, x);
  }
  function tgWarn(r, k, m) {
    var w = r.warn[k] || (r.warn[k] = { n: 0, at: -1e9 });
    w.m = m;
    if (now() - w.at > 20000) { w.n++; w.at = now(); tgAdd(r, '⚠ ' + m); }
  }
  function tgErr(e) {
    console.error('[TTBot]', e);
    var m = String(e && e.message || e);
    if (tgRec) tgWarn(tgRec, 'err:' + m, 'Lỗi mã trợ thủ: ' + m + ' @ ' + String(e && e.stack || '').split('\n').slice(1, 4).join(' ').replace(/\(?[a-z-]+:[^\s)]*[\\/]([^\\/\s)]+)\)?/gi, '$1').replace(/\s+/g, ' ').slice(0, 220));
  }
  var TG_BAD = /không được|chưa .*được|từ chối|lỗi|thất bại|không tìm được|không đi được|đi mãi không tới|bỏ qua|không có đường|không còn đường/i;
  function tgRej(r, m) {
    if (!TG_BAD.test(m) || /^Lỗi mã/.test(m)) return;
    var k = m.replace(/\d+/g, '#').slice(0, 90), c = r.rej[k] = (r.rej[k] || 0) + 1;
    if (c >= 3) tgWarn(r, 'rej:' + k, 'Lặp lại ×' + c + ': ' + m);
  }
  function tgWatch(g, r, stp) {
    var me = g.me, P = g.P, t = now(), hp = me.hpMax ? me.hp / me.hpMax : 1;
    if (!r.hp.length || t - r.hp[r.hp.length - 1].t >= 1000) { r.hp.push({ t: t, v: Math.round(hp * 100) }); if (r.hp.length > 11) r.hp.shift(); }
    if (me.downed) { r.mv = null; return; }
    if (!r.mv || dist(me.x, me.y, r.mv.x, r.mv.y) > 24) r.mv = { x: me.x, y: me.y, at: t };
    if (me.state === 'attack' || me.state === 'sit' || st.healing || (st.bh && st.bh.phase !== 'fight') || t - lastStrikeAt < 3000) r.actAt = t;
    var still = t - r.mv.at, s0 = stp || '';
    if (still > 15000 && t - r.stepAt > 15000 && /^(đi|tới|đuổi|chạy|ra |về|lùi|áp)/i.test(s0)) tgWarn(r, 'ket', 'Kẹt: đứng yên ' + Math.round(Math.min(still, t - r.stepAt) / 1000) + 's mà đang "' + s0 + '" · ' + mapName(g.mapId) + ' (' + Math.round(me.x) + ',' + Math.round(me.y) + ')');
    else if (still > 20000 && t - (r.actAt || r.t0n) > 20000 && t - r.stepAt > 20000 && !/chờ|đứng|núp|giữ|hồi máu|thiền|vận|cầm/i.test(s0)) tgWarn(r, 'idle', 'Đứng không làm gì ' + Math.round(still / 1000) + 's' + (s0 ? ' (việc: ' + s0 + ')' : '') + ' · Tự Động ' + (g.sw.autoOn ? 'bật' : 'tắt'));
    var h = r.hist = r.hist.filter(function (x) { return t - x.t < 60000; });
    r.backs = r.backs.filter(function (x) { return t - x < 60000; });
    if (r.backs.length >= 6 && r.k !== 'bc') {
      var ds = {}; h.forEach(function (x) { ds[x.s] = 1; });
      var nd = Object.keys(ds);
      if (nd.length <= 4) { tgWarn(r, 'flip', 'Quay qua quay lại ' + r.backs.length + ' lần trong 1 phút giữa: ' + nd.join(' ⇄ ')); r.hist = []; r.backs = []; }
    }
    if (hp < 0.3) {
      var U = P.TamLoUI, d0 = U && U.doi ? U.doi() : -9;
      var th = hostilePlayers(g).concat((g.sw.enemies || []).filter(function (m) { return m && !m.dead && !m.kh && m.def && m.def.tamLo && /tru|nha/.test(m.def.tamLo.ve || '') && m.tm !== d0; }));
      var dn = th.reduce(function (a, o) { return Math.min(a, dist(me.x, me.y, o.x, o.y)); }, 1e9);
      if (!r.dn) r.dn = { d: dn, t: t };
      else if (t - r.dn.t > 2000) { if (dn < 500 && dn < r.dn.d - 40) tgWarn(r, 'push', 'Máu ' + Math.round(hp * 100) + '% mà vẫn tiến về phía địch / trụ địch (còn ' + Math.round(dn) + 'px) · việc: ' + s0); r.dn = { d: dn, t: t }; }
    } else r.dn = null;
  }
  function tgDeath(g, r) {
    var me = g.me, P = g.P, U = P.TamLoUI;
    var mobs = mobsAlive(g).filter(function (m) { return dist(me.x, me.y, m.x, m.y) < 320; }).slice(0, 4).map(function (m) { return mobLabel(m) + ' ' + evPct(m); });
    var foes = hostilePlayers(g).filter(function (o) { return dist(me.x, me.y, o.x, o.y) < 450; }).map(function (o) { return (o.name || 'địch') + (o.hp != null && o.hp <= 1 ? ' ' + Math.round(o.hp * 100) + '%' : ''); });
    var x = 'Gục · máu 10 giây trước: ' + r.hp.map(function (h) { return h.v; }).join('→') + ' · việc: ' + (r.stp || '-') + ' · quái quanh: ' + (mobs.join(', ') || 'không') + ' · người thù quanh: ' + (foes.join(', ') || 'không');
    if (r.k === 'tl' && U && U.doi) {
      var d0 = U.doi(), R = P.Gateway.remotes || {}, al = Object.keys(R).filter(function (k) { var o = R[k]; return o && !o.downed && U.laBanNguoi(o) && dist(me.x, me.y, o.x, o.y) < 500; }).length;
      var tw = (g.sw.enemies || []).some(function (m) { return m && !m.dead && !m.kh && m.def && m.def.tamLo && m.def.tamLo.ve === 'tru' && m.tm !== d0 && dist(me.x, me.y, m.x, m.y) < 360; });
      x += ' · đồng đội quanh ' + al + (tw ? ' · ĐANG ĐỨNG TRONG TẦM TRỤ ĐỊCH' : '');
    }
    tgWarn(r, 'death' + r.deaths, x);
  }
  function tgBag(P) { var o = {}, b = P.Inventory && P.Inventory.bag || {}; Object.keys(b).forEach(function (k) { o[k] = b[k] | 0; }); o.linh_thach = P.Progress && P.Progress.stones | 0; return o; }
  function tgGain(g, r) {
    if (!r.bag0) return '';
    var b1 = tgBag(g.P), b0 = r.bag0, I = g.P.ITEMS || {}, nm = function (k) { return I[k] && I[k].name || (k === 'linh_thach' ? 'Linh Thạch' : k); }, up = [], dn = [];
    Object.keys(Object.assign({}, b0, b1)).forEach(function (k) { var d = (b1[k] | 0) - (b0[k] | 0); if (d) (d > 0 ? up : dn).push([k, d]); });
    up.sort(function (x, y) { return (y[0] === 'linh_thach') - (x[0] === 'linh_thach') || y[1] - x[1]; });
    return (up.length ? '🎁 Thu được: ' + up.map(function (x) { return nm(x[0]) + ' ×' + x[1]; }).join(', ') : '🎁 Thu được: không có gì') +
      (dn.length ? '\n💸 Đã dùng: ' + dn.map(function (x) { return nm(x[0]) + ' ×' + (-x[1]); }).join(', ') : '');
  }
  function tgEnd(g, why) {
    var r = tgRec;
    tgRec = null; tgLast = r;
    try { r.gain = tgGain(g, r); } catch (e) { }
    if (r.k === 'lt' && g.P.LinhThuUI && g.P.LinhThuUI.ket) r.result = 'Kết quả: ' + ltRes(g.P.LinhThuUI);
    if (r.k === 'tl' && g.P.TamLoUI) { var kq = (g.P.TamLoUI.trangThai() || {}).ketqua; if (kq) r.result = 'Kết quả: ' + (kq.ketQua || '?') + ' · hạ ' + (kq.ha || []).join('-') + ' · trụ ' + (kq.tru || []).join('-') + ' · lý do ' + (kq.lyDo || ''); }
    if (r.k === 'td' && st.lastTdResult) { r.result = 'Kết quả: ' + st.lastTdResult; st.lastTdResult = ''; }
    if (r.k === 'xc') { var kCnt = (st.xc && st.xc.kills) || 0; r.result = 'Kết quả: ' + (kCnt ? ('Đã hạ ' + kCnt + ' quái') : 'Kết thúc săn'); }
    if (r.k === 'vt' && st.lastVtResult) { r.result = 'Kết quả: ' + st.lastVtResult; st.lastVtResult = ''; }
    tgAdd(r, 'Kết thúc' + (why ? ' (' + why + ')' : '') + (r.result ? ' · ' + r.result : ''));
    if (tgReady()) tgReport(r, true);
  }
  function tgReport(r, fin, full) {
    var W = Object.keys(r.warn).map(function (k) { return r.warn[k]; }), hard = function (w) { return /^(Lỗi mã|Kẹt|Gục)/.test(w.m); };
    var lv = r.deaths || W.some(hard) ? 2 : W.length ? 1 : 0;
    var key = r.lines.filter(function (l) { return /Lượt này gửi nhặt|Xong kỳ|Kết quả|đã bị hạ|Đã thu|Xong \d tầng/.test(l) && !/\] Kết thúc/.test(l); }).slice(-3).map(function (l) { return l.replace(/^\[[^\]]*\] /, ''); });
    var head = ['✅', '⚠️', '🚨'][lv] + ' ' + r.name + ' · ' + r.who + ' · ' + tgT(r) + (r.deaths ? ' · gục ' + r.deaths + ' lần' : '') + (fin ? '' : ' (đang diễn ra)') +
      (r.result ? '\n' + r.result : '') + (r.cong ? '\n🎯 Công boss: ' + r.cong : '') + (key.length ? '\n' + key.join('\n') : '') + (fin && r.gain ? '\n' + r.gain : '');
    if (!cfg.tgAlwaysFile && !lv && !full) { if (fin) tgSend(head); return; }
    var d = new Date(r.t0), stamp = d.getFullYear() + ('0' + (d.getMonth() + 1)).slice(-2) + ('0' + d.getDate()).slice(-2) + '-' + ('0' + d.getHours()).slice(-2) + ('0' + d.getMinutes()).slice(-2);
    var fn = ['', 'CANHBAO-', 'LOI-'][lv] + r.k + '-' + plainVi(r.who).replace(/[^a-z0-9]+/g, '') + '-' + stamp + (r.part ? '-p' + r.part : '') + '.txt';
    var wl = function (n) { return W.slice(0, n).map(function (w) { return (hard(w) ? '🔴 ' : '🟡 ') + (n > 10 ? w.m : w.m.slice(0, 180)) + (w.n > 1 ? ' ×' + w.n : ''); }).join('\n'); };
    var tail = r.lines.filter(function (l) { return !/\] máu \d/.test(l); }).slice(-8).join('\n');
    tgSend([lv === 2 ? '🚨🚨🚨 BẤT THƯỜNG NGHIÊM TRỌNG' : lv ? '⚠️⚠️ CÓ BẤT THƯỜNG' : '📄 Báo cáo đầy đủ'].concat(head,
      W.length ? '\n' + wl(10) : [], '\n📜 Diễn biến cuối:\n' + tail, '\n📎 File log: ' + fn).join('\n'));
    tgFile(fn, r.name + ' · ' + r.who + ' · trợ thủ v' + VERSION + ' · bắt đầu ' + d.toLocaleString('vi-VN') +
      '\n===== TÓM TẮT =====\n' + head + (W.length ? '\n' + wl(99) : '') + '\n📜 Diễn biến cuối:\n' + tail + '\n===== NHẬT KÝ =====\n' + r.lines.join('\n'), ['📄', '⚠️', '🚨'][lv] + ' ' + fn);
  }
  function tickReport(g) {
    tgHook(g.P);
    tgPump();
    if (!cfg.tgOn) { tgRec = null; return; }
    var ev = TG_EV.filter(function (e) { return cfg['tgEv_' + e[0]] !== false && e[2](g); })[0], r = tgRec;
    if (r && (!ev || ev[0] !== r.k)) {
      if (!ev && !r.gone) r.gone = now();
      if (ev || now() - r.gone > 15000) tgEnd(g, ev ? 'chuyển sang ' + ev[1] : '');
      r = tgRec;
    }
    if (!r && ev) {
      var bz = ev[0] === 'bh' && (tgBoss(g) || null);
      var evName = ev[1];
      if (bz) evName += ' · ' + tgBossName(bz);
      else if (st.bh && st.bh.b) evName += ' · ' + bhName(g.P, st.bh.b);
      else if (ev[0] === 'td' && st.td) evName += (st.td.ev ? ' · ' + mapName(st.td.ev.map) + (st.td.ev.khu ? ' k' + st.td.ev.khu : '') : (g ? ' · ' + mapName(g.mapId) : ''));
      else if (ev[0] === 'vt') { var vch = vtChuyen(g.P); evName += ' · ' + (vch && g.P.VanTieu && g.P.VanTieu.tenHang ? g.P.VanTieu.tenHang(vch.hang) : 'Hộ tống'); }
      r = tgRec = { bag0: (function () { try { return tgBag(g.P); } catch (e) { return null; } })(), k: ev[0], name: evName, st: ev[3], t0: Date.now(), t0n: now(), stepAt: now(), lines: [], deaths: 0, who: myName(g) || 'nhân vật', flushAt: Date.now(), part: 0, warn: {}, rej: {}, hp: [], hist: [], backs: [] };
      tgAdd(r, 'Bắt đầu ' + evName + ' · ' + r.who + ' · trợ thủ ' + (enabled ? 'đang bật' : 'đang tắt (đánh tay)') + ' · v' + VERSION);
    }
    if (!r || !ev) return;
    r.gone = 0;
    var a = (st[r.st] || (r.k === 'bc' && st.yl) || (r.k === 'll' && st.ht)) || null, stp = a && a.step;
    var sk = stp && stp.replace(/\d+/g, '#');
    r.stp = stp;
    if (sk && sk !== r.step) {
      r.step = sk; r.stepAt = now(); tgAdd(r, '→ ' + stp);
      var kf = /^(đánh|hạ) /.test(sk) ? 'đánh' : sk.replace(/^(tới|đi thu|nhặt|giao tranh · dồn) [^·(]+/, '$1 …').slice(0, 40);
      if (!/^⏸/.test(sk) && kf !== r.kf) { if (r.hist.some(function (x) { return x.s === kf && now() - x.t < 60000; })) r.backs.push(now()); r.kf = kf; r.hist.push({ t: now(), s: kf }); }
    }
    if (!!g.me.downed !== !!r.down) { r.down = !!g.me.downed; if (r.down) { r.deaths++; tgDeath(g, r); } else tgAdd(r, '↺ hồi sinh'); }
    tgWatch(g, r, stp);
    if (now() - (r.snapAt || -1e9) > 10000) { r.snapAt = now(); tgSnap(g, r); }
    if (Date.now() - r.flushAt > 30 * 60000) { if (Object.keys(r.warn).length && tgReady()) { r.part++; tgReport(r, false); r.lines = []; r.warn = {}; } else r.lines = r.lines.slice(-3000); r.flushAt = Date.now(); }
  }

  /* ================= Cảm biến Thiên Lao (Anti-Jail & Panic Kill-switch) ================= */
  function isJailed(g) {
    if (!g) return false;
    var P = g.P || window.PNTT;
    if (!P) return false;
    try {
      // 1. Kiểm tra qua hệ thống Hắc Thị (đang bị giam)
      if (P.HacThi) {
        if (typeof P.HacThi.dangGiam === 'function' && P.HacThi.dangGiam(g.P || P)) return true;
        if (typeof P.HacThi.giamConMs === 'function' && P.HacThi.giamConMs(g.P || P) > 0) return true;
      }
      // 2. Kiểm tra qua dữ liệu nhân vật / Progress
      var prog = (g.P && g.P.Progress) || P.Progress;
      if (prog && prog.hacThi && prog.hacThi.giamDen && prog.hacThi.giamDen > Date.now()) return true;
      // 3. Kiểm tra toạ độ trong ngục Thiên Lao (Bát Quái Thạch Phàn / ô giam [tx: 48..55, ty: 9..14])
      if (g.mapId === 'bat_quai_thach_phan' && g.me) {
        var tx = Math.floor(g.me.x / 32), ty = Math.floor(g.me.y / 32);
        if (P.HacThi && typeof P.HacThi.trongLao === 'function' && P.HacThi.trongLao(tx, ty)) return true;
        if (tx >= 48 && tx <= 55 && ty >= 9 && ty <= 14) return true;
      }
      // 4. Kiểm tra qua DOM banner hiển thị Thiên Lao
      if (typeof document !== 'undefined') {
        var dai = document.querySelector('.hct-dai');
        if (dai && (dai.classList.contains('lao') || /thien lao/i.test(dai.textContent || ''))) return true;
      }
    } catch (e) { }
    return false;
  }

  function panicThienLao(g, reason) {
    if (st.jailedPanic) return;
    st.jailedPanic = true;
    st.jailed = true;
    st.jailedAt = now();

    // 1. Tắt công tắc chính và tắt Auto chiến đấu của game
    enabled = false;
    if (typeof prioRestore === 'function') prioRestore();
    if (g) setAuto(g, false);

    // 2. Xoá sạch mọi kế hoạch di chuyển, đánh quái, nhặt đồ
    st.plan = null;
    st.travel = null;
    st.farmTarget = null;
    st.cuop = null;
    st.xc = null;
    st.td = null;
    st.bd = null;
    st.bh = null;
    st.vn = null;
    st.tq = null;
    st.hl = null;
    st.ll = null;
    st.ht = null;
    st.lt = null;
    st.tl = null;
    st.fa = null;
    st.dc = null;
    st.ga = null;
    st.hon = null;
    st.healing = false;
    st.dodging = false;
    st.kiting = false;
    st.engaging = false;
    st.looting = null;
    st.fastLoot = null;

    // 3. Đứng im tuyệt đối (xoá đường đi và tiếp cận)
    if (g && g.me) { g.me.path = []; }
    if (g && g.sw) { g.sw.approach = null; }

    // 4. Báo động UI Caption & Console
    say('🚨 PHẠT TÙ THIÊN LAO! ĐÃ TẮT TOÀN BỘ AUTO ĐỂ BẢO VỆ TÀI KHOẢN!');
    if (g && g.P && g.P.HUD && g.P.HUD.setCaption) g.P.HUD.setCaption('🚨 PHẠT TÙ THIÊN LAO! ĐÃ TẮT AUTO');
    klog('🚨 [THIÊN LAO] ' + (reason || 'Phát hiện nhân vật bị giam') + ' → NGẮT KHẨN CẤP TOÀN BỘ TIẾN TRÌNH.');

    // 5. Gửi cảnh báo khẩn cấp qua Telegram
    if (tgReady() && cfg.tgEv_lao !== false) {
      var who = g ? myName(g) : 'Nhân vật';
      var conMs = (g && g.P && g.P.HacThi && g.P.HacThi.giamConMs ? g.P.HacThi.giamConMs(g.P) : 0);
      var conStr = (g && g.P && g.P.HacThi && g.P.HacThi.chuGiam ? g.P.HacThi.chuGiam(conMs) : (conMs > 0 ? (Math.ceil(conMs / 60000) + ' phút') : 'Đang thụ án'));
      tgSend('🚨🚨 [CẢNH BÁO KHẨN CẤP] TÀI KHOẢN BỊ PHẠT TÙ THIÊN LAO!\n' +
             '👤 Nhân vật: ' + who + '\n' +
             '📍 Bản đồ: Bát Quái Thạch Bàn' + (g ? ' (Khu ' + gaKhu(g.P) + ')' : '') + '\n' +
             '⏳ Thời gian phạt tù: ' + conStr + '\n' +
             '🛑 Trợ thủ đã TỰ ĐỘNG TẮT TOÀN BỘ (KILL-SWITCH) để bảo vệ tài khoản, chống GM soi/ban. Vui lòng tự đăng nhập kiểm tra!');
    }
    if (typeof refresh === 'function') refresh();
  }

  /* ================= Vòng chính ================= */
  function tick() {
    tickDev();
    cleanCaches();
    if (window.PNTT && enabled) { var gT = game(); if (gT) { tickTeam(gT); tickBiTich(gT); } }
    if (window.PNTT) { hookPNTTGateway(window.PNTT); hookGame(window.PNTT); hookBiCanh(window.PNTT); hookHarvest(window.PNTT); hookDialog(window.PNTT); hookKhu(window.PNTT); hookHarvestStats(window.PNTT); hookLootStats(window.PNTT); hookFastLoot(window.PNTT); hookFps(window.PNTT); hookVanTieu(window.PNTT); hookChat(window.PNTT); hookTargeting(window.PNTT); hookLamLang(window.PNTT); hookBossFx(window.PNTT); }
    var g = game();
    if (g && isJailed(g)) {
      panicThienLao(g, 'Nhân vật đang bị giam trong Thiên Lao (Bát Quái Thạch Bàn)');
      return;
    }
    if (g) { tickStats(g); tickSwings(g); tickStrike(g); tickSwingConfirm(); tickIncoming(g); tickSplash(); checkStaleStates(g); }
    if (g && g.P && g.P.Input && g.P.Input.hasManualMove && g.P.Input.hasManualMove()) { st.lastManualAt = now(); }
    if (g) { try { tickReport(g); } catch (e) { } }
    if (!enabled || !g) { if (!enabled) prioRestore(); return; }
    prioApply(prioNow(g, evIn(g)));
    if (cfg.alwaysRun && !g.P.Input.run) g.P.Input.setRun(true);
    tickPriority(g);
    if (tickRevive(g)) return;
    if (ylHold(g)) return; // Yên Lãng: lệnh núi Tĩnh / Đảo Âm (trước cả né chiêu)
    tickTalismans(g);
    tickKhoiLoi(g);
    tickHoaThan(g);
    tickTran(g);
    if (cfg.bossRadar || cfg.bossHunt) tickBossPoll(g);
    if (tickDodge(g)) return;
    if (st.bh) bhObserve(g);
    if (tickDaiHoi(g)) return;
    tickHeal(g);
    if (st.healing) return;
    tickVtFly(g);
    tickReFly(g);
    tickAlwaysFly(g);
    if (tickHuyetLan(g)) return; // Chiến Trường: hái Vạn Hoang Huyết Lan
    if (tickContest(g)) return; // đồ rơi giữa trận boss / sự kiện: tranh ngay (chạy tới + gọi lệnh nhặt liên tục)
    if (tickTamLo(g)) return;
    if (tickLinhThu(g)) return;
    if (tickLamLang(g)) return;
    if (tickHuThien(g)) return;
    if (tickVetNut(g)) return;
    var inBc = (HUYET_MAPS[g.mapId] && (cfg.hxRun || planIs('hx'))) || (g.P.YenLang && g.mapId === g.P.YenLang.MAP && (cfg.ylRun || planIs('yl')));
    if (inBc && (HUYET_MAPS[g.mapId] ? tickHuyetXich(g) : tickYenLang(g))) return;
    var inEv = evIn(g) || !!st.ll || !!st.ht || !!st.lt || !!(st.vn && cfg.vnRun) || !!inBc;
    if (st.ct) { var evWhat = ctEventName(g, inEv); if (evWhat) ctYield(g, evWhat); }
    tickCtUnflag(g);
    if (inEv || st.ll || st.ht || st.lt) { st.vt = vtActive(g) ? st.vt : null; }
    if ((inEv || st.bh) && st.fish && (g.sw.fishing || g.sw.fishingAuto) && g.sw.stopFishing) g.sw.stopFishing(); // boss / hoạt động: thôi câu
    if (st.fish && (inEv || st.bh || st.bd || st.xc || st.td || st.fa || st.dc || st.ga || st.hon || st.ll || st.ht || st.tl || st.lt || st.vn) && !st.fish.paused) {
      st.fish.paused = true;
      fishLog('Có việc chen ngang (' + (st.bh ? 'boss' : st.td ? 'Thương Đội' : st.bd ? 'biến dị' : st.xc ? 'xổng chuồng' : st.fa ? 'chăm vườn' : st.dc ? 'Dược Công' : st.ga ? 'nhặt NL' : st.hon ? 'săn hồn' : 'hoạt động') + ') → tạm dừng câu, xong quay lại');
    }
    if (!inEv) {
      if (tickBossHunt(g)) { ctYield(g, 'đi boss'); return; }
      if (st.bh) { if (!vtActive(g)) st.vt = null; tickHonCraft(g); } // tới giờ boss: gác mọi việc treo khác
    }
    // Việc trong lịch bị gác lại: không tính thời gian chờ boss / hoạt động vào hạn giờ của việc đó.
    var tNow = now();
    if ((inEv || st.bh) && st.plan && st.plan.job && st.prioTickAt) st.plan.at += Math.min(2000, tNow - st.prioTickAt);
    st.prioTickAt = tNow;
    if (!inEv && !st.bh) {
      if (tickStandalone(g)) return;
      if (tickCuopTieu(g)) return;
      if (tickBienDi(g)) return;
      if (tickXongChuong(g)) return;
      if (tickThuongDoi(g)) return;
      if (tickHuyetXich(g)) return;
      if (tickYenLang(g)) return;
      if (tickHonBuy(g)) return;
      tickHonCraft(g);
      if (tickPlan(g)) return;
      if (tickDuocCong(g)) return;
      if (tickFarmCare(g)) return;
      if (tickGather(g)) return;
      if (tickFish(g)) return;
      if (cfg.vnRun && vnBuyTicket(g)) return;
      if (tickFarmKhu(g)) return;
      if (tickHonFarm(g)) return;
      if (tickGoBack(g)) return;
    }
    if (!st.bh && tickHarvest(g)) return;
    tickTarget(g);
    if (tickBossBurst(g)) return;
    if (g.sw.autoOn && tickTowerExit(g)) return;
    if (tickKite(g)) return;
    if (tickLoot(g)) return;
    tickEat(g);
    if (!inEv) tickStayFarm(g);
    if (tickTravel(g)) return;
    // Tắt hit & run thì vẫn chọn chỗ đứng đánh lan (lúc không có chiêu sắp dùng).
    if (!cfg.kite && g.sw.autoOn && !st.looting) { var kt = kiteTarget(g); if (kt && !plannedSkill(g, kt) && splashMove(g, kt)) return; }
    smartMove(g);
    if (cfg.keepAuto && !busyUI(g.P)) setAuto(g, true);
  }
  setInterval(tick, TICK_MS);
  setInterval(function () {
    if (!enabled) return;
    var g = game();
    if (!g || g.me.downed) return;
    if (ylHold(g)) { kiteNow = 'Không lùi: đang giữ lệnh núi Yên Lãng'; return; }
    // Né chiêu cũng chạy ở vòng dày này: đòn vồ chỉ gồng 0.75s, vòng chính 150ms là quá thưa.
    if (tickDodge(g)) { kiteNow = 'Không lùi: đang né chiêu'; return; }
    if (st.healing) { kiteNow = 'Không lùi: đang đi thiền'; return; }
    if (st.harvest || (st.looting && st.looting.hold)) { kiteNow = 'Không lùi: đang thu / vận nhặt đồ'; return; }
    tickSwings(g);
    tickStrike(g);
    tickSwingConfirm();
    if (tickCtBurst(g)) return; // cướp tiêu: chiêu vừa hồi là xả vào xe
    if (tickBossBurst(g)) return; // vừa vung xong là tung chiêu, không chờ vòng chính
    tickKite(g);
  }, KITE_FAST_MS);

  function onNames() { try { return JSON.parse(localStorage.getItem('ttbot.onNames') || '{}') || {}; } catch (e) { return {}; } }
  function setEnabled(on) {
    var g0 = game();
    if (on && g0 && isJailed(g0)) {
      say('🚨 ĐANG BỊ GIAM THIÊN LAO! Vui lòng chờ hết hạn giam trước khi bật auto.');
      if (g0.P && g0.P.HUD && g0.P.HUD.setCaption) g0.P.HUD.setCaption('🚨 ĐANG BỊ GIAM THIÊN LAO!');
      refresh();
      return;
    }
    if (on) {
      st.jailedPanic = false;
      st.jailed = false;
    }
    enabled = on;
    var nm0 = g0 && myName(g0);
    if (nm0) { var O = onNames(); if (on) O[nm0] = 1; else delete O[nm0]; try { localStorage.setItem('ttbot.onNames', JSON.stringify(O)); } catch (e) { } }
    if (!on) {
      prioRestore();
      st.healing = false;
      st.healMoving = false;
      st.travel = null;
      st.dodging = false;
      st.kiting = false;
      st.harvest = null;
      st.looting = null;
      st.dc = null;
      dcDlg = null;
      st.ga = null;
      st.fa = null;
      st.fk = null;
      st.bh = null;
      st.bd = null;
      st.hon = null;
      st.honBuy = null;
      st.back = null;
      st.plan = null; st.vt = null; st.td = null; st.xc = null; st.tl = null; st.lt = null; st.sn = null; st.dd = null; st.gc = null; st.gaOverride = null; st.oneShot = null;
      st.ll = null; st.ht = null; st.llOpen = null; st.pin = null;
      var g = game();
      releaseTarget(g);
      if (g && g.sw.autoOn) g.P.Input.pressAutoToggle();
    }
    say(on ? 'Đã bật trợ thủ' : 'Đã tắt trợ thủ');
    refresh();
  }

  /* ================= Giao diện ================= */
  // Bố cục: thanh trạng thái (máu, linh lực, map, đang làm gì) → nút bật → công tắc nhanh →
  // 7 tab theo việc (Đánh · Hồi · Nhặt · Việc · Đi · Số · Log) → dòng thông báo cuối.
  var CSS = [
    ':host{all:initial}',
    '*{box-sizing:border-box;font-family:"Segoe UI",Tahoma,sans-serif}',
    '.panel{width:470px;max-width:calc(100vw - 16px);background:linear-gradient(180deg,#1b2318f7,#11170ff7);color:#e4ecd6;font-size:12px;',
    '  border:1px solid #4f6b3f;border-radius:12px;box-shadow:0 10px 32px #000c;overflow:hidden}',
    /* đầu bảng */
    '.head{display:flex;align-items:center;gap:7px;padding:7px 8px 7px 11px;background:#232d1d;cursor:move;user-select:none}',
    '.head b{font-size:13px;letter-spacing:.3px}',
    '.ver{color:#7f936e;font-size:10px}',
    '.dot{width:8px;height:8px;border-radius:50%;background:#6b6b6b;box-shadow:0 0 0 2px #0004}',
    '.dot.on{background:#7ee36b;box-shadow:0 0 7px #7ee36b}',
    '.sp{flex:1}',
    '.icon{background:none;border:0;color:#cfdcbf;font-size:14px;line-height:1;width:24px;height:24px;border-radius:6px;cursor:pointer}',
    '.icon:hover{background:#ffffff1a}',
    '.power{padding:4px 12px;border:1px solid #5d7a4a;border-radius:14px;cursor:pointer;font-weight:700;font-size:11px;letter-spacing:.4px;background:#3b4a31;color:#dfe9d2}',
    '.power:hover{filter:brightness(1.15)}',
    '.power.on{background:linear-gradient(180deg,#76c95f,#4f9a3e);border-color:#9be38a;color:#10200b}',
    /* trạng thái */
    '.status{padding:7px 11px 7px;border-bottom:1px solid #2f3b28}',
    '.bar{position:relative;height:14px;border-radius:7px;background:#3a1c1c;overflow:hidden}',
    '.bar.mp{height:6px;margin-top:3px;background:#1a2638}',
    '.bar i{position:absolute;inset:0 auto 0 0;width:0;background:linear-gradient(90deg,#b53a3a,#e2594a);transition:width .3s}',
    '.bar.mp i{background:linear-gradient(90deg,#2f6fb5,#5aa6ea)}',
    '.bar span{position:relative;display:block;text-align:center;font-size:10px;line-height:14px;color:#fff;text-shadow:0 1px 1px #000}',
    '.meta{display:flex;justify-content:space-between;align-items:center;gap:6px;margin-top:5px}',
    '.meta .map{color:#b8c9a6;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.chip{flex:none;padding:1px 8px;border-radius:9px;background:#333d2b;color:#cfe0bc;font-size:10.5px}',
    '.chip.go{color:#4ade80}.chip.warn{color:#facc15}.chip.bad{color:#f87171}',
    '.chip.go{background:#2f5a2a;color:#c9f7b8}.chip.warn{background:#5c4a1f;color:#ffe2a0}.chip.bad{background:#5a2424;color:#ffc4c4}',
    '.doing{margin-top:5px;padding:4px 7px;border-radius:6px;background:#0f140d;color:#cfe0bc;font-size:10.5px;',
    '  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-height:21px}',
    /* thân: điều hướng dọc + nội dung */
    '.body{display:flex;min-height:0}',
    '.nav{flex:none;width:78px;padding:4px 0 6px;background:#151b12;border-right:1px solid #2f3b28;max-height:66vh;overflow:auto}',
    '.nav::-webkit-scrollbar{width:4px}.nav::-webkit-scrollbar-thumb{background:#3c4b32;border-radius:2px}',
    '.ng{padding:7px 9px 2px;color:#66775a;font-size:9px;text-transform:uppercase;letter-spacing:.7px}',
    '.nav button{display:flex;align-items:center;gap:6px;width:100%;padding:5px 8px;background:none;border:0;border-left:3px solid transparent;',
    '  color:#9aab8a;cursor:pointer;font-size:11px;text-align:left}',
    '.nav button b{font-weight:400;font-size:13px;width:16px;text-align:center;flex:none}',
    '.nav button span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.nav button:hover{background:#ffffff08;color:#d6e4c6}',
    '.nav button.on{color:#effae2;background:#2b3a24;border-left-color:#7ec96a}',
    '.nav button.big{flex-direction:column;gap:2px;padding:9px 4px;text-align:center;font-size:10.5px;border-bottom:1px solid #222b1c}',
    '.nav button.big b{font-size:18px;width:auto}.nav button.big span{white-space:normal;line-height:1.2}',
    '.subtabs{display:flex;flex-wrap:wrap;gap:4px;padding:2px 8px 4px;border-bottom:1px solid #2c3826}',
    '.subtabs button{padding:4px 9px;border-radius:12px;border:1px solid #3a4a30;background:#1a2216;color:#a9bb98;font-size:11px;cursor:pointer}',
    '.subtabs button.on{background:#3b5530;border-color:#7ec96a;color:#effae2}',
    '.grptabs{display:flex;flex-wrap:wrap;gap:3px;margin:2px 0 7px}',
    '.grptabs button{padding:2px 7px;border-radius:9px;border:1px dashed #3a4a30;background:none;color:#93a684;font-size:10px;cursor:pointer;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.grptabs button.on{border-style:solid;border-color:#a9c094;color:#e8f3da;background:#2b3a24}',
    '.main{flex:1;min-width:0;display:flex;flex-direction:column}',
    '.search{padding:6px 8px 4px}',
    '.search input{width:100%;padding:5px 8px;background:#10150e;color:#e4ecd6;border:1px solid #3c4b32;border-radius:7px;font-size:11.5px;outline:none}',
    '.search input:focus{border-color:#7ec96a}',
    '.panes{max-height:calc(66vh - 34px);overflow:auto;padding:2px 8px 6px}',
    '.panes::-webkit-scrollbar{width:6px}.panes::-webkit-scrollbar-thumb{background:#3c4b32;border-radius:3px}',
    'section{display:none}',
    'section.on{display:block}',
    '.nores{display:none;padding:14px;text-align:center;color:#7f936e}',
    '.nores.on{display:block}',
    /* nhóm + dòng cài đặt */
    '.grp{margin-bottom:7px;padding:2px 9px 6px;border:1px solid #2c3826;border-radius:9px;background:#ffffff05}',
    '.gh{color:#a9c094;font-size:10.5px;font-weight:600;margin:6px 0 2px;text-transform:uppercase;letter-spacing:.6px}',
    '.row{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:5px 0;cursor:pointer;border-top:1px solid #ffffff06}',
    '.row:first-of-type{border-top:0}',
    '.row .txt{display:flex;flex-direction:column;min-width:0}',
    '.row .txt small{color:#7f936e;font-size:10px;line-height:1.35}',
    '.sub{display:flex;align-items:center;flex-wrap:wrap;gap:4px;padding:1px 0 6px 2px;color:#b7c6a7;font-size:11.5px}',
    '.tg{position:relative;flex:none;width:34px;height:18px}',
    '.tg input{opacity:0;width:0;height:0;position:absolute}',
    '.tg i{position:absolute;inset:0;border-radius:9px;background:#4a4f45;transition:.2s}',
    '.tg i:before{content:"";position:absolute;left:2px;top:2px;width:14px;height:14px;border-radius:50%;background:#e9eee3;transition:.2s}',
    '.tg input:checked+i{background:#5fae4c}',
    '.tg input:checked+i:before{transform:translateX(16px)}',
    '.seg{display:flex;flex-wrap:wrap;gap:4px;padding:2px 0 4px}',
    '.seg button{flex:1 1 auto;padding:4px 7px;border:1px solid #4a5c3d;background:#232c1e;color:#c5d4b5;border-radius:6px;cursor:pointer;font-size:11px}',
    '.seg button.on{background:#4f8a3f;border-color:#7ec96a;color:#fff}',
    'input[type=number]{width:52px;padding:2px 4px;background:#10150e;color:#e4ecd6;border:1px solid #4a5c3d;border-radius:5px;text-align:center}',
    '.txtin{width:100%;padding:5px 6px;margin:0 0 6px;background:#10150e;color:#e4ecd6;border:1px solid #4a5c3d;border-radius:6px;font-size:11.5px}',
    'select{width:100%;padding:5px;background:#10150e;color:#e4ecd6;border:1px solid #4a5c3d;border-radius:6px}',
    '.btns{display:flex;gap:6px;margin:6px 0 2px}',
    '.btn{flex:1;padding:6px;border:1px solid #5d7a4a;background:#2c3a24;color:#e4ecd6;border-radius:6px;cursor:pointer;font-size:11.5px}',
    '.btn:hover{filter:brightness(1.2)}.btn.pri{background:#4f8a3f;border-color:#7ec96a}.btn.ghost{background:none}',
    '.card{padding:7px 8px;border:1px dashed #4a5c3d;border-radius:7px;color:#b8c9a6;font-size:11px;line-height:1.5}',
    '.prow{display:flex;align-items:center;gap:5px;border:1px solid #2c3826;border-radius:7px;margin:3px 0;padding:0 4px;background:#141b11}',
    '.prow.drag{opacity:.4}.prow.over{border-color:#9fe07a}.phd{cursor:grab;color:#8fa37c;font-size:14px;padding:0 2px;user-select:none}',
    '.pno{color:#e8d9a8;font-size:11px;min-width:16px}.pbd{flex:1;min-width:0}.pud{display:flex;flex-direction:column;gap:1px}',
    '.pmv{background:#1d2618;color:#b8c9a6;border:1px solid #3a4a30;border-radius:4px;font-size:9px;line-height:1;padding:1px 4px;cursor:pointer}',
    '.btr{display:flex;gap:7px;align-items:flex-start;padding:5px 4px;border-bottom:1px solid #2c3826;font-size:11px;line-height:1.45;color:#d6e2c8}',
    '.btr.off{opacity:.55}.btic{flex:0 0 26px;min-height:24px;display:flex;flex-direction:column;gap:2px;align-items:center}.btic canvas{image-rendering:pixelated;width:24px;height:24px}',
    '.btb{flex:1;min-width:0}.btk{color:#6f7f62;margin-right:1px}.btk.on{color:#9fe07a}.bth{margin:8px 0 2px;font-weight:700;color:#e8d9a8;font-size:11.5px}',
    '.bti{width:16px;height:16px;image-rendering:pixelated;vertical-align:-3px;margin-right:2px}.btw.ok{color:#9fe07a}.btw.no{color:#f0a070}',
    '.note{padding:5px 8px;border-radius:6px;font-size:10.5px;margin:4px 0}',
    '.note.ok{background:#22401d;color:#c4eeb4}',
    '.kitenow{margin:2px 0 4px;padding:5px 7px;border-radius:6px;background:#0f140d;color:#cfe0bc;font-size:10.5px;line-height:1.4}',
    /* bật nhanh */
    '.quick{display:grid;grid-template-columns:repeat(3,1fr);gap:5px;padding:3px 0 2px}',
    '.quick button{padding:6px 3px;border:1px solid #3c4b32;background:#1d2519;color:#93a383;border-radius:7px;cursor:pointer;font-size:10.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.quick button.on{background:#2f5a2a;border-color:#6fbf5c;color:#e3ffd6}',
    '.quick button:hover{filter:brightness(1.2)}',
    /* log */
    '.klog{height:44vh;max-height:360px;overflow:auto;padding:4px 7px;border:1px solid #2f3b28;border-radius:7px;background:#0d110b;',
    '  font:10.5px/1.5 Consolas,monospace;color:#b8c9a6}',
    '.klog:empty:before{content:"Chưa có sự kiện — bật trợ thủ rồi đánh quái / làm việc";color:#6c7d5e}',
    '.klog div{padding:1px 0;border-bottom:1px solid #161d13}',
    '.klog b{color:#7ec96a;font-weight:400}.klog i{color:#78896a;font-style:normal}',
    '.klog .dc b{color:#e8c46a}.klog .loot b{color:#6ac7e8}.klog .net b{color:#b685ff}.klog .net{color:#d5c2ff}',
    /* chân bảng */
    '.log{padding:5px 11px 3px;color:#98b385;font-size:10.5px;border-top:1px solid #2f3b28;min-height:22px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.hint{color:#66775a;font-size:9.5px;text-align:center;padding:0 0 5px}',
    '.min .body,.min .hint{display:none}',
    /* bảng chiêu / thống kê */
    'table{width:100%;border-collapse:collapse;font-size:10.5px}',
    'th{color:#98aa86;font-weight:400;text-align:right;padding:2px 3px;border-bottom:1px solid #33402b}',
    'td{text-align:right;padding:3px;border-bottom:1px solid #26301f;white-space:nowrap}',
    'th:first-child,td:first-child{text-align:left}',
    'tr.best td{background:#2f5a2a88;color:#e9ffd9}',
    'tr.off td{color:#7d8a70}',
    '.kv{display:grid;grid-template-columns:auto 1fr;gap:2px 8px;font-size:11px}',
    '.kv b{font-weight:400;color:#98aa86}',
    '.why{margin-top:4px;color:#ffe2a0;font-size:11px}',
    /* nút tròn khi thu nhỏ */
    '.mini{display:none;width:34px;height:34px;border-radius:50%;border:1px solid #7ec96a;background:#26301f;color:#e4ecd6;',
    '  font-size:17px;line-height:1;cursor:pointer;box-shadow:0 3px 12px #000a}',
    '.mini.on{border-color:#7ee36b;box-shadow:0 0 8px #7ee36b}',
    '.cfgbox{width:100%;box-sizing:border-box;height:64px;margin-top:4px;background:#0d110b;color:#9fe07a;border:1px solid #4a5c3d;border-radius:5px;font:11px monospace;resize:vertical}',
    '.vh{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0}'
  ].join('\n');

  var PRIORITY = [['', 'Mặc định'], ['auto', 'Gần nhất'], ['quai', 'Quái'], ['boss', 'Boss'], ['mau', 'Máu thấp'], ['nguoi', 'PK người']];
  // Thanh điều hướng dọc: [nhóm, [[mã tab, biểu tượng, tên], …]].
  var NAV = [
    ['Chung', [['home', '🏠', 'Tổng quan'], ['fps', '⚡', 'FPS · Lag'], ['plan', '📅', 'Lịch treo'], ['cfg', '⚙', 'Cấu hình']]],
    ['Chiến đấu', [['fight', '⚔', 'Đánh'], ['bitich', '📖', 'Bí tịch'], ['dodge', '🌀', 'Né & lùi'], ['support', '✨', 'Trận · Bùa'], ['heal', '❤', 'Hồi phục']]],
    ['Boss & sự kiện', [['boss', '👑', 'Boss'], ['event', '☁', 'Thiên Đạo'], ['vetnut', '🌀', 'Vết Nứt'], ['bicanh', '🩸', 'Bí cảnh'], ['clan', '🏯', 'Hoạt động']]],
    ['Tổ đội', [['team', '👥', 'Tổ đội'], ['cuop', '🐎', 'Cướp tiêu']]],
    ['Việc', [['hon', '🏴', 'Hồn Phiên'], ['job', '📜', 'Việc ngày'], ['loot', '🎒', 'Nhặt · Thu'], ['move', '🧭', 'Di chuyển']]],
    ['Khác', [['stats', '📊', 'Số liệu'], ['log', '📝', 'Nhật ký'], ['tele', '📢', 'Telegram']]]
  ];
  var NAV_ICON = { 'Chung': '🏠', 'Chiến đấu': '⚔', 'Boss & sự kiện': '👑', 'Tổ đội': '👥', 'Việc': '📜', 'Khác': '📊' };
  function navGroupOf(tab) { for (var i = 0; i < NAV.length; i++) if (NAV[i][1].some(function (t) { return t[0] === tab; })) return i; return 0; }
  var TABS = [];
  NAV.forEach(function (gr) { gr[1].forEach(function (t) { TABS.push(t); }); });
  // Công tắc nhanh trên đầu bảng: [khoá cài đặt, nhãn, giải thích].
  var QUICK = [['keepAuto', '🤖 Auto', 'Giữ Tự Động luôn bật'], ['dodge', '🌀 Né chiêu', 'Né chiêu của địch'],
  ['kite', '↩ Đánh-lùi', 'Đánh rồi lùi'], ['autoLoot', '🧲 Nhặt đồ', 'Tự nhặt vật phẩm rơi'],
  ['healSit', '🧘 Thiền', 'Máu thấp thì ra chỗ an toàn thiền'], ['alwaysFly', '🕊 Bay', 'Luôn bay (trừ lúc thiền)'],
  ['bossHunt', '👑 Đi boss', 'Tự đi đánh boss thế giới theo giờ'], ['bossBurst', '💥 Xả chiêu', 'Xả chiêu liên tục vào boss'],
  ['tdHunt', '🐫 Thương Đội', 'Săn Thương Đội theo tin Thiên Đạo'], ['honSell', '🏴 Hồn dư', 'Rảnh thì săn số dư Phàm Hồn để bán'],
  ['autoTran', '🔯 Trận bàn', 'Tự dựng trận khi đánh'], ['ctRun', '🐎 Cướp tiêu', 'Tổ đội cướp tiêu ở Thung Lũng'], ['llRun', '🏯 Lãm Làng', 'Tự vào Lãm Làng khi tông mở'], ['vnRun', '🌀 Vết Nứt', 'Tự vào Vết Nứt Không Gian'],
  ['planRun', '📅 Lịch', 'Bật lịch treo máy'], ['fishRun', '🎣 Câu cá', 'Tự câu cá săn Linh Ngư'], ['dcRun', '🌿 Dược Công', 'Tự chạy Dược Công'], ['stayFarm', '📍 Giữ bãi', 'Lạc ra khỏi bãi thì tự về']];
  var LOG_FILTERS = [['all', 'Tất cả'], ['fight', 'Chiến đấu'], ['loot', 'Nhặt / thu'], ['dc', 'Việc & lịch'], ['net', 'Mạng / Server']];

  function toggle(key, label, hint) {
    return '<label class="row"><span class="txt"><span>' + label + '</span>' + (hint ? '<small>' + hint + '</small>' : '') +
      '</span><span class="tg"><input type="checkbox" data-key="' + key + '"><i></i></span></label>';
  }
  function seg(key, opts) {
    return '<div class="seg" data-seg="' + key + '">' + opts.map(function (o) {
      return '<button data-v="' + o[0] + '">' + o[1] + '</button>';
    }).join('') + '</div>';
  }
  function numIn(key, min, max) { return '<input type="number" data-num="' + key + '" min="' + min + '" max="' + max + '">'; }
  function grp(title, body) { return '<div class="grp"><div class="gh">' + title + '</div>' + body + '</div>'; }

  var HTML =
    '<div class="panel">' +
    '<div class="head" id="head"><span class="dot" id="dot"></span><b>Trợ thủ</b><span class="ver">v' + VERSION + '</span>' +
    '<span class="sp"></span><button class="power" id="power">BẬT</button>' +
    '<button class="icon" id="min" title="Thu gọn">▾</button><button class="icon" id="hide" title="Thu nhỏ (F8)">✕</button></div>' +
    '<div class="status">' +
    '<div class="bars"><div class="bar"><i id="hpbar"></i><span id="hptext">—</span></div><div class="bar mp" title="Linh lực"><i id="mpbar"></i></div></div>' +
    '<div class="meta"><span class="map" id="mapname">Chưa vào game</span><span class="chip" id="state">Đang tắt</span><span class="chip" id="fpsChip">-- FPS</span><span class="chip" id="netChip" title="Gói tin máy chủ đã bắt">📡 0 gói</span></div>' +
    '<div class="doing" id="doing">—</div>' +
    '</div>' +
    '<div class="body">' +
    '<nav class="nav">' + NAV.map(function (gr, i) {
      return '<button class="big" data-grp="' + i + '"><b>' + (NAV_ICON[gr[0]] || gr[1][0][1]) + '</b><span>' + gr[0] + '</span></button>';
    }).join('') + '</nav>' +
    '<div class="main">' +
    '<div class="search"><input type="text" id="q" placeholder="🔍 Tìm cài đặt… (vd: boss, né, hồn, trận)"></div>' +
    '<div class="subtabs" id="subtabs"></div>' +
    '<div class="panes">' +

    // ---- Tổng quan ----
    '<section data-pane="home">' +
    grp('Bật nhanh', '<div class="quick" id="quick">' + QUICK.map(function (q) {
      return '<button data-quick="' + q[0] + '" title="' + q[2] + '">' + q[1] + '</button>';
    }).join('') + '</div>') +
    grp('Đang bật', '<div class="card" id="homeOn">—</div>') +
    grp('Sắp tới', '<div class="card" id="homeNext">—</div>') +
    grp('Bãi farm', '<div class="card" id="homeFarm">—</div>' +
      '<div class="btns"><button class="btn pri" id="setFarm3">📍 Lưu chỗ đang đứng làm bãi farm</button></div>') +
    '</section>' +

    // ---- FPS · Lag ----
    '<section data-pane="fps">' +
    grp('Tốc độ khung hình (FPS)',
      toggle('fpsUnlock', 'Khoá FPS theo mức chọn', 'Gỡ ép 30 FPS khi treo máy (8 giây) / đông người (≥ 15 người), ép 10 FPS khi tiết kiệm pin · giữ đúng mức FPS chọn bên dưới') +
      '<div class="sub">Mức FPS</div>' +
      seg('fpsTarget', [['120', '120'], ['60', '60'], ['30', '30 (nhẹ máy)'], ['0', 'Tối đa']]) +
      '<div class="sub">Treo nhiều nhân vật cùng lúc thì chọn 30 cho nhẹ máy</div>' +
      toggle('antiAutoDowngrade', 'Chống game tự hạ đồ hoạ', 'Không để game tự tụt đồ hoạ khi giật')) +
    grp('Giảm lag khi đông người / đánh boss',
      toggle('hideRemoteSkills', 'Ẩn chiêu của người khác', 'Không vẽ chiêu người chơi khác · VẪN hiện đủ chiêu và vòng đỏ của boss để né') +
      toggle('hideImpactFx', 'Tắt hiệu ứng chém trúng của người khác', 'Không vẽ tia lửa / khói khi người khác đánh trúng, chống dồn âm thanh') +
      '<div class="sub">Số sát thương nhảy (sát thương mình nhận luôn hiện)</div>' +
      seg('hideDamage', [['remote', 'Chỉ của mình'], ['throttle', 'Giảm tải'], ['all', 'Ẩn hết'], ['off', 'Hiện hết']]) +
      toggle('hideWeatherFx', 'Tắt thời tiết & hiệu ứng map', 'Lá rơi, mưa, gợn nước, khói bụi') +
      '<div class="sub">Hiện người chơi khác</div>' +
      seg('playerVis', [['default', 'Theo game'], ['none', 'Ẩn hết'], ['party', 'Chỉ đồng đội'], ['all', 'Hiện hết']])) +
    '</section>' +

    // ---- Lịch treo máy ----
    '<section data-pane="plan">' +
    grp('Treo máy theo lịch',
      toggle('planRun', 'Bật lịch treo máy', 'Làm lần lượt các việc được chọn · xong hết thì về chỗ farm · boss / hoạt động / Thương Đội vẫn chen ngang khi tới') +
      '<div class="card" id="planNow">—</div>' +
      '<div class="sub">Việc trong lịch: làm từ trên xuống · kéo ☰ (hoặc bấm ▲ ▼) để xếp việc nào làm trước</div>' +
      '<div id="planList">' + planList().map(function (j, i) {
        return '<div class="prow" draggable="true" data-pj="' + j.id + '"><span class="phd" title="Kéo để đổi thứ tự">☰</span><b class="pno">' + (i + 1) + '.</b>' +
          '<div class="pbd">' + toggle('plan_' + j.id, j.ten, '<span data-planinfo="' + j.id + '">—</span>') + '</div>' +
          '<span class="pud"><button class="pmv" data-pmv="-1" title="Lên">▲</button><button class="pmv" data-pmv="1" title="Xuống">▼</button></span></div>';
      }).join('') + '</div>' +
      '<div class="sub">Nhặt nguyên liệu mỗi lượt tối đa ' + numIn('planGatherMin', 1, 240) + ' phút</div>') +
    grp('Chỗ farm khi xong việc',
      '<div class="card" id="planHome">—</div>' +
      '<div class="btns"><button class="btn pri" id="setFarm2">📍 Lưu chỗ này làm chỗ farm</button></div>') +
    grp('Chen ngang khi tới', '<div class="card" id="planInt">—</div>') +
    '</section>' +

    // ---- Cấu hình ----
    '<section data-pane="cfg">' +
    grp('Xuất / nhập cấu hình', '<div class="sub">Chép toàn bộ cài đặt sang nhân vật khác: Xuất ở máy này → dán vào ô ở máy kia → Nhập</div>' +
      '<label class="row"><span class="txt"><span>Kèm bãi farm</span></span><span class="tg"><input type="checkbox" id="cfgFarm"><i></i></span></label>' +
      '<label class="row"><span class="txt"><span>Kèm token Telegram</span><small>Chỉ bật khi chép sang máy của mình · token lọt ra ngoài thì người khác điều khiển được bot</small></span><span class="tg"><input type="checkbox" id="cfgTg"><i></i></span></label>' +
      '<textarea class="cfgbox" id="cfgBox" spellcheck="false" placeholder="Dán cấu hình vào đây rồi bấm Nhập"></textarea>' +
      '<div class="btns"><button class="btn" id="cfgOut">📤 Xuất (chép)</button><button class="btn" id="cfgSaveF">💾 Lưu file</button><button class="btn pri" id="cfgIn">📥 Nhập</button>' +
      '<label class="btn" for="cfgFile">📂 Mở file</label><input type="file" id="cfgFile" accept=".json,.txt" class="vh"></div>' +
      '<div class="sub" id="cfgMsg"></div>') +
    '</section>' +

    // ---- Đánh ----
    '<section data-pane="fight">' +
    grp('Tự chiến',
      toggle('keepAuto', 'Giữ Tự Động luôn bật', 'Bị tắt thì tự bật lại') +
      toggle('speed125', 'Luôn duy trì tốc độ di chuyển 1.25x', 'Tăng 25% tốc độ chạy toàn thời gian, hỗ trợ áp sát mục tiêu, né chiêu và săn boss/thương đội nhanh nhất') +
      '<div class="sub">Ưu tiên mục tiêu</div>' + seg('priority', PRIORITY) +
      toggle('smartTarget', 'Chọn con có lời nhất', 'Khi ưu tiên "Gần nhất": EXP / thời gian, tránh con giữa bầy')) +
    grp('Chiêu thức',
      toggle('optimize', 'Tự chọn chiêu tối ưu', 'Theo sát thương có ích và linh lực') +
      '<div class="sub">Dồn sát thương khi linh lực ≥ ' + numIn('mpFull', 1, 100) + ' %</div>' +
      '<div class="sub">Chỉ đánh thường khi &lt; ' + numIn('mpReserve', 1, 99) + ' % (trừ boss)</div>' +
      toggle('noOverkill', 'Không phí chiêu lên quái sắp chết')) +
    grp('Vũ khí đánh lan',
      toggle('splashPos', 'Chọn chỗ đứng trúng nhiều con', 'Tự đo tầm lan của vũ khí qua số con máy chủ báo trúng mỗi nhát') +
      '<div class="sub">Tầm lan đặt tay ' + numIn('splashManual', 0, 400) + ' px (0 = tự đo)</div>' +
      '<div class="card" id="splashInfo">—</div>' +
      '<div class="btns"><button class="btn ghost" id="splashReset">Đo lại vũ khí này</button></div>') +
    '</section>' +

    // ---- Né & lùi ----
    '<section data-pane="bitich">' +
    grp('Bộ bí tịch dựng sẵn',
      '<div class="sub">Tự phân tích mọi bí tịch của game, đối chiếu cuốn bạn đang có, dựng bộ 8 chiêu (★ = tick Tự Động) + 5 bị động cho từng việc. Bấm Dùng: chiêu chủ động vào Combo "TT·…" trong menu Tự Động (Combo của bạn giữ nguyên), bị động thay luôn.</div>' +
      toggle('btAuto', 'Tự đổi bộ theo việc đang làm', 'Có người thù địch gần = PK · đánh boss / sự kiện = Săn boss · Vết Nứt / Lãm Làng có tổ đội = Tổ đội · còn lại Farm (giữ ≥ 3 giây mới đổi, cách nhau ≥ 20 giây; PK đổi ngay)') +
      toggle('autoHoaThan', 'Tự dùng Bí Tịch Biến Hình (Kim Cương / Xích Ma / Thạch Giáp) khi PK, Boss hoặc máu thấp', 'Tự kích hoạt khi có người thù địch <= 350px, khi đánh Boss <= 450px hoặc khi máu <= 50%') +
      '<div id="btPlans">—</div>') +
    grp('Toàn bộ bí tịch của game', '<div class="card" id="btAll">—</div>') +
    '</section>' +

    '<section data-pane="dodge">' +
    grp('Né chiêu',
      toggle('dodge', 'Né chiêu của địch', 'Ra khỏi vùng chiêu sắp nổ, vồ, tuyệt chiêu, chiêu boss (cả khi bật ẩn chiêu boss)') +
      toggle('dodgePlayers', 'Né cả chiêu người chơi khác') +
      '<div class="sub">Cách mép vùng chiêu ' + numIn('dodgeMargin', 5, 200) + ' px</div>') +
    grp('Đánh rồi lùi (hit &amp; run)',
      toggle('kite', 'Đánh rồi lùi', 'Ra đòn xong lùi khỏi tầm với của địch · đánh boss thế giới / Tà Soái thì không lùi') +
      '<div class="sub">Đứng ngoài tầm với ' + numIn('kiteGap', 1, 200) + ' px</div>' +
      '<div class="sub">Giữ cách mục tiêu ' + numIn('keepDist', 0, 400) + ' px · 0 = tự tính (đứng ngoài tầm địch, trong tầm chiêu / vũ khí) · đặt xa hơn tầm chiêu của mình thì không đánh tới</div>' +
      '<div class="sub">Đứng ngoài sau mỗi đòn ' + numIn('kiteOut', 50, 3000) + ' ms</div>' +
      '<div class="kitenow" id="kiteNow">—</div>') +
    '</section>' +

    // ---- Trận · Bùa · Triệu hồi ----
    '<section data-pane="support">' +
    grp('Trận bàn (từ Trúc Cơ)',
      toggle('autoTran', 'Tự dựng trận khi đánh', 'Cần có trận bàn trong túi · tốn Linh Thạch phí dựng / duy trì và linh lực kích hoạt như bấm tay · mỗi lúc một trận') +
      toggle('tranOnlyBossTd', 'Chỉ dùng khi săn Boss / Thương Đội / Thú Xổng', 'Mọi hoạt động khác (farm quái thường, biến dị, hoạt động...) tuyệt đối không dùng để tránh tốn Linh Thạch') +
      toggle('tran_tu_linh', '· Tụ Linh Trận', 'Hồi linh lực quanh mình · dựng khi đang đánh mà linh lực thấp') +
      '<div class="sub">Dựng Tụ Linh khi linh lực &lt; ' + numIn('tranMp', 5, 95) + ' %</div>' +
      toggle('tran_liet_hoa', '· Liệt Hỏa Trận', 'Đốt tối đa 4 con trong vòng 96px') +
      toggle('tran_loan_loi_hoa', '· Loạn Lôi Hỏa Trận', 'Sét gây choáng · chờ 5s mới đánh') +
      toggle('tran_tu_tuong', '· Tứ Tượng Trận', 'Từ Kết Đan') +
      toggle('tran_dao_gia', '· Đạo Gia Bát Quái Trận', 'Chính Đạo') +
      toggle('tran_ma_dao', '· Ma Đạo Cửu U Trận', 'Ma Đạo') +
      '<div class="sub">Trận sát thương: boss thì luôn dựng · quái thường khi có từ ' + numIn('tranMobs', 1, 10) + ' con trong vòng trận</div>') +
    grp('Bùa tự động',
      toggle('autoShield', 'Kim Long / Kim Giáp khi máu thấp', 'Chỉ khi đang bị mất máu · Kim Long trước nếu dùng được · Kim Quang Cự Kiếm khoá mình cũng dùng') +
      '<div class="sub">Dùng khi máu &lt; ' + numIn('shieldHp', 5, 90) + ' %</div>' +
      toggle('autoMpTal', 'Thanh Tâm khi cạn linh lực', 'Đang đánh mà linh lực &lt; 15% (đánh boss: &lt; 40%)') +
      toggle('autoHaste', 'Tốc Hành khi chạy', 'Chạy ra chỗ thiền hoặc né chiêu xa') +
      toggle('autoDash', 'Thổ Độn khi không kịp né / bị trói', 'Lướt theo đường thoát đã tính')) +
    grp('Khôi Lỗi / Thi Khôi',
      toggle('autoKhoiLoi', 'Tự triệu hồi khi đánh', 'Cần Trúc Cơ và có khôi lỗi trong túi · không gọi lúc làm Dược Công / săn hồn') +
      seg('khoiLoiPref', [['auto', 'Tự động'], ['dps', 'Ra đòn nặng'], ['tank', 'Chịu đòn']])) +
    '</section>' +

    // ---- Hồi phục ----
    '<section data-pane="heal">' +
    grp('Thiền hồi máu',
      toggle('healSit', 'Máu thấp → ra chỗ an toàn thiền', 'Ngoài tầm quái hung hăng và tầm bắn của trụ') +
      '<div class="sub">Ngồi khi &lt; ' + numIn('healLow', 5, 90) + ' % · đứng khi ≥ ' + numIn('healHigh', 20, 100) + ' %</div>' +
      '<div class="sub">Cách quái ≥ ' + numIn('healSafe', 50, 800) + ' px rồi mới ngồi</div>' +
      toggle('healEarly', 'Rút sớm theo máu đang mất / giây', 'Tính đủ thời gian chạy ra trước khi máu cạn')) +
    grp('Hồi sinh · ăn uống',
      toggle('autoRevive', 'Tự hồi sinh khi gục') +
      seg('reviveMode', [['spot', 'Tại chỗ (còn lượt)'], ['home', 'Về làng']]) +
      toggle('autoEat', 'Tự ăn khi hết no')) +
    grp('Phi hành · chạy',
      toggle('alwaysFly', 'Luôn bay', 'Trừ lúc thiền, câu cá, chặt cây, vận thu, áp tiêu') +
      toggle('reFly', 'Thiền xong bay lại', 'Nếu lúc ngồi đang bay') +
      toggle('alwaysRun', 'Luôn chạy (Shift)')) +
    '</section>' +

    // ---- Boss ----
    '<section data-pane="boss">' +
    grp('Tự đi đánh boss thế giới',
      toggle('bossHunt', 'Đi đánh theo giờ', 'Theo lịch boss toàn máy chủ · lên đường sớm và đứng chờ boss ra · khu không có boss thì tự đổi khu · xong về chỗ farm') +
      '<div class="sub">Lên đường khi boss sắp ra trong ' + numIn('bossLead', 0, 900) + ' giây</div>' +
      BOSS_TABLE.map(function (b) { return toggle('bh_' + b.type, '· ' + (BH_NAMES[b.type] || b.type), '<span data-bhinfo="' + b.type + '">—</span>'); }).join('')) +
    grp('Dồn sát thương',
      toggle('bossFocus', 'Có boss gần thì nhắm boss', 'Đánh cho đủ ngưỡng nhận đồ (máy chủ báo sát thương của mình)') +
      toggle('bossBurst', 'Xả chiêu liên tục vào boss (mọi loại boss)', 'Lập chuỗi chiêu tối ưu: thử mọi thứ tự 4 chiêu tới (hồi chiêu riêng, nhịp chung 1,2 giây, Lôi Chưởng chen giữa) lấy chuỗi sát thương cao nhất · chiêu mạnh sắp hồi thì chờ · thiếu tầm thì bước sát vào · vẫn giữ chiêu kết liễu, vẫn né chiêu') +
      toggle('bossAllSkills', '· Chọn trong mọi chiêu đã học', 'Kể cả chiêu chưa tick Tự Động (đánh boss và lúc dồn sát thương)') +
      toggle('bossMaxDmg', 'Boss thế giới: dồn tối đa', 'Không lùi · đánh không ra sát thương thì hạ hộ vệ trước · Kim Ô / Hoả Phù · Thanh Tâm khi linh lực &lt; 40% · gượng dậy ngay') +
      toggle('bossNoSit', 'Boss thế giới: không ngồi thiền', 'Không bao giờ ngồi thiền khi đánh boss · dồn tối đa sát thương để tăng tỉ lệ nhận đồ') +
      toggle('tmTru', 'Đánh Trụ Trấn Mạch (Mỏ Linh Thạch)', 'Chỉ bật khi tông đang chiếm mạch và đã cắm cờ Đỏ · tắt thì auto không bao giờ nhắm trụ (đánh không được mà cứ lao vào)')) +
    grp('Kết liễu (last-hit)',
      toggle('lastHitBoss', 'Giữ chiêu mạnh nhất kết liễu boss', 'Máu boss ≤ chiêu mạnh nhất × hệ số thì tung, sắp tới thì giữ chiêu') +
      toggle('lastHitDouble', 'Tính combo hai chiêu mạnh nhất', 'Tung chiêu nhì trước, chiêu nhất kết liễu') +
      toggle('lastHitScan', 'Quét & chuyển mục tiêu cướp Last-Hit', 'Tự động phát hiện Boss / Xổng chuồng sắp gục (≤ 25% máu) để chuyển mục tiêu dứt điểm giành 100% đồ rơi') +
      toggle('autoHpMargin', 'Hệ số an toàn tự tính', 'Theo máu boss tụt mỗi giây và số người quanh boss') +
      '<div class="sub">Hệ số đặt tay ' + numIn('hpMarginPct', 100, 200) + ' % (khi tắt tự tính)</div>') +
    grp('Ưu tiên boss / hoạt động',
      '<div class="sub">Tới giờ boss hoặc vào hoạt động: gác hết mọi việc treo khác, xong mới làm tiếp</div>' +
      toggle('prioOpt', 'Tạm bật cài đặt tối ưu', 'Nhắm boss, dồn sát thương, xả chiêu, trận bàn, không thiền, né chiêu, gượng dậy ngay, tự ăn, tự nhặt, bùa, khôi lỗi · xong trả lại cài đặt cũ') +
      toggle('prioVt', 'Ưu tiên cả khi đang áp tiêu dở', 'Bỏ xe tiêu lại để đi boss / hoạt động (xe có thể bị cướp, mất phí) · tắt thì giao tiêu xong mới đi')) +
    grp('Radar boss', '<div class="card" id="radarInfo">—</div>' +
      toggle('bossRadar', 'Hỏi lịch boss toàn máy chủ', 'Như bảng Hoạt Động, 30 giây một lần')) +
    '</section>' +

    // ---- Thiên Đạo ----
    '<section data-pane="event">' +
    grp('Thương Đội',
      toggle('tdHunt', 'Săn Thương Đội', 'Thiên Đạo báo map + khu → đi thẳng đúng map, đổi đúng khu, tuần tìm đoàn rồi đuổi theo tới khi hạ (không treo chờ, không dò khu) · Ma Đạo: Tiêu Sư / Thương Nhân lấy Oán Hồn · Chính Đạo: Kiếp Tặc lấy Hiệp Nghĩa Lệnh · chỉ khi đang cần') +
      '<div class="card" id="tdInfo">—</div>') +
    grp('Quái biến dị',
      toggle('bdHunt', 'Săn quái biến dị', 'Thiên Đạo báo con biến dị xuất hiện → tới map (có khu thì sang thẳng khu đó), đánh, xong về · đòn cắn mạnh gấp 5') +
      '<div class="card" id="bdInfo">—</div>') +
    grp('Yêu thú xổng chuồng',
      toggle('xcHunt', 'Săn yêu thú xổng chuồng', 'Thiên Đạo báo "… vừa xổng chuồng tại <map>, khu N" → tới đúng khu, tuần khắp map, hạ hết · đồ chỉ rơi cho người kết liễu') +
      '<div class="card" id="xcInfo">—</div>') +
    grp('Nhật ký Thiên Đạo',
      '<div class="sub">Tự ghi mọi tin, lưu lại giữa các lần tải trang</div>' +
      '<div class="card" id="tdnInfo">—</div>' +
      '<div class="btns"><button class="btn ghost" id="tdnCopy">📋 Sao chép nhật ký</button><button class="btn ghost" id="tdnClear">Xoá nhật ký</button></div>') +
    '</section>' +

    // ---- Hoạt động ----
    '<section data-pane="clan">' +
    grp('Bí Cảnh Lãm Làng',
      toggle('llRun', 'Tự vào Lãm Làng', 'Tông mở lượt (mỗi ngày một lượt) thì tự vào · tự chia tuyến với trợ thủ khác · Huyết Ấn / Xích / Trận Nhãn tự phối hợp · có Tà Soái thì dồn Tà Soái') +
      '<div class="sub">Thệ Nguyện</div>' + seg('llThe', [['kiem', 'Liệt Kiếm +15%'], ['xuan', 'Hồi Xuân'], ['menh', 'Hộ Mệnh']]) +
      '<div class="sub">Làm tuyến nào trước</div>' + seg('llTuyen', [['auto', 'Tự chia'], ['lao', 'Cổng Đông (lồng)'], ['tru', 'Đài Đá (trụ)']]) +
      '<div class="card" id="llInfo">—</div>' +
      '<div class="btns"><button class="btn" id="llOpenBtn">🏯 Mở Lãm Làng (Tông Chủ / Trưởng Lão)</button></div>') +
    grp('Vạn Hoang Chiến Trường',
      toggle('hlRun', 'Vạn Hoang Chiến Trường (Sinh tồn)', 'Tự ghi danh, né bão độc, loot rương/Huyết Lan, ẩn thân bụi rậm & tự vệ PK kết liễu')) +
    grp('Sỹ Sách Điện (tối Thứ Năm 20:16)',
      toggle('htRun', 'Tự vào Sỹ Sách Điện', 'Tự tới Thủ Điện ở Miếu Ông Trường Con · Ải 1 gom Ngọc Phù · Ải 2 phá Trụ Băng / Hoả · Ải 3 đánh Sỹ Sách Đỉnh · từ Ải 3 các tông PK nhau') +
      toggle('htMatThat', '· Vào Mật Thất khi vòng xoáy tím mở', 'Đánh Lôi Thú') +
      '<div class="card" id="htInfo">—</div>') +
    grp('Tam Lộ Tranh Phong (tối Thứ Tư 21h)',
      toggle('tlRun', 'Tự ghi danh và đánh', 'Tự ghi danh, bấm "Chơi luôn!" · trong trận tự chọn việc theo tình hình: giao tranh cùng đồng đội (dồn địch máu thấp, thả diều nếu đánh xa), bị đông hơn thì lùi về trụ, giữ trụ / nhà, gom Cổ Long / Baron, đường vắng thì dọn rừng, cuối trận đi theo đội · không vào tầm trụ địch khi thiếu lính đỡ · máu thấp về thành / suối · xong về chỗ farm') +
      toggle('tlJungle', 'Đi rừng', 'Dọn bãi rừng phe mình (bùa trước khi thiếu), gom Cổ Long / Baron, vào giao tranh khi đồng đội đánh · tắt: đi đường, đường vắng thì dọn rừng gần') +
      '<div class="sub">Đường</div>' + seg('tlLane', [['a', 'Tự chọn'], ['0', 'Thượng'], ['1', 'Trung'], ['2', 'Hạ']]) +
      '<div class="sub">Về suối khi máu &lt; ' + numIn('tlBackHp', 10, 80) + ' %</div>' +
      '<div class="card" id="tlInfo">—</div>') +
    grp('Tranh Đoạt Linh Thụ (tối Thứ Ba · Thứ Bảy 20:16)',
      toggle('ltRun', 'Tự ghi danh và đánh', '20:00–20:16 tự ghi danh · đã ghi danh thì 90 giây trước khoá sổ đứng chờ (vắng / bận là mất suất) · trong trận: giữ cây (đủ góp mặt), máu thấp về hồi, Thụ Tâm 2 phút cuối, nối rễ bị cắt, đánh địch quanh mình, không đuổi vào sân nhà địch') +
      '<div class="card" id="ltInfo">—</div>') +
    '</section>' +

    // ---- Vết Nứt ----
    '<section data-pane="vetnut">' +
    grp('Vết Nứt Không Gian (mỗi tối 18:00–23:00)',
      toggle('vnRun', 'Tự vào Vết Nứt Không Gian', 'Thiên Đạo báo vết nứt mở ở Thung Lũng / Long Uyên → tới đúng chỗ bước vào · hạ Hộ Môn mở cửa · lối báo THÔNG thì đi thẳng, bỏ lối CỤT, chưa rõ thì đánh boss canh lối gần nhất · đứng trụ ấn còn trống · cửa thật mở thì đánh Hòm · Hòm vỡ nhặt đồ quý trước, cầm đồ thì ở yên trong Phòng Hòm né người lạ cho đủ 20 giây') +
      toggle('vnBuy', '· Tự mua Hư Không Lệnh khi hết vé', 'Hồng Tỷ (Chân Núi Tản Viên) · giá theo game') +
      '<div class="sub">Giữ sẵn ' + numIn('vnTicketKeep', 1, 20) + ' vé</div>' +
      toggle('vnHomHold', '· Cầm đồ Hòm thì đứng xa người lạ', 'Trong Phòng Hòm được PK sau khi Hòm vỡ · gục là văng đồ') +
      '<div class="card" id="vnInfo">—</div>') +
    '</section>' +

    // ---- Bí cảnh ----
    '<section data-pane="bicanh">' +
    grp('Huyết Xích Cấm Địa (đi một mình được)',
      toggle('hxRun', 'Tự đi Huyết Xích Cấm Địa', 'Tới nữ tu Miếu Hoang đăng ký (100 Linh Thạch/lượt, Luyện Khí 7+) · tầng 1–2: quét hết quái (cả đầu đàn) cho tan phong ấn rồi hái Cổ Bích Mộc / Trấn Thần Thạch / Địa Linh Hóa Quả · tầng 3: hạ U Minh Cự Mãng, nhặt đồ rơi, hái Trúc Cơ Thảo · đi lần lượt các lượt còn trong ngày') +
      toggle('hxLeave', '· Xong 3 tầng thì rời ngay', 'Không chờ hết 15 phút → đi lượt kế sớm') +
      '<div class="sub">Giữ lại ít nhất ' + numIn('hxKeep', 0, 1000000) + ' Linh Thạch</div>' +
      '<div class="card" id="hxInfo">—</div>') +
    grp('Yên Lãng Sơn (luật game: tổ đội 2–6 người)',
      toggle('ylRun', 'Tự đi Yên Lãng Sơn', 'Đội trưởng tự đăng ký ở nữ tu Miếu Hoang, thành viên đứng chờ ở đó · lượt còn mở thì vào lại · nghe lệnh núi: Tĩnh thì đứng yên không đánh, Đảo Âm thì chạy · né vòng chiêu quái / Tộc Trưởng · hạ 2 Tuần Vệ → hái 3 bụi linh thảo → đổ 3 Trấn Sơn Bia → Hộ Vệ → Tộc Trưởng · thắng thì nhặt đồ rồi rời') +
      '<div class="card" id="ylInfo">—</div>') +
    '</section>' +

    // ---- Tổ đội ----
    '<section data-pane="team">' +
    grp('Tổ đội trợ thủ',
      toggle('teamOn', 'Tự lập tổ đội với các nhân vật cùng dùng trợ thủ', 'Người đầu danh sách làm đội trưởng: thấy đồng đội ở gần thì mời · người khác tự nhận lời · Vết Nứt: cả đội theo lối đội trưởng, 3 người chia đúng 3 trụ ấn (tự mở cửa), Hòm vỡ mỗi người nhặt món gần mình, cầm đồ thì đứng gần nhau · mở chung một trình duyệt thì báo cho nhau trực tiếp') +
      '<div class="sub">Tên các nhân vật (cách nhau dấu phẩy, người đầu là đội trưởng)</div>' +
      '<input type="text" class="txtin" data-text="teamNames" placeholder="vd: TenNhanVat1, TenNhanVat2, TenNhanVat3">' +
      '<div class="card" id="teamInfo">—</div>') +
    '</section>' +

    // ---- Cướp tiêu ----
    '<section data-pane="cuop">' +
    grp('Tổ đội cướp tiêu (Bãi Đá → Thung Lũng)',
      toggle('ctRun', 'Bật tổ đội cướp tiêu', 'Cắm cờ tổ đội (cùng màu là đồng minh) · tự chọn chỗ chờ trên đường xe (Bãi Đá / Mỏ Linh Thạch / Thung Lũng) đủ thời gian cho số người đang có đánh vỡ xe, xe qua thì bám theo, qua cổng thì đuổi theo · hạng cao trước · ai cướp được thì kéo về Bảnh Tiên Sinh, cả đội đi kèm đánh người chơi thù địch tới gần · dùng chung danh sách Tổ đội trợ thủ bên dưới') +
      toggle('ctCap', '· Chỉ khi đã đủ trần Linh Thạch ngày', 'Thưởng giao xe không tính vào trần · tắt thì đi cướp ngay trong giờ Vận Tiêu') +
      '<div class="sub">Màu cờ tổ đội · nhóm trưởng (tên đầu danh sách Tổ đội trợ thủ) chọn, các thành viên tự cắm theo màu nhóm trưởng</div>' +
      seg('ctFlag', [['vang', '🟨 Vàng'], ['lam', '🟦 Lam'], ['luc', '🟩 Lục'], ['den', '⬛ Đen']]) +
      '<div class="sub">Chỗ đứng chờ xe · Tự tính: lùi xa dần khi ít người / xe nặng cho đủ thời gian đánh vỡ · chọn map thì đứng đúng chỗ đó (bảng trạng thái báo nếu không đủ thời gian)</div>' +
      seg('ctCampMap', [['', '🧮 Tự tính'], ['bai_da_hang_gio', 'Bãi Đá'], ['mo_linh_thach', 'Mỏ Linh Thạch'], ['thach_phong_thung_lung', 'Thung Lũng']]) +
      seg('ctCampPos', [['dau', '⏮ Đầu map (cổng xe vào)'], ['giua', '⏺ Giữa map'], ['cuoi', '⏭ Cuối map']]) +
      '<div class="sub">Loại tiêu sẽ cướp (bỏ chọn thì gặp xe loại đó cũng không đánh)</div>' +
      toggle('ctH_trang', '⬜ Tiêu Kỳ Trắng', 'Máu ít nhất · thưởng thấp nhất') +
      toggle('ctH_luc', '🟩 Tiêu Kỳ Lục', '') +
      toggle('ctH_do', '🟥 Tiêu Kỳ Đỏ', '') +
      toggle('ctH_vang', '🟨 Tiêu Kỳ Vàng', 'Máu nhiều nhất · thưởng cao nhất · đi chậm nhất') +
      '<div class="sub">Cờ đen (Chiến Đấu): đánh được mọi người đang đeo cờ · các màu khác: khác màu mới đánh nhau</div>' +
      '<div class="sub">Khu camp ' + numIn('ctKhu', 0, 20) + ' (0 = giữ khu đang đứng · cả đội nên đặt cùng khu)</div>' +
      '<div class="card" id="ctInfo">—</div>') +
    grp('Thành tích cướp tiêu', '<div class="card" id="ctStat">—</div>') +
    '</section>' +

    // ---- Hồn Phiên ----
    '<section data-pane="hon">' +
    grp('Săn hồn',
      toggle('honRun', 'Tự săn hồn (ngoài lịch)', 'Săn hồn cho con Âm Hồn kế tiếp · giữ Sát Nghiệp · cần đã có Hồn Phiên') +
      toggle('honFarm', '· Săn Phàm Hồn', 'Tiều Phu, Nông Phu, Dược Nông, Thư Sinh, Phu Khuân Vác · Oán Hồn: Thương Nhân / Tiêu Sư (tab ☁ Thiên Đạo)') +
      toggle('honFocus', '· Tập trung săn cho xong', 'Bỏ farm quái, khu hết người phàm thì đổi khu ngay · quét hết thì về chỗ farm, không đứng chờ') +
      toggle('honSell', 'Săn thêm để bán chợ', 'Lúc rảnh (không có Thương Đội / việc khác) tự đi săn số dư dưới đây, đủ thì về chỗ farm · vẫn dừng trước mốc tên đỏ · bạn tự đăng bán') +
      '<div class="sub">Giữ dư Phàm Hồn ' + numIn('honSellPham', 0, 9999) + ' · Oán Hồn ' + numIn('honSellOan', 0, 9999) + ' (0 = không săn thêm)</div>') +
    grp('Sát Nghiệp',
      toggle('honAllowRed', 'Cho săn quá mốc tên đỏ', 'Tên đỏ = như kẻ đồ sát, người khác được giết mình') +
      toggle('honCung', 'Tự cúng gột nghiệp khi chạm mốc', 'Ông Từ Giữ Miếu · 500 Linh Thạch mỗi điểm')) +
    grp('Bầy Pháp Bảo (Âm Hồn / Kiếm Linh / Quyền Ảnh / Mị Điệp)',
      toggle('honLuyen', 'Tự luyện / nâng cấp khi đủ nguyên liệu', 'Tự mở khiếu / luyện bầy cho cả 4 môn phái (không cần mở túi)') +
      '<div class="sub">⚡ Bầy tự bay ra tấn công khi bật Tự Động (Auto On), không tốn Linh Lực · Tuyệt đối không gửi lệnh gọi thủ công.</div>' +
      '<div class="card" id="honInfo">—</div>' +
      '<div class="btns"><button class="btn" id="honBuy">🏴 Thỉnh Hồn Phiên (4.444 LT)</button></div>') +
    '</section>' +

    // ---- Việc hằng ngày ----
    '<section data-pane="job">' +
    grp('Điểm danh · Đại Hội · Tàng Kinh miễn phí',
      toggle('dhRun', '⚔ Tự đánh Đại Hội Tu Tiên', 'Tự ghi danh khi mở sổ (Luyện Khí 7–13; Trúc Cơ kỳ 13:16, 20:16) · chốt sổ thì đứng chờ, lên đài dồn đánh đối thủ · xong về chỗ cũ · vào đài xong tự Điểm Danh 30 Ngày · có việc Dược Công Thắng Trận Đại Hội thì nhận và làm luôn') +
      toggle('dhAll', '· Dự mọi kỳ', 'Tắt: chỉ dự khi hôm nay chưa vào đài hoặc đang giữ việc Dược Công Đại Hội') +
      '<div class="card" id="dailyInfo">—</div>' +
      '<div class="btns"><button class="btn" id="ddNow">📅 Điểm danh ngay</button><button class="btn" id="gcNow">📖 Rút miễn phí ngay</button></div>') +
    grp('Dược Công',
      toggle('dcRun', 'Tự chạy Dược Công (ngoài lịch)', 'Lỗi thì tự làm lại · xong về chỗ farm lúc bật · không làm Đại Hội') +
      '<div class="sub">Việc được làm</div>' +
      DC_TASKS.map(function (t) { return toggle('dc_' + t[0], t[1], '<span data-dcleft="' + t[0] + '">—</span>'); }).join('') +
      '<div class="card" id="dcInfo">—</div>') +
    grp('Nhiệm vụ tông môn',
      toggle('snRun', 'Tự làm (ngoài lịch)', 'Trong lịch thì bật ở tab 📅 Lịch treo') +
      '<div class="sub">Chọn 3 việc muốn làm (ưu tiên theo thứ tự, việc có dần khi farm làm sau cùng)</div>' +
      SN_LIST.map(function (x) { return toggle('sn_' + x[0], x[1], x[2]); }).join('') +
      '<div class="card" id="snInfo">—</div>') +
    grp('Vận Tiêu (từ Trúc Cơ)',
      toggle('vtRun', 'Tự áp tiêu (ngoài lịch)', 'Kéo xe từ Huấn Sư Huynh (Thanh Trúc Lâm) tới Bảnh Tiên Sinh · 400 Linh Thạch / chuyến · có người cướp được ở đoạn giữa') +
      toggle('vtAutoTrigger', 'Tự động vận tiêu theo giờ hẹn', 'Chạm mốc giờ hẹn bên dưới sẽ tự kích hoạt đi vận tiêu (kể cả trong lịch hoặc ngoài lịch)') +
      '<div class="sub">Giờ hẹn tự chạy Vận Tiêu: ' + numIn('vtScheduleHour', 11, 21) + ' h</div>' +
      toggle('vtQuietKhu', 'Đổi sang khu vắng nhất trước khi nhận tiêu', 'Tránh 100% người chơi khác cướp tiêu trên đường đi (tự động dò khu ít người nhất)') +
      toggle('vtGuardCart', 'Hộ tiêu: diệt quái cắn xe & hồi phục an toàn', 'Diệt mục tiêu cắn xe, bật Giáp khi xe tụt máu, đứng chờ xe tự hồi đầy 100% máu an toàn') +
      toggle('vtSafePortal', 'Bảo hiểm qua cổng (xe ≤ 80px mới bước)', 'Chống đứt dây kéo (320px) khi chuyển map bằng cách giữ xe áp sát cổng') +
      '<div class="card" id="vtInfo">—</div>') +
    grp('Câu cá săn Linh Ngư',
      toggle('fishRun', 'Tự câu Linh Ngư (ngoài lịch)', 'Tới chỗ câu, bật "Tự động câu" của game · mỗi lần câu ~5s, ~4% ra Linh Ngư (còn lại Cá Sông) → trung bình ~2 phút một con · quái đánh thì dừng câu đánh xong câu tiếp · đủ số / túi đầy thì về chỗ farm') +
      '<div class="sub">Câu tới khi có ' + numIn('fishGoal', 0, 9999) + ' Linh Ngư (0 = câu mãi)</div>' +
      '<div class="sub">Chỗ câu</div>' + seg('fishSpot', [['', 'Tự chọn'], ['ho_bich_thuy_cong', 'Hồ Bích Thủy'], ['suoi_duoc_coc', 'Suối Dược Cốc']]) +
      '<div class="card" id="fishInfo">—</div>') +
    grp('Chăm vườn (Luống Thuốc)',
      toggle('farmAuto', 'Tự đi chăm khi vườn có việc (ngoài lịch)', 'Thu luống chín · gieo luống trống · tưới (khi có nước) · xong về chỗ cũ') +
      '<div class="card" id="farmCareInfo">—</div>' +
      '<div class="btns"><button class="btn pri" id="farmCareBtn">🌿 Chăm vườn ngay</button></div>') +
    '</section>' +

    // ---- Nhặt · Thu ----
    '<section data-pane="loot">' +
    grp('Đồ rơi',
      toggle('autoLoot', 'Tự nhặt vật phẩm rơi', 'Đánh xong mới nhặt · trước khi đổi khu / rời map: nhặt hết, đồ của mình thì đứng chờ game tự hút về') +
      toggle('lootSweep', 'Quét một vòng khi phải đi nhặt', 'Nhiều món thì chạy một đường qua tất cả, đi ngang là nhặt') +
      '<div class="sub">Tìm đồ trong vòng ' + numIn('lootRadius', 40, 1000) + ' px</div>' +
      toggle('smartPriority', 'Nhặt món phẩm cấp cao trước', 'Thiên &gt; Địa &gt; Linh &gt; Phàm') +
      '<div class="sub">Chỉ nhặt (trống = nhặt hết)</div>' +
      '<input type="text" class="txtin" data-text="lootOnly" placeholder="vd: yeu_dan, bí tịch, linh thạch">' +
      toggle('runLoot', '🏃 Chạy nhặt đồ rơi ngay', 'Quái vừa rớt đồ là chạy lại nhặt (kể cả đồ của mình, kể cả lúc đang đánh) · đồ rơi trong tầm thì gửi lệnh nhặt ngay lúc máy chủ báo rơi · Yêu Đan / Nanh Hổ / Ngưu Sừng ưu tiên nhất')) +
    grp('Đi nhặt nguyên liệu chế tạo',
      toggle('gatherRun', 'Tự đi nhặt nguyên liệu (ngoài lịch)', 'Tới Mỏ Linh Thạch / Bãi Đá / Tản Viên · hết thì đổi khu, đổi map') +
      '<div class="sub">Loại cần nhặt</div>' +
      GATHER_TYPES.map(function (t) { return toggle('ga_' + t[0], t[2], '<span data-gahave="' + t[1] + '">—</span>'); }).join('') +
      '<div class="sub">Dừng khi mỗi loại đủ ' + numIn('gatherGoal', 0, 99999) + ' (0 = nhặt mãi)</div>' +
      toggle('gatherFightOn', 'Đánh quái đuổi theo', 'Mặc định tắt: chỉ nhặt, auto tắt, né chiêu / thiền lo an toàn') +
      '<div class="card" id="gaInfo">—</div>') +
    grp('Bí cảnh',
      toggle('harvest', 'Tự thu điểm tài nguyên', 'Huyết Xích, linh thảo Yên Lãng · vận 3s · bảo vật Hư Thiên')) +
    grp('Thống kê nhặt',
      '<div class="card" id="lootStatsBox">—</div>' +
      '<div class="btns"><button class="btn pri" id="lootCopy">📋 Copy</button><button class="btn ghost" id="lootReset">Xoá</button></div>') +
    '</section>' +

    // ---- Di chuyển ----
    '<section data-pane="move">' +
    grp('Bãi farm',
      '<div class="card" id="farmInfo">Chưa lưu</div>' +
      '<div class="btns"><button class="btn pri" id="setFarm">📍 Lưu chỗ này</button><button class="btn ghost" id="clrFarm">Xoá</button></div>' +
      toggle('stayFarm', 'Giữ trong bãi', 'Lạc ra ngoài hoặc chết về làng thì tự đi về') +
      '<div class="sub">Bán kính ' + numIn('farmRadius', 100, 3000) + ' px</div>') +
    grp('Dò tìm mục tiêu',
      '<div class="sub">Người phàm, quái biến dị, yêu thú xổng chuồng, Thương Đội, boss: máy chủ chỉ cho thấy quái ở gần → phải đi dò</div>' +
      seg('scanMode', [['map', 'Dò kín toàn bộ map'], ['spawn', 'Chỉ quanh chỗ sinh (nhanh)']]) +
      '<div class="sub">Toàn bộ map: xem chỗ sinh trước, rồi đi hết lưới phủ kín map · thấy mục tiêu là dừng dò và đánh ngay</div>') +
    grp('Khu ít người',
      toggle('farmKhu', 'Mở Bảng Khu thì tự sang khu ít người', 'Bảng Khu được mở (bạn tự mở, hoặc bấm nút bên dưới) thì đọc số người từng khu · có khu vắng hơn thì sang luôn') +
      toggle('farmKhuAuto', 'Tự chạy ra Bảng Khu theo chu kỳ', 'Lúc đang tự đánh (rảnh, không bị quái đuổi) cứ mỗi N phút chạy ra Bảng Khu xem · có khu vắng hơn thì sang · xong về đúng chỗ farm') +
      '<div class="sub">Xem lại mỗi ' + numIn('farmKhuMin', 1, 120) + ' phút</div>' +
      '<div class="card" id="khuInfo">—</div>' +
      '<div class="btns"><button class="btn pri" id="khuNow">🗺 Tìm khu ít người ngay</button></div>') +
    grp('Đi tới map',
      '<select id="dest"><option value="">— chọn map —</option></select>' +
      '<div class="btns"><button class="btn pri" id="go">🚶 Đi bộ tới</button><button class="btn" id="stop">Dừng</button></div>') +
    grp('Tốc độ di chuyển (Dev)',
      '<div class="note" id="devNote"></div>' +
      '<div class="seg" id="devSpeed"><button data-v="1">x1</button><button data-v="1.1">x1.1</button><button data-v="1.25">x1.25</button>' +
      '<button data-v="1.5">x1.5</button><button data-v="1.75">x1.75</button><button data-v="2">x2</button><button data-v="3">x3</button></div>') +
    '</section>' +

    // ---- Số liệu ----
    '<section data-pane="stats">' +
    grp('Mục tiêu', '<div class="card" id="optTarget">—</div>') +
    grp('Chiêu trong bảng Tự Động', '<div id="optSkills"></div>') +
    grp('Thống kê farm', '<div class="kv" id="optStats"></div>' +
      '<div class="btns"><button class="btn ghost" id="optReset">Đặt lại thống kê</button></div>') +
    '</section>' +

    // ---- Nhật ký ----
    '<section data-pane="log">' +
    seg('logFilter', LOG_FILTERS) +
    '<div class="klog" id="kiteLog"></div>' +
    '<div class="btns"><button class="btn pri" id="kiteCopy">📋 Copy log</button><button class="btn ghost" id="kiteClr">Xoá log</button></div>' +
    '</section>' +

    // ---- Telegram ----
    '<section data-pane="tele">' +
    grp('Báo cáo Telegram', toggle('tgOn', 'Gửi báo cáo sự kiện về Telegram', 'Mỗi lượt sự kiện: báo lúc bắt đầu · xong thì gửi tóm tắt + file nhật ký đầy đủ (bước trợ thủ làm, trạng thái 10 giây / lần, gục, tin máy chủ) · ghi cả khi bạn tự đánh tay') +
      toggle('tgAlwaysFile', 'Luôn gửi kèm file log (.txt)', 'Mỗi lượt boss / hoạt động đều đính kèm file log chi tiết để tải về hoặc để AI phân tích tối ưu') +
      '<div class="sub">Token bot (lấy ở @BotFather)</div><input class="txtin" type="password" data-text="tgToken" placeholder="123456789:AA…" autocomplete="off">' +
      '<div class="sub">Chat ID nhóm (bấm Tìm Chat ID)</div><input class="txtin" data-text="tgChat" placeholder="-100…">' +
      '<div class="btns"><button class="btn" id="tgFind">🔎 Tìm Chat ID</button><button class="btn" id="tgTest">✉ Gửi thử</button><button class="btn" id="tgLastB">📤 Gửi lượt gần nhất</button></div>' +
      '<div class="card" id="tgMsg">Chưa nối Telegram</div>') +
    grp('Báo cáo những sự kiện nào', TG_EV.map(function (e) { return toggle('tgEv_' + e[0], e[1]); }).join('') + toggle('tgEv_upd', 'Game cập nhật mã mới', 'Mở game mà mã game khác lần trước → báo danh sách file đổi / file mới') + toggle('tgEv_khu', 'Đổi khu ít người', 'Mỗi lần xem Bảng Khu: số người từng khu, đổi sang đâu / vì sao không đổi · báo khi đổi khu định kỳ bị kẹt')) +
    '</section>' +
    '<div class="nores" id="nores">Không tìm thấy cài đặt nào</div>' +

    '</div>' +
    '</div>' +
    '</div>' +
    '<div class="log" id="log">Sẵn sàng</div>' +
    '<div class="hint">F8 (hoặc `) ẩn/hiện · kéo tiêu đề để dời</div>' +
    '</div>' +
    '<button class="mini" id="mini" title="Mở Trợ thủ (F8)">☯</button>';

  var ui = {}, uiQuery = '';
  // Tab Tổng quan: các phần đang bật, việc sắp tới, bãi farm.
  function btMelee(g) {
    var P = g.P, I = P.Inventory, wp = g.me.cfg && g.me.cfg.weapon, out = [];
    function owns(id) { return !!(I && (I.owns ? I.owns(id, 1) : I.has && I.has(id, 1))); }
    [['LucTinhTrucKiem', 'Lục Tinh Trực Kiếm', 'mỗi đòn thường 20% phóng 6 trực kiếm · cần kiếm, Chính Đạo, Trúc Cơ 2'],
    ['HuyenAnh', 'Huyễn Ảnh Ma Trảm', 'mỗi đòn thường 20% tách 2 ảo ảnh cùng chém · Ma Đạo, Trúc Cơ 2, không dùng cung / ám khí']].forEach(function (x) {
      var M = P[x[0]];
      if (!M) return;
      var has = M.owned ? M.owned(P) : owns(M.BOOK), lock = M.lockReason ? M.lockReason(P) : null;
      var why = !has ? '✗ chưa có' : lock ? '○ có · ' + lock : M.compatible && !M.compatible(wp) ? '○ có · vũ khí đang cầm không hợp' : '◉ đang chạy';
      out.push(why.charAt(0) + ' ' + esc(x[1]) + ' · ' + esc(x[2]) + (why.length > 2 ? ' (' + esc(why.slice(2)) + ')' : ''));
    });
    out.push((owns('bi_tich_dan_linh') ? '◉' : '✗') + ' Dẫn Linh Quyết · bí tịch gốc: khai mở linh lực, hồi linh lực');
    return out;
  }
  function refreshBiTich(g) {
    var P = g && g.P, S = P && P.Skills;
    if (!S || !S.DEFS || !S.learnedSlots) { ui.btPlans.textContent = 'Chưa vào game'; ui.btAll.textContent = '—'; return; }
    if (btCache && ui.btPlans._at === btCache.at) return;
    var plans = btPlans(g), cur = st.btMode;
    ui.btPlans._at = btCache.at;
    ui.btPlans.innerHTML = BT_MODES.map(function (m) {
      var pl = plans[m[0]];
      return '<div class="card"><b>' + esc(m[1]) + '</b>' + (cur === m[0] ? ' <span class="chip">đang dùng</span>' : '') + '<br><span class="sub">' + esc(m[2]) + '</span><br>' +
        'Chiêu: ' + (pl.bar.map(function (id) { return (pl.auto.indexOf(id) >= 0 ? '★' : '·') + esc(btSkillName(g, id)); }).join(', ') || 'chưa có chiêu sát thương') + '<br>' +
        'Bị động: ' + (pl.passives.map(function (id) { return esc(S.PASSIVES[id] ? S.PASSIVES[id].short : id); }).join(', ') || '—') + '<br>' +
        '<span class="sub">Ước tính' + (m[0] === 'farm' ? ' (cụm 4 con)' : '') + ': ' + num(pl.d6) + ' / 6 giây · ' + num(pl.d12) + ' / 12 giây · ' + num(pl.d30) + ' / 30 giây</span>' +
        '<div class="btns"><button class="btn' + (cur === m[0] ? '' : ' pri') + '" data-bt="' + m[0] + '">Dùng bộ này</button></div></div>';
    }).join('');
    var owned = {};
    S.learnedSlots().forEach(function (k) { owned[S.SLOTS[k]] = 1; });
    var fit = btFit(g), wpId = btWeapon(g), IT = P.ITEMS || {};
    function itemImg(id) { var it = IT[id], ic = it && (it.icon || id); return ic ? '<img class="bti" alt="" src="' + esc(P.Assets && P.Assets.itemPath ? P.Assets.itemPath(ic) : 'assets/items/icon_' + ic + '.png') + '" onerror="this.style.display=\'none\'">' : ''; }
    function ck(on, t) { return '<span class="btk' + (on ? ' on' : '') + '" title="' + esc(t) + '">' + (on ? '☑' : '☐') + '</span>'; }
    var rows = ['loi_chuong'].concat(Object.keys(S.DEFS)).map(function (id) {
      var d = id === 'loi_chuong' ? S.THUNDER_DEF : S.DEFS[id];
      if (!d) return null;
      var inf = btInfo(g, d, 1), bw = btBoost(g, d), lock = owned[id] ? '' : (!d.thunder && S.ownsBook && S.ownsBook(id) && S.lockReason ? S.lockReason(id) : '') || '';
      var tags = [];
      if ((d.maxTargets || 1) > 1 || d.shape === 'aura' || (d.blastR || 0) >= 40) tags.push('diện rộng' + (d.maxTargets ? ' ' + d.maxTargets : ''));
      if (!d.thunder && (d.shots | 0) > 1) tags.push(d.shots + ' viên (chia sát thương)');
      btEffects(d).forEach(function (e) { tags.push({ burn: 'thiêu', slow: 'chậm', stun: 'choáng', root: 'trói', freeze: 'đóng băng', fear: 'hoảng sợ', wound: 'rỉ máu' }[e.kind] || e.kind); });
      if (d.lifesteal) tags.push('hút máu');
      if (d.playerTargetOnly) tags.push('chỉ đánh người');
      if (d.bienHinh) tags.push('hoá thân');
      if (d.delay >= 1) tags.push('nổ chậm ' + d.delay + 's');
      var inBar = BT_MODES.map(function (m) { return (btCache && btCache.plans[m[0]] && btCache.plans[m[0]].bar.indexOf(id) >= 0) ? m[0] : null; }).filter(Boolean);
      var wHtml = bw ? '<span class="btw ' + (bw.ok ? 'ok' : 'no') + '">' + itemImg(bw.id) + esc(bw.name) + (bw.ok ? (bw.held ? ' · đang cầm' : ' · có trong túi') : (bw.need ? ' · THIẾU (không dùng được)' : ' · THIẾU → 50% sát thương')) + '</span>' : '';
      return {
        owned: !!owned[id], score: inf.one / Math.max(inf.cd, 1.2), html: '<div class="btr' + (owned[id] ? '' : ' off') + '">' +
          '<span class="btic" data-ico="' + esc(id) + '"></span>' +
          '<div class="btb"><b>' + esc(d.short || d.name) + '</b> <span class="sub">' + esc(d.element || '') + '</span> ' + ck(!!owned[id], owned[id] ? 'Đã sở hữu, dùng được' : 'Chưa sở hữu / chưa dùng được') + (owned[id] ? ' có' : ' chưa có') + (lock ? ' <span class="sub">(' + esc(lock) + ')</span>' : '') + '<br>' +
          '<span class="sub">' + (d.bienHinh ? 'cường hoá thân' : num(inf.one) + ' ST') + ' · hồi ' + (Math.round(inf.cd * 10) / 10) + 's · ' + inf.mp + ' LL' + (inf.cd > 0 && !d.bienHinh ? ' · ' + num(inf.one / Math.max(inf.cd, spellGap(g))) + '/s theo hồi chiêu' : '') + (tags.length ? ' · ' + esc(tags.join(', ')) : '') + '</span>' +
          (wHtml ? '<br>' + wHtml : '') + '<br>' +
          BT_MODES.map(function (m) { return ck(fit[m[0]][id], 'Hợp ' + m[1]) + esc(m[1].replace(/^\S+\s/, '')) + (inBar.indexOf(m[0]) >= 0 ? '★' : ''); }).join(' ') +
          '</div></div>'
      };
    }).filter(Boolean).sort(function (a, b) { return (b.owned - a.owned) || (b.score - a.score); });
    var pasL = Object.keys(S.PASSIVES || {}).map(function (id) {
      var q = S.PASSIVES[id], has = S.knownPassive && S.knownPassive(id), on = S.passiveOn && S.passiveOn(id);
      var modes = BT_MODES.filter(function (m) { return (BT_PASSIVE[m[0]] || []).slice(0, 6).indexOf(id) >= 0; });
      var note = id === 'kiem_y' ? (/kiem/.test(wpId) ? ' · đang cầm kiếm ✓' : ' · cần đang CẦM kiếm (vũ khí hiện tại không phải kiếm)') : id === 'hoa_mach' ? ' · chỉ cộng cho chiêu hệ Hỏa' : '';
      return '<div class="btr' + (has ? '' : ' off') + '">' + '<span class="btic">' + itemImg(q.book) + '</span>' +
        '<div class="btb"><b>' + esc(q.short || q.name) + '</b> ' + ck(has, has ? 'Đã sở hữu' : 'Chưa sở hữu') + (has ? ' có' : ' chưa có') + (on ? ' · <b>đang đeo</b>' : '') +
        (!has && S.passiveLock && S.ownsPassive && S.ownsPassive(id) ? ' <span class="sub">(' + esc(S.passiveLock(id) || '') + ')</span>' : '') + '<br>' +
        '<span class="sub">' + esc(q.tip || '') + esc(note) + '</span><br>' +
        BT_MODES.map(function (m) { return ck(modes.indexOf(m) >= 0, 'Hợp ' + m[1]) + esc(m[1].replace(/^\S+\s/, '')); }).join(' ') + '</div></div>';
    });
    ui.btAll.innerHTML = '<div class="sub">Vũ khí đang cầm: <b>' + esc(IT[wpId] ? IT[wpId].name : wpId || 'tay không') + '</b> · ☑ có / hợp · ★ đang nằm trong bộ dựng sẵn · ST = sát thương một lần thi triển lên một mục tiêu theo tu vi hiện tại</div>' +
      '<div class="bth">Chủ động (' + rows.length + ')</div>' + rows.map(function (r) { return r.html; }).join('') +
      '<div class="bth">Bị động (' + pasL.length + ', đeo tối đa ' + (S.PASSIVE_MAX || 5) + ')</div>' + pasL.join('') +
      '<div class="bth">Bí tịch đòn đánh thường (không chiếm ô, game tự bật khi đủ điều kiện)</div><div class="card">' + btMelee(g).join('<br>') + '</div>';
    // Biểu tượng chiêu vẽ bằng chính CombatIcons của game (giống thanh chiêu).
    Array.prototype.forEach.call(ui.btAll.querySelectorAll('[data-ico]'), function (el) {
      var c = P.CombatIcons && P.CombatIcons.create ? P.CombatIcons.create('skill', el.getAttribute('data-ico'), 24) : null;
      if (c) el.appendChild(c);
    });
  }
  function refreshCtStat() {
    if (!ui.ctStat) return;
    var t = ctStatToday(), A = ctStats.all, team = { rob: t.rob, giao: t.giao, mat: t.mat, lt: t.lt }, n = 1;
    Object.keys(teamSeen).forEach(function (id) { var b = teamSeen[id], x = b && b.ct && b.ct.stat; if (!x || now() - b.at > 60000) return; n++;['rob', 'giao', 'mat', 'lt'].forEach(function (k) { team[k] += x[k] | 0; }); });
    var rate = function (o) { return o.rob ? Math.round(o.giao / o.rob * 100) + '%' : '—'; };
    ui.ctStat.innerHTML = esc('Hôm nay: cướp thành công ' + t.rob + ' · dắt về giao ' + t.giao + ' · mất giữa đường ' + t.mat + ' · tỉ lệ dắt về ' + rate(t) + ' · +' + num(t.lt) + ' Linh Thạch') + '<br>' +
      (n > 1 ? esc('Cả đội (' + n + ' trợ thủ chung trình duyệt): cướp ' + team.rob + ' · giao ' + team.giao + ' · mất ' + team.mat + ' · +' + num(team.lt) + ' Linh Thạch') + '<br>' : '') +
      esc('Tổng từ trước: cướp ' + A.rob + ' · giao ' + A.giao + ' · mất ' + A.mat + ' · tỉ lệ dắt về ' + rate(A) + ' · +' + num(A.lt) + ' Linh Thạch');
  }
  function refreshCuopTieu(g) {
    refreshCtStat();
    var P = g && g.P;
    if (!P || !P.VanTieu) { ui.ctInfo.textContent = 'Chưa vào game'; return; }
    var s = ctStones(P), a = st.ct, G = P.Gateway, co = G && G.coChien, ld = ctLeader(g), wf = ctWantFlag(g);
    ui.ctInfo.innerHTML = esc([
      'Linh Thạch hôm nay: ' + (s ? num(s.da) + '/' + num(s.tran) + (s.da >= s.tran ? ' · đã đủ trần' : '') : '—') + ' · lượt cướp còn ' + ctTurns(P) + '/' + (P.VanTieu.LUOT_CUOP || 3),
      'Cờ: ' + ({ vang: 'vàng', do: 'đỏ (đang kéo xe)', den: 'đen', luc: 'lục', lam: 'lam' }[co] || (co ? co : 'chưa cắm')) + ' · tổ đội: ' + CT_COLORS[wf.flag] + ' (' + (ld.self ? 'mình là nhóm trưởng' : wf.from) + ')',
      a ? '▶ ' + (a.step || '…') : cfg.ctRun ? 'Chờ: ' + (st.ctWhy || '…') : 'Đang tắt'
    ].join(' | ')).split(' | ').join('<br>');
  }
  function refreshTeam(g) {
    var P = g && g.P, lines = [];
    if (!P) { ui.teamInfo.textContent = 'Chưa vào game'; return; }
    var L = teamList(), pt = teamParty(P), G = P.Gateway;
    lines.push(L.length ? 'Danh sách: ' + String(cfg.teamNames).split(/[,;\n]/).map(function (x) { return x.trim(); }).filter(Boolean).join(', ') + (teamIsDesignatedLeader(g) ? ' · mình là đội trưởng' : '') : 'Chưa nhập tên đồng đội');
    lines.push(pt ? 'Tổ đội ' + pt.members.length + '/' + (pt.maxMembers || 6) + ': ' + pt.members.map(function (m) { return (m.id === pt.leaderId ? '♛' : '') + (m.name || '?') + (m.id !== G.selfId && !m.online ? ' (rời mạng)' : m.id !== G.selfId && m.mapId && m.mapId !== G.mapId ? ' (khác map)' : ''); }).join(', ') : 'Chưa có tổ đội');
    var bus = Object.keys(teamSeen).filter(function (id) { return now() - teamSeen[id].at < TEAM_FRESH_MS; });
    lines.push(teamBus ? 'Kênh chung trình duyệt: ' + (bus.length ? bus.map(function (id) { return teamSeen[id].name || id; }).join(', ') : 'chưa thấy trợ thủ nào khác') : 'Không có kênh chung (khác trình duyệt) · phối hợp theo dữ liệu tổ đội');
    ui.teamInfo.innerHTML = lines.map(esc).join('<br>');
  }
  function refreshVetNut(g) {
    var P = g && g.P, V = P && P.VetNut, lines = [];
    if (!V) { ui.vnInfo.textContent = g ? 'Game chưa có Vết Nứt Không Gian' : 'Chưa vào game'; return; }
    var S = P.VetNutUI && P.VetNutUI.st, nut = S && S.nut, L = vnSt(P) || {};
    lines.push('Vé Hư Không Lệnh: ' + vnTickets(P) + ' · cảnh giới ' + (V.duTuCach && V.duTuCach(P.Progress && P.Progress.realmId) ? 'đủ' : 'chưa đủ (Luyện Khí 13)'));
    if (nut && Date.now() < nut.den) lines.push('Đang mở ở ' + (nut.ten || mapName(nut.map)) + ' · ' + (nut.so | 0) + '/' + (nut.toiDa || V.TOI_DA) + ' người · khép sau ' + V.dem(nut.den - Date.now()) + (S.daVao ? ' · đã vào lượt này' : ''));
    else lines.push('Chưa mở · mỗi ngày một lần trong 18:00–23:00, Thiên Đạo báo trước 5 phút');
    if (vnIn(g)) {
      var cua = L.cua || {}, lo = cua.lo || [];
      lines.push('Trong mê cung · ' + (L.tt || '') + ' · còn ' + (L.mang | 0) + ' mạng · lối: ' + [0, 1, 2, 3, 4].map(function (k) { return V.tenCong(k) + (lo[k] === 1 ? ' THÔNG' : lo[k] === 2 ? ' cụt' : ' ?'); }).join(', '));
    }
    if (st.vn) lines.push('→ ' + (st.vn.step || ''));
    if (st.vnBuy) lines.push('→ ' + (st.vnBuy.step || ''));
    ui.vnInfo.innerHTML = lines.map(esc).join('<br>');
  }
  function refreshBiCanh(g) {
    var P = g && g.P;
    if (!P) { ui.hxInfo.textContent = ui.ylInfo.textContent = 'Chưa vào game'; return; }
    var hx = [], yl = [];
    if (!P.HuyetSac) hx.push('Bản game này chưa có Huyết Xích');
    else {
      var w = hxWhyNot(g), tl = hxTimeLeft();
      hx.push('Hôm nay còn ' + hxLeft(P) + '/' + P.HuyetSac.luotNgay(bcRealm(P)) + ' lượt · Linh Thạch ' + num(bcStones(P)) + (w ? ' · ' + w : ''));
      if (HUYET_MAPS[g.mapId]) hx.push('Đang ở ' + mapName(g.mapId) + (tl != null && tl > 0 ? ' · còn ' + fmtSec(tl / 1000) : ''));
      if (st.hxRuns) hx.push('Phiên này đã đi ' + st.hxRuns + ' lượt');
      if (st.hx) hx.push('→ ' + (st.hx.step || ''));
    }
    var Y = P.YenLang;
    if (!Y) yl.push('Bản game này chưa có Yên Lãng Sơn');
    else {
      var pt = bcParty(P), w2 = ylWhyNot(g), S = P.YenLangUI && P.YenLangUI.st;
      yl.push('Hôm nay còn ' + ylLeft(P) + '/' + Y.luotNgay(bcRealm(P)) + ' lượt · tổ đội ' + pt.n + ' người' + (pt.n > 1 ? (pt.leader ? ' (bạn là đội trưởng)' : ' (thành viên)') : '') + (w2 ? ' · ' + w2 : ''));
      if (S && g.mapId === Y.MAP) yl.push('Bia còn ' + (S.bia || []).filter(function (b) { return !b.vo; }).length + '/' + (S.bia || []).length + ' · linh thảo ' + (S.linhThaoMo ? 'đã mở' : 'còn phong') + ' · Tộc Trưởng ' + (S.boss ? Math.round(S.boss.hp / Math.max(1, S.boss.hpMax) * 100) + '%' : S.tocTruongHien ? 'đã gục' : 'đang ngủ') + (ylPhase(P) ? ' · LỆNH ' + (ylPhase(P) === 'tinh' ? 'TĨNH' : 'ĐẢO ÂM') : ''));
      if (st.yl) yl.push('→ ' + (st.yl.step || ''));
    }
    ui.hxInfo.innerHTML = hx.map(esc).join('<br>');
    ui.ylInfo.innerHTML = yl.map(esc).join('<br>');
  }
  function refreshFish(g) {
    var P = g && g.P;
    if (!P) { ui.fishInfo.textContent = 'Chưa vào game'; return; }
    var lines = [];
    if (!P.Fishing) lines.push('Bản game này không có câu cá');
    else {
      var spot = cfg.fishSpot && propMap(P, cfg.fishSpot) ? cfg.fishSpot : DC_WATERS.filter(function (w) { return propMap(P, w); })[0];
      lines.push('Linh Ngư trong túi: ' + fishCount(P) + (cfg.fishGoal > 0 ? '/' + cfg.fishGoal + (fishWant(P) ? ' · còn ~' + fishEta(cfg.fishGoal - fishCount(P)) + ' (~5s một lần câu)' : ' · đã đủ') : '') + ' · Cá Sông: ' + (P.Inventory ? P.Inventory.count(FISH_COMMON) : 0));
      lines.push('Chỗ câu: ' + (spot ? (findHere(g, spot) && findHere(g, spot).title || spot) + ' · ' + mapName(propMap(P, spot)) : 'không tìm thấy'));
      if (st.fish) lines.push('→ ' + (st.fish.step || ''));
    }
    ui.fishInfo.innerHTML = lines.map(esc).join('<br>');
  }
  function refreshHome(g) {
    var P = g && g.P, onList = [];
    var names = {
      keepAuto: 'Giữ Auto', dodge: 'Né chiêu', kite: 'Đánh-lùi', autoLoot: 'Tự nhặt', healSit: 'Thiền', bossHunt: 'Đi boss theo giờ', bossBurst: 'Xả chiêu boss',
      tdHunt: 'Thương Đội', vnRun: 'Vết Nứt', hxRun: 'Huyết Xích', ylRun: 'Yên Lãng', bdHunt: 'Biến dị', xcHunt: 'Xổng chuồng', honRun: 'Săn hồn', honSell: 'Săn hồn dư', autoTran: 'Trận bàn',
      autoKhoiLoi: 'Khôi lỗi', ltRun: 'Linh Thụ', llRun: 'Lãm Làng', htRun: 'Sỹ Sách Điện', tlRun: 'Tam Lộ', planRun: 'Lịch treo', dcRun: 'Dược Công', vtRun: 'Vận Tiêu',
      ctRun: 'Cướp tiêu', hlRun: 'Chiến Trường', teamOn: 'Tổ đội', snRun: 'NV tông môn', gatherRun: 'Nhặt NL', fishRun: 'Câu Linh Ngư', farmAuto: 'Chăm vườn', stayFarm: 'Giữ bãi', farmKhu: 'Mở bảng → khu ít người', farmKhuAuto: 'Tự xem khu mỗi N phút', prioOpt: 'Ưu tiên boss / hoạt động'
    };
    Object.keys(names).forEach(function (k) { if (cfg[k]) onList.push(names[k]); });
    ui.homeOn.textContent = onList.length ? onList.join(' · ') : 'Chưa bật gì';
    var next = [];
    if (P) {
      try { bossTimers(g).slice(0, 4).forEach(function (t) { next.push('👑 ' + t); }); } catch (e) { }
      var pend = tdEvents.filter(function (e) { return !e.done && now() - e.at < TD_EVENT_MS; });
      pend.forEach(function (e) { next.push('🐫 Thương Đội ' + mapName(e.map) + (e.khu ? ' khu ' + e.khu : '')); });
      bdPending().forEach(function (e) { next.push('☁ ' + bdName(P, e.type) + ' · ' + mapName(e.map)); });
      xcPending().forEach(function (e) { next.push('☁ Xổng chuồng ' + mapName(e.map) + ' khu ' + e.khu); });
    }
    ui.homeNext.innerHTML = next.length ? next.map(esc).join('<br>') : 'Chưa có boss / tin Thiên Đạo nào sắp tới';
    var f = cfg.farm;
    ui.homeFarm.textContent = f ? '🌿 ' + f.name + ' · (' + Math.round(f.x) + ', ' + Math.round(f.y) + ')' + (cfg.stayFarm ? ' · đang giữ bãi' : '') : 'Chưa lưu — đứng ở bãi rồi bấm nút dưới';
  }

  function buildPanel() {
    var host = document.createElement('div');
    host.id = 'ttbot-host';
    host.style.cssText = 'position:fixed;z-index:99999;top:8px;right:8px';
    var root = host.attachShadow({ mode: 'open' });
    root.innerHTML = '<style>' + CSS + '</style>' + HTML;
    document.body.appendChild(host);

    function $(id) { return root.getElementById(id); }
    ui = {
      host: host, root: root, panel: root.querySelector('.panel'),
      dot: $('dot'), hpbar: $('hpbar'), hptext: $('hptext'), mpbar: $('mpbar'), doing: $('doing'), mapname: $('mapname'), state: $('state'),
      power: $('power'), log: $('log'), farmInfo: $('farmInfo'), devNote: $('devNote'),
      optTarget: $('optTarget'), optSkills: $('optSkills'), optStats: $('optStats'),
      kiteNow: $('kiteNow'), kiteLog: $('kiteLog'), dcInfo: $('dcInfo'), gaInfo: $('gaInfo'), lootStatsBox: $('lootStatsBox'), khuInfo: $('khuInfo'), splashInfo: $('splashInfo'), honInfo: $('honInfo'), bdInfo: $('bdInfo'), xcInfo: $('xcInfo'), tlInfo: $('tlInfo'), ltInfo: $('ltInfo'), tdInfo: $('tdInfo'), tdnInfo: $('tdnInfo'), vnInfo: $('vnInfo'), hxInfo: $('hxInfo'), ylInfo: $('ylInfo'), teamInfo: $('teamInfo'), btPlans: $('btPlans'), btAll: $('btAll'), ctInfo: $('ctInfo'), ctStat: $('ctStat'), fpsChip: $('fpsChip'), netChip: $('netChip'), fishInfo: $('fishInfo'), homeOn: $('homeOn'), homeNext: $('homeNext'), homeFarm: $('homeFarm'), planNow: $('planNow'), planHome: $('planHome'), planInt: $('planInt'), llInfo: $('llInfo'), htInfo: $('htInfo'), dailyInfo: $('dailyInfo'), snInfo: $('snInfo'), vtInfo: $('vtInfo'), honBuy: $('honBuy'), farmCareInfo: $('farmCareInfo'), radarInfo: $('radarInfo'), mini: $('mini'), cfgBox: $('cfgBox'), cfgMsg: $('cfgMsg'), tgMsg: $('tgMsg')
    };
    ui.log.textContent = st.log || 'Sẵn sàng';
    if (!TABS.some(function (t) { return t[0] === cfg.ui.tab; })) cfg.ui.tab = cfg.ui.tab === 'opt' ? 'stats' : 'home';

    ['pointerdown', 'pointerup', 'keydown', 'keyup', 'wheel'].forEach(function (ev) {
      host.addEventListener(ev, function (e) { e.stopPropagation(); });
    });

    root.querySelectorAll('[data-key]').forEach(function (el) {
      var k = el.dataset.key;
      el.checked = !!cfg[k];
      el.addEventListener('change', function () { setOpt(k, el.checked); });
    });
    root.getElementById('quick').addEventListener('click', function (e) {
      var b = e.target.closest('button');
      if (b) setOpt(b.dataset.quick, !cfg[b.dataset.quick]);
    });

    root.querySelectorAll('[data-text]').forEach(function (el) {
      var k = el.dataset.text;
      el.value = cfg[k] || '';
      el.addEventListener('change', function () { cfg[k] = el.value.trim(); userSet(k); save(); });
    });
    $('farmCareBtn').addEventListener('click', function () { faStart('bấm nút'); refresh(); });
    $('khuNow').addEventListener('click', function () { fkStart('bấm nút'); refresh(); });
    $('honBuy').addEventListener('click', function () { honBuyStart(); refresh(); });
    ui.btPlans.addEventListener('click', function (ev) {
      var b = ev.target && ev.target.closest ? ev.target.closest('[data-bt]') : null, g = game();
      if (!b || !g) return;
      btCache = null;
      if (btApply(g, b.getAttribute('data-bt'), 'bấm tay')) { btWant = null; refresh(); }
    });
    // Lịch: kéo thả / ▲▼ đổi thứ tự việc (dời chính các dòng có sẵn để công tắc giữ nguyên sự kiện đã gắn).
    (function () {
      var box = $('planList'), dragEl = null;
      if (!box) return;
      function rows() { return Array.prototype.slice.call(box.querySelectorAll('.prow')); }
      function saveOrder() {
        cfg.planOrder = rows().map(function (r) { return r.dataset.pj; });
        rows().forEach(function (r, i) { var n = r.querySelector('.pno'); if (n) n.textContent = (i + 1) + '.'; });
        save();
        if (st.plan) st.plan.checkAt = 0; // xét lại ngay theo thứ tự mới
      }
      box.addEventListener('dragstart', function (ev) { var r = ev.target.closest && ev.target.closest('.prow'); if (!r) return; dragEl = r; r.classList.add('drag'); try { ev.dataTransfer.effectAllowed = 'move'; ev.dataTransfer.setData('text/plain', r.dataset.pj); } catch (e) { } });
      box.addEventListener('dragover', function (ev) {
        if (!dragEl) return;
        ev.preventDefault();
        var r = ev.target.closest && ev.target.closest('.prow');
        if (!r || r === dragEl) return;
        var bx = r.getBoundingClientRect(), after = ev.clientY > bx.top + bx.height / 2;
        box.insertBefore(dragEl, after ? r.nextSibling : r);
      });
      box.addEventListener('drop', function (ev) { if (dragEl) ev.preventDefault(); });
      box.addEventListener('dragend', function () { if (!dragEl) return; dragEl.classList.remove('drag'); dragEl = null; saveOrder(); });
      box.addEventListener('click', function (ev) {
        var b = ev.target.closest && ev.target.closest('[data-pmv]');
        if (!b) return;
        ev.preventDefault();
        var r = b.closest('.prow'), dir = +b.dataset.pmv;
        if (dir < 0 && r.previousElementSibling) box.insertBefore(r, r.previousElementSibling);
        else if (dir > 0 && r.nextElementSibling) box.insertBefore(r.nextElementSibling, r);
        saveOrder();
      });
    })();
    $('llOpenBtn').addEventListener('click', function () { if (!enabled) setEnabled(true); st.llOpen = { at: now(), touches: 0, touchAt: 0, routeAt: 0, travels: 0 }; evLog('Lãm Làng', 'Đi tới Quản Sự mở bí cảnh'); refresh(); });
    $('ddNow').addEventListener('click', function () { if (!enabled) setEnabled(true); st.dd = null; st.oneShot = 'dd'; refresh(); });
    $('gcNow').addEventListener('click', function () { if (!enabled) setEnabled(true); st.gc = null; st.oneShot = 'gc'; refresh(); });
    $('setFarm2').addEventListener('click', function () { $('setFarm').click(); if (st.plan) { var g2 = game(); if (g2) st.plan.back = planHome(g2); } refresh(); });
    $('tdnCopy').addEventListener('click', function () {
      var txt = tdNews.map(function (r) { return new Date(r.ts).toLocaleString() + '\t' + (TDN_KIND[r.kind] || r.kind) + '\t' + (r.map ? mapName(r.map) : '') + '\t' + (r.khu || '') + '\t' + r.text; }).join('\n');
      try { navigator.clipboard.writeText(txt).then(function () { say('Đã sao chép ' + tdNews.length + ' tin Thiên Đạo'); }, function () { console.log(txt); say('Không sao chép được → đã in ra Console'); }); } catch (e) { console.log(txt); say('Đã in nhật ký ra Console'); }
    });
    $('tdnClear').addEventListener('click', function () { if (!confirm('Xoá toàn bộ nhật ký Thiên Đạo?')) return; tdNews.length = 0; try { localStorage.removeItem(TDN_KEY); } catch (e) { } refresh(); });
    $('splashReset').addEventListener('click', function () { var g = game(); if (g && cfg.splashLearn2) { delete cfg.splashLearn2[weaponId(g.P)]; save(); } refresh(); });
    $('lootReset').addEventListener('click', function () { lootStats = { since: Date.now(), total: 0, stones: 0, items: {}, history: [] }; refresh(); });
    $('lootCopy').addEventListener('click', function () {
      copyText(lootReport(), function (ok) {
        var b = $('lootCopy');
        b.textContent = ok ? '✓ Đã copy' : '✗ Không copy được';
        setTimeout(function () { b.textContent = '📋 Copy'; }, 1500);
      });
    });

    root.querySelectorAll('[data-num]').forEach(function (el) {
      var k = el.dataset.num;
      el.value = cfg[k];
      el.addEventListener('change', function () {
        var v = Math.round(+el.value);
        cfg[k] = v > 0 || ((k === 'gatherGoal' || k === 'splashManual' || k === 'bossLead' || k === 'keepDist') && v === 0) ? v : DEFAULTS[k];
        if (cfg.healHigh <= cfg.healLow) cfg.healHigh = Math.min(100, cfg.healLow + 10);
        if (cfg.mpFull <= cfg.mpReserve) cfg.mpFull = Math.min(100, cfg.mpReserve + 10);
        userSet(k); save(); syncInputs();
      });
    });

    root.querySelectorAll('[data-seg]').forEach(function (box) {
      var k = box.dataset.seg;
      box.addEventListener('click', function (e) {
        var b = e.target.closest('button');
        if (!b) return;
        cfg[k] = b.dataset.v; userSet(k); save();
        refresh();
      });
    });

    function goTab(tab) { cfg.ui.tab = tab; uiQuery = ''; $('q').value = ''; save(); refresh(); root.querySelector('.panes').scrollTop = 0; }
    root.querySelector('.nav').addEventListener('click', function (e) {
      var b = e.target.closest('button[data-grp]');
      if (!b) return;
      var gi = +b.dataset.grp, last = cfg.ui.lastTab && cfg.ui.lastTab[gi];
      goTab(NAV[gi][1].some(function (t) { return t[0] === last; }) ? last : NAV[gi][1][0][0]);
    });
    $('subtabs').addEventListener('click', function (e) {
      var b = e.target.closest('button[data-tab]');
      if (b) goTab(b.dataset.tab);
    });
    root.querySelector('.panes').addEventListener('click', function (e) {
      var b = e.target.closest('.grptabs button');
      if (!b) return;
      cfg.ui.grp = cfg.ui.grp || {}; cfg.ui.grp[cfg.ui.tab] = b.dataset.g; save(); refresh();
      root.querySelector('.panes').scrollTop = 0;
    });
    $('q').addEventListener('input', function () { uiQuery = this.value; refresh(); });
    $('setFarm3').addEventListener('click', function () { $('setFarm').click(); refresh(); });

    function tgMsg(t) { $('tgMsg').textContent = t; }
    function tgNeed(chat) { if (!String(cfg.tgToken).trim()) { tgMsg('Dán token bot vào ô Token trước'); return false; } if (chat && !String(cfg.tgChat).trim()) { tgMsg('Chưa có Chat ID · bấm Tìm Chat ID'); return false; } return true; }
    $('tgFind').addEventListener('click', function () {
      if (!tgNeed()) return;
      tgMsg('Đang hỏi Telegram…');
      tgReq('getUpdates', '{}', 'application/json', function (res) {
        if (!res || !res.ok) { tgMsg('Lỗi: ' + (res && res.description || '') + (res && res.error_code === 401 ? ' · token sai' : '')); return; }
        var seen = {}, list = [];
        (res.result || []).forEach(function (u) { var m = u.message || u.channel_post || u.my_chat_member || u.edited_message, c = m && m.chat; if (c && !seen[c.id]) { seen[c.id] = 1; list.push(c); } });
        var grps = list.filter(function (c) { return c.type !== 'private'; });
        // Nếu có supergroup (dạng -100...), ưu tiên chọn supergroup (vì Telegram thường lưu cả ID cũ và ID mới -100... khi nâng cấp nhóm)
        var sg = grps.find(function (c) { return String(c.id).startsWith('-100') || c.type === 'supergroup'; });
        if (sg || grps.length > 0) {
          var target = sg || grps[0];
          cfg.tgChat = String(target.id);
          save();
          syncInputs();
          tgMsg('Đã tự điền Chat ID nhóm "' + (target.title || target.username || target.first_name) + '" (' + target.id + ') · bấm Gửi thử');
          return;
        }
        tgMsg(!list.length ? 'Chưa thấy tin nào · vào nhóm gõ /start@<tên bot> rồi bấm lại' : 'Thấy: ' +
          list.map(function (c) { return (c.title || c.username || c.first_name) + ' = ' + c.id; }).join(' · ') + ' · chép số của nhóm vào ô Chat ID');
      });
    });
    $('tgTest').addEventListener('click', function () {
      if (!tgNeed(true)) return;
      var g0 = game(); tgMsg('Đang gửi…');
      tgSend('✓ Trợ thủ v' + VERSION + ' · ' + (g0 ? myName(g0) : 'chưa vào game') + ' đã nối Telegram', function (res) { tgMsg(res && res.ok ? 'Gửi thử được · bật "Gửi báo cáo" là xong' : 'Lỗi: ' + (res && res.description || '') + (res && /chat not found/i.test(res.description || '') ? ' · Chat ID sai hoặc bot chưa ở trong nhóm' : '')); });
    });
    $('tgLastB').addEventListener('click', function () {
      if (!tgNeed(true)) return;
      var r = tgRec || tgLast;
      if (!r) { tgMsg('Chưa có lượt sự kiện nào được ghi từ lúc mở trang'); return; }
      tgReport(r, !tgRec, true); tgMsg('Đã xếp gửi ' + r.name + (tgRec ? ' (đang diễn ra)' : ''));
    });
    function cfgMsg(t) { $('cfgMsg').textContent = t; }
    $('cfgOut').addEventListener('click', function () { var t = cfgExport($('cfgFarm').checked, $('cfgTg').checked); $('cfgBox').value = t; copyText(t, function (ok) { cfgMsg(ok ? 'Đã chép cấu hình · dán sang nhân vật khác rồi bấm Nhập' : 'Chưa chép được · bôi đen ô trên rồi Ctrl+C'); }); });
    $('cfgSaveF').addEventListener('click', function () {
      var a = document.createElement('a'), u = URL.createObjectURL(new Blob([cfgExport($('cfgFarm').checked, $('cfgTg').checked)], { type: 'application/json' }));
      a.href = u; a.download = 'tro-thu-cau-hinh.json'; document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(u); }, 2000);
      cfgMsg('Đã lưu file tro-thu-cau-hinh.json');
    });
    function cfgDoImport(t) { try { var n = cfgImport(t); cfgMsg('Đã nhập ' + n + ' mục cài đặt'); say('Đã nhập cấu hình (' + n + ' mục)'); } catch (e) { cfgMsg('Nhập không được: ' + (e instanceof SyntaxError ? 'nội dung dán vào không phải cấu hình trợ thủ (chép lại đủ cả chuỗi)' : e && e.message || e)); } }
    $('cfgIn').addEventListener('click', function () { cfgDoImport($('cfgBox').value); });
    $('cfgFile').addEventListener('change', function () { var f = this.files && this.files[0], el = this; if (!f) return; var r = new FileReader(); r.onload = function () { $('cfgBox').value = String(r.result || ''); cfgDoImport(r.result); el.value = ''; }; r.readAsText(f); });

    ui.power.addEventListener('click', function () { setEnabled(!enabled); });
    $('min').addEventListener('click', function () { cfg.ui.collapsed = !cfg.ui.collapsed; save(); refresh(); });
    $('hide').addEventListener('click', function () { setHidden(true); });

    $('setFarm').addEventListener('click', function () {
      var g = game();
      if (!g || !g.me) return say('Chưa vào game');
      var k = gaKhu(g.P);
      cfg.farm = { map: g.mapId, name: mapName(g.mapId), x: g.me.x, y: g.me.y, khu: k };
      st.stayFarmPaused = false;
      st.travelManual = false;
      save(); refresh(); say('Đã lưu bãi farm' + (k > 1 ? ' khu ' + k : ''));
    });
    $('clrFarm').addEventListener('click', function () {
      cfg.farm = null; cfg.stayFarm = false; st.stayFarmPaused = false; st.travelManual = false; save(); syncInputs(); refresh(); say('Đã xoá bãi farm');
    });

    var dest = $('dest');
    dest.addEventListener('focus', function () { fillMaps(dest); });
    $('go').addEventListener('click', function () {
      if (!dest.value) return say('Chọn map trước');
      if (!enabled) setEnabled(true);
      st.back = null;
      st.travelManual = true;
      startTravel(dest.value, null, null, 'Đi bộ tới ' + mapName(dest.value));
    });
    $('stop').addEventListener('click', function () { stopTravel('Đã dừng đi đường'); });

    $('optReset').addEventListener('click', function () { stats = newStats(); refresh(); say('Đã đặt lại thống kê'); });
    $('kiteClr').addEventListener('click', function () { kiteLog.length = 0; refresh(); });
    $('kiteCopy').addEventListener('click', function () {
      copyText(kiteReport(), function (ok) {
        var b = $('kiteCopy');
        b.textContent = ok ? '✓ Đã copy' : '✗ Không copy được';
        setTimeout(function () { b.textContent = '📋 Copy log'; }, 1500);
      });
    });

    $('devSpeed').addEventListener('click', function (e) {
      var b = e.target.closest('button');
      if (b) { devSpeed(+b.dataset.v); refresh(); }
    });

    var drag = null;
    $('head').addEventListener('pointerdown', function (e) {
      if (e.target.closest('button')) return;
      var r = host.getBoundingClientRect();
      drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
      $('head').setPointerCapture(e.pointerId);
    });
    $('head').addEventListener('pointermove', function (e) {
      if (!drag) return;
      cfg.ui.x = e.clientX - drag.dx;
      cfg.ui.y = e.clientY - drag.dy;
      place();
    });
    $('head').addEventListener('pointerup', function () { if (drag) { drag = null; save(); } });
    window.addEventListener('resize', place);

    ui.mini.addEventListener('click', function () { setHidden(false); });
    // F8 (hoặc `) ẩn/hiện bảng. Nghe ở pha capture để game không nuốt mất phím.
    window.addEventListener('keydown', function (e) {
      if (e.repeat || (e.code !== 'F8' && e.code !== 'Backquote')) return;
      var t = e.target && e.target.tagName;
      if (e.code === 'Backquote' && (t === 'INPUT' || t === 'TEXTAREA' || (e.target && e.target.isContentEditable))) return;
      if (e.code === 'F8') e.preventDefault();
      setHidden(!cfg.ui.hidden);
    }, true);

    try { syncInputs(); } catch (e) { console.error('[TTBot] syncInputs', e); }
    try { place(); } catch (e) { console.error('[TTBot] place', e); }
    safeRefresh();
    setInterval(safeRefresh, 400);
  }
  var refreshErrAt = 0;
  function safeRefresh() {
    try { refresh(); }
    catch (e) { if (now() - refreshErrAt > 10000) { refreshErrAt = now(); console.error('[TTBot] Lỗi hiển thị (bảng vẫn chạy)', e); } }
  }

  // Bật / tắt một cài đặt (từ công tắc trong tab hoặc công tắc nhanh) kèm việc đi theo nó.
  function setOpt(k, on) {
    cfg[k] = !!on; userSet(k); save();
    if (k === 'alwaysRun' && !on && window.PNTT) window.PNTT.Input.setRun(false);
    if (k === 'stayFarm' && on && !cfg.farm) say('Nhớ lưu bãi farm trước (tab 🧭 Di chuyển)');
    if (k === 'planRun') { planStop(game()); if (on && !enabled) setEnabled(true); if (on) say('Lịch treo máy: bắt đầu'); }
    if ((k === 'vtRun' || k === 'snRun' || k === 'llRun' || k === 'htRun' || k === 'xcHunt' || k === 'tlRun' || k === 'ltRun' || k === 'vnRun' || k === 'hxRun' || k === 'ylRun') && on && !enabled) setEnabled(true);
    if (k === 'hxRun') { st.hxRest = 0; st.hxWhy = ''; if (!on) st.hx = null; }
    if (k === 'ylRun') { st.ylRest = 0; st.ylWhy = ''; if (!on) st.yl = null; }
    if (k === 'htRun' && on) st.htSkip = null;
    if (k === 'snRun') { st.snRest = 0; if (!on) { snEndSub(game()); st.sn = null; } }
    if (k === 'gatherRun') { st.ga = null; if (on && !enabled) setEnabled(true); if (!on && st.travel) stopTravel(); }
    if (k === 'fishRun') { if (on && !enabled) setEnabled(true); if (!on && st.fish) fishStop(game()); }
    if (k === 'dcRun') {
      st.dc = null; if (st.back && st.back.kind === 'dc') st.back = null;
      if (on) {
        var g0 = game();
        cfg.dcReturn = g0 ? { map: g0.mapId, x: g0.me.x, y: g0.me.y, khu: gaKhu(g0.P) } : null;
        save();
        if (cfg.dcReturn) say('Dược Công: làm xong sẽ về ' + mapName(cfg.dcReturn.map) + ' farm tiếp');
        if (!enabled) setEnabled(true);
      } else if (st.travel) stopTravel();
    }
    if (ui.root) { syncInputs(); refresh(); }
  }

  function setHidden(h) {
    cfg.ui.hidden = h; save();
    applyHidden();
    if (h) console.log('[TTBot] Đã thu nhỏ bảng — bấm nút ☯ hoặc phím F8 để mở lại');
  }

  function applyHidden() {
    ui.host.style.display = '';
    ui.panel.style.display = cfg.ui.hidden ? 'none' : '';
    ui.mini.style.display = cfg.ui.hidden ? 'block' : 'none';
    ui.mini.classList.toggle('on', enabled);
  }

  function place() {
    var h = ui.host;
    if (!h) return;
    if (cfg.ui.x == null) { h.style.left = ''; h.style.right = '8px'; h.style.top = '8px'; return; }
    var w = h.offsetWidth || 268, hh = h.offsetHeight || 60;
    var x = Math.max(0, Math.min(window.innerWidth - w, cfg.ui.x));
    var y = Math.max(0, Math.min(window.innerHeight - Math.min(hh, 40), cfg.ui.y));
    h.style.right = ''; h.style.left = x + 'px'; h.style.top = y + 'px';
  }

  function fillMaps(sel) {
    if (sel.options.length > 1 || !window.PNTT) return;
    var graph = mapGraph(window.PNTT);
    Object.keys(graph).map(function (id) { return graph[id]; })
      .sort(function (a, b) { return a.name.localeCompare(b.name, 'vi'); })
      .forEach(function (m) {
        var o = document.createElement('option');
        o.value = m.id; o.textContent = m.name;
        sel.appendChild(o);
      });
  }

  function syncInputs() {
    if (!ui.root) return;
    ui.root.querySelectorAll('[data-key]').forEach(function (el) { el.checked = !!cfg[el.dataset.key]; });
    ui.root.querySelectorAll('[data-num]').forEach(function (el) { el.value = cfg[el.dataset.num]; });
    ui.root.querySelectorAll('[data-text]').forEach(function (el) { el.value = cfg[el.dataset.text] || ''; });
  }

  function refresh() {
    if (!ui.root) return;
    var R = ui.root, g = game();
    if (ui.fpsChip) { var fv = fpsTracker.fps || 0; ui.fpsChip.textContent = fv ? fv + ' FPS' : '-- FPS'; ui.fpsChip.className = 'chip ' + (!fv ? '' : fv >= 50 ? 'go' : fv >= 28 ? 'warn' : 'bad'); }
    if (ui.netChip) {
      var nc = netState.receivedCount || 0;
      var isConn = !!(window.PNTT && window.PNTT.Gateway && window.PNTT.Gateway.connected);
      ui.netChip.textContent = '📡 ' + (nc ? (nc > 999 ? (nc / 1000).toFixed(1) + 'k' : nc) + ' gói' : '0 gói');
      ui.netChip.className = 'chip ' + (isConn ? 'go' : nc > 0 ? 'warn' : 'bad');
      ui.netChip.title = 'Máy chủ: ' + (isConn ? 'Đã kết nối' : 'Chưa nối') + ' · Đã nhận ' + nc + ' gói, gửi ' + (netState.sentCount || 0) + ' gói';
    }

    applyHidden();
    ui.panel.classList.toggle('min', !!cfg.ui.collapsed);
    R.getElementById('min').textContent = cfg.ui.collapsed ? '▸' : '▾';
    var isLao = st.jailedPanic || (g && isJailed(g));
    ui.dot.classList.toggle('on', enabled && !isLao);
    ui.dot.classList.toggle('bad', !!isLao);
    ui.power.classList.toggle('on', enabled);
    ui.power.textContent = isLao ? '🚨 BỊ PHẠT TÙ' : (enabled ? '■ ĐANG CHẠY' : '▶ BẬT');
    ui.power.title = isLao ? 'Tài khoản đang bị phạt tù Thiên Lao (Bát Quái Thạch Bàn)' : (enabled ? 'Bấm để tắt trợ thủ' : 'Bấm để bật trợ thủ');

    // Tìm cài đặt: hiện mọi nhóm (ở mọi tab) có chữ khớp; không tìm thì chỉ hiện tab đang chọn.
    var q = plainVi(uiQuery).trim(), hits = 0;
    var gi = navGroupOf(cfg.ui.tab);
    cfg.ui.lastTab = cfg.ui.lastTab || {}; cfg.ui.lastTab[gi] = cfg.ui.tab;
    R.querySelectorAll('.nav button[data-grp]').forEach(function (b) { b.classList.toggle('on', !q && +b.dataset.grp === gi); });
    var stb = R.getElementById('subtabs');
    if (stb) {
      if (stb.dataset.g !== String(gi)) { stb.dataset.g = String(gi); stb.innerHTML = NAV[gi][1].map(function (t) { return '<button data-tab="' + t[0] + '">' + t[1] + ' ' + t[2] + '</button>'; }).join(''); }
      stb.style.display = q ? 'none' : '';
      stb.querySelectorAll('button').forEach(function (b) { b.classList.toggle('on', b.dataset.tab === cfg.ui.tab); });
    }
    R.querySelectorAll('section').forEach(function (s) {
      if (!q) {
        var onS = s.dataset.pane === cfg.ui.tab;
        s.classList.toggle('on', onS);
        var gps = Array.prototype.filter.call(s.children, function (x) { return x.classList && x.classList.contains('grp'); });
        // Trang có từ 3 nhóm: hàng chip nhóm, mỗi lúc hiện một nhóm (hoặc "Tất cả") cho khỏi phải cuộn.
        if (gps.length >= 3) {
          var bar = s.querySelector(':scope > .grptabs');
          if (!bar) {
            bar = document.createElement('div'); bar.className = 'grptabs';
            bar.innerHTML = gps.map(function (gp, i) { var h = gp.querySelector('.gh'); return '<button data-g="' + i + '" title="' + esc(h ? h.textContent : '') + '">' + esc(h ? h.textContent.replace(/\s*\(.*\)\s*$/, '') : 'Nhóm ' + (i + 1)) + '</button>'; }).join('') + '<button data-g="all">Tất cả</button>';
            s.insertBefore(bar, s.firstChild);
          }
          bar.style.display = '';
          var sel = (cfg.ui.grp && cfg.ui.grp[s.dataset.pane]) || '0';
          if (sel !== 'all' && !(+sel < gps.length)) sel = '0';
          bar.querySelectorAll('button').forEach(function (b) { b.classList.toggle('on', b.dataset.g === sel); });
          gps.forEach(function (gp, i) { gp.style.display = sel === 'all' || String(i) === sel ? '' : 'none'; });
        } else gps.forEach(function (gp) { gp.style.display = ''; });
        return;
      }
      var bar2 = s.querySelector(':scope > .grptabs'); if (bar2) bar2.style.display = 'none';
      var any = false;
      s.querySelectorAll('.grp').forEach(function (gp) { var ok = plainVi(gp.textContent).indexOf(q) >= 0; gp.style.display = ok ? '' : 'none'; if (ok) any = true; });
      s.classList.toggle('on', any);
      if (any) hits++;
    });
    R.getElementById('nores').classList.toggle('on', !!q && !hits);
    R.querySelectorAll('[data-seg]').forEach(function (box) {
      var v = cfg[box.dataset.seg] || '';
      box.querySelectorAll('button').forEach(function (b) { b.classList.toggle('on', b.dataset.v === v); });
    });

    if (g) {
      var me = g.me, pct = me.hpMax ? Math.max(0, Math.min(100, me.hp / me.hpMax * 100)) : 0;
      ui.hpbar.style.width = pct + '%';
      ui.hptext.textContent = Math.round(me.hp) + ' / ' + Math.round(me.hpMax) + '  (' + pct.toFixed(0) + '%)';
      ui.mapname.textContent = '📍 ' + mapName(g.mapId);
      ui.mpbar.style.width = (me.mpMax ? Math.max(0, Math.min(100, me.mp / me.mpMax * 100)) : 0) + '%';
    }
    ui.doing.textContent = doingText(g);
    R.querySelectorAll('[data-quick]').forEach(function (b) { b.classList.toggle('on', !!cfg[b.dataset.quick]); });
    var s = ['Đang tắt', ''];
    if (isLao) {
      s = ['🚨 THIÊN LAO', 'bad'];
    } else if (enabled) {
      if (!g) s = ['Chờ vào game', 'warn'];
      else if (g.me.downed) s = ['Trọng thương', 'bad'];
      else if (st.dodging) s = ['Đang né chiêu', 'warn'];
      else if (st.kiting) s = ['Lùi né đòn', 'warn'];
      else if (st.ll) s = ['Lãm Làng', 'warn'];
      else if (st.ht) s = ['Sỹ Sách Điện', 'warn'];
      else if (st.vn) s = ['Vết Nứt', 'warn'];
      else if (st.bh) s = ['Săn boss', 'warn'];
      else if (st.bd) s = ['Săn biến dị', 'warn'];
      else if (st.xc) s = ['Xổng chuồng', 'warn'];
      else if (st.tl) s = ['Tam Lộ', 'warn'];
      else if (st.td) s = ['Thương Đội', 'warn'];
      else if (st.vt || vtActive(g)) s = ['Vận Tiêu', 'go'];
      else if (st.sn) s = ['Tông môn', 'go'];
      else if (st.dd || st.gc) s = ['Việc ngày', 'go'];
      else if (st.dc) s = ['Dược Công', 'go'];
      else if (st.ga) s = ['Nhặt nguyên liệu', 'go'];
      else if (st.fish) s = ['Câu cá', 'go'];
      else if (st.fa) s = ['Chăm vườn', 'go'];
      else if (st.hon || st.honBuy) s = ['Săn hồn', 'go'];
      else if (st.fk) s = ['Đổi khu', 'go'];
      else if (st.looting) s = ['Đi nhặt đồ', 'go'];
      else if (st.healing) s = st.healMoving ? ['Ra chỗ thiền', 'warn'] : ['Đang thiền', 'warn'];
      else if (st.travel) s = ['→ ' + mapName(st.travel.map), 'go'];
      else if (g.sw.autoOn) s = ['Đang tự chiến', 'go'];
      else s = ['Chờ', ''];
    }
    ui.state.textContent = s[0];
    ui.state.className = 'chip ' + s[1];

    var f = cfg.farm;
    ui.farmInfo.textContent = f ? '🌿 ' + f.name + (f.khu ? ' (Khu ' + f.khu + ')' : '') + '  ·  (' + Math.round(f.x) + ', ' + Math.round(f.y) + ')' : 'Chưa lưu — đứng ở bãi rồi bấm "Lưu"';

    ui.devNote.className = 'note ok';
    ui.devNote.textContent = dev.mult > 1 ? 'Đang x' + dev.mult + ': máy chủ có thể kéo lại; nhặt đồ / nói chuyện NPC sẽ chậm hơn.' :
      'Trên x1 dễ bị máy chủ kéo lại. Làm Dược Công / nhặt đồ nên để x1.';

    if (!cfg.ui.collapsed) {
      var on = function (t) { return q ? true : cfg.ui.tab === t; };
      if (on('home')) refreshHome(g);
      if (on('plan')) refreshPlan(g);
      if (on('stats')) refreshOpt(g);
      if (on('boss')) { refreshBossHunt(g); refreshRadar(g); }
      if (on('event')) { refreshThuongDoi(g); refreshBienDi(g); refreshXc(g); refreshTdn(); }
      if (on('clan')) { refreshEvents(g); refreshTamLo(g); refreshLinhThu(g); }
      if (on('vetnut')) refreshVetNut(g);
      if (on('bicanh')) refreshBiCanh(g);
      if (on('team')) refreshTeam(g);
      if (on('cuop')) refreshCuopTieu(g);
      if (on('bitich')) refreshBiTich(g);
      if (on('hon')) refreshHon(g);
      if (on('job')) { refreshDc(g); refreshFarmCare(g); refreshDaily(g); refreshSect(g); refreshVanTieu(g); refreshFish(g); }
      if (on('loot')) { refreshGather(g); refreshLootStats(); }
      if (on('move')) refreshKhu(g);
      if (on('fight')) refreshSplash(g);
      if (on('dodge')) ui.kiteNow.textContent = enabled ? kiteNow || '—' : 'Trợ thủ đang tắt';
      if (on('log')) refreshKiteLog();
    }

    R.querySelectorAll('#devSpeed button').forEach(function (b) {
      b.disabled = false;
      b.classList.toggle('on', +b.dataset.v === dev.mult);
    });
  }

  // Số đang có từng loại nguyên liệu, map / khu / bước đang làm.
  function lootReport() {
    var mins = Math.max(1, Math.round((Date.now() - lootStats.since) / 60000));
    var lines = ['[Trợ thủ v' + VERSION + '] thống kê nhặt · ' + mins + ' phút · ' + lootStats.total + ' món · ' + lootStats.stones + ' Linh Thạch'];
    Object.keys(lootStats.items).sort(function (a, b) { return lootStats.items[b] - lootStats.items[a]; })
      .forEach(function (k) { lines.push('  ' + k + ': ' + lootStats.items[k]); });
    return lines.join('\n');
  }
  function refreshLootStats() {
    var mins = Math.max(1 / 60, (Date.now() - lootStats.since) / 60000), top = Object.keys(lootStats.items)
      .sort(function (a, b) { return lootStats.items[b] - lootStats.items[a]; }).slice(0, 8);
    var html = esc(lootStats.total + ' món · ' + num(lootStats.stones) + ' Linh Thạch · ' + (lootStats.total / mins * 60).toFixed(0) + ' món/giờ');
    if (top.length) html += '<br>' + top.map(function (k) { return esc(k + ' ×' + lootStats.items[k]); }).join(' · ');
    if (lootStats.history.length) html += '<br><span style="color:#7f936e">Mới nhất: ' + lootStats.history.slice(0, 4).map(function (h) {
      return esc('+' + h.qty + ' ' + h.name);
    }).join(', ') + '</span>';
    ui.lootStatsBox.innerHTML = lootStats.total || lootStats.stones ? html : 'Chưa nhặt được gì từ lúc bật';
  }
  function refreshBossHunt(g) {
    var res = st.bossList, el = res ? (now() - st.bossListAt) / 1000 : 0;
    ui.root.querySelectorAll('[data-bhinfo]').forEach(function (span) {
      var b = BOSS_TABLE.filter(function (x) { return x.type === span.dataset.bhinfo; })[0], txt = '—';
      if (!g) txt = 'Chưa vào game';
      else if (st.bh && st.bh.b === b) txt = '→ đang đi đánh (' + st.bh.phase + ')';
      else if (!res) txt = cfg.bossRadar || cfg.bossHunt ? 'đang hỏi lịch…' : 'bật "Hỏi lịch boss" để xem giờ';
      else if (b.type === 'song_duc_ma_bao') txt = res.maBao ? (res.maBao.dangSong ? 'đang xuất hiện' : res.maBao.daHa ? 'hôm nay đã bị hạ' : 'ngẫu nhiên 11h–21h') : '—';
      else {
        var row = (res.boss || []).filter(function (x) { return x.id === b.spawn; })[0];
        txt = row ? (!row.dead ? 'đang xuất hiện' : row.con > 0 ? 'ra sau ' + fmtSec(Math.max(0, row.con - el)) : 'sắp xuất hiện') : '—';
      }
      if (bhSkip[b.type] > now() && !(st.bh && st.bh.b === b)) txt += ' · tạm bỏ qua ' + Math.ceil((bhSkip[b.type] - now()) / 60000) + ' phút';
      var rs = radarSeen[b.type], ch = bossHint(b.type);
      if (rs) txt += ' · radar thấy ở khu ' + rs.khu + ' ' + fmtSec((now() - rs.at) / 1000) + ' trước';
      if (ch) txt += ' · chat báo ' + (ch.dead ? 'bị hạ ở' : 'ở') + ' khu ' + ch.khu + ' ' + fmtSec((now() - ch.at) / 1000) + ' trước';
      span.textContent = txt + ' · ' + mapName(b.map);
    });
  }

  function refreshPlan(g) {
    var p = st.plan, P = g && g.P;
    ui.planNow.innerHTML = esc(!cfg.planRun ? 'Lịch đang tắt · bật lên để treo máy theo lịch' : !enabled ? 'Trợ thủ đang tắt' : !g ? 'Chờ vào game' :
      p && p.job ? '▶ Đang làm: ' + planJob(p.job).ten + ' · ' + fmtSec((now() - p.at) / 1000) :
        p && p.home ? '✓ Xong việc → đang farm · xem lại lịch sau ~' + Math.max(0, Math.round((p.checkAt - now()) / 1000)) + 's' : 'Đang chọn việc kế tiếp');
    ui.root.querySelectorAll('[data-planinfo]').forEach(function (el) {
      var J = planJob(el.dataset.planinfo), txt = '—';
      if (P) { try { txt = J.info(P); } catch (e) { txt = '—'; } }
      if (p && p.job === J.id) txt = '▶ đang làm · ' + txt;
      else if (p && p.rest[J.id] > now()) txt += ' · nghỉ ' + fmtSec((p.rest[J.id] - now()) / 1000);
      el.textContent = txt;
    });
    var b = p && p.back || cfg.farm;
    ui.planHome.textContent = b ? mapName(b.map) + ' (' + Math.round(b.x) + ', ' + Math.round(b.y) + ')' + (cfg.farm ? '' : ' · chỗ đứng lúc bật lịch (chưa lưu bãi farm)') : 'Chưa lưu · không lưu thì dùng chỗ đứng lúc bật lịch';
    ui.planInt.innerHTML = [['bossHunt', '👑 Boss thế giới theo giờ'], ['bdHunt', '🦎 Quái biến dị (Thiên Đạo báo)'], ['xcHunt', '🐂 Yêu thú xổng chuồng (Thiên Đạo báo map + khu)'], ['ltRun', '🌳 Tranh Đoạt Linh Thụ (tối T3, T7)'], ['tlRun', '⚔ Tam Lộ Tranh Phong (tối Thứ Tư)'], ['tdHunt', '🐎 Thương Đội → Oán Hồn (Thiên Đạo báo)'], ['llRun', '🏯 Bí Cảnh Lãm Làng (tông mở)'], ['htRun', '📚 Sỹ Sách Điện (tối Thứ Năm)']]
      .map(function (x) { return esc((cfg[x[0]] ? '✓ ' : '✗ ') + x[1]); }).join('<br>') + '<br><span style="color:#7f936e">Bật / tắt ở tab 👑 Boss · ☁ Thiên Đạo · 🏯 Hoạt động</span>';
  }
  function refreshDaily(g) {
    var P = g && g.P, G = P && P.Gacha;
    if (!P) { ui.dailyInfo.textContent = 'Chưa vào game'; return; }
    var lines = [];
    lines.push(ddText(P), '⚔ ' + dhText(g));
    var pools = gcPools(P);
    lines.push(!G ? 'Game chưa có Tàng Kinh' : !(P.Quest && P.Quest.flags && P.Quest.flags.bi_tich_hoan_thanh) ? 'Tàng Kinh chưa mở (làm tới nhiệm vụ Bí Tịch)' :
      pools.length ? '• Còn lượt rút miễn phí: ' + pools.map(function (id) { return G.POOLS[id].label || id; }).join(', ') : '✓ Hết lượt rút miễn phí hôm nay');
    if (st.dd || st.gc) lines.push('→ ' + doingText(g).replace(/^\S+ /, ''));
    ui.dailyInfo.innerHTML = lines.map(esc).join('<br>');
  }
  function refreshSect(g) {
    var P = g && g.P;
    if (!P) { ui.snInfo.textContent = 'Chưa vào game'; return; }
    if (!P.Sect) { ui.snInfo.textContent = 'Game chưa có nhiệm vụ tông môn'; return; }
    var nv = snNv(P), picked = SN_LIST.filter(function (x) { return cfg['sn_' + x[0]]; }).length, lines = [];
    if (!nv) { snFetch(P); lines.push('Đang xem sổ việc của Quản Sự…'); }
    else if (!nv.coTong) lines.push('Chưa vào tông môn nào — chưa nhận việc được');
    else {
      lines.push('Hôm nay ' + (nv.soXong | 0) + '/' + (nv.toiDa | 0) + ' việc' + (picked !== 3 ? ' · đang chọn ' + picked + ' việc (nên chọn 3)' : ''));
      var s = snDang(P, nv);
      if (s) lines.push('Đang làm: ' + s.def.ten + ' ' + s.co + '/' + s.can + (s.du ? ' — đủ, về nộp' : ''));
      var picks = snPicks(P, nv);
      if (!s && !snDoneToday(nv)) lines.push(picks.length ? 'Kế tiếp: ' + picks.slice(0, 3).map(function (id) { return snDefs(P)[id].ten; }).join(' → ') : 'Không còn việc nào được chọn làm được hôm nay');
    }
    if (st.sn) lines.push('→ ' + (st.sn.step || ''));
    ui.snInfo.innerHTML = lines.map(esc).join('<br>');
  }
  function refreshVanTieu(g) {
    var P = g && g.P, V = P && P.VanTieu;
    if (!V || !V.conLuotVan) { ui.vtInfo.textContent = P ? 'Game chưa có Vận Tiêu' : 'Chưa vào game'; return; }
    var ch = vtChuyen(P), lines = [];
    if (ch) {
      var cart = vtCart(g);
      lines.push('Đang áp ' + (V.tenHang ? V.tenHang(ch.hang) : 'xe') + (cart ? ' · xe cách ' + Math.round(cart.d) + 'px' : ' · chưa thấy xe') + (ch.dung ? ' · XE TỤT LẠI' : ''));
    } else {
      var why = vtWhyNot(P);
      lines.push(why ? 'Chưa áp tiêu được: ' + why : 'Còn ' + vtLeft(P) + '/' + V.LUOT_VAN + ' chuyến hôm nay · phí ' + V.PHI + ' Linh Thạch');
    }
    lines.push('Tuyến: ' + V.TUYEN.map(mapName).join(' → '));
    if (st.vt) lines.push('→ ' + (st.vt.step || ''));
    ui.vtInfo.innerHTML = lines.map(esc).join('<br>');
  }
  function refreshThuongDoi(g) {
    var P = g && g.P;
    if (!P) { ui.tdInfo.textContent = 'Chưa vào game'; return; }
    var lines = [], pend = tdEvents.filter(function (e) { return !e.done && now() - e.at < TD_EVENT_MS; });
    if (st.td) lines.push('→ ' + (st.td.step || ''));
    pend.forEach(function (e) { lines.push('Thương Đội qua ' + mapName(e.map) + (e.khu ? ' khu ' + e.khu : '') + ' · báo ' + fmtSec((now() - e.at) / 1000) + ' trước'); });
    if (P.LuyenQuy) lines.push(tdWant(P) ? 'Hồn Phiên đang cần Oán Hồn → có tin là đi săn' : 'Hồn Phiên chưa cần Oán Hồn (hoặc sắp chạm mốc nghiệp) → không đi');
    if (!pend.length && !st.td) lines.push('Chưa có tin Thương Đội (Thiên Đạo báo trên kênh Thế Giới)');
    ui.tdInfo.innerHTML = lines.map(esc).join('<br>');
  }

  function refreshTdn() {
    var lines = [], hh = function (ts) { var d = new Date(ts); return ('0' + d.getDate()).slice(-2) + '/' + ('0' + (d.getMonth() + 1)).slice(-2) + ' ' + ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2); };
    lines.push('Đã lưu ' + tdNews.length + ' tin' + (tdNews.length ? ' (từ ' + hh(tdNews[0].ts) + ')' : ''));
    ['td', 'bd', 'xc', 'boss'].forEach(function (k) {
      var s0 = tdnStats(k);
      if (!s0.n) return;
      var mp = Object.keys(s0.maps).sort(function (a, b) { return s0.maps[b].n - s0.maps[a].n; }).slice(0, 3).map(function (id) {
        var x = s0.maps[id], kh = Object.keys(x.khu).sort(function (a, b) { return x.khu[b] - x.khu[a]; }).slice(0, 3).map(function (q) { return 'k' + q + '×' + x.khu[q]; });
        return mapName(id) + ' ' + x.n + (kh.length ? ' (' + kh.join(' ') + ')' : '');
      });
      var hr = Object.keys(s0.hours).sort(function (a, b) { return s0.hours[b] - s0.hours[a]; }).slice(0, 3).map(function (h) { return h + 'h'; });
      lines.push('▸ ' + TDN_KIND[k] + ': ' + s0.n + ' lần' + (mp.length ? ' · ' + mp.join(', ') : '') + (hr.length ? ' · giờ hay ra ' + hr.join(', ') : ''));
    });
    tdNews.slice(-8).reverse().forEach(function (r) { lines.push(hh(r.ts) + ' · ' + r.text); });
    ui.tdnInfo.innerHTML = lines.map(esc).join('<br>');
  }
  function refreshEvents(g) {
    var P = g && g.P;
    if (!P) { ui.llInfo.textContent = ui.htInfo.textContent = 'Chưa vào game'; return; }
    var LL = P.LamLang, LU = P.LamLangUI, l = [];
    if (!LL || !LU) l.push('Game chưa có Lãm Làng');
    else {
      var n = LU.ngoai, S = LU.st;
      if (S && g.mapId === LL.MAP) {
        l.push((LL.TEN_GD[S.gd] || S.gd) + ' · Tông Mệnh ' + Math.round(S.menh || 0) + '%' + (S.the && LL.THE[S.the] ? ' · ' + LL.THE[S.the].ten : ''));
        l.push('Cổng Đông: ' + (S.tuyen1 ? 'xong' : (S.lao || []).filter(function (x) { return x.tt === 'cuu'; }).length + '/' + (S.lao || []).length + ' lồng') +
          ' · Đài Đá: ' + (S.tuyen2 ? 'xong' : (S.tru || []).filter(function (x) { return x.vo; }).length + '/' + (S.tru || []).length + ' trụ'));
      } else if (n) {
        l.push(n.run ? 'Tông đang mở lượt · ' + (n.run.soNguoi | 0) + '/' + LL.TOI_DA + ' người' + (n.run.conNhan ? '' : ' · đã khoá cửa') :
          n.daMoHomNay ? 'Hôm nay tông đã vào' : !n.coTong ? 'Chưa thuộc tông môn nào' : 'Hôm nay tông chưa mở lượt');
        if (n.daDuHomNay) l.push('Hôm nay bạn đã dự');
      } else l.push(cfg.llRun ? 'Đang hỏi tình hình bí cảnh…' : 'Bật lên để tự vào khi tông mở lượt');
      if (st.ll) l.push('→ ' + (st.ll.step || ''));
      if (st.llOpen) l.push('→ đi tới Quản Sự mở bí cảnh');
    }
    ui.llInfo.innerHTML = l.map(esc).join('<br>');
    var HT = P.HuThien, h = [];
    if (!HT || !HT.kyTai) h.push('Game chưa có Sỹ Sách Điện');
    else {
      var t0 = htNow(P), ky = HT.kyTai(t0), gd = HT.giaiDoan(t0, ky);
      h.push(gd === 'MO' ? 'Đang mở · nhận người tới ' + HT.gioDoc(ky.dongCuaLuc) + ' · hết giờ ' + HT.gioDoc(ky.ketThucLuc) :
        gd === 'BAO' ? 'Sắp mở lúc ' + HT.gioDoc(ky.batDauLuc) + ' (danh sách tông đã chốt)' :
          'Kỳ tới ' + ddmmVN(ky.batDauLuc) + ' lúc ' + HT.gioDoc(ky.batDauLuc));
      if (st.htSkip === ky.id) h.push('Kỳ này bỏ qua (không vào được)');
      var U = P.HuThienUI, S2 = U && U.st;
      if (S2 && HT.laMap(g.mapId)) h.push((HT.TEN_AI[g.mapId] || '') + ' · hạ sát ' + ((S2.toi || {}).haSat | 0) + ' · gục ' + ((S2.toi || {}).chet | 0));
      if (st.ht) h.push('→ ' + (st.ht.step || ''));
    }
    ui.htInfo.innerHTML = h.map(esc).join('<br>');
  }

  function refreshTamLo(g) {
    var P = g && g.P, TL = P && P.TamLo, lines = [];
    if (!P) { ui.tlInfo.textContent = 'Chưa vào game'; return; }
    if (!TL) { ui.tlInfo.textContent = 'Game chưa có Tam Lộ'; return; }
    var l = TL.lich(tlNow(P)), S = P.TamLoUI && P.TamLoUI.st, mine = S && S.lich && S.lich.id === l.id ? S : null;
    var GIAI = { CHUA_MO: 'chưa mở ghi danh', DANG_KY: 'đang nhận ghi danh', CHAP_NHAN: 'đang chấp nhận trận', MAN_CHO: 'đang vào trận', CHUAN_BI: 'đang vào trận', DANG_DAU: 'đang diễn ra' };
    lines.push('Kỳ ' + ddmmVN(l.batDauLuc) + ' ' + TL.gioDoc(l.batDauLuc) + ' · ' + (GIAI[l.giaiDoan] || l.giaiDoan) + (mine && mine.daGhi ? ' · đã ghi danh' : ''));
    if (!(P.Gateway && P.Gateway.tamLo)) lines.push('Máy chủ chưa mở kết nối Tam Lộ (game mới có giao diện) → script chờ, mở là tự chạy');
    var b = g.me.realmId && TL.bangCua ? TL.bangCua(g.me.realmId) : null;
    if (b && b.why) lines.push(b.why);
    if (st.tl) lines.push('→ ' + (st.tl.step || ''));
    ui.tlInfo.innerHTML = lines.map(esc).join('<br>');
  }
  function refreshLinhThu(g) {
    if (!ui.ltInfo) return;
    var P = g && g.P, L = P && P.LinhThu, lines = [];
    if (!P) { ui.ltInfo.textContent = 'Chưa vào game'; return; }
    if (!L) { ui.ltInfo.textContent = 'Game chưa có Linh Thụ'; return; }
    var l = L.lich(Date.now()), U = P.LinhThuUI, S = U && U.st, mine = S && S.lich && S.lich.id === l.id ? S : null;
    var GIAI = { CHUA_MO: 'chưa mở ghi danh', DANG_KY: 'đang nhận ghi danh', CHUAN_BI: 'chuẩn bị vào sân', DANG_DAU: 'đang diễn ra' };
    lines.push('Kỳ ' + ddmmVN(l.batDauLuc || l.khoiLuc) + ' ' + L.gioDoc(l.batDauLuc || l.khoiLuc) + ' · ' + (GIAI[l.giaiDoan] || l.giaiDoan) + (mine && mine.daGhi ? ' · đã ghi danh' : ''));
    if (mine && mine.tuCach) lines.push(L.viLoi ? L.viLoi(mine.tuCach) : mine.tuCach);
    if (st.lt) lines.push('→ ' + (st.lt.step || ''));
    if (U && U.ket) lines.push('Kết quả: ' + ltRes(U));
    ui.ltInfo.innerHTML = lines.map(esc).join('<br>');
  }
  function refreshXc(g) {
    var P = g && g.P, lines = [];
    if (!P) { ui.xcInfo.textContent = 'Chưa vào game'; return; }
    if (st.xc) lines.push('→ ' + (st.xc.step || ''));
    xcPending().forEach(function (e) { if (!st.xc || st.xc.ev !== e) lines.push(mapName(e.map) + ' khu ' + e.khu + ' · báo ' + fmtSec((now() - e.at) / 1000) + ' trước'); });
    if (!lines.length) lines.push('Chưa có tin yêu thú xổng chuồng (Thiên Đạo báo trên kênh Thế Giới)');
    ui.xcInfo.innerHTML = lines.map(esc).join('<br>');
  }
  function refreshBienDi(g) {
    var P = g && g.P, lines = [], pend = bdPending();
    if (!P) { ui.bdInfo.textContent = 'Chưa vào game'; return; }
    if (st.bd) lines.push('→ ' + (st.bd.step || ''));
    pend.forEach(function (e) { lines.push(bdName(P, e.type) + ' ở ' + mapName(e.map) + ' · báo ' + fmtSec((now() - e.at) / 1000) + ' trước'); });
    var here = bdVisible(g);
    if (here.length) lines.push('Đang thấy ' + here.length + ' con biến dị ngay đây');
    if (!lines.length) lines.push('Chưa có tin quái biến dị (Thiên Đạo báo trên kênh Thế Giới)');
    ui.bdInfo.innerHTML = lines.map(esc).join('<br>');
  }

  function refreshSplash(g) {
    if (!g) { ui.splashInfo.textContent = 'Chưa vào game'; return; }
    var P = g.P, reach = P.Player.reach ? P.Player.reach() : 26, w = weaponId(P), e = splashEstimate(w, reach);
    var lines = [weaponName(P) + ' · tầm đánh ' + Math.round(reach) + 'px · đã đo ' + e.sw + ' nhát (' + e.n + ' lần có con khác trong tầm, ' + e.nearN + ' ở gần)'];
    if (cfg.splashManual > 0) lines.push('Tầm lan đặt tay: ' + cfg.splashManual + 'px');
    else if (e.r === null && gameSingleTarget(g)) lines.push('Theo mã game, vũ khí này đánh MỘT mục tiêu (chỉ Trúc Kiếm đánh lan) — số đo ' + (e.hit ? 'có ' + e.hit + ' lần trúng thêm' : '0% trúng thêm') + ', nên không đi đo. Chắc nó lan thì nhập tay ô trên');
    else if (e.r === null) lines.push(reach >= SPLASH_EXPLORE_MIN_REACH ? 'Đang đo — tạm đứng nửa tầm (~' + Math.round(reach * 0.5) + 'px) để vừa đánh lan vừa đo (' + e.nearN + ' mẫu gần)' : 'Chưa đủ mẫu');
    else if (e.r === 0) lines.push('Vũ khí đánh đơn (đo ' + e.nearN + ' lần có con khác đứng gần, không trúng con nào)');
    else lines.push('Tầm lan đo được: ~' + Math.min(e.r, Math.round(reach)) + 'px');
    var L = cfg.splashLearn2 && cfg.splashLearn2[w];
    if (L) {
      var ks = Object.keys(L.b).map(Number).sort(function (a, b) { return a - b; }).filter(function (k) { return L.b[k][0] >= 2; });
      if (ks.length) lines.push('Tỉ lệ trúng con khác: ' + ks.map(function (k) { return k * SPLASH_BIN + '–' + (k + 1) * SPLASH_BIN + ':' + Math.round(L.b[k][1] / L.b[k][0] * 100) + '%'; }).join(' · '));
    }
    ui.splashInfo.innerHTML = lines.map(esc).join('<br>');
  }

  function refreshKhu(g) {
    if (!g) { ui.khuInfo.textContent = 'Chưa vào game'; return; }
    var P = g.P, n = gaSoKhu(P), L = khuList && khuList.mapId === g.mapId ? khuList : null, lines = [];
    lines.push(n > 1 ? 'Đang ở khu ' + gaKhu(P) + '/' + n + ' · ' + mapName(g.mapId) : 'Map này không chia khu');
    if (L && L.dem && n > 1) {
      var mins = Math.round((now() - khuListAt) / 60000);
      lines.push('Số người (' + (mins ? mins + ' phút trước' : 'vừa xem') + '): ' + L.dem.slice(0, n).map(function (d, i) { return (i + 1 === gaKhu(P) ? '[' + (i + 1) + ']' : i + 1) + ':' + (d | 0); }).join(' '));
    }
    if (st.fk) lines.push('→ ' + doingText(g).replace(/^🗺 /, ''));
    else if (cfg.farmKhuAuto && n > 1) {
      var left = Math.max(0, Math.round((cfg.farmKhuMin * 60000 - (now() - (st.fkCheckAt || -1e9))) / 1000));
      lines.push(left > 0 ? 'Tự xem lần tới sau ~' + fmtSec(left) : 'Tới lượt xem' + (st.fkWhy && st.fkWhy !== 'chờ tới lượt xem' ? ' · đang chờ vì: ' + st.fkWhy : ''));
    }
    else if (cfg.farmKhu && n > 1) lines.push('Chờ mở Bảng Khu (tự mở hoặc bấm nút) · chưa bật tự xem theo chu kỳ');
    else if (!cfg.farmKhu) lines.push('Chưa bật "Mở Bảng Khu thì tự sang khu ít người" · nút bên dưới vẫn dùng được');
    ui.khuInfo.innerHTML = lines.map(esc).join('<br>');
  }

  function refreshHon(g) {
    var P = g && g.P, L = P && P.LuyenQuy, s = L && honState(P);
    if (!s) { ui.honInfo.textContent = g ? 'Game chưa có hệ thống Hồn Phiên' : 'Chưa vào game'; return; }
    var lines = [];
    ui.honBuy.style.display = s.phien ? 'none' : '';
    if (!s.phien) {
      var why = L.xetThinhPhien ? L.xetThinhPhien(P) : '';
      lines.push('Chưa có Hồn Phiên — ' + (why ? 'chưa thỉnh được: ' + why : 'bấm nút dưới để đi thỉnh'));
    } else {
      var cap = (s.moc && s.moc.tenDo) || 20;
      lines.push('Âm Hồn trong phiên ' + (s.am | 0) + ' · đang gọi ' + (s.dang | 0) + ' · tối đa ' + s.tran + ' · Sát Nghiệp ' + (s.nghiep | 0) + '/' + cap + (s.nghiep >= cap ? ' (TÊN ĐỎ)' : ''));
      var need = honNext(P, s);
      if (!need) lines.push('Phiên đã đầy');
      else lines.push('Con thứ ' + ((s.am | 0) + (s.dang | 0) + 1) + ': ' + need.map(function (x) { return x.ten + ' ' + x.co + '/' + x.can + (x.co >= x.can ? ' ✓' : ''); }).join(' · '));
      var ext = need ? need.filter(function (x) { return !HON_KILL_NGHIEP[x.id] && x.co < x.can; }) : [];
      ext.forEach(function (x) {
        lines.push('Thiếu ' + x.ten + ' — ' + (x.id === 'tu_si_hon' ? 'chỉ có khi hạ người chơi Chính tu (script không tự PK)' : 'rơi từ boss thế giới (bật Săn boss thế giới)'));
      });
      if (cfg.honSell) {
        var tp = honSellTarget(s, need, 'pham_hon'), to = honSellTarget(s, need, 'oan_hon');
        lines.push('Săn thêm bán chợ: ' + (tp ? 'Phàm Hồn ' + (s.pham | 0) + '/' + tp + ((s.pham | 0) >= tp ? ' ✓' : '') : 'Phàm Hồn tắt') + ' · ' +
          (to ? 'Oán Hồn ' + (s.oan | 0) + '/' + to + ((s.oan | 0) >= to ? ' ✓' : ' (qua Thương Đội)') : 'Oán Hồn tắt') + ' (gồm cả phần cho con kế tiếp)');
      }
    }
    if (st.hon) lines.push('→ ' + (st.hon.step || ''));
    ui.honInfo.innerHTML = lines.map(esc).join('<br>');
  }

  function refreshFarmCare(g) {
    var F = g && g.P.Farm;
    if (!F || !F.count) { ui.farmCareInfo.textContent = g ? 'Game chưa có vườn' : 'Chưa vào game'; return; }
    var lines = ['Chín ' + F.count('ready') + ' · đang lớn ' + F.count('growing') + ' · trống ' + F.count('empty') + ' · khô ' + F.count('dry') +
      ' · hạt trong túi ' + (F.seedsInBag ? F.seedsInBag().length : 0) + ' loại'];
    lines.push(st.fa ? '→ ' + (st.fa.step || 'đi tới vườn') : faWork(g.P) ? faWork(g.P) + ' luống cần làm' : 'Chưa có việc');
    ui.farmCareInfo.innerHTML = lines.map(esc).join('<br>');
  }
  function refreshRadar(g) {
    if (!g) { ui.radarInfo.textContent = 'Chưa vào game'; return; }
    var lines = [], me = g.me;
    mobsAlive(g).filter(isBoss).forEach(function (m) {
      var cb = bossShare(m);
      var bossText = '👑 ' + esc(mobLabel(m)) + ' · ' + Math.round(m.hp / Math.max(1, m.hpMax) * 100) + '% · cách ' + Math.round(dist(me.x, me.y, m.x, m.y)) + 'px';
      if (cb) bossText += '<br>&nbsp;&nbsp;' + esc(bossShareText(cb));
      lines.push(bossText);
    });
    var pk = hostilePlayers(g).map(function (r) { return esc((r.name || 'Người chơi') + ' ' + Math.round(dist(me.x, me.y, r.x, r.y)) + 'px' + (r.doSat ? ' (đồ sát)' : '')); });
    if (pk.length) lines.push('⚔ Kẻ thù gần: ' + pk.join(' · '));
    var tm = bossTimers(g);
    if (tm.length) {
      tm.forEach(function (t) { lines.push('🕑 ' + esc(t)); });
    } else if (cfg.bossRadar) {
      lines.push('🕑 Đang hỏi lịch boss…');
    }
    ui.radarInfo.innerHTML = lines.length ? lines.join('<br>') : 'Không có boss / kẻ thù gần';
  }

  function refreshGather(g) {
    var inv = g && g.P.Inventory;
    ui.root.querySelectorAll('[data-gahave]').forEach(function (el) {
      el.textContent = inv && inv.count ? 'đang có ' + inv.count(el.dataset.gahave) : '—';
    });
    if (!g) { ui.gaInfo.textContent = 'Chưa vào game'; return; }
    var a = st.ga, lines = [];
    if (!cfg.gatherRun) lines.push('Đang tắt · bật lên để tự đi nhặt');
    else if (a) {
      lines.push('Map: ' + mapName(g.mapId) + ' · khu ' + gaKhu(g.P) + '/' + gaSoKhu(g.P) + ' · đã nhặt ' + a.got);
      if (a.step) lines.push('→ ' + a.step);
    }
    var vis = Object.keys(gaVisited).filter(function (k) { return now() - gaVisited[k] < GA_KHU_REVISIT_MS; }).length;
    if (vis) lines.push(vis + ' khu vừa vét, chờ mọc lại');
    ui.gaInfo.innerHTML = lines.map(esc).join('<br>') || '—';
  }

  // Lượt còn lại từng việc và việc đang làm.
  function refreshDc(g) {
    var Q = g && g.P.Quest;
    if (!Q || !Q.seedTaskRunsLeft) { ui.dcInfo.textContent = g ? 'Không đọc được sổ Dược Công' : 'Chưa vào game'; return; }
    var t = Q.seedTaskInfo(), lines = [];
    ui.root.querySelectorAll('[data-dcleft]').forEach(function (el) {
      var id = el.dataset.dcleft, n = Q.seedTaskRunsLeft(id);
      el.textContent = dcSkip[id] === dcToday() ? 'bỏ qua hôm nay (lỗi mãi)' : n > 0 ? 'còn ' + n + ' lượt hôm nay' : 'hết lượt hôm nay';
    });
    lines.unshift('Dược Công: ' + ((g.P.Progress && g.P.Progress.duocCong) || 0) + ' điểm' +
      (t ? ' · đang làm ' + (t.shortName || t.name) + (t.kind !== 'escort' && t.kind !== 'tournament' ? ' ' + Q.seedQuestProgress() + '/' + t.need : '') : ''));
    if (st.dc && st.dc.step) lines.push('→ ' + st.dc.step);
    ui.dcInfo.innerHTML = lines.map(esc).join('<br>');
  }

  function esc(v) {
    return String(v).replace(/[&<>"']/g, function (c) { return '&#' + c.charCodeAt(0) + ';'; });
  }
  function num(n) {
    n = Math.round(n || 0);
    return n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : n >= 1e4 ? (n / 1e3).toFixed(1) + 'k' : String(n);
  }

  // Mục tiêu auto vừa đánh, không có thì con gần nhất trong tầm.
  function optTargetOf(g) {
    var t = g.me.castTarget;
    if (t && !t.dead && (g.sw.enemies || []).indexOf(t) >= 0) return t;
    var best = null, bd = g.P.CONFIG.TARGET ? g.P.CONFIG.TARGET.RANGE : 400;
    mobsAlive(g).forEach(function (m) {
      var d = dist(g.me.x, g.me.y, m.x, m.y);
      if (d < bd) { bd = d; best = m; }
    });
    return best;
  }

  function refreshOpt(g) {
    var mins = Math.max(1 / 60, (now() - stats.since) / 60000);
    ui.optStats.innerHTML =
      '<b>Thời gian</b><span>' + mins.toFixed(1) + ' phút</span>' +
      '<b>Đã giết</b><span>' + stats.kills + ' (' + (stats.kills / mins * 60).toFixed(0) + '/giờ)</span>' +
      '<b>EXP</b><span>' + num(stats.exp) + ' (' + num(stats.exp / mins * 60) + '/giờ)</span>' +
      '<b>Sát thương</b><span>' + num(stats.dmg) + ' (' + num(stats.dmg / mins) + '/phút)</span>' +
      '<b>Linh lực tiêu</b><span>' + num(stats.mp) + ' (' + num(stats.mp / mins) + '/phút)</span>' +
      '<b>ST / linh lực</b><span>' + (stats.mp ? (stats.dmg / stats.mp).toFixed(1) : '—') + '</span>' +
      '<b>Giết TB</b><span>' + (stats.kills ? (stats.killSec / stats.kills).toFixed(1) + ' s/con' : '—') + '</span>';

    var t = g && optTargetOf(g);
    if (!t) {
      ui.optTarget.textContent = g ? 'Không có quái gần' : 'Chưa vào game';
      ui.optSkills.innerHTML = '';
      return;
    }
    var d = dist(g.me.x, g.me.y, t.x, t.y), c = choose(g, t, d);
    var pct = t.hpMax ? t.hp / t.hpMax * 100 : 0;
    var hitsMelee = c.melee > 0 ? Math.ceil(Math.max(0, t.hp) / c.melee) : 0;
    var ms = stats.skill[MELEE];
    ui.optTarget.innerHTML =
      '<div class="kv">' +
      '<b>Tên</b><span>' + esc(t.def && t.def.name || t.type) + (c.boss ? ' · BOSS' : '') + '</span>' +
      '<b>Máu</b><span>' + num(t.hp) + ' / ' + num(t.hpMax) + ' (' + pct.toFixed(0) + '%)</span>' +
      '<b>Đòn thường</b><span>' + num(c.melee) + '/đòn → cần ' + hitsMelee + ' đòn' +
      (ms && ms.hits ? ' · đo ' + num(ms.dmg / ms.hits) : '') + '</span>' +
      '<b>Linh lực</b><span>' + num(g.me.mp) + ' / ' + num(g.me.mpMax) + '</span>' +
      '</div>' +
      '<div class="why">→ ' + (c.best ? esc(c.best.def.short || c.best.def.name) + ': ' : '') + esc(c.why) + '</div>';

    if (!c.rows.length) {
      ui.optSkills.innerHTML = '<div class="card">Chưa bật chiêu nào trong bảng Tự Động</div>';
      return;
    }
    var html = '<table><tr><th>Chiêu</th>' +
      '<th title="Sát thương mỗi lần ra chiêu theo công thức game (+ thiêu đốt)">ST</th>' +
      '<th title="Trung bình đo được mỗi lần ra chiêu">Đo</th>' +
      '<th title="Sát thương có ích: cắt theo máu còn lại, cộng các con trúng thêm">Có ích</th>' +
      '<th>LL</th><th title="Có ích / linh lực">/LL</th><th></th></tr>';
    c.rows.forEach(function (r) {
      var s = stats.skill[r.def.id], cls = r === c.best ? 'best' : r.ok ? '' : 'off';
      html += '<tr class="' + cls + '"><td>' + esc(r.def.short || r.def.name) + (r.n > 1 ? ' ×' + r.n : '') + '</td>' +
        '<td>' + num(r.per) + (r.dot ? '+' + num(r.dot) : '') + '</td>' +
        '<td>' + (s && s.casts ? num(s.dmg / s.casts) : '—') + '</td>' +
        '<td>' + num(r.eff) + '</td>' +
        '<td>' + num(r.mp) + '</td>' +
        '<td>' + (r.eff / Math.max(1, r.mp)).toFixed(1) + '</td>' +
        '<td>' + (r === c.best ? '★' : esc(r.why)) + '</td></tr>';
    });
    ui.optSkills.innerHTML = html + '</table>';
  }

  function refreshKiteLog() {
    var f = cfg.logFilter || 'all', html = '';
    for (var i = kiteLog.length - 1; i >= 0; i--) {
      var e = kiteLog[i];
      if (f !== 'all' && e.cat !== f) continue;
      html += '<div class="' + (e.cat || '') + '"><b>' + e.at.toLocaleTimeString() + '</b> ' + esc(e.msg) + (e.n > 1 ? ' <i>×' + e.n + '</i>' : '') + '</div>';
    }
    ui.kiteLog.innerHTML = html;
  }

  // Một dòng "đang làm gì" dưới thanh máu.
  function doingText(g) {
    if (st.jailedPanic || (g && isJailed(g))) return '🚨 BỊ GIAM THIÊN LAO — Đã ngắt toàn bộ Auto để chống ban!';
    if (!enabled) return 'Trợ thủ đang tắt — bấm nút bên dưới để bật';
    if (!g) return 'Chờ vào game';
    if (g.me.downed) return '💀 Trọng thương — chờ hồi sinh';
    if (st.healing) return '🧘 ' + (st.healMoving ? 'Ra chỗ an toàn để thiền' : 'Đang thiền') + ' · máu ' + Math.round(g.me.hp / Math.max(1, g.me.hpMax) * 100) + '%';
    if (st.bh && st.bh.phase !== 'fight') return '👑 Đi đánh ' + bhName(g.P, st.bh.b) + ' · ' + (st.bh.step || { go: 'đang tới ' + mapName(st.bh.b.map), wait: 'chờ boss ra, đánh hộ vệ', loot: 'hút đồ rồi về' }[st.bh.phase] || '');
    if (st.ll) return '🏯 Lãm Làng · ' + (st.ll.step || '');
    if (st.ht) return '📚 Sỹ Sách Điện · ' + (st.ht.step || '');
    if (st.lt || ltIn(g)) return '🌳 Linh Thụ · ' + (st.lt && st.lt.step || '');
    if (st.vn) return '🌀 Vết Nứt · ' + (st.vn.step || '');
    if (st.vnBuy) return '🌀 Vết Nứt · ' + (st.vnBuy.step || 'mua vé');
    if (st.bd) return '🦎 Biến dị · ' + (st.bd.step || '');
    if (st.xc) return '🐂 Xổng chuồng · ' + (st.xc.step || '');
    if (st.tl) return '⚔ Tam Lộ · ' + (st.tl.step || '');
    if (st.td) return '🐎 Thương Đội · ' + (st.td.step || '');
    if (st.vt || vtActive(g)) return '🛒 Vận Tiêu · ' + (st.vt && st.vt.step || 'đang áp tải');
    if (st.fish) return '🎣 Câu Linh Ngư · ' + (st.fish.step || '');
    if (st.sn) return '🏯 Tông môn · ' + (st.sn.step || '');
    if (st.dd) return '📅 Điểm danh';
    if (st.gc) return '📖 Rút Tàng Kinh miễn phí';
    if (st.dc) return '📜 Dược Công · ' + (st.dc.step || 'đang tính bước tiếp');
    if (st.ga) return '⛏ Nhặt NL · ' + (st.ga.step || 'đang tính bước tiếp');
    if (st.fa) return '🌿 Chăm vườn · ' + (st.fa.step || 'đi tới vườn');
    if (st.honBuy) return '🏴 Đi thỉnh Hồn Phiên';
    if (st.hon) return '🏴 Hồn Phiên · ' + (st.hon.step || '');
    if (st.fk) return '🗺 Tìm khu ít người · ' + ({ ask: 'hỏi số người', board: 'tới Bảng Khu', decide: 'chọn khu', 'switch': 'tới Bảng Khu đổi sang khu ' + st.fk.want, wait: 'chờ sang khu ' + st.fk.want }[st.fk.step] || '');
    if (st.back && st.travel) return '🧭 ' + st.back.why;
    if (st.plan && st.travel && st.travel.plan) return '🧭 Lịch: về chỗ farm ' + mapName(st.plan.back.map);
    if (st.travel) return '🧭 Đi tới ' + mapName(st.travel.map);
    if (st.harvest) return '🌿 Thu ' + propName(st.harvest.prop);
    if (st.looting) return st.looting.sweep ? '🧲 Quét nhặt ' + st.looting.list.length + ' vật phẩm rơi' : '🎒 Nhặt ' + dropName(g, st.looting.drop);
    if (st.dodging) return '🌀 Đang né chiêu';
    var t = kiteTarget(g);
    if (t && (t.def || t.name)) {
      var nm = t.def ? mobLabel(t) : t.name || 'Người chơi';
      var cbs = isBoss(t) ? bossShare(t) : null;
      return '🎯 ' + nm + ' · ' + num(t.hp) + '/' + num(t.hpMax) + ' · cách ' + Math.round(dist(g.me.x, g.me.y, t.x, t.y)) + 'px' + (st.kiting ? ' · đang lùi' : '') +
        (cbs ? ' · ' + bossShareText(cbs) : '');
    }
    return g.sw.autoOn ? '⚔ Đang tự chiến — chưa có mục tiêu gần' : 'Chờ';
  }

  // Văn bản dán được: trạng thái hiện tại, cài đặt liên quan, log hit & run (cũ → mới).
  function kiteReport() {
    var g = game(), me = g && g.me, lines = ['[Trợ thủ v' + VERSION + '] log hit & run · ' + new Date().toLocaleString()];
    if (g) {
      lines.push('Map: ' + mapName(g.mapId) + ' · máu ' + Math.round(me.hp) + '/' + Math.round(me.hpMax) +
        ' · linh lực ' + Math.round(me.mp || 0) + '/' + Math.round(me.mpMax || 0) + (me.flying ? ' · đang bay' : '') +
        ' · Tự Động ' + (g.sw.autoOn ? 'bật' : 'tắt') + ' · trợ thủ ' + (enabled ? 'bật' : 'tắt'));
    }
    lines.push('Cài đặt: hit&run ' + (cfg.kite ? 'bật' : 'tắt') + ' · đứng ngoài tầm ' + cfg.kiteGap + 'px · đứng ngoài sau đòn ' +
      cfg.kiteOut + 'ms · né chiêu ' + (cfg.dodge ? 'bật' : 'tắt') + ' · tối ưu chiêu ' + (cfg.optimize ? 'bật' : 'tắt') +
      ' · nhặt đồ ' + (cfg.autoLoot ? 'bật' : 'tắt'));
    lines.push('Trạng thái: ' + (kiteNow || '—'));
    lines.push('Log:');
    kiteLog.forEach(function (e) { lines.push('  ' + e.at.toLocaleTimeString() + ' ' + e.msg + (e.n > 1 ? ' ×' + e.n : '')); });
    if (!kiteLog.length) lines.push('  (trống)');
    return lines.join('\n');
  }

  // Clipboard API cần trang đang được focus; không được thì dùng textarea tạm + execCommand.
  function copyText(text, done) {
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.style.cssText = 'position:fixed;left:-9999px;top:0';
      document.body.appendChild(ta);
      ta.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e) { }
      ta.remove();
      done(ok);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () { done(true); }, fallback);
    } else fallback();
  }

  // Xuất / nhập cấu hình để chép sang nhân vật khác. Không chép vị trí bảng, chỗ đứng Dược Công, số đo vũ khí.
  var CFG_SKIP = { ui: 1, dcReturn: 1, splashLearn2: 1 };
  function cfgExport(withFarm, withTg) {
    var src = prioSaved ? Object.assign({}, cfg, prioSaved) : cfg, o = {};
    Object.keys(src).forEach(function (k) { if (!CFG_SKIP[k] && (withFarm || k !== 'farm') && (withTg || k !== 'tgToken')) o[k] = src[k]; });
    return JSON.stringify({ ttbot: VERSION, cfg: o });
  }
  function cfgImport(txt) {
    var j = JSON.parse(String(txt || '').trim()), src = j && j.cfg, n = 0;
    if (!src || typeof src !== 'object') throw new Error('không phải cấu hình trợ thủ');
    Object.keys(src).forEach(function (k) {
      var v = src[k], d = k in cfg ? cfg[k] : DEFAULTS[k];
      if (CFG_SKIP[k] || !(k in DEFAULTS || /^[a-zA-Z]+_[a-zA-Z0-9_]+$/.test(k))) return;
      if (d != null && v != null && typeof d !== typeof v) return;
      cfg[k] = v; userSet(k); n++;
    });
    save(); syncInputs(); refresh();
    return n;
  }

  // Game cập nhật: tải lại trang chủ (game tự gỡ thẻ script sau khi nạp), danh sách file .js .css kèm hash / v=.
  function gameUpdCheck() {
    if (!window.fetch) return;
    window.fetch('/?ttbot=' + Date.now(), { cache: 'no-store' }).then(function (r) { return r.ok ? r.text() : ''; }).then(gameUpdCmp).catch(function () { });
  }
  function gameUpdCmp(html) {
    var cur = [], re = /(?:src|href)="([^"]+?(?:\.[0-9a-f]{8,}\.(?:js|css)|\.(?:js|css)\?v=[^"]*))"/g, m0;
    while ((m0 = re.exec(html || ''))) if (cur.indexOf(m0[1]) < 0) cur.push(m0[1]);
    cur.sort();
    if (cur.length < 20) return;
    var K = 'ttbot.gameFiles', old = null;
    try { old = JSON.parse(localStorage.getItem(K) || 'null'); localStorage.setItem(K, JSON.stringify(cur)); } catch (e) { }
    if (!old || old.join() === cur.join()) return;
    var base = function (u) { return u.replace(/\.[0-9a-f]{8,}(\.(js|css))$/, '$1').replace(/\?v=.*$/, ''); }, ob = {}, nb2 = {};
    old.forEach(function (u) { ob[base(u)] = u; }); cur.forEach(function (u) { nb2[base(u)] = u; });
    var neu = Object.keys(nb2).filter(function (k) { return !ob[k]; }), chg = Object.keys(nb2).filter(function (k) { return ob[k] && ob[k] !== nb2[k]; }), gone = Object.keys(ob).filter(function (k) { return !nb2[k]; });
    var msg = '🆕 Game vừa cập nhật mã · ' + chg.length + ' file đổi' + (neu.length ? ' · ' + neu.length + ' file mới' : '') + (gone.length ? ' · ' + gone.length + ' file bỏ' : '') + ' · trợ thủ v' + VERSION +
      (neu.length ? '\nFile mới: ' + neu.slice(0, 15).join(', ') : '') + (chg.length ? '\nĐổi: ' + chg.slice(0, 20).join(', ') + (chg.length > 20 ? '…' : '') : '') + '\n→ nhờ Claude tải mã mới về và kiểm tra trợ thủ';
    klog('[Game] ' + msg.split('\n')[0]); say('Game vừa cập nhật mã');
    if (tgReady() && cfg.tgEv_upd !== false) tgSend(msg);
  }

  // Game đòi tải lại trang (hộp lỗi "Tải lại", phiên hết hạn / F5) hoặc rớt mạng >60s thì tự tải lại trang.
  var inWorld = false, netOk = false, dcSince = 0, rlAt = 0, autoOn = false, lastNm = '';
  function netWhy() {
    var G = window.PNTT && window.PNTT.Gateway, e = String(G && G.lastError || '');
    if (document.getElementById('pntt-crash')) return 'game dừng vì lỗi';
    if (G && G.connected) netOk = true;
    if (!G || G.connected || !netOk) { dcSince = 0; return ''; }
    var t = Date.now() - (dcSince = dcSince || Date.now());
    if (/nơi khác/.test(e)) return t > 5000 ? '!' + e : '';
    if (/F5|tải lại/i.test(e) && t > 10000) return e;
    return t > 60000 ? 'mất kết nối ' + Math.round(t / 1000) + 's' : '';
  }
  function netWatch() {
    var g = game();
    if (g) { inWorld = true; lastNm = myName(g) || lastNm; }
    if (g && !autoOn && lastNm) {
      autoOn = true;
      if (onNames()[lastNm] && !enabled) { setEnabled(true); klog('[Mạng] Vào lại game → tự bật lại trợ thủ'); }
    }
    if (!inWorld || rlAt) return;
    var w = netWhy(), who = (lastNm || 'nhân vật') + ' · ';
    if (!w) return;
    if (w[0] === '!') { if (!st.kickTg) { st.kickTg = 1; klog('[Mạng] ' + w.slice(1) + ' → không tự tải lại'); if (tgReady()) tgSend('🔌 ' + who + w.slice(1) + ' → không tự tải lại (sẽ đá phiên bên kia)'); } return; }
    var L = [];
    try { L = JSON.parse(localStorage.getItem('ttbot.rl') || '[]').filter(function (x) { return Date.now() - x < 900000; }); } catch (e) { }
    if (L.length >= 3) { if (!st.rlTg) { st.rlTg = 1; if (tgReady()) tgSend('🔌 ' + who + w + ' · đã tự tải lại 3 lần trong 15 phút → dừng, cần xem tay'); } return; }
    L.push(Date.now());
    try { localStorage.setItem('ttbot.rl', JSON.stringify(L)); } catch (e) { }
    rlAt = Date.now();
    klog('[Mạng] ' + w + ' → tự tải lại trang');
    if (tgReady()) { tgSend('🔌 ' + who + w + ' → tự tải lại trang (F5)' + (onNames()[lastNm] ? ' · trợ thủ sẽ tự bật lại' : '')); tgPump(); }
    setTimeout(function () { location.reload(); }, 4000);
  }

  var waitN = 0;
  var waitPanel = setInterval(function () {
    // 40 giây có màn game mà không thấy dữ liệu game: Tampermonkey đang chạy sandbox mode không thấy window.PNTT
    if (++waitN === 80 && !window.PNTT && document.body && document.querySelector('canvas') && !document.getElementById('ttbot-error')) {
      var nb = document.createElement('div');
      nb.id = 'ttbot-error';
      nb.style.cssText = 'position:fixed;z-index:99999;top:8px;right:8px;max-width:380px;padding:8px 10px;background:#3a0f0c;color:#ffd9d0;border:1px solid #e0604a;font:12px sans-serif;border-radius:6px';
      nb.textContent = 'Trợ thủ ' + VERSION + ' không đọc được dữ liệu game. Mở Tampermonkey → Cài đặt → Chế độ cấu hình: Nâng cao → mục "Sandbox Mode" chọn "JavaScript" (hoặc "Mặc định") → Lưu → F5.';
      document.body.appendChild(nb);
    }
    if (document.body && window.PNTT) {
      clearInterval(waitPanel);
      try {
        gameUpdCheck();
        setInterval(gameUpdCheck, 1800000);
        setInterval(function () { try { netWatch(); } catch (e) { } }, 5000);
      } catch (e) { }
      try { buildPanel(); }
      catch (e) {
        console.error('[TTBot] Lỗi khi dựng bảng trợ thủ', e);
        var box = document.createElement('div');
        box.id = 'ttbot-error';
        box.style.cssText = 'position:fixed;z-index:99999;top:8px;right:8px;max-width:420px;padding:8px 10px;background:#3a0f0c;color:#ffd9d0;border:1px solid #e0604a;font:12px sans-serif;white-space:pre-wrap';
        box.textContent = 'Trợ thủ ' + VERSION + ' lỗi khi dựng bảng:\n' + String(e && e.stack || e).split('\n').slice(0, 4).join('\n');
        document.body.appendChild(box);
      }
    }
  }, 500);

  var netPublicApi = {
    state: netState,
    bus: ServerBus,
    on: ServerBus.on.bind(ServerBus),
    off: ServerBus.off.bind(ServerBus),
    onAny: ServerBus.onAny.bind(ServerBus),
    getHistory: function (op) {
      if (!op) return netState.history.slice();
      return netState.history.filter(function (h) { return h.op === op; });
    },
    getSocket: function () {
      return netState.activeSocket || (window.PNTT && window.PNTT.Gateway && window.PNTT.Gateway.socket);
    }
  };

  window.TTBot = {
    version: VERSION, VERSION: VERSION,
    cfg: cfg, st: st, save: save, game: game,
    on: function () { setEnabled(true); }, off: function () { setEnabled(false); },
    goTo: startTravel, stop: stopTravel, speed: devSpeed, kiteLog: kiteLog,
    careFarm: function () { faStart('lệnh'); }, findKhu: function () { fkStart('bấm nút'); }, lootStatsDebug: function () { return lootStats; },
    exportCfg: cfgExport, importCfg: cfgImport,
    dev: {
      eval: function (code) { return eval(code); },
      cleanCaches: cleanCaches,
      checkStaleStates: checkStaleStates,
      tickChienTruong: tickChienTruong,
      btWantMode: btWantMode,
      gradeScore: gradeScore,
      tickHuThien: tickHuThien,
      vnHomStance: vnHomStance,
      vnFight: vnFight,
      vtVnHour: vtVnHour,
      vtVnDay: vtVnDay,
      PLAN_JOBS: PLAN_JOBS,
      tickStandalone: tickStandalone,
      tickLinhThu: tickLinhThu,
      ltIn: ltIn,
      cfgExport: cfgExport,
      cfgImport: cfgImport,
      tgSend: tgSend,
      tgReady: tgReady,
      takeBack: takeBack,
      goBack: goBack,
      tickGoBack: tickGoBack
    },
    net: netPublicApi
  };
  window.__ttNet = netPublicApi;
})(typeof unsafeWindow !== 'undefined' ? unsafeWindow : window);